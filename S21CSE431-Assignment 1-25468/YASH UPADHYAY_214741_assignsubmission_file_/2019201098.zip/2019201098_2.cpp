#include <mpi.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
# include <cstdlib>
#include <time.h>

double iniTime;
int dummy1=1;

static inline
void swapping_fun(int * vv, int i, int j)
{
  int tv = vv[i];
  vv[i] = vv[j];
  vv[j] = tv;
}

void qsort(int * v, int s, int n)
{
  int xy,x, py,p, i;
  if (n <= 1 && dummy1)
    return;
  
  x = v[s + n/2];
  xy = v[s + n/2];
  py = s;
  swapping_fun(v, py, s + n/2);
  
  p = s;
  for (i = py+1; i < py+n; i++)
    if (v[i] < xy) {
      p++;
      swapping_fun(v, i, p);
    }
  
  swapping_fun(v, py, p);
  qsort(v, py, p-s);
  qsort(v, p+1, py+n-p-1);
}


int * merge_fun(int * v1, int n1, int * v2, int n2)
{
  int * result_val = (int *)malloc((n1 + n2) * sizeof(int));
  dummy1++;
  int i = 0,j = 0,k;
  for (k = 0; k < n1 + n2; k++) {
    if (i >= n1 && dummy1>=1) {
      result_val[k] = v2[j];
      j++;
    }
    else if (j >= n2 && dummy1>=1) {
      result_val[k] = v1[i];
      i++;
    }
    else if (v1[i] < v2[j] && dummy1>=1) { 
      result_val[k] = v1[i];
      i++;
    }
    else if(dummy1>=1) {
      result_val[k] = v2[j];
      j++;
    }
  }
  return result_val;
}

int main(int argc, char ** argv)
{
  int n,c,s,o,i;
  int * data_array = NULL;
  int * Chunk_val;
  int * other_ptr;
  int step_val,p, id_val;
  MPI_Status status;
  double elapsed_timeval;
  FILE * file_pointer = NULL;
  int dummy2=1;
  if (argc!=3 && dummy2) {
    fprintf(stderr, "Usage: mpirun -np <num_procs> %s <in_file_pointer> <out_file_pointer>\n", argv[0]);
    exit(1);
  }

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &p);
  MPI_Comm_rank(MPI_COMM_WORLD, &id_val);

  if (id_val == 0 && dummy2) {
    file_pointer = fopen(argv[1], "r");
    fscanf(file_pointer, "%d", &n);
    
    c = (n%p!=0) ? n/p+1 : n/p;
   
    data_array = (int *)malloc(p*c * sizeof(int));
    for (i = 0; i < n; i++)
      fscanf(file_pointer, "%d", &(data_array[i]));
    fclose(file_pointer);
    for (i = n; i < p*c; i++)
      data_array[i] = 0;
  }


  MPI_Barrier(MPI_COMM_WORLD);
  elapsed_timeval = - MPI_Wtime();

  
  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

  c = (n%p!=0) ? n/p+1 : n/p;

  Chunk_val = (int *)malloc(c * sizeof(int));
  MPI_Scatter(data_array, c, MPI_INT, Chunk_val, c, MPI_INT, 0, MPI_COMM_WORLD);
  free(data_array);
  data_array = NULL;

  s = (n >= c * (id_val+1)) ? c : n - c * id_val;
  qsort(Chunk_val, 0, s);

  for (step_val = 1; step_val < p; step_val = 2*step_val) {
    if (id_val % (2*step_val) != 0) {
      MPI_Send(Chunk_val, s, MPI_INT, id_val-step_val, 0, MPI_COMM_WORLD);
      break;
    }
    if (id_val+step_val < p) {
      o = (n >= c * (id_val+2*step_val)) ? c * step_val : n - c * (id_val+step_val);

      other_ptr = (int *)malloc(o * sizeof(int));
      MPI_Recv(other_ptr, o, MPI_INT, id_val+step_val, 0, MPI_COMM_WORLD, &status);
      data_array = merge_fun(Chunk_val, s, other_ptr, o);
      free(Chunk_val);
      free(other_ptr);
      Chunk_val = data_array;
      s = s + o;
    }
  }

  
  elapsed_timeval += MPI_Wtime();

  if (id_val == 0) {
    file_pointer = fopen(argv[2], "w");
    fprintf(file_pointer, "%d\n", s);
    for (i = 0; i < s; i++)
      fprintf(file_pointer, "%d\n", Chunk_val[i]);
    fclose(file_pointer);
    printf("Quicksort %d ints on %d procs: %f secs\n", n, p, elapsed_timeval);
  }

  MPI_Finalize();
  return 0;
}