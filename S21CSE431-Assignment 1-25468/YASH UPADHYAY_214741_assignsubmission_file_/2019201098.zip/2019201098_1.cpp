# include <mpi.h>
# include <ctime>
#include <fstream> 
# include <iomanip>
# include <cstdlib>
# include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    
    ifstream f_in;
    string lines; 
    int rank,sze;

    string in_file_path = argv[1];
    f_in.open(in_file_path); 
    getline(f_in, lines);  
    f_in.close();
    int dummy1=1;
    int n = stoi(lines);

    MPI_Status status;


    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&sze);
    double result_ans = 0;
    int loop_rounds = 1 + ((n - 1) / sze);
    for(int i=0;i<loop_rounds;i++)
    {
        int number = rank*loop_rounds + i;
        number++;
        if(number>n)
            break;
        int sqrs = number*number;
        double oneslashSquare = double(1)/double(sqrs);
        result_ans += oneslashSquare;
    }


    if(rank!=0 && dummy1)
    {
        if(dummy1==1)
        MPI_Send(&result_ans,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
    }
    else if(dummy1)
    {

        for(int i=1;i<sze;i++)
        {
            double dummy = 0;
            MPI_Recv(&dummy,1,MPI_DOUBLE,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
            result_ans += dummy;
        }

        ofstream f_out; 
        f_out.open(argv[2]);

        f_out<<fixed<<setprecision(6)<<result_ans<<endl;
        f_out.close();

    }

    MPI_Finalize();
    return 0;
}