## Q1

A range of numbers is assigned to a process and the result is calculated by summing the inverse
squares over that range. The final results are combined together using MPI\_Reduce. The final
output is written to the file.

## Q2

A range of numbers is assigned to a process which uses quicksort to sort these groups individually.
Then, the combined sets of arrays are combined together using MPI\_Send and MPI\_Recv functions, in
atmost log2(numberOfProcesses) phases using the merge function. The final array is written to the
file.

## Q3

The graph is first converted into a line graph, and then we use a vertex colouring algo.
A randomized distributed vertex colouring algorithm with asymptotic complexity of O(logN) is used
in the code. The algorithm proceeds in phases. Each vertex has a fixed pallette of colours it can  choose from. 
(The pallette of vertex u consists of d(u) + 1 colours from the set of all colours, where d(u) is the degree of vertex u)
In each phase, every vertex selects a random colour for itself from its pallette.
If none of its neighbors have choosen that colour, it accepts it and stays permanently colours.
Otherwise it abandons that colour (the neighbor abandons it as well).
In case the vertex abandons the colour, it removes all the colours from its pallette which have been taken by its neighbours permanently.
After that the phase restarts. The algorithm continues till all vertices are coloured.

It runs in atmost O(log2(N)) phases where N is the number of nodes.
