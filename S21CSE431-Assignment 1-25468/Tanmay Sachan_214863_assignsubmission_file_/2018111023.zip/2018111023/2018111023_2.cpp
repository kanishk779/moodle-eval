#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(int* arr, int low, int high) {
    int p = arr[high];
    int i = (low - 1);

    for (int j = low; j < high; j++) {
        if (arr[j] <= p) {
            i++;
            swap(arr[i], arr[j]); 
        }
    }

    swap(arr[i+1], arr[high]);

    return ++i;
} 

void quicksort(int* arr, int lo, int hi) {
    if (lo >= hi) return;

    int p = partition(arr, lo, hi);
    quicksort(arr, lo, p - 1);
    quicksort(arr, p + 1, hi);
}

int* merge(int* a, int lena, int* b, int lenb) {

    int* final_arr = (int*)malloc((lena + lenb) * sizeof(int));
    int i = 0;
    int j = 0;
    int k = 0;
    while (i < lena && j < lenb) {
        if (a[i] < b[j]) {
            final_arr[k++] = a[i++];
        } else {
            final_arr[k++] = b[j++];
        }
    }
    while (i < lena) {
        final_arr[k++] = a[i++];
    }
    while (j < lenb) {
        final_arr[k++] = b[j++];
    }
    return final_arr;
}

int main( int argc, char **argv ) {

    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    ifstream inp; ofstream out;

    if (rank == 0) {
        inp.open(argv[1], ios::in);
        out.open(argv[2], ios::out);
    }

    int n;
    if (rank == 0) {
        inp >> n;
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int bracket_size = ceil(n/(float)numprocs);

    int* arr = (int*) malloc (numprocs * bracket_size * sizeof(int));

    int ex = 0;

    // Read from a single file, dont waste speed
    if (rank == 0) {
        for (int i = 0; i < numprocs*bracket_size; i++) {
            if (i >= n) {
                ex++;
                arr[i] = INT_MIN;
            }
            inp >> arr[i];
        }
    }

    MPI_Bcast(arr, n, MPI_INT, 0, MPI_COMM_WORLD);

    int start = rank * bracket_size;
    int ends = (rank+1) * bracket_size;


    int* subarr = (int*)malloc((ends-start) * sizeof(int));

    MPI_Scatter(arr, ends - start, MPI_INT, subarr, ends-start, MPI_INT, 0, MPI_COMM_WORLD);

    free(arr);

    quicksort(subarr, 0, ends-start-1);

    // combine arrs
    int cur_size = ends - start;

    for (int step = 1; step < numprocs; step = 2*step) {
        if (rank % (2*step) != 0) {
            MPI_Send(&cur_size, 1, MPI_INT, rank - step, 0, MPI_COMM_WORLD);
            MPI_Send(subarr, cur_size, MPI_INT, rank - step, 0, MPI_COMM_WORLD);
            break;
        }

        if (rank + step < numprocs) {
            int siz;

            MPI_Status status;

            MPI_Recv(&siz, 1, MPI_INT, rank+step, 0, MPI_COMM_WORLD, &status);

            int* recd = (int*) malloc(siz * sizeof(int));

            MPI_Recv(recd, siz, MPI_INT, rank + step, 0, MPI_COMM_WORLD, &status);

            int* sub = merge(subarr, cur_size, recd, siz);

            free(subarr);
            free(recd);

            subarr = sub;
            cur_size += siz;
        }
    }

    if (rank == 0) {
        for (int i = ex; i < cur_size; i++) {
            out << subarr[i] << " ";
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
