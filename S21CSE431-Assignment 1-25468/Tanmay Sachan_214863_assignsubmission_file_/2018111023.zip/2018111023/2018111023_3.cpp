/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    random_device rd;
    mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(1, 1000);

    ifstream inp; ofstream out;

    inp.open(argv[1], ios::in);
    out.open(argv[2], ios::out);

    int n, m;
    inp >> n >> m;

    // prepare line graph, broadcast to all processes.

    int adj_mat[m][m];

    int colours[m];

    int degrees_v[n];
    int degrees_e[m];

    int agreement = 0;

    
    if (rank == 0) {
        for(int i = 0; i < max(n, m); i++){
            if (i < n) {
                degrees_v[i] = 0;
            }
            if (i < m) {
                degrees_e[i] = 0;
            }
            
            for(int j = 0; j < m; j++){
                adj_mat[i][j] = 0;
            }
        }

        typedef pair<int, pair<int, int>> point;

        vector<point> V;

        for (int edge = 0; edge < m; edge++){
            int a, b;
            inp >> a >> b;
            a--, b--;

            degrees_v[a]++;
            degrees_v[b]++;
            
            V.push_back(make_pair(edge, make_pair(a, b)));
        }

        auto overlap = [](point a, point b){
            return (
                    a.second.first == b.second.first ||
                    a.second.second == b.second.first ||
                    a.second.first == b.second.second ||
                    a.second.second == b.second.second
                   );
        };

        for (int i = 0; i < V.size(); i++) {
            for (int j = i+1; j < V.size(); j++){
                if (overlap(V[i], V[j])) {
                    adj_mat[i][j] = 1;

                    degrees_e[i]++;
                    degrees_e[j]++;
                }
            }
        }

    }

    MPI_Bcast(adj_mat, m*m, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(degrees_e, m, MPI_INT, 0, MPI_COMM_WORLD);

    for (int i = 0; i < m; i++) {
        colours[i] = 0;
    }

    // divide edges among processes
    int bracket_size = ceil(m/(float)numprocs);

    map<int, set<int>> M;

    int starts = rank * bracket_size;
    int ends = (rank + 1) * bracket_size;

    // preprocess
    for (int i = starts; i < ends && i < m; i++) {
        for (int j = 0; j < degrees_e[i] + 1; j++) {
            M[i].insert(j+1);
        }
    }

    int colours_checked[m];

    // Iterate in phases
    int local_agreement = 0;

    int max_deg = 0;
    for (int i = 0; i < m; i++) {
        max_deg = max(max_deg, degrees_e[i]);
    }

    while(true) {
        for (int i = starts; i < ends && i < m; i++) {
            // Need good randomness, otherwise seeds sync between processes
            // Use random_device for process specific seed
            if (colours[i] == 0) {
                int rng = dist(mt) % M[i].size();
                auto it = M[i].begin();
                advance(it, rng);
                colours[i] = *it;
            }
        }

        for (int i = 0; i < m; i++) colours_checked[i] = 0;

        MPI_Barrier( MPI_COMM_WORLD );

        for (int i = 0; i < m; i++) {
            MPI_Reduce(&colours[i], &colours_checked[i], 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        }
        MPI_Bcast(colours_checked, m, MPI_INT, 0, MPI_COMM_WORLD);

        bool agree = true;

        vector<pair<int, int>> colours_to_remove;
        for (int node = starts; node < ends && node < m; node++) {
            for (int i = 0; i < m; i++) {
                if ((adj_mat[node][i] || adj_mat[i][node]) && i != node) {
                    if (colours_checked[i] == colours_checked[node]) {
                        agree = false;
                        colours[node] = 0;
                        colours[i] = 0;
                    } else {
                        colours_to_remove.push_back(make_pair(node, colours_checked[i]));
                    }
                }
            }
        }

        if (agree) local_agreement = 1;

        MPI_Reduce(&local_agreement, &agreement, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Bcast(&agreement, 1, MPI_INT, 0, MPI_COMM_WORLD);

        // All nodes agree
        if (agreement == numprocs) {
            if (rank == 0) {
                int maxx = 0;
                for (int i = 0; i < m; i++) {
                    maxx = max(maxx, colours_checked[i]);
                }
                out << maxx << endl;
                for (int i = 0; i < m; i++) {
                    out << colours_checked[i] << " ";
                }
                out << endl;
            }
            break;
        }

        // Removing colours from pallette
        for (auto it: colours_to_remove) {
            if (M[it.first].find(it.second) != M[it.first].end()) {
                M[it.first].erase(M[it.first].find(it.second));
            }
        }

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
