/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define scatter_tag 10101
#define MAX_NUM LONG_MAX

struct value_index
{
    long value;
    int index;
};


int partition(vector<long> &arr,int a, int b){
    if(b<=a){
        return -1;
    }
    int i=a,j=a;
    long c,temp;
    c=arr[b];

    for(j=a;j<b;j++){
        if(arr[j]<c){
            
            temp = arr[j];
            arr[j]=arr[i];
            arr[i]=temp;
            i++;
        }
        //printArray();

    }
    temp = arr[i];
    arr[i] = c;
    arr[b]=temp; 

    return i;

}

void quickSort(vector<long> &arr,int a,int b){
    int r=partition(arr,a,b);
    //printArray();
    //printf("correct pos %d \n", r);
    if(r==-1)
        return;
    int temp;
    if(a<r-1){
        //printf("called qs(%d,%d)\n",a,r-1 );
        //scanf("%d",&temp);
        quickSort(arr,a,r-1);
    }
    if(r+1<b){

        //printf("called qs(%d,%d)\n",r+1,b );
        //scanf("%d",&temp);
        quickSort(arr,r+1,b);
    }
    return;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    vector<long> data;

    string buffer;
    ifstream inputFile(argv[1]);
    getline (inputFile, buffer);

    int size = stoi(buffer);
    int avgSize = ceil(size/((double)numprocs));

    if(rank==0)
    {
        getline (inputFile, buffer);
        stringstream ssobj(buffer); 
          
        string intermediate; 
          
        while(getline(ssobj, intermediate, ' ')) 
        { 
            data.push_back(stoi(intermediate)); 
        } 
          
        // DebugCode
        // for(int i = 0; i < data.size(); i++) 
        //     cout << data[i] << " "; 
    }

// int MPI_Scatter(void *send_data, int send_count, MPI_Datatype send_type, 
// void *receive_data, int receive_count, MPI_Datatype receive_type, 
// int sending_process_ID, MPI_Comm comm); 




    vector<int> send_counts(numprocs);
    vector<int> send_displacements(numprocs);
    int start=0;
    for(int i=0;i<numprocs;i++)
    {
        // if()
        send_displacements[i] = (start);
        if(start+avgSize>size)
        {
            send_counts[i] = size-start;
        }
        else
        {
            send_counts[i] = avgSize;
        }
        start+=avgSize;
        
        // DebugCode
        // if(rank==0)
        // cout << " | " << send_counts[i] << ", " << send_displacements[i] << " | ";
    }

    // MPI_Finalize();
    // return 0;

    int recvCount;
    vector<long> chunk(avgSize+1,MAX_NUM);

    // MPI_Scatter(data.data(),avgSize,MPI_LONG,chunk.data(),avgSize,MPI_LONG,0,MPI_COMM_WORLD);

    /*
    int MPI_Scatterv(const void* buffer_send,
                 const int counts_send[],
                 const int displacements[],
                 MPI_Datatype datatype_send,
                 void* buffer_recv,
                 int count_recv,
                 MPI_Datatype datatype_recv,
                 int root,
                 MPI_Comm communicator);

    */

    MPI_Scatterv(data.data(),
        send_counts.data(),
        send_displacements.data(),
        MPI_LONG,
        chunk.data(),
        send_counts[rank],
        MPI_LONG,
        0,
        MPI_COMM_WORLD
        );
    

    chunk[send_counts[rank]]=MAX_NUM;
    // DebugCode
    // cout << "Proc " << rank << " : ";
    // cout << send_counts[rank] << endl;
    // for(int i=0;i<chunk.size();i++)
    // {
    //     cout << chunk[i] << " ";
    // }
    // cout << endl;

    quickSort(chunk,0,chunk.size()-1);

    // for(int i=0;i<chunk.size();i++)
    // {
    //     cout << chunk[i] << " ";
    // }
    // cout << endl;

    int index=0;

    struct value_index min_value_index;
    min_value_index.value=-1000;
    struct value_index send_value_index;
    while(min_value_index.value!=MAX_NUM)
    {
        send_value_index.value = chunk[index];
        send_value_index.index = rank;

        MPI_Allreduce(&send_value_index,&min_value_index,1,MPI_LONG_INT,MPI_MINLOC,MPI_COMM_WORLD);

        if(min_value_index.index==rank)
        {
            // cout << "Incr for process " << rank << endl;
            index++;
        }
       
        if(rank==0 && min_value_index.value!=MAX_NUM)
        {
            ofstream output_file;
            output_file.open(argv[2], ios_base::app);
            // cout << "Mn " << min_value_index.value << " " << min_value_index.index << endl;
            output_file << min_value_index.value << " ";
            output_file.close();

        }
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}