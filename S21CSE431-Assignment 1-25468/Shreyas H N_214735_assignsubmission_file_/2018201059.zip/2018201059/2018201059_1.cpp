/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    MPI_Status status;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int ierr;

    if(rank==0)
    {
        // cout << argc << " ";
        // for(int i=0;i<argc;i++)
        // {
        //     cout << argv[i] << " ";
        // }
        // cout << endl;

        string n_value;

        ifstream inputFile(argv[1]);
        getline (inputFile, n_value);

        int n = stoi(n_value);

        // cout << n << endl;

        int perProcess = ceil((double)n/(numprocs-1));

        // cout << "perProcess " << perProcess << endl;

        int remainingComput = n;

        int startNum=1,endNum;
        for(int procID=1;procID<numprocs;procID++)
        {
            if(remainingComput>perProcess)
                endNum=startNum+perProcess;
            else
                endNum=startNum+remainingComput;

            ierr = MPI_Send( &startNum, 1 , MPI_INT,
                procID, 10001, MPI_COMM_WORLD);

            ierr = MPI_Send( &endNum, 1 , MPI_INT,
                procID, 10001, MPI_COMM_WORLD);

            remainingComput-=perProcess;
            startNum=endNum;
        }

        double array[numprocs];
        double buffer;

        for(int i=1;i<numprocs;i++)
        {
            ierr = MPI_Recv(&buffer, 1 , MPI_DOUBLE,
                i, 10002, MPI_COMM_WORLD,&status);
            // cout<< "received " << buffer<<endl;
            array[i]=buffer;
        }

        double result=0.0;
        for(int i=1;i<numprocs;i++)
        {
            result+=array[i];
            // cout << array[i] << " ";
        }

        // cout << "\n Result : " << result << endl;

        ofstream output_file(argv[2]);
        output_file << setprecision(7) << result << endl;
        output_file.close();

    }
    else
    {
        int startNum,endNum;
        // cout << "Process " << rank << " started"<<endl;

        ierr = MPI_Recv( &startNum, 1 , MPI_INT,
                0, 10001, MPI_COMM_WORLD,&status);

        ierr = MPI_Recv( &endNum, 1 , MPI_INT,
                0, 10001, MPI_COMM_WORLD,&status);

        // cout << "Process " << rank << " received : " << startNum << ", " << endNum <<endl;

        double interim_result=0.0;
        for(int i=startNum;i<endNum;i++)
        {
            interim_result+= 1/(i*(double)i);
        }

        // cout << "Process " << rank << " sending " << interim_result <<endl;

        ierr = MPI_Send(&interim_result, 1 , MPI_DOUBLE,
                0, 10002, MPI_COMM_WORLD);

    }
    


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}