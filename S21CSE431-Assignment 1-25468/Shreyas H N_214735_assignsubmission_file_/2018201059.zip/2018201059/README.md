## Problem 1

If there are n processes available, computation of terms will be divided equally among n-1 processes.

Root process will only assign tasks, gather data and then add up each computed solution.

For example, if there are 6 processes and given n=10.
Root is p0
P1 is responsible to compute first two terms, add them and send result to root
P2 is responsible to compute next two terms, add them and send result to root
So on.

## Problem 2

MPIScatterv() and MPIReduceall() are used effectively.
**One special feature used is MPI_MAXLOC**
This features allows us to find the min value accross all processes and also get the rank of the process from which the min value came. This is very usefull when merging the data.

The program has been tested with varying number of processes and input data aswell.

1. MPIScatterv() is used to share chunks data with the processes.
2. Each process with individually sort their chuck using quick sort function
3. MPIReduceall() function combined with MPI_MAXLOC features is used to efficently merge the values (within the distributed setup)

### Time Complexity

It is highly inefficent to try to use a "very powerfull" processer to sort data of range 10GB+. This task can be achieved much faster with hortizontal scaling, and distibuted algorithms.

MPIScatterv and MPIReduceall are internally optimised. In such a distributed setup, there is scope for ample internal optimization. Ex - A broadcast message can be delivered in a tree fashion (one process sends to two, they send to another 4, so on). In this example time complexity is reduced to around log(n).


## Problem 3

The linear approach to edge coloring primarily involved backtracking (trying out all the options). This fact can be exploited to introduce parallelism and significantly improve the time taken. Research work and evidence on this was done by Howard JKarloff by 1987.

