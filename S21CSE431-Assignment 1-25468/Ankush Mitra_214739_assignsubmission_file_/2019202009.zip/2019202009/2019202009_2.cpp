#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include<vector>
using namespace std;



int randPart(vector<int>&arr,int p,int r)
{
 	    
        int i=rand()%(r-p+1);
        i=i+p;
        int temp;
        temp=arr[r];
        arr[r]=arr[i];
        arr[i]=temp;
        int x=arr[r];
        i=p-1;
        for(int j=p;j<=r-1;j++)
        {
            if(arr[j]<=x)
            {

                i=i+1;
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
                
            }
        }
        temp=arr[i+1];
        arr[i+1]=arr[r];
        arr[r]=temp;
        return i+1;
        
  }

  void quicksort(vector<int>&A, int p, int r) {
	  if(p>=r)     return;
	else{
		int part = randPart(A, p, r);
		quicksort(A, p, part-1);
		quicksort(A, part + 1, r);
	}
}

vector<int> merge(vector<int>&A,int n,vector<int>&B,int m) {
	int i=0,j=0,k=0;
	int ts=n+m;
	std::vector<int> C;
    C.resize(ts);
	for(;i<n&&j<m;)
	{
		if(A[i]<=B[j]) C[k++]=A[i++];
		else C[k++]=B[j++];
	}
	for(;i<n;)  C[k++]=A[i++];
	for(;j<m;)  C[k++]=B[j++];
	return C;
}

int main(int argc, char *argv[]) {	
	std::ifstream inFile;
    ofstream outFile;

    std::stringstream strStream;
    //str holds the content of the file
    MPI_Status status;
    
	int num_process, rank, range;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &num_process);

	 /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    


	if(rank==0) {
		int size ,extra ,start, n;
		outFile.open(argv[2]);
		inFile.open(argv[1]); //open the input file
		strStream << inFile.rdbuf(); //read the file
		std::string str = strStream.str();
		// cout<<str<<endl;
		stringstream ss(str);
    	string temp,temp1;
		vector<int> vec;
		while(getline(ss,temp,'\n'))
		{
		
				stringstream ss1(temp);
				while(getline(ss1,temp,' '))
				{
					if(temp.size()!=0)
					vec.push_back(stoi(temp));
				}
			
		}

		size=vec[0];
        std::vector<int> arr;
		     arr.resize(size);
		for(int i=0;i<size;++i) arr[i] = vec[i+1];

		range = size/num_process;
		extra = size%num_process;
		quicksort(arr,0,range+extra-1);

		n=range+extra;
		std::vector<int> finalVec;
        finalVec.resize(n);
		for(int i=0;i<n;++i) finalVec[i]=arr[i];

		start = range+extra;
		for(int i=1;i<num_process;++i) {
			MPI_Send(&range, 1, MPI_INT, i,i,MPI_COMM_WORLD);
			MPI_Send(&arr[start], range,MPI_INT, i,i,MPI_COMM_WORLD);
			start += range;
		}
		for(int pid=1;pid<num_process;++pid) {
            std::vector<int> array2;
			array2.resize(range);
			MPI_Recv(&array2[0], range, MPI_INT, pid,pid,MPI_COMM_WORLD,&status);
			finalVec = merge(finalVec,n,array2,range);
			n += range;
		}
		for(int i=0;i<n;++i) outFile<<finalVec[i]<<" ";
		outFile.close();
		MPI_Barrier( MPI_COMM_WORLD );
		double elapsedTime = MPI_Wtime() - tbeg;
		double maxTime;
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
        printf( "Total time (s): %f\n", maxTime );

		
	} else {
		int array2 ;
        MPI_Recv(&array2,1,MPI_INT, 0,rank,MPI_COMM_WORLD,&status);
		vector<int> arr2(array2);
		MPI_Recv(&arr2[0], array2, MPI_INT, 0,rank,MPI_COMM_WORLD,&status);
		quicksort(arr2,0,array2-1);
		MPI_Send(&arr2[0], array2, MPI_INT, 0,rank,MPI_COMM_WORLD);
		MPI_Barrier( MPI_COMM_WORLD );
		double elapsedTime = MPI_Wtime() - tbeg;
		double maxTime;
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	}

	MPI_Finalize();
	return 0;
}
