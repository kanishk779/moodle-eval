#include<bits/stdc++.h>
#include <mpi.h>
#define send_tag 3001
#define recv_tag 3002

using namespace std;

int main(int argc,char *argv[])
{
int num_process,id,i, num,local_set_size,remaining,range;
int root=0;
double ls=0,gs=0, *arr,*local_recv;

int *displacement,*element_for_process;

MPI_Status status;
MPI_Init(&argc,&argv);
MPI_Comm_size(MPI_COMM_WORLD,&num_process);
MPI_Comm_rank(MPI_COMM_WORLD,&id);

MPI_Barrier( MPI_COMM_WORLD );
double tbeg = MPI_Wtime();

/* write your code here */

//make array at root process
if(id==root)
{
  std::ifstream inFile;
  ofstream outFile;
        outFile.open(argv[2]);
		inFile.open(argv[1]); //open the input file
		stringstream strStream;
        strStream << inFile.rdbuf(); //read the file
		std::string str = strStream.str();
		// cout<<str<<endl;
		stringstream ss(str);
    	string temp,temp1;
		vector<int> vec;
    while(getline(ss,temp,'\n'))
		{
		
				stringstream ss1(temp);
				while(getline(ss1,temp,' '))
				{
					if(temp.size()!=0)
					vec.push_back(stoi(temp));
				}
			
		}
    num=vec[0];
    // cout<<vec.size()<<endl;
  arr=new double[num];
  for(int i=0;i<num;i++)
  {
    int p=i+1;
    arr[i]=   (double) 1/(pow(p,2));
  }
    
}
// Broadcast num and num_Process to each process
MPI_Bcast(&num,1,MPI_INT,0,MPI_COMM_WORLD);
MPI_Bcast(&num_process,1,MPI_INT,0,MPI_COMM_WORLD);

//range size for each process
if(num<num_process)
 range=1;
else
  range= num/num_process;

//Find displeacement and element_for_process
displacement=new int[num_process];
element_for_process=new int[num_process];

// Fill up element_for_process
remaining=num;
i=0;
while(i<num_process-1)
{
  if(remaining>0)
  {
    if(range<remaining)
     element_for_process[i]=range;
    else
     element_for_process[i]=remaining;
  }
   
  else
    element_for_process[i]=0;
    
  if(range<remaining)
    remaining=remaining-range;
  else
    remaining=0;
  i++;
}

element_for_process[num_process-1]=remaining;

//Find displacement for each process
for(int i=0;i<num_process;i++) displacement[i]=0;
i=1;
while(i<num_process)
{
  displacement[i]=displacement[i-1]+element_for_process[i-1];
   i++;
}



// local computation
local_set_size=element_for_process[id];

if(local_set_size>0)
 local_recv=new double[local_set_size];

MPI_Scatterv(arr,element_for_process,displacement,MPI_DOUBLE,local_recv,local_set_size,MPI_DOUBLE,0,MPI_COMM_WORLD);

//Calculate local sum
i=0;
while(i<local_set_size)
  ls+=local_recv[i++];

//Collect all ans at root 
if(id!=root)
{
    MPI_Send(&ls,1,MPI_DOUBLE,root,recv_tag,MPI_COMM_WORLD);
    MPI_Barrier( MPI_COMM_WORLD );
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
}
else
{
    gs+=ls;
    for(i=1;i<num_process;i++)
    {
         MPI_Recv(&ls,1,MPI_DOUBLE,MPI_ANY_SOURCE,recv_tag,MPI_COMM_WORLD,&status);
         gs+=ls;
    }
    FILE* fp = fopen(argv[2],"w");
    fprintf(fp,"%.6f",gs);
    fclose(fp);
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
      printf( "Total time (s): %f\n", maxTime );
}


MPI_Finalize();

}