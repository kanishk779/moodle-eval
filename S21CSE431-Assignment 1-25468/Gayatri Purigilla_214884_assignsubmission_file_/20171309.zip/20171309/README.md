Problem 1:

The program populates an array of the size of the number of terms in the sequence and fills it with th given sequence. Next partial sum is calculated by each process which calculates the sum of a part of the array it receives. This partial sum is sent back to the root process to calculate the final sum.

