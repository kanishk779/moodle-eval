#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    
    int num;
    float prtlsum;
    
    FILE * file = NULL;
    if(rank == 0)
    {
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &num);
        fclose(file);

        int numsinprocess = num/numprocs;
        float arr[num + 10];
        for(int i = 0; i < num; i++)
            arr[i] = 1/(((float)i + 1) * ((float)i + 1));
        
        float sum = 0;
        for(int i = 1; i < numprocs; i++)
        {
            int temp = (i + 1) * numsinprocess;
            if(num < (i + 2) * numsinprocess)
                temp = num - 1;
            int send = temp - i * numsinprocess;
            MPI_Send(&send, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&arr[i * numsinprocess + 1], send, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
        }


        for(int i = 0; i < numsinprocess + 1; i++)
            sum += arr[i];

        for(int i = 1; i < numprocs; i++)
        {
            MPI_Recv(&prtlsum, 1, MPI_FLOAT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            sum += prtlsum;
        }
        file = fopen(argv[2], "w");
        fprintf(file, "%.6f", sum);
        fclose(file);
    }
    else
    {
        float arr2[num + 10];
        prtlsum = 0;
        int receive;
        MPI_Recv(&receive, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&arr2, receive, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int received = receive;
        for(int i = 0; i < received; i++)
            prtlsum += arr2[i];
        MPI_Send(&prtlsum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    
    MPI_Finalize();
    return 0;
}