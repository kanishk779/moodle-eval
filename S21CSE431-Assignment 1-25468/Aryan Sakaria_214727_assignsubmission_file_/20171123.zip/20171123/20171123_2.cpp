#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void papa_merge(vector<ll> &v, vector<int> counts, vector<int> displacements)
{
    // int n = counts.size();
    for (int i = 1; i < counts.size(); ++i)
    {
        int offset = displacements[i];
        int end_set = displacements[i] + counts[i];
        inplace_merge(v.begin(), v.begin() + offset, v.begin() + end_set);
        /* code */
    }
}

ll partition(vector<ll> &v, ll l, ll r)
{
    ll pivot = v[r];
    ll idx = l - 1;
    for (ll j = l; j < r; ++j)
    {
        if(v[j] < pivot)
        {
            idx = idx + 1;
            ll temp = v[idx];
            v[idx] = v[j];
            v[j] = temp;
        }
        /* code */
    }
    ll temp = v[idx + 1];
    v[idx + 1] = v[r];
    v[r] = temp;
    return idx + 1;
}

void quicksort(vector<ll> &v, ll l, ll r)
{
    if(l < r)
    {
        ll q = partition(v, l, r);
        quicksort(v, l , q -1);
        quicksort(v, q+1 , r);

    }
}




int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    ll N, avg_proc;
    vector<ll> arr;
    vector<int> counts;
    if (rank == 0)
    {
        /*
        replace with input code later
        */

        ifstream inpfile;
        inpfile.open(argv[1]);
        inpfile >> N;

        for (int i = 0; i < N; i++)
        {
            ll temp_int;
            inpfile >> temp_int;
            arr.push_back(temp_int);
             /* code */
        } 
        inpfile.close();
        // cout << "reached here" << endl;
        avg_proc = N/numprocs;

        vector<int> displacements;
        // vector<int> counts;
        ll count_tot = 0;

        for (ll i = 0; i < numprocs; ++i)
        {
            /* code */
            displacements.push_back(i*avg_proc);
            if(i == numprocs-1)
            {
                counts.push_back(N - count_tot);
            }
            else
            {
                count_tot += avg_proc;
                counts.push_back(avg_proc);
            }
        }

        // for (int i = 0; i < numprocs; ++i)
        // {
        //     cout << displacements[i] << " ";
        //     /* code */
        // }
        // cout << endl;

        // for (int i = 0; i < numprocs; ++i)
        // {
        //     cout << counts[i] << " ";
        //     /* code */
        // }

        vector<ll> v;
        v.resize(counts[0]);

        MPI_Scatterv(arr.data(), counts.data(), displacements.data(), MPI_LONG, v.data(), counts[0],MPI_LONG, 0, MPI_COMM_WORLD);

        // cout << endl;
        // cout << "\nI am process " << rank << " and I received " << endl;
        // for (int i = 0; i < counts[0]; ++i)
        // {
        //     cout << v[i] << " ";
        //     /* code */
        // }
        // cout << endl;
        quicksort(v, 0, v.size()-1);

        /* code */
        // cout << 
        MPI_Bcast(counts.data(), numprocs, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Gatherv(v.data(), counts[0], MPI_LONG, arr.data(),counts.data(), displacements.data(), MPI_LONG, 0, MPI_COMM_WORLD);
        // cout << "final gathered array" << endl;
        // for (int i = 0; i < arr.size(); ++i)
        // {
        //     cout << arr[i] << " ";
        //     /* code */
        // }
        // cout << endl;
        papa_merge(arr, counts, displacements);
        // cout << "final sorted array" << endl;

        ofstream outputfile;
        outputfile.open(argv[2]);
        // outputfile<<fixed<<setprecision(6);
        // outputfile<<sum<<endl;


        for (int i = 0; i < arr.size(); ++i)
        {
            // cout << arr[i] << " ";
            outputfile << arr[i] << " ";
            /* code */
        }
        cout << endl;

        outputfile.close();
    }

    if(rank!= 0)
    {
        // cout << "size of counts in process " << rank << counts.size();
        counts.resize(numprocs);
        MPI_Bcast(counts.data(), numprocs, MPI_INT, 0, MPI_COMM_WORLD);

        
        vector<ll> v;
        v.resize(counts[rank]);
        MPI_Scatterv(NULL, NULL, NULL, NULL, v.data(), counts[rank], MPI_LONG, 0, MPI_COMM_WORLD);
        quicksort(v, 0, v.size()-1);
        MPI_Gatherv(v.data(), counts[rank], MPI_LONG, NULL,NULL, NULL, MPI_LONG, 0, MPI_COMM_WORLD);

        // cout << "\nI am process " << rank << " and I received " << endl;
        // // for (int i = 0; i < counts.size(); ++i)
        // // {
        // //     cout << counts[i] << " ";
        // //     /* code */
        // // }

        // for (int i = 0; i < counts[rank]; ++i)
        // {
        //     cout << v[i] << " ";
        //     /* code */
        // }
        // cout << endl;

    }
    

   

    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}