/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    int num_elem;
    if(rank == 0) 
    {
        // cout << "Enter num elem" << endl;
        // cin >> num_elem;
        ifstream inpfile;
        inpfile.open(argv[1]);
        inpfile >> num_elem;
        inpfile.close();


        int avg_proc = num_elem / numprocs; 
        // cout << "avg_proc " << avg_proc << endl;

        for(int i=1; i < numprocs; i++)
        {   
            int start_idx = i*avg_proc + 1;
            int end_idx = (i + 1)*avg_proc;

            if(i == numprocs - 1)
            {
                // cout << "Hitting this case" << endl;
                end_idx = num_elem;
            }

            int total_elem = end_idx - start_idx + 1;
            MPI_Send(&total_elem, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&start_idx, 1, MPI_INT, i, 0, MPI_COMM_WORLD);

            // MPI_Send(arr + start_idx, total_elem, MPI_INT, i, 0, MPI_COMM_WORLD);
        }

        double sum = 0;
        // cout << "display from root rank :" << endl;
        for(int k = 0; k < avg_proc; k++)
        {
            // cout << k + 1 << " ";
            sum = sum + (1 / pow(k+1,2));
        }
        // cout << endl;

        // cout << "sum from root " << sum << endl;

        for(int i=1; i < numprocs; i++)
        {
            double slave_sum;
            MPI_Recv(&slave_sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            sum += slave_sum;
        }

        // cout << "final sum" << sum << endl;
        ofstream outputfile;
        outputfile.open(argv[2]);
        outputfile<<fixed<<setprecision(6);
        outputfile<<sum<<endl;
        outputfile.close();
    }
    else 
    {
        int slave_len;
        int slave_start;

        MPI_Recv(&slave_len, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&slave_start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        double send_sum = 0;

        // MPI_Recv(&slave_arr, slave_len, MPI_INT)

        // int received[10];
     //    MPI_Recv(received, 10, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // bubbleSort(received,10);
        for (int i = slave_start - 1; i < slave_start + slave_len - 1; ++i)
        {
            send_sum = send_sum + (1 / pow(i+1,2));

            // cout << i + 1 << " ";
            /* code */
        }
        // cout << endl;
        MPI_Send(&send_sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        // cout << "rank " << rank << " " << "start_idx " << slave_start  <<  " len " << slave_len << endl;
    }











    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}