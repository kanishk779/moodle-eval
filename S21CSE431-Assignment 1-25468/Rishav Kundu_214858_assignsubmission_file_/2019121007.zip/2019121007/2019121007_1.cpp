#include <cassert>
#include <iomanip>
#include <iostream>
#include <mpi.h>

#define EXPECT(arg)                                                            \
  do {                                                                         \
    assert(arg == MPI_SUCCESS);                                                \
  } while (0);

int main(int argc, char **argv) {

  EXPECT(MPI_Init(&argc, &argv));

  int rank, nproc;
  EXPECT(MPI_Comm_rank(MPI_COMM_WORLD, &rank));
  EXPECT(MPI_Comm_size(MPI_COMM_WORLD, &nproc));

  int limit;
  if (rank == 0) {
    std::cin >> limit;
    assert(limit >= 2 && limit <= 1e4);
  }

  EXPECT(MPI_Bcast(&limit, 1, MPI_INT, 0, MPI_COMM_WORLD));

  int chunk_sz = limit / nproc;
  if (limit % nproc != 0)
    chunk_sz++;

  double sum = 0;
  for (int i = rank * chunk_sz; i < (rank + 1) * chunk_sz; ++i) {
    if (i + 1 > limit)
      break;
    /* std::cout << "adding " << i + 1 << '\n'; */
    double val = pow(pow(i + 1, 2), -1);
    sum += val;
  }

  double global_sum;
  EXPECT(
      MPI_Reduce(&sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD));

  if (rank == 0) {
    std::cout << std::setprecision(6) << std::fixed << global_sum << '\n';
  }

  EXPECT(MPI_Finalize());
}
