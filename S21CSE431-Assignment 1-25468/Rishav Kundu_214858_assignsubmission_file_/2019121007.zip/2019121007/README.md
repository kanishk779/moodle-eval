Distributed Systems Assignment 1

Problem 1

The upper limit is broadcasted to all the processes, and each determines the range it has to sum using its rank. The results of each summation are gathered back to the rank-0 process and displayed.

Time

❯ time mpirun --oversubscribe -np 4 ./q1 < inp1.txt
1.644834

________________________________________________________
Executed in  350.63 millis    fish           external
   usr time  447.53 millis  120.00 micros  447.41 millis
   sys time  207.11 millis  623.00 micros  206.49 millis


Problem 2

Algorithm described in http://www.cas.mcmaster.ca/~nedialk/COURSES/4f03/Lectures/quicksort.pdf is implemented. Pivot is selected in master node and partitioning step is distributed. Then, the union of all L and R partitions is made, and recursively distributed to sub-processes.

Time

(n = 1e6, p = 4)

❯ time mpirun --oversubscribe -np 4 ./q2 < input.txt > /dev/null

________________________________________________________
Executed in    6.29 secs   fish           external
   usr time   17.25 secs  114.00 micros   17.25 secs
   sys time    4.29 secs  689.00 micros    4.28 secs


(n = 1e6, p = 11)

❯ time mpirun --oversubscribe -np 11 ./q2 < input.txt > /dev/null

________________________________________________________
Executed in    6.83 secs   fish           external
   usr time    9.94 secs  144.00 micros    9.94 secs
   sys time   13.71 secs  727.00 micros   13.71 secs
