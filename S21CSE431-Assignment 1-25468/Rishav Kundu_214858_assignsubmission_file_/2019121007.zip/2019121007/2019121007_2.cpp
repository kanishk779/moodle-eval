#include "mpi.h"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <vector>

#define EXPECT(arg)                                                            \
  do {                                                                         \
    assert(arg == MPI_SUCCESS);                                                \
  } while (0);

void recv_int(int *tmp) {
  EXPECT(MPI_Recv(tmp, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
}

void recv_ints(int *buf, int cnt) {
  EXPECT(MPI_Recv(buf, cnt, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG,
                  MPI_COMM_WORLD, MPI_STATUS_IGNORE));
}

int partition(int *arr, int len, int pivot) {

  int i = -1;
  int j = len;
  while (1) {
    do {
      i++;
    } while (i < len && arr[i] < pivot);
    do {
      j--;
    } while (j >= 0 && arr[j] > pivot);
    if (i >= j)
      return j;
    std::swap(arr[i], arr[j]);
  }
}

void process_partition_request() {
  int leader, pivot, len, *arr;
  recv_int(&leader);
  recv_int(&pivot);
  recv_int(&len);
  /* std::cout << "requested: " << len << std::endl; */
  arr = new int[len];
  recv_ints(arr, len);
  int new_pivot = partition(arr, len, pivot);

  /* std::cout << "pivot = " << pivot << " len = " << len << std::endl; */
  /* std::cout << "paritioning" */
  /*           << " pivot idx = " << new_pivot << std::endl; */
  /* for (int i = 0; i < len; ++i) { */
  /*   std::cout << arr[i] << ' '; */
  /* } */
  /* std::cout << std::endl << "==============" << std::endl; */

  EXPECT(MPI_Send(&new_pivot, 1, MPI_INT, leader, 1, MPI_COMM_WORLD));
  EXPECT(MPI_Send(&len, 1, MPI_INT, leader, 1, MPI_COMM_WORLD));
  EXPECT(MPI_Send(arr, len, MPI_INT, leader, 1, MPI_COMM_WORLD));
}

// from https://www.geeksforgeeks.org/quick-sort/

int partition2(int arr[], int low, int high) {
  int pivot = arr[high]; // pivot
  int i = (low - 1);     // Index of smaller element

  for (int j = low; j <= high - 1; j++) {
    // If current element is smaller than the pivot
    if (arr[j] < pivot) {
      i++; // increment index of smaller element
      std::swap(arr[i], arr[j]);
    }
  }
  std::swap(arr[i + 1], arr[high]);
  return (i + 1);
}

/* The main function that implements QuickSort
arr[] --> Array to be sorted,
low --> Starting index,
high --> Ending index */
void quickSort(int arr[], int low, int high) {
  if (low < high) {
    /* pi is partitioning index, arr[p] is now
    at right place */
    int pi = partition2(arr, low, high);

    // Separately sort elements before
    // partition and after partition
    quickSort(arr, low, pi - 1);
    quickSort(arr, pi + 1, high);
  }
}

void qs(int *arr, int len) { quickSort(arr, 0, len - 1); }

void send_partition_request(int *arr, int len, int dest, int src, int pivot) {
  /* std::cout << "requesting partition from " << src << std::endl; */
  int code = 0xfae;
  MPI_Send(&code, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
  MPI_Send(&src, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
  MPI_Send(&pivot, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
  MPI_Send(&len, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
  MPI_Send(arr, len, MPI_INT, dest, 1, MPI_COMM_WORLD);
}

void receive_partitioned(int src, int *len, int *pivot, int *arr) {

  EXPECT(MPI_Recv(pivot, 1, MPI_INT, src, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  EXPECT(MPI_Recv(len, 1, MPI_INT, src, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  EXPECT(MPI_Recv(arr, *len, MPI_INT, src, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
}

void sort(int leader, int nproc, int len, int *arr);

void process_sort_request() {
  int tag, leader, nproc, len, *arr;
  EXPECT(MPI_Recv(&tag, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  EXPECT(MPI_Recv(&leader, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG,
                  MPI_COMM_WORLD, MPI_STATUS_IGNORE));
  EXPECT(MPI_Recv(&nproc, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG,
                  MPI_COMM_WORLD, MPI_STATUS_IGNORE));

  EXPECT(MPI_Recv(&len, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  arr = new int[len];
  EXPECT(MPI_Recv(arr, len, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG,
                  MPI_COMM_WORLD, MPI_STATUS_IGNORE));

  /* std::cout << "obtained data in process_sort" << std::endl; */
  sort(leader, nproc, len, arr);

  /* std::cout << "done sorting!" << std::endl; */
  /* for (int i = 0; i < len; ++i) */
  /*   std::cout << arr[i] << ' '; */
  /* std::cout << std::endl; */

  MPI_Send(&len, 1, MPI_INT, leader, tag, MPI_COMM_WORLD);
  MPI_Send(arr, len, MPI_INT, leader, tag, MPI_COMM_WORLD);
}

int send_sort_request(int leader, int nproc, int len, int *arr) {
  int my_rank;
  int tag = rand();
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
  int code = 0xfee;
  MPI_Send(&code, 1, MPI_INT, leader, 1, MPI_COMM_WORLD);
  MPI_Send(&tag, 1, MPI_INT, leader, 1, MPI_COMM_WORLD);
  MPI_Send(&my_rank, 1, MPI_INT, leader, 1, MPI_COMM_WORLD);

  MPI_Send(&nproc, 1, MPI_INT, leader, 1, MPI_COMM_WORLD);

  MPI_Send(&len, 1, MPI_INT, leader, 1, MPI_COMM_WORLD);

  MPI_Send(arr, len, MPI_INT, leader, 1, MPI_COMM_WORLD);
  return tag;
}

void receive_sorted(int tag, int *arr) {
  int len;
  EXPECT(MPI_Recv(&len, 1, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  EXPECT(MPI_Recv(arr, len, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD,
                  MPI_STATUS_IGNORE));
  /* std::cout << "received sorted!" << std::endl; */
}

void sort(int leader, int nproc, int len, int *arr) {
  int f = rand();
  int *og = arr;
  arr = new int[len];
  std::copy(og, og + len, arr);
  int my_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
  if (nproc > len)
    nproc = len;
  /* std::cout << "sort called with params "; */
  /* std::cout << "rank: " << my_rank; */
  /* std::cout << "leader: " << leader; */
  /* std::cout << " nproc: " << nproc; */
  /* std::cout << " len: " << len; */
  /* std::cout << " rand: " << f; */
  /* std::cout << " { "; */
  /* for (int i = 0; i < len; ++i) */
  /*   std::cout << arr[i] << ", "; */
  /* std::cout << "}" << std::endl; */
  if (nproc == 1) {
    // sequential qs
    // send to leader
    qs(arr, len);
    /* EXPECT(MPI_Send(arr, len, MPI_INT, leader, MPI_ANY_TAG,
     * MPI_COMM_WORLD));
     */
    std::copy(arr, arr + len, og);

    /* std::cout << "Sorted array rand = " << f << ": "; */
    /* for (int *t = arr; t < arr + len; t++) */
    /*   std::cout << *t << " "; */
    /* std::cout << std::endl; */
  } else {
    int chunk_sz = len / nproc;
    if (len % nproc != 0) {
      chunk_sz++;
      nproc = len / chunk_sz;
      if (len % chunk_sz != 0)
        nproc++;
    }

    /* nproc = len / chunk_sz; */

    int pivot = arr[len / 2];

    int my_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    for (int i = 0; i < nproc; ++i) {
      int start = chunk_sz * i;
      /* if (start >= len) */
      /*   break; */
      int end = std::min(len - 1, chunk_sz * (i + 1) - 1);
      /* std::cout << nproc << " " << len << " " << i << " " << chunk_sz << " "
       */
      /* << start << " " << end << "\n"; */
      if (i != 0) {
        send_partition_request(arr + start, end - start + 1, my_rank + i,
                               my_rank, pivot);
      }
    }

    std::vector<int> L, R;
    for (int i = 0; i < nproc; ++i) {
      if (i != 0) {
        int pivot, len;
        /* if (chunk_sz * i >= len) */
        /*   break; */
        receive_partitioned(my_rank + i, &len, &pivot, arr + chunk_sz * i);

        /* if (my_rank == 0) { */
        /*   for (int ix = 0; ix < len; ++ix) { */
        /*     std::cout << "baz " << arr[chunk_sz * i + ix] << " "; */
        /*   } */
        /*   std::cout << std::endl; */
        /* } */
        int *start = arr + chunk_sz * i;
        int *end = start + len;
        L.insert(L.end(), start, start + pivot + 1); // TODO

        /* std::cout << "yeet " << R.size() << std::endl; */
        R.insert(R.end(), start + pivot + 1, end);

        /* std::cout << "test: \n"; */
        /* for (auto x : R) { */
        /*   std::cout << x << " "; */
        /* } */
        /* std::cout << std::endl; */
      } else {

        int start = chunk_sz * i;
        int end = std::min(len, chunk_sz * (i + 1));

        int pivot_pos = partition(arr, end - start, pivot);

        /* for (int i = start; i <= end */

        /* std::cout << "partitioning " << start << " " << end << " " <<
         * pivot_pos */
        /*           << std::endl; */
        /* for (int i = start; i < end; ++i) */
        /*   std::cout << arr[i] << " "; */
        /* std::cout << std::endl; */

        L.insert(L.end(), arr + start, arr + start + pivot_pos + 1); // TODO

        /* std::cout << R.size() << "aasdasdad \n"; */

        R.insert(R.end(), std::max(arr + start, arr + start + pivot_pos + 1),
                 arr + end);

        /* std::cout << R.size() << "aasdasdad \n"; */
      }
    }

    /* if (f == 28925691) { */
    /*   std::cout << "-------- here --------" << std::endl; */
    /*   std::cout << pivot << std::endl; */

    /*   std::cout << " ===== part begin ====== " << std::endl; */
    /*   for (auto x : L) */
    /*     std::cout << x << ' '; */

    /*   std::cout << std::endl; */

    /*   for (auto x : R) */
    /*     std::cout << x << ' '; */
    /*   std::cout << " \n ===== part end ====== " << std::endl; */

    /*   std::cout << std::endl; */
    /* } */

    int tag = 1;
    if (R.size() > 0) {
      tag = send_sort_request(my_rank + nproc / 2, nproc - nproc / 2, R.size(),

                              R.data());
    }

    if (L.size() > 0) {
      sort(my_rank, nproc / 2, L.size(), L.data());
    }

    /* std::cout << "le waiting: " << std::endl; */

    /* if (f == 28925691) { */
    /*   std::cout << "Contents of R: "; */
    /*   for (auto x : R) */
    /*     std::cout << x << " "; */
    /*   std::cout << std::endl; */
    /* } */
    if (R.size() > 0) {
      receive_sorted(tag, R.data());
    }

    /* if (f == 28925691) { */
    /*   std::cout << "Contents of R: "; */
    /*   for (auto x : R) */
    /*     std::cout << x << " "; */
    /*   std::cout << std::endl; */
    /* } */

    /* if (f == 28925691) { */
    /*   std::cout << "m done doe!" << std::endl; */

    /*   std::cout << "pivot: " << pivot << std::endl; */
    /*   for (auto x : L) */
    /*     std::cout << x << " ho "; */
    /*   std::cout << std::endl; */

    /*   for (auto x : R) */
    /*     std::cout << x << " ho "; */
    /*   std::cout << std::endl; */
    /* } */

    std::copy(L.begin(), L.end(), arr);
    std::copy(R.begin(), R.end(), arr + L.size());

    /* std::cout << "Sorted array: " << f << std::endl; */
    /* for (int *t = arr; t < arr + len; t++) */
    /*   std::cout << *t << " "; */
    /* std::cout << std::endl; */

    std::copy(arr, arr + len, og);
  }
}

int main(int argc, char **argv) {
  MPI_Init(&argc, &argv);

  int my_rank, nproc;
  EXPECT(MPI_Comm_rank(MPI_COMM_WORLD, &my_rank));
  MPI_Comm_size(MPI_COMM_WORLD, &nproc);

  srand(my_rank);
  int N = 4;
  std::cin >> N;
  std::vector<int> arr(N);
  for (int i = 0; i < N; ++i)
    std::cin >> arr[i];
  /* arr[0] = 1; */
  /* arr[1] = 2; */
  /* arr[2] = 3; */
  /* arr[3] = 4; */
  if (my_rank == 0) {
    sort(0, nproc, N, arr.data());
    /* std::cout << "Final Sorted: "; */
    for (auto x : arr) {
      std::cout << x << ' ';
    }
    std::cout << std::endl;
    for (int i = 1; i < nproc; ++i) {
      int code = 0xbeef;
      MPI_Send(&code, 1, MPI_INT, i, 1, MPI_COMM_WORLD);
    }
    /* std::cout << "dooooone!!" << std::endl; */
    MPI_Finalize();
    return 0;
  } else {
    while (1) {
      int type;
      recv_int(&type);
      /* std::cout << type << std::endl; */
      if (type == 0xfae) {
        process_partition_request();
      } else if (type == 0xfee) {
        process_sort_request();
      } else if (type == 0xbeef) {
        MPI_Finalize();
        return 0;
      }
    }
  }
}
