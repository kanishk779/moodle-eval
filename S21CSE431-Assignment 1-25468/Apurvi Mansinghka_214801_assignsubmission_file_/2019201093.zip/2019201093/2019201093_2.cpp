/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
void read_elements(ifstream &fptr,vector<ll>&ele){
    int temp;
    while(fptr>>temp){
        ele.push_back(temp);
    }

}
ll numberPerProcess(vector<ll>&ele,vector<ll>&arr,ll &numprocs){
    // cout<<"inside numProcess\n";
    ll elements_per_proc = 0;
    ll size = ele.size();
    // cout<<"size ele is"<<size<<"\n";
    elements_per_proc = (ll)ceil((size * 1.00) / numprocs);
    // cout<<"elements_per_proc: "<<elements_per_proc<<"\n";
    for (ll i = size; i < (elements_per_proc * numprocs); i++){
            ele.push_back(LONG_LONG_MIN);
    }
    return elements_per_proc;

}
void init(ll &pivot,ll &i,ll &res,ll &start,ll &end){
    pivot = end;
    i = start-1;
    res = -1;
}
ll partiton(vector<ll>&arr, ll start, ll end){
    // cout<<"inside partion\n";
    ll pivot,i,res;
    init(pivot,i,res,start,arr[end]);
    for (ll j = start; j < end; j++)
    {
        if (pivot > arr[j])
        {
            i++;
            swap(arr[i],arr[j]);
        }
    }
    swap(arr[i+1],arr[end]);
    res = (i + 1);
    return res;
}
void quicksort(vector<ll>&arr,ll start,ll end,ll ele){
    // cout<<"inside qick\n";
    if(start<end){
        ll pivot = partiton(arr,start,end);
        quicksort(arr, start, end - 1,11);
        quicksort(arr, pivot + 1, end,11);
    }

}
void scatterData(vector<ll>&arr,vector<ll>&processArray,ll &n){
    // cout<<"inside scatterData\n";
    // cout<<"n is "<<n<<"\n";
    MPI_Scatter(arr.data(), n, MPI_LONG_LONG_INT, processArray.data(),n, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
    // cout<<"out of scatter ";
    quicksort(processArray,0,n-1,11);


}
ll sortArray(string file,ll numprocs,vector<ll>&processArray,vector<ll>&ele, ll &arr_size){
    ifstream fptr;
    fptr.open(file);
    ll inp;
    fptr>>inp;
    arr_size = inp;
    // cout<<"size: "<<arr_size<<"\n";
    read_elements(fptr,ele);
    vector<ll>arr;
    ll elements_per_proc = numberPerProcess(ele,arr,numprocs);
    // cout<<"elembts pr proc "<<elements_per_proc<<"\n";
    MPI_Bcast(&elements_per_proc, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
    processArray.resize(elements_per_proc);
    scatterData(ele,processArray,elements_per_proc);
    // ele = arr;
    // cout<<"out of sort\n";
    return elements_per_proc;

}
bool check(ll &rank,ll &step){
    return (rank % (2 * step) == 0);
}
vector<ll> recvMPI(ll &rank,ll &step, ll &m){
    ll n = 0;
    MPI_Status status;
    vector<ll>other;
    MPI_Recv(&m, 1, MPI_LONG_LONG_INT, rank + step, 0, MPI_COMM_WORLD, &status);
    other.resize(m);
    MPI_Recv(other.data(), m, MPI_LONG_LONG_INT,rank + step, 0, MPI_COMM_WORLD, &status);
    return other;
}
bool checkMerge(ll &ai,ll &as,ll &bi,ll &bs){
    return (ai < as && bi < bs);
}
vector<ll> merge(vector<ll> &A, vector<ll> &B)
{
    
    ll ai, bi, ci, i,cv=0;
    ll as = A.size();
    ll bs= B.size();
    vector<ll> C(as+bs);

    ai = 0;
    bi = 0;
    ci = 0;

    while (checkMerge(ai,as,bi,bs))
    {
        if (A[ai] <= B[bi])
        {
            C[ci] = A[ai];
            cv++;
            ai++;
        }
        else
        {
            C[ci] = B[bi];
            cv+=1;
            bi++;
        }
        ci++;
    }
    ll cs = C.size();
    if (ai >= as)
        for (i = ci; i < cs; i++, bi++)
            C[i] = B[bi];

    else if (bi >= bs)
        for (i = ci; i < cs; i++, ai++)
            C[i] = A[ai];

    for (i = 0; i < as; i++)
        A[i] = C[i];
    for (i = 0; i < bs; i++)
        B[i] = C[as + i];

    return C;
}
ll calcNear(ll &rank,ll &step){
    check(rank,step);
    return rank-step;
}
void mergeArray(ll numprocs,vector<ll>&processArray,ll rank,ll &num_elements_per_proc,ll arrsize){
    ll step = 1;
    // cout<<"inside merge array\n";
    // cout<<"arrsize is "<<arrsize<<"\n";
    for (ll step = 1; step < numprocs; step *= 2)
    {
        // cout<<"step is "<<step<<"\n";

        if (check(rank,step))
        {
            if (rank + step < numprocs)
            {
                ll m,sz;
                auto other = recvMPI(rank,step,m);
                sz+=m
                processArray = merge(processArray, other);
                num_elements_per_proc += m;
            }
        }
        else
        {
            ll near = calcNear(rank,step);
            MPI_Send(&num_elements_per_proc, 1, MPI_LONG_LONG_INT, near, 0, MPI_COMM_WORLD);
            ll checkele = 0;
            MPI_Send(processArray.data(), num_elements_per_proc, MPI_LONG_LONG_INT, near, 0, MPI_COMM_WORLD);
            checkele++;
            break;
        }
        // cout<<"step is "<<step<<"\n";
    }
}

void writeToFile(string &output_file,ll rank,vector<ll>&processArray,ll &arrsize){
    if (rank == 0)
    {

        FILE *fout;
        const char* file = output_file.c_str();
        fout = fopen(file, "w");
        ll size = processArray.size();
        // cout<<"arrsize "<<arrsize<<"\n";
        for (ll i = processArray.size() - arrsize; i < processArray.size(); i++)
        {
            // cout<<"i is "<<i<<"\n";
            // cout<<processArray[i]<<"\n";
            fprintf(fout, "%lld ", processArray[i]);
        }
        fclose(fout);
    }
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank);
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    string input_file = argv[1];
    // cout<<"input file :"<<input_file;
    string output_file = argv[2];
    vector<ll> processArray,arr;
    ll arr_size = 0;
    ll elements_per_proc;
    if(rank == 0){
        elements_per_proc = sortArray(input_file,numprocs,processArray,arr,arr_size);
        // cout<<"size after sort array "<<arr.size()<<"\n";
    }
    else{
        elements_per_proc = -1;
        MPI_Bcast(&elements_per_proc, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
        ll check_ele = -1;
        if (elements_per_proc == -1)
            MPI_Abort(MPI_COMM_WORLD, MPI_ERR_COUNT);
        processArray.resize(elements_per_proc);
        // cout<<"size in else "<<arr.size()<<"\n";
        scatterData(arr,processArray,elements_per_proc);
        // cout<<"bnbnnb";
    }
    // cout<<"out of sort\n";
    // ll arr_size = arr.size();
    // cout<<"size before merge "<<arr_size<<"\n";
    mergeArray(numprocs,processArray,rank,elements_per_proc,arr_size);
    writeToFile(output_file,rank,processArray,arr_size);


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
