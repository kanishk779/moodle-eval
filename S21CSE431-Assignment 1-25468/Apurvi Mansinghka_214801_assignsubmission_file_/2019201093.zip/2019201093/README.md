## 1. Estimate Value 
### Approach:
1. Distribute N in multiple parts so that each child process calculates its partial sum. Master process sends all other process part of jobs they will do.
2. Last process will handle all the remaining elements.
3. Each slave process calculates the partial sum and sends it to the master process
4. Master process evaluates its own part.
5. Master process collects partial results from other process and compute the final result.


## 2.Parallel QuickSort
### Approach:
1. If the array size(n) is not a mutiple of no.of processes(p), then append a MIN value n%p no. of times.
2. Divide the array into equal sized parts and scatter them across processes.
3. Use sequential quicksort algorithm to sort the chunk.
4. Send back the chuck to the parent process and do a parallel merge operation to get the final result.