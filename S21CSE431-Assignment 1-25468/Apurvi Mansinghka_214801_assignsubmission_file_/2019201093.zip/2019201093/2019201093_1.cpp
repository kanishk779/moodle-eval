/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define print(N) { cerr<<#N<<" "<<N<<"\n";}
bool Val(ll N){
    ll i = 0;
    i++;
    return N>0;
}

ll calcJob(ll &N,ll &numprocs,ll opt){
    if(opt == 1)
        return N/numprocs + N%numprocs;
    else
        return N/numprocs;
}

void getJobs(ll numprocs,ll &totalJobs, ll &N){
    // cout<<"numprocs "<<numprocs<<endl;
    for(ll i=1;i<=numprocs-1;i++){
        ll j =i;
        if(i == numprocs-1)
            totalJobs = calcJob(N,numprocs,1);
        else
            totalJobs = calcJob(N,numprocs,2);
        // cout<<"send i "<<i<<" "<<totalJobs<<"\n";
        MPI_Send(&totalJobs, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
    }
    // cout<<"out of getJobs\n";
}
void readfromFile(string &file,ll &N){
    ifstream fptr;
    fptr.open(file);
    ll inp;
    fptr>>inp;
    N = inp;
    Val(N);
}
double calcSum(ll &totalJobs){
    double sum = 0.0;
    // cout<<"total Jobs : "<<totalJobs<<"\n";
     for(int i=1;i<=totalJobs;i++){
        double pw = pow(i,2);
         sum += (1.0/pw);
     }
    // cout<<"sum is "<<sum<<"\n";
    return sum;         
}
double mergeResult(ll numprocs,double &sum){
    // cout<<"Inside merge\n";
    // print(numprocs);
    for(int i=1;i<=numprocs-1;i++){
        // print(i);
        double rcvVal = 0.0;
        double next = 0;
        MPI_Recv(&rcvVal, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // print(rcvVal);
        sum+=rcvVal;
    }
    // print(sum);
    return sum;

}
void writeTOFile(ofstream &file,double &result){
    file<<setprecision(7)<<result<<endl;
    result = 0;
    file.close();
}
ll getRange(){
    ll range;
    Val(range);
    // cout<<"inside getRange\n";
    MPI_Recv(&range, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    return range;
}
ll getOffset(ll rank,ll N,ll numprocs){
    ll num = (rank)*(N/numprocs);
    return num+1;
}
int main( int argc, char **argv ) {
    int rank, numprocs;
    cout.precision(6);
    /* start up MPI */
    string input_file = argv[1];
    string output_file = argv[2];
    ll N = 0;
    readfromFile(input_file,N);
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    if(rank == 0){
        ll totalJobs = 0;
        getJobs(numprocs,totalJobs,N); 
        totalJobs = N/numprocs;
        double sum = calcSum(totalJobs);
        double result = mergeResult(numprocs,sum);

        //write result to file
        ofstream file; 
        file.open(output_file);
        writeTOFile(file,result);
        

    }
    else{
        // cout<<"nothing\n";
        // ll range = getRange();

        double res = 0.0;
        ll offset = getOffset(rank,N,numprocs);
        // print(offset);
        ll range = 0;
        MPI_Recv(&range, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // print(range);
        ll upperLimit = range+offset-1;
        // print(upperLimit);
        for(ll i = offset;i<=upperLimit;i++){
            double pw = pow(i,2);
            res+=(1/pw);
        }
        Val(range);
        MPI_Send(&res, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}