#include <bits/stdc++.h>
using namespace std;
#include <mpi.h>

int main(int argc, char *argv[])
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    MPI_Init(&argc, &argv);
    int v, E;
    int root_rank = 0;

    int size;
    int my_rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    if (my_rank == root_rank)
    {
        fstream input_file;

        input_file.open(argv[1], ios::in);

        input_file >> v >> E;
        int edges[E + 1][2];
        for (int i = 0; i < E; i++)
        {
            input_file >> edges[i][0] >> edges[i][1];
        }
        MPI_Bcast(&E, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        MPI_Bcast(&edges, (E + 1) * 2, MPI_INT, root_rank, MPI_COMM_WORLD);

        vector<vector<int>> adj;

        adj.resize(E + 1);
        for (int i = 0; i < E; i++)
        {
            for (int j = 0; j < E; j++)
            {
                if (i != j)
                {
                    if (edges[i][0] == edges[j][0] || edges[i][1] == edges[j][0] || edges[i][0] == edges[j][1] || edges[i][1] == edges[j][1])
                    {
                        adj[i + 1].push_back(j + 1);
                    }
                }
            }
        }

        int chunk_size = E / size;

        int start = my_rank * chunk_size + 1;

        int end = (my_rank + 1) * chunk_size;
        if (my_rank == size - 1)
        {
            end = E;
        }
        // cout << start << " " << end << endl;
        int total = 0;

        int num[E + 1];
        int assigned[E + 1];

        for (int i = 0; i <= E; i++)
        {
            num[i] = i;
            assigned[i] = 0;
        }
        // MPI_Bcast(&total, 1, MPI_INT, root_rank, MPI_COMM_WORLD);

        while (total < E)
        {
            MPI_Bcast(&total, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
            MPI_Bcast(&num, E + 1, MPI_INT, root_rank, MPI_COMM_WORLD);
            MPI_Bcast(&assigned, E + 1, MPI_INT, root_rank, MPI_COMM_WORLD);
            // MPI_Bcast(&total, 1, MPI_INT, root_rank, MPI_COMM_WORLD);

            // total += 1;
            vector<int> current;
            for (int i = start; i <= end; i++)
            {
                if (!assigned[i])
                {
                    int f = 0;
                    for (int j = 0; j < adj[i].size(); j++)
                    {
                        if (assigned[adj[i][j]] == 0 && adj[i][j] > i)
                        {
                            f = 1;
                            break;
                        }
                    }
                    if (!f)
                    {
                        current.push_back(i);
                    }
                }
            }
            total += current.size();
            for (int i = 0; i < current.size(); i++)
            {
                int x = current[i];
                map<int, int> m;
                for (int j = 0; j < adj[x].size(); j++)
                {
                    int k = adj[x][j];
                    if (assigned[k])
                    {
                        m[num[k]] += 1;
                    }
                }
                int j = 1;
                while (1)
                {
                    if (m[j] == 0)
                    {
                        break;
                    }
                    j += 1;
                }
                num[x] = j;
                // cout << x << " " << j << endl;
                assigned[x] = 1;
            }
            // cout << total << endl;
            for (int i = 1; i < size; i++)
            {
                int update_size;
                MPI_Recv(&update_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                int updates[update_size + 1][2];
                MPI_Recv(&updates, update_size * 2, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                total += update_size;
                for (int j = 0; j < update_size; j++)
                {
                    assigned[updates[j][0]] = 1;
                    num[updates[j][0]] = updates[j][1];
                }
            }
        }
        // cout << total << endl;
        MPI_Bcast(&total, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        ofstream fout(argv[2]);
        set<int> ss;
        for (int i = 1; i <= E; i++)
        {
            ss.insert(num[i]);
        }
        fout << ss.size() << endl;
        for (int i = 1; i <= E; i++)
        {
            fout << num[i] << " ";
        }
        fout << endl;
    }
    else
    {

        MPI_Bcast(&E, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        // cout << E << endl;
        int edges[E + 1][2];
        MPI_Bcast(&edges, (E + 1) * 2, MPI_INT, root_rank, MPI_COMM_WORLD);

        vector<vector<int>> adj;
        adj.resize(E + 1);
        for (int i = 0; i < E; i++)
        {
            for (int j = 0; j < E; j++)
            {
                if (edges[i][0] == edges[j][0] || edges[i][1] == edges[j][0] || edges[i][0] == edges[j][1] || edges[i][1] == edges[j][1])
                {
                    adj[i + 1].push_back(j + 1);
                }
            }
        }

        int num[E + 1];
        int assigned[E + 1];
        int total = 0;
        int chunk_size = E / size;

        int start = my_rank * chunk_size + 1;

        int end = (my_rank + 1) * chunk_size;
        if (my_rank == size - 1)
        {
            end = E;
        }

        while (total < E)
        {

            MPI_Bcast(&total, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
            // cout << total << endl;
            if (total >= E)
            {
                break;
            }
            MPI_Bcast(&num, E + 1, MPI_INT, root_rank, MPI_COMM_WORLD);
            MPI_Bcast(&assigned, E + 1, MPI_INT, root_rank, MPI_COMM_WORLD);

            vector<int> current;
            for (int i = start; i <= end; i++)
            {
                if (!assigned[i])
                {
                    int f = 0;
                    for (int j = 0; j < adj[i].size(); j++)
                    {
                        if (assigned[adj[i][j]] == 0 && adj[i][j] > i)
                        {
                            f = 1;
                            break;
                        }
                    }
                    if (!f)
                    {
                        current.push_back(i);
                    }
                }
            }
            int update_size = current.size();
            int updates[update_size + 1][2];
            for (int i = 0; i < current.size(); i++)
            {
                int x = current[i];
                map<int, int> m;
                for (int j = 0; j < adj[x].size(); j++)
                {
                    int k = adj[x][j];
                    if (assigned[k])
                    {
                        m[num[k]] += 1;
                    }
                }
                int j = 1;
                while (1)
                {
                    if (m[j] == 0)
                    {
                        break;
                    }
                    j += 1;
                }
                updates[i][0] = x;
                updates[i][1] = j;
            }
            MPI_Send(&update_size, 1, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
            MPI_Send(&updates, update_size * 2, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
        }
    }
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == root_rank)
    {
        printf("Total time (s): %f\n", maxTime);
    }
    MPI_Finalize();
    return EXIT_SUCCESS;
}
