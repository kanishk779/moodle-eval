# Parallel Sum

## Description:

A parallel approach using MPI is followed to find sum of the reciprocals of the squares of integer from 1 to N. Integers from 1 to N are divided in equal chunks and passed to the processes. Each process calculates the sum corresponding to integers belonging to its chunk. All the sums from different processes are summed up to give the final answer using MPI Reduce.

## Analysis

- For N = 1e4 and 11 processes: Time Taken: 0.000361 seconds
- For N = 1e4 and 1 processes: Time Taken: 0.000145 seconds

# Parallel Quick Sort

## Description:

A parallel approach using MPI is followed to sort given array using quick sort algorithm. Input array is divided into equak chunks of continuous subarrays and passed to different processes. Each process sorts its corresponding subarray using quicksort algorithm and returns this sorted subarray to root process using MPI_Send. The root proccess merges all these sorted subarrays received by parallel quicksort from different processes.

### Merge Step:

We keep a pointer at the begining of all sorted subarrays. The pointer having the smallest value is pushed one step ahead and this value is stored in a new array which will be our output. We continue adding elements till all the pointers reach ahead of the end of their corresponding subarrays.

## Analysis

- For N = 10 with random values of array from 0 till 1e9 and 1 processes: Time Taken: 0.000154
- For N = 10 with random values of array from 0 till 1e9 and 11 processes: Time Taken: 0.000844

- For N = 1e6 with random values of array from 0 till 1e9 and 1 processes: Time Taken: 0.4289
- For N = 1e6 with random values of array from 0 till 1e9 and 11 processes: Time Taken: 0.6634

  A but surprising result is that the more the number of processes, the more time it takes which is counter-intutive. But, it can be justified as the overhead of sending and receiving a large part of array is more than the very simple quick sort that it has to do.Hence the time increases.

# Parallel Edge Coloring

## Description:

A parallel approach is to be followed to color the edges of given graph in such a way that no two adjacent edges have same color and maximum number of colors used is not more than `1 + max(Delta of the original graph, Delta of the line graph)`. Initially given graph is transformed to its line graph. A line graph L(G) of a simple graph G is obtained by associating a vertex with each edge of the graph and connecting two vertices with an edge iff the corresponding edges of G have a vertex in common
Now for this line graph our problem is transformed to graph coloring (vertex-coloring). For this a parallel approach has been followed using **Jones-Plassmann** algorithm as explained [here](https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/).

#### Implementation Steps:

- Initially we assign random distinct colors to all nodes.
- The vertices of this line graph are divided in equal chunks and assigned to the processes.Each process will color only the vertices belonging to its own subgraph.
- In each step we find all nodes of subgraphs which have the greatest number as its color when compared to all its uncolored neighbours.
- Now we color all the nodes belonging to this set. Each node is assigned the smallest color which has not been assigned to any of its colored neighbours.
- All these updates made in different processes are returned to the root process and the coloring arrays are updated and broadcasted again for next iteration.
- We stop once all our nodes are colored.

## Analysis

- For 80 vertices and 508 edges(random) and 1 processes: Time Taken: 0.026251 seconds
- For 80 vertices and 508 edges(random) and 11 processes: Time Taken: 0.032966 seconds
