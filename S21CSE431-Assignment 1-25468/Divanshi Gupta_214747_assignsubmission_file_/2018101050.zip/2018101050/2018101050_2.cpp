#include <bits/stdc++.h>
using namespace std;
#include <mpi.h>
void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
int partition(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main(int argc, char *argv[])
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    MPI_Init(&argc, &argv);
    int root_rank = 0;
    int size;
    int my_rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    if (root_rank != my_rank)
    {
        int n;
        MPI_Bcast(&n, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        int arr[n + 1];

        MPI_Bcast(&arr, n + 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        int chunk_size = n / size;
        int start = my_rank * chunk_size;
        int end = (my_rank + 1) * (chunk_size);
        if (my_rank == size - 1)
        {
            end = n;
        }
        quickSort(arr, start, end - 1);
        int csize = end - start;
        MPI_Send(arr + start, csize, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
    }

    if (my_rank == root_rank)
    {

        fstream input_file;

        input_file.open(argv[1], ios::in);
        int n;
        input_file >> n;
        MPI_Bcast(&n, 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        int arr[n + 1];
        for (int i = 0; i < n; i++)
        {
            input_file >> arr[i];
        }
        MPI_Bcast(&arr, n + 1, MPI_INT, root_rank, MPI_COMM_WORLD);
        int chunk_size = n / size;
        int start = my_rank * chunk_size;
        int end = (my_rank + 1) * (chunk_size);
        if (my_rank == size - 1)
        {
            end = n;
        }
        quickSort(arr, start, end - 1);
        int start_pointers[size + 1];
        int end_pointers[size + 1];
        start_pointers[0] = 0;
        for (int i = 1; i < size; i++)
        {
            int i_chunk_size = n / size;
            int i_start = i * chunk_size;
            int i_end = (i + 1) * (chunk_size);
            if (i == size - 1)
            {
                i_end = n;
            }
            int isize = i_end - i_start;
            MPI_Recv(arr + i_start, isize, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            start_pointers[i] = i_start;
        }
        for (int i = 0; i < size - 1; i++)
        {
            end_pointers[i] = start_pointers[i + 1];
        }
        end_pointers[size - 1] = n;
        int f = 0;
        int i = 0;
        int sorted_arr[n + 1];
        while (i != n)
        {
            int mi = 1e9;
            int in;
            for (int j = 0; j < size; j++)
            {
                if (start_pointers[j] != -1 && arr[start_pointers[j]] < mi)
                {
                    mi = arr[start_pointers[j]];
                    in = j;
                }
            }
            sorted_arr[i] = arr[start_pointers[in]];
            start_pointers[in] += 1;
            if (start_pointers[in] == end_pointers[in])
            {
                start_pointers[in] = -1;
            }

            i += 1;
        }
        ofstream fout(argv[2]);

        for (int i = 0; i < n; i++)
        {
            fout << sorted_arr[i] << " ";
        }
        fout << endl;
    }
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
