#include <bits/stdc++.h>
using namespace std;
#include <mpi.h>
int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    int n;

    double buffer = 0;
    int root_rank = 0;
    double ans;
    int size = 0;
    int my_rank = 0;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    if (my_rank == root_rank)
    {
        fstream input_file;

        input_file.open(argv[1], ios::in);

        input_file >> n;
    }
    MPI_Bcast(&n, 1, MPI_INT, root_rank, MPI_COMM_WORLD);

    int x = n / size;

    int a = my_rank * x + 1;

    int b = (my_rank + 1) * (x);
    if (my_rank == size - 1)
    {
        b = n;
    }
    for (int i = a; i <= b; i++)
    {
        double k = i * i;
        double f = 1 / k;
        buffer += f;
    }
    MPI_Reduce(&buffer, &ans, 1, MPI_DOUBLE, MPI_SUM, root_rank, MPI_COMM_WORLD);

    if (my_rank == root_rank)
    {
        ofstream fout(argv[2]);
        fout << fixed << setprecision(6) << ans << endl;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
