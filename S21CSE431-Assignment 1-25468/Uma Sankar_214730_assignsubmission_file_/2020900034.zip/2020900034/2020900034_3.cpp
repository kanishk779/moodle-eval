/**
Author: Uma Sankar Yedida
Roll number: 2020900034
Email: uma.sankar@students.iiit.ac.in
*/

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

void initialize(int ***matrix, int V, int defaultValue) {
  
  int* values = (int*) malloc(V * V * sizeof(int));

  (*matrix) = (int**) malloc(V * sizeof(int*));
  int* x = &values[0];
  for (int i = 0; i < V; i++) {
    (*matrix)[i] = x;
    x += (V * sizeof(int));
  }

  for (int i = 0; i < V; i++) {
    for (int j = 0; j < V; j++) {
      (*matrix)[i][j] = defaultValue;
    }
  }
}

int main( int argc, char **argv ) {
  int rank, numprocs;
  int V, E;
  FILE *inputFile = NULL;
  FILE *outputFile = NULL;
  int adj_matrix[1000][1000], coloring[1000][1000];
  int colored[1000];
  int current_vertex;
  int done = 0;

  /* start up MPI */
  MPI_Init( &argc, &argv );

  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
  int iters[numprocs] = {0};

  if (rank == 0) {
    inputFile = fopen(argv[1], "r");
    fscanf(inputFile, "%d", &V);
    fscanf(inputFile, "%d", &E);

    adj_matrix[V][V] = {0};
    coloring[V][V] = {-1};
    colored[V] = {-1};

    for (int i = 0; i < V; i++) {
      for (int j = 0; j < V; j++) {
        coloring[i][j] = -1;
      }
      colored[i] = -1;
    }

    for (int i = 0; i < E; i++) {
      int u, v;
      fscanf(inputFile, "%d", &u);
      fscanf(inputFile, "%d", &v);
      adj_matrix[u - 1][v - 1] = 1;
      adj_matrix[v - 1][u - 1] = 1;
    }

    int process = 1;
    for (int i = 0; i < V; i++) {
      iters[process]++;
      process++;
      if (process == numprocs) {
        process = 1;
      }
    }

    fclose(inputFile);
  }

  MPI_Bcast(&V, 1, MPI_INT, 0, MPI_COMM_WORLD);

  MPI_Bcast(&E, 1, MPI_INT, 0, MPI_COMM_WORLD);

  MPI_Bcast(iters, numprocs, MPI_INT, 0, MPI_COMM_WORLD);

  /*synchronize all processes*/
  MPI_Barrier( MPI_COMM_WORLD );
  double tbeg = MPI_Wtime();

  if (numprocs < 2) {
    printf("2 processes must be used to run this program!!");
  } else {
    if (rank == 0) {
      int p = 1;
      for (int i = 0; i < V; i++) {
        MPI_Send(&i, 1, MPI_INT, p, 0, MPI_COMM_WORLD);
        MPI_Send(colored, V, MPI_INT, p, 0, MPI_COMM_WORLD);

        for (int v = 0; v < V; v++) {
          MPI_Send(&adj_matrix[v], V, MPI_INT, p, 0, MPI_COMM_WORLD);
          MPI_Send(&coloring[v], V, MPI_INT, p, 0, MPI_COMM_WORLD);
        }

        for (int v = 0; v < V; v++) {
          MPI_Recv(&coloring[v], V, MPI_INT, p, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        MPI_Recv(colored, V, MPI_INT, p, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        p++;
        if (p == numprocs) {
          p = 1;
        }
      }
    } else {
      for (int i = 0; i < iters[rank]; i++) {
        int cv;
        int adj_matrix[V][V];
        int coloring[V][V];
        int colored[V];

        MPI_Recv(&cv, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        MPI_Recv(colored, V, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int i = 0; i < V; i++) {
          MPI_Recv(&adj_matrix[i], V, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
          MPI_Recv(&coloring[i], V, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        int color = 1;
        for (int i = 0; i < V; i++) {
          if (adj_matrix[cv][i] == 1) {
            if (colored[cv] == -1 || coloring[cv][i] == -1) {
              if (color < coloring[cv][i]) {
                color = coloring[cv][i];
                continue;
              }
              stmt:
              coloring[i][cv] = coloring[cv][i] = color;
              for (int j = 0; j < V; j++) {
                if (j == i) {
                  continue;
                }
                if (adj_matrix[j][cv] == 1) {
                  if (coloring[j][cv] == coloring[cv][i]) {
                    color++;
                    goto stmt;
                  }
                }
              }
            }
          }
        }
        colored[cv] = 1;

        for (int i = 0; i < V; i++) {
          MPI_Send(&coloring[i], V, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }

        MPI_Send(colored, V, MPI_INT, 0, 0, MPI_COMM_WORLD);
      }
    }
  }

  MPI_Barrier( MPI_COMM_WORLD );
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

  // Write the output to argv[2]
  if (rank == 0) {
      outputFile = fopen(argv[2], "w");
      for (int i = 0; i < V; i++) {
        for (int j = i; j < V; j++) {
          if (coloring[i][j] != -1) {
            fprintf(outputFile, "%d ", coloring[i][j]);
          }
        }
      }
      fclose(outputFile);
      printf( "Total time (s): %f\n", maxTime );
  }

  /* shut down MPI */
  MPI_Finalize();
  return 0;
}
