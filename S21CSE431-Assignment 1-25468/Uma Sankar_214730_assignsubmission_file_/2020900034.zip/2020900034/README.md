# Assignment 1

> Author: Uma Sankar Yedida
>
> Roll numnber: 2020900034
>
> Email: uma.sankar@students.iiit.ac.in
>
> Date: 23rd Jan, 2021

## Problem 1

Used `MPI_Scatter` to scatter the values to all processes. If array is not equally divided by the number of processes, we will pad the excess array indexes with 0.

Once all the processes receives the chunks, they will compute the sum for that chunk.

To produce final result, used `MPI_Reduce` to collect sum from all processes. The root process will write the result to output file.

## Problem 2

Used `MPI_Scatter` to scatter the values to all processes. If array is not equally divided by the number of processes, we will pad the excess array indexes with `INT_MAX`.

Upon receiving of the chunk by a process, it performs `quick_sort` on that chunk and sends it back to root process.

The root process will merge each sub arrays' sent by other processes using `merging two arrays` technique and writes the result to the file.

## Problem 3

Root process sends the adjacency matrix to a process along with the vertex it has to color it's edges, then that process receives the matrix along with the vertex number and all coloring will happen, it sends back the result to the root process and root process repeats this until all vertex edges are colored.
