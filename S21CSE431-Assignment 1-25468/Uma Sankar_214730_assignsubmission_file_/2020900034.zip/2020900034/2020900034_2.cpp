/**
Author: Uma Sankar Yedida
Roll number: 2020900034
Email: uma.sankar@students.iiit.ac.in
*/

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int* merge_two_arrays(int* first, int f, int* second, int s) {
    int* new_array = (int*) malloc((f+s) * sizeof(int));

    int i = 0, j = 0, k = 0;
    while (i < f && j < s) {
        if (first[i] < second[j]) {
            new_array[k++] = first[i++];
        } else {
            new_array[k++] = second[j++];
        }
    }

    while (i < f) {
        new_array[k++] = first[i++];
    }

    while (j < s) {
        new_array[k++] = second[j++];
    }

    return new_array;
}

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partition(int* array, int low, int high) {
    int pivot = array[high];
    int i = (low - 1);
    
    for (int j = low; j <= high - 1; j++) {  
        if (array[j] < pivot) {
            i++;
            swap(&array[i], &array[j]);  
        }
    }
    swap(&array[i + 1], &array[high]);  
    return (i + 1);  
}

void quick_sort(int* array, int low, int high) {
    if (low < high) {
        int pivot = partition(array, low, high);

        quick_sort(array, low, pivot - 1);
        quick_sort(array, pivot + 1, high);
    }
}

int main( int argc, char **argv ) {
    int rank, numprocs;
    int N;
    int *array = NULL;
    int *chunk = NULL;
    int *receive_chunk = NULL;
    FILE *inputFile = NULL;
    FILE *outputFile = NULL;
    int chunk_size, updated_size;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    if (rank == 0) {
        // Read I/P from argv[1]
        inputFile = fopen(argv[1], "r");
        fscanf(inputFile, "%d", &N);

        // Rounding the chunk_size to make sure each chunk gets same length
        // of values as well as never leaving any value behind
        chunk_size = N % numprocs == 0 ? N / numprocs : (N / numprocs) + 1;

        int padding = numprocs * chunk_size;
        array = (int*) malloc(padding * sizeof(int));
        for (int i = 0; i < N; i++) {
            fscanf(inputFile, "%d", &(array[i]));
        }
        fclose(inputFile);

        // Fill the padding values with INT_MAX
        for (int i = N; i < padding; i++) {
            array[i] = INT_MAX;
        }

        cout << endl;
    }

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    // Re-compute the chunk_size in every other process
    chunk_size = N % numprocs == 0 ? N / numprocs : (N / numprocs) + 1;

    chunk = (int*) malloc(chunk_size * sizeof(int));
    MPI_Scatter(
        array, // Send data
        chunk_size, // Send data size
        MPI_INT, // Send datatype
        chunk, // Receive data
        chunk_size, // Receive data size
        MPI_INT, // Receive datatype
        0, // root process id
        MPI_COMM_WORLD // Communicator
    );
    // Once we scatter, we don't need to hold onto the original array
    free(array);
    array = NULL;

    // Perform quick sort on this chunk
    quick_sort(chunk, 0, chunk_size - 1);

    if (rank != 0) {
        // Send the sorted chunks to root process
        // Root process will merge the data
        MPI_Send(chunk, chunk_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    updated_size = chunk_size;
    if (rank == 0) {
        for (int i = 1; i < numprocs; i++) {
            receive_chunk = (int*) malloc(chunk_size * sizeof(int));
            MPI_Recv(receive_chunk, chunk_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            array = merge_two_arrays(chunk, updated_size, receive_chunk, chunk_size);
            updated_size += chunk_size;

            // Free the memory back to the system
            free(receive_chunk);
            free(chunk);
            
            // Overwrite the chunk with the merged array
            chunk = array;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    // Write the output to argv[2]
    if (rank == 0 && chunk != NULL) {
        outputFile = fopen(argv[2], "w");
        // Writing the first element handles one element case
        fprintf(outputFile, "%d", chunk[0]);
        for (int i = 1; i < N; i++) {
            fprintf(outputFile, " %d", chunk[i]);
        }
        fclose(outputFile);

        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
