/**
Author: Uma Sankar Yedida
Roll number: 2020900034
Email: uma.sankar@students.iiit.ac.in
*/

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    int N;
    FILE *inputFile = NULL;
    FILE *outputFile = NULL;
    int chunk_size;
    double *array = NULL;
    double *values = NULL;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    if (rank == 0) {
        // Read I/P from argv[1]
        inputFile = fopen(argv[1], "r");
        fscanf(inputFile, "%d", &N);
        fclose(inputFile);

        chunk_size = N % numprocs == 0 ? N / numprocs : (N / numprocs) + 1;

        int padding = chunk_size * numprocs;
        array = (double*) malloc(padding * sizeof(double));
        for (int i = 0; i < N; i++) {
          array[i] = i + 1;
        }
        for (int i = N; i < padding; i++) {
          array[i] = 0;
        }
    }

    // No need to read the input file for every process
    // Read the inputFile in process 0 and broadcast it to others
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    double result = N > 0 ? 1 : 0;

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    chunk_size = N % numprocs == 0 ? N / numprocs : (N / numprocs) + 1;

    values = (double*) malloc(chunk_size * sizeof(double));
    MPI_Scatter(array, chunk_size, MPI_DOUBLE, values, chunk_size, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    double sum = 0.0;
    for (int i = 0; i < chunk_size; i++) {
      if (values[i] != 0) {
        sum += (1.0 / (values[i] * values[i]));
      }
    }

    MPI_Reduce(&sum, &result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    // Write the output to argv[2]
    if (rank == 0) {
        outputFile = fopen(argv[2], "w");
        fprintf(outputFile, "%0.6f", result);
        fclose(outputFile);

        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
