#include<bits/stdc++.h>
#include<mpi.h>
#include <iomanip>      
using namespace std;
const long double PI = 3.14159265358979323846;
const int mod=1e9+7;
#define re return
#define ll long long
#define fio ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define vi vector<ll>
#define f(x,n,j) for(int i=x;i<n;i+=j)
#define input(a,n) vi a(n); for(int i=0;i<n;i++) cin>>a[i];
#define print(y,n)  for(int i=0;i<n;i++) cout<<y[i]<<" ";
#define vvi vector<vector<ll>>
#define us unordered_set
#define um unordered_map
#define pb push_back
// typedef pii pair<ll,ll>
ll gcd(ll a,ll b){if(!b)re a; re gcd(b,a%b);}
ll fexp(ll a, ll b){ll r=1;while(b){if(b&(ll)1)r*=a;a*=a;b>>=1;}re r;}
bool isInt(double d){double dummy; return modf(d, &dummy) == 0.0;}
// Write program  here

int rf(char* filename){
   int n;
   ifstream ifs(filename);
   string line;
   getline(ifs,line);
   stringstream ss(line);
   ss>>n;
   // cout<<n<<endl;
   return n;
}

void of(double n, char* filename){
      ofstream ofs(filename);
      ofs<<std::setprecision(7)<<n;
}

int main(int argc, char** argv){
	std::setprecision(7);
   
	// cout<<argc<<endl;

	// for(int i=0;i<argc;i++) cout<<argv[i]<<endl;

   int n, proc,rank;
   double result=0, temp=0; 

   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD,&proc);
   MPI_Comm_rank(MPI_COMM_WORLD,&rank);


   MPI_Barrier( MPI_COMM_WORLD );
   double tbeg = MPI_Wtime();

    /* write your code here */

    
   if(rank==0){
   		// n=99;
   		n=rf(argv[1]);
   }
   MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);

   if(n>=proc){
      int x=n/proc;
      int l=rank*x;
      int h=l+x;
      l++;h++;
      // cout<<rank<<l<<h<<endl;
      for(double i=l;i<h;i++){
            double z=i*i;
            z=(double)1/z;
            temp+=z;
            // cout<<z<<endl;
      }
   }else{
      if(rank==0){
         for(double i=1;i<=n;i++){
            double z=i*i;
            z=(double)1/z;
            temp+=z;
         }
      }
   }
   MPI_Reduce(&temp,&result,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
   MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
   // cout.precision(6);
   if(rank==0){
   		// cout<<std::setprecision (7)<<"va:"<<result<<endl;  
   		of(result,argv[2]);
   } 
   MPI_Finalize();
    return 0;
} 
