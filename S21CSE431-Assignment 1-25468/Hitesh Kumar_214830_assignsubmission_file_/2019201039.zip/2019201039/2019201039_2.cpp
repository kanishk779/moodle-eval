#include<bits/stdc++.h>
#include<mpi.h>
using namespace std;
const long double PI = 3.14159265358979323846;
const int mod=1e9+7;
#define re return
#define ll long long
#define fio ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define vi vector<ll>
#define f(x,n,j) for(int i=x;i<n;i+=j)
#define input(a,n) vi a(n); for(int i=0;i<n;i++) cin>>a[i];
#define print(y,n)  for(int i=0;i<n;i++) cout<<y[i]<<" ";
#define vvi vector<vector<ll>>
#define us unordered_set
#define um unordered_map
#define pb push_back
// typedef pii pair<ll,ll>
ll gcd(ll a,ll b){if(!b)re a; re gcd(b,a%b);}
ll fexp(ll a, ll b){ll r=1;while(b){if(b&(ll)1)r*=a;a*=a;b>>=1;}re r;}
bool isInt(double d){double dummy; return modf(d, &dummy) == 0.0;}
// Write program  here
// void print(int *a, int n){
//    for(int i=0;i<n;i++) cout<<a[i]<<" ";
// }

#define max_numb 9

int* rf(int &n,char* filename){

   ifstream ifs(filename);
   string line;
   getline(ifs,line);
   stringstream s(line);
   s>>n;
   getline(ifs,line);
   stringstream ss(line);
   int* a=(int*) malloc(sizeof(int)*n);
   for(int i=0;i<n;i++){
         ss>>a[i];
   }
   return a;
}

void of(int* a, int n, char* filename){
      ofstream ofs(filename);
      for(int i=0;i<n;i++){
         ofs<<a[i]<<" ";
   }
}

int part (int* arr, int low, int high){  
    int pivot = arr[high]; 
    int i = (low - 1); 
  
    for (int j = low; j <= high - 1; j++){  
        if (arr[j] < pivot){  
            i++; 
            swap(arr[i], arr[j]);  
        }  
    }  
    swap(arr[i + 1], arr[high]);  
    return (i + 1);  
}

void quickSort(int* a, int low, int high, int numProc, int rank, int depth){  

   int two=1; 
   int destinationRank=rank+(two<<depth);

   // cout<<"qs# depth:: " <<depth<<" low:: "<<low<<" high:: "<<high<<" rank:: "<<rank<<" numProc:: "<<numProc<<" destinationRank:: "<<destinationRank<<endl;


    if(destinationRank>=numProc){
         sort(a+low,a+((high-low)+1));
         // print(a,((high-low)+1));
         // cout<<endl;

    }else if (low < high){ 
         MPI_Status status1; 
         int pi = part(a, low, high);
         MPI_Send(a+pi+1,high-pi,MPI_INT,destinationRank,(depth+1),MPI_COMM_WORLD);
         quickSort(a,low,pi - 1,numProc,rank,depth+1);
         // cout<<"I am waiting for destinationRank:: "<< destinationRank<<" tag:: "<<depth+1<<" size:: "<<high-pi<<endl;
         MPI_Status status;
         int receivedSize=0;
         MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
         MPI_Get_count(&status, MPI_INT, &receivedSize);

         int source_process = status.MPI_SOURCE;
         int source_tag= status.MPI_TAG;
         
         // cout<<"MPI_Probe results:: destinationRank:: "<< source_process<<" tag:: "<<source_tag<<" size:: "<<receivedSize<<endl;
         
         int x=MPI_Recv(a+pi+1,high-pi,MPI_INT,destinationRank,MPI_ANY_TAG,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
         
         // cout<<"error::"<<x<<MPI_SUCCESS<<endl;
    }  
    // cout<<"rolling back with rank:: "<<rank<<endl;
}

int main(int argc, char** argv){
   
   int n, proc,rank;

   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD,&proc);
   MPI_Comm_rank(MPI_COMM_WORLD,&rank);
   MPI_Barrier( MPI_COMM_WORLD );
   double tbeg = MPI_Wtime();
   if(rank==0){
   		// readfile
      // for(int i=0;i<argc;i++) cout<<argv[i];

      // int a[]={9,3, -11, 100, 4, 6,56,9889,-76,34};
      int n;
      int *a;
      a=rf(n,argv[1]);
      // print(a,n);
      // cout<<endl;
      quickSort(a,0,n-1,proc,rank,0);
      // cout<<"I am here"<<endl;
      // for(int i=0;i<7;i++) cout<<a[i]<<endl;
      // print(a,n);
      // cout<<endl;
      of(a,n,argv[2]);
      for(int i=1;i<proc;i++){
           MPI_Send(a,1,MPI_INT,i,5,MPI_COMM_WORLD); 
      }
   }else{

         MPI_Status status;
         int receivedSize=0;
         MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
         MPI_Get_count(&status, MPI_INT, &receivedSize);

         int source_process = status.MPI_SOURCE;
         int source_tag= status.MPI_TAG;

         // cout<<"#####"<<status.MPI_ERROR<<endl;
         int *a = (int*)malloc(receivedSize * sizeof(int));
         // cout<<endl<<"main else# source:: " <<source_process<<" "<<"tag:: "<<source_tag<<endl;
         MPI_Recv(a, receivedSize, MPI_INT, source_process, source_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
         quickSort(a, 0, receivedSize-1, proc, rank, source_tag);
         // cout<<"I am sending"<<endl;
         MPI_Send(a, receivedSize, MPI_INT, source_process, source_tag, MPI_COMM_WORLD);
         // cout<<"I sent to myRank:: "<< rank<< " source_process:: "<<source_process<<" with tag:: "<<source_tag<<" with size:: "<<receivedSize<<endl;

   }
   
   MPI_Barrier( MPI_COMM_WORLD );
   double elapsedTime = MPI_Wtime() - tbeg;
   double maxTime;
   MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
   MPI_Finalize();
   // cout<<"finalize:: "<<rank<<endl;
    return 0;
} 
