# Question 1
I brodacst n to all nodes and divided it according to their rank. after calculating the result I get back the result, added it using mpi_reduce.

# Question 2 

I modify standard QuickSort algo, as usual we call quicksort agian to left and right respectively, but what I did is rather calling right to itself I sent it to the node which is in network. Same recursive call is happening until you get sorted routine.

Now the challnge is to select the distributed nodes (or destinationRank) for that I used a simple formula.


>![Equations](https://latex.codecogs.com/gif.latex?destinationRank&space;=&space;currentRank&space;&plus;&space;2^{recursiveDepth})

Afterwards It was pretty simple.

# Question 3

I tried the third question but for some input it was working and for some it was not, so I thought of not addiing it as I took the refrence from some paper.
# Refrences
https://ieeexplore.ieee.org/document/6620033
https://www.mpi-inf.mpg.de/fileadmin/inf/d1/teaching/winter15/tods/ToDS_01.pdf 
