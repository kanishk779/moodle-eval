/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include<time.h>
using namespace std;
typedef long long int ll;
#define pb push_back
#define ff first
#define ss second

vector<int> arr;
vector<int> garr;
vector<vector<int>> final;
int partition(vector<int>& v,int l,int r)
{
    int small_pointer=l-1;
    int pivot=v[r];
    int i;
    for(i=l;i<r;i++)
    {
        if(v[i]<=pivot)
        {
            small_pointer++;
            swap(v[small_pointer],v[i]);
        }
    }
    swap(v[small_pointer+1],v[r]);
    return small_pointer+1;
}

int random_partition(vector<int>& v,int l,int r)
{
    srand(time(NULL));
    int rand_pivot=l+ rand()%(r-l);
    swap(v[rand_pivot],v[r]);
    return partition(v,l,r);
}

void quicksort(vector<int>& v, int l, int r)
{
    if(l<r)
    {
        int pivot = random_partition(v,l,r);
        quicksort(v,l,pivot-1);
        quicksort(v,pivot+1,r);
    }
}

vector<int> mergeArrays()
{
    priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>> > q;
    vector<int> ret; //vector to return;

    for(int i=0;i<final.size();i++)
        q.push(make_pair(final[i][0], make_pair(i,0)));
    while(!q.empty())
    {
        int i,j;
        pair<int,pair<int,int>> curr=q.top();
        q.pop();
        i=curr.ss.ff;
        j=curr.ss.ss;
        ret.pb(curr.first);
        int jf=final[i].size();
        if(j+1<jf)
            q.push({final[i][j+1],{i,j+1}});
    }
    return ret;
}
int main( int argc, char **argv ) {
    int rank, numprocs;
    MPI_Status status;
    int start,end,rows,n,nrows;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );

    /* write your code here */
    int root_rank=0;
    if(rank==root_rank)
    {                
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n;     
        arr.resize(n);    
        for(int i = 0; i < n; i++) {
            input_file >> arr[i];
        } 
        input_file.close();
    }
    double tbeg = MPI_Wtime();
    if(rank==root_rank)
    {    
        if(numprocs==1)
        {
            quicksort(arr,0,n-1);
        }
        else
        {
            int sz; //the chunk size
            sz = (n%numprocs==0) ? n/numprocs : n/numprocs+1;  
            // cout<<"sz:"<<sz<<endl;
            quicksort(arr,0,sz-1);
            for(int i=1;i<numprocs;i++)
            {
                start=sz*i;
                if(start+sz-1<n)
                    end=start+sz-1;
                else
                    end=n-1;
                rows=end-start+1;
                MPI_Send(&rows,1,MPI_INT,i,0,MPI_COMM_WORLD);
                // if(i==2)
                //     cout<<start<<" "<<end<<endl;
                if(start<=end)
                    MPI_Send(&arr[start],rows,MPI_INT,i,0,MPI_COMM_WORLD);
            }
            garr.resize(sz);
                        
            vector<int> locd;
            for(int i=0;i<sz;i++)
                locd.push_back(arr[i]);
            final.push_back(locd);
            for(int i=1;i<numprocs;i++)
            {
                start=sz*i;
                if(start+sz-1<n)
                    end=start+sz-1;
                else
                    end=n-1;
                rows=end-start+1;
                if(start<=end)
                {                                        
                    MPI_Recv(&garr[0],rows,MPI_INT,i,0,MPI_COMM_WORLD,&status);                                        
                    vector<int> loc;
                    for(int j=0;j<rows;j++)
                        loc.push_back(garr[j]);
                    final.push_back(loc);                    
                }                
            }            
            arr=mergeArrays();
        }                    
    }
    else
    {
        MPI_Recv(&nrows,1,MPI_INT,0,0,MPI_COMM_WORLD,&status);
            if(nrows>0)
            {                          
                garr.resize(nrows);
                MPI_Recv(&garr[0],nrows,MPI_INT,0,0,MPI_COMM_WORLD,&status);                

                quicksort(garr, 0,nrows-1);                
                MPI_Send(&garr[0],nrows,MPI_INT,0,0,MPI_COMM_WORLD);
            }
    }
    

    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        // for(int i=0;i<n;i++)
        // cout<<arr[i]<<" ";
        // cout<<endl;
        ofstream outfile(argv[2]);
        for(int i=0;i<arr.size();i++)
        {
            outfile<<arr[i]<<" ";
        }
        outfile.close();
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}