PROBLEM-1 :

Description:-
A parallel approach using MPI Broadcast is followed to find sum of the reciprocals of the squares of integer from 1 to N. Integers from 1 to N are divided equally to each process and each process calculates their respective sum of reciprocals of squares and sends the calculated sum to the root process. In the root process all the partial sums from different processes are added together using MPI Reduce and presented as the total sum in the output.

Analysis:-
- For N = 1e4 and 11 processes: Time Taken: 0.000868 seconds


PROBLEM-2 :

Description:-
A parallel approach using MPI is followed to sort given array using quick sort algorithm. Initially input array is divided into equal continous subarrays with size of each subarray depending upon total number of processes. Subarrays are passed to each process where each process sorts their recieved subarrays parallely using quick sort
algorithm. Now after each process sorts its subarray they send back the sorted subarray to root process. Now in the root process these sorted arrays are merged together to output a single array as the answer.

Analysis:-
- For N = 1e6 with random values of array from 0 till 1e9 and 11 processes: Time Taken: 0.9735


PROBLEM-3 :

Description:-
Initially we assign random numbers to each node. Now distribute nodes of original graph to each process equally or in other words divide original graph into subgraphs and pass the subgraph nodes to each process. Each process has task to color its own subgraph but we need to do that parallely so that there are no color conflicts. For this we do this task in iterations. In each iteration first find an independent set of subgraph from nodes which are not colored. Process of finding this independent set is that for all nodes which are not colored choose the ones having node value more than all its uncolored neighbours. This way we make an independent set. Now as it is an independent set we can color all nodes of independent set parallely in each process iteration wise. Color each node of independent set with smallest color not assigned to any of the neighbours this way we ensure that max number of colors used is not more than 1 + Delta of line graph. At the end of each iteration send back colored nodes from each process to root process. In the root process update color array and then broadcast it to all processes for next iteration. When a process finishes coloring all its nodes stop that process and mark it as done so that root process not waits for any communication with this process now.

Analysis:-
- For 100 vertices and 500 edges(random) and 11 processes: Time Taken: 0.045721 seconds