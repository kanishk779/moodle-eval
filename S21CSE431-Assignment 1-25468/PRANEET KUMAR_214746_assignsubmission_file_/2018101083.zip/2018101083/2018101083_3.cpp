/* MPI Program Template */

#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>

using namespace std;
typedef long long int ll;
#define for0(i,n) for(i=0;i<n;i++)
#define for1(i,n) for(i=1;i<=n;i++)
#define forg(i,j,n) for(i=j;i<n;i++)
#define ff first
#define ss second
#define pb push_back
#define mp make_pair

// typedef push_back pb;

    int arr[1002];
    int adj[501][501]={0};
    int col[501]={0};
    int val[501]={0};

int main( int argc, char **argv ) {
    int rank, numprocs,i,j;        
    vector<pair<int,int>>mat;
    int x,y;
    int n,m,sz;
    // memset(adj,0,sizeof(adj));
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
        if(rank==0){                
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n>>m;        
        for0(i,m){
            input_file>>x>>y;
            mat.pb(mp(min(x,y),max(y,x)));            
        }
        int xx,yy;
        int jf=mat.size();
        for0(i,jf){
            y=mat[i].ss;
            x=mat[i].ff;
            val[i+1]=i+1;
            forg(j,i+1,mat.size()){
                    yy=mat[j].ss;
                    xx=mat[j].ff;
                    int ve=0,vf=0;
                    if(x==xx || x==yy || y==xx || y==yy){
                    ve=1;
                    adj[j+1][i+1]=1;vf=1;                    
                    adj[i+1][j+1]=1;vf-=1;
                    }                    

            }
        }
        
        input_file.close();
        
    }


    /* write your code here */
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(adj, ((501)*(501))  , MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(val, ((501))  , MPI_INT, 0, MPI_COMM_WORLD);
    
    int mx;
    sz= (m%numprocs==0) ? m/numprocs : m/numprocs+1;
    int l=(rank*sz)+1;
    int r=l+sz-1;
    if(r>m){
    r=m;
    }
    
    while(1){
        vector<int>ind;
        for(ll i=l;i<=r;++i)
        {
            if(!col[i]){
            int  flag=0;
            for1(j,m){
                if(adj[i][j]!=0)
                {
                    if(col[j]==0 && val[j]>val[i])
                    {
                        flag=1;
                        break;
                    }
                }
            }
            if(!flag)
            {
                set<int>v;
                for1(j,m){
                    if( adj[i][j]!=0 && col[j]!=0)
                            v.insert(col[j]);
                }                
                int k=1;
                for(auto u: v){
                    if(!(u!=k))
                    k++;
                    else
                    break;
                }
                col[i]=k;
                ind.pb(i);
                ind.pb(k);
            }
            }            
        }        
        int ro=ind.size();        
        for0(j,ro)
        arr[j]=ind[j];

        for0(i,numprocs){            
            MPI_Bcast(&ro,1 , MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(arr,ro , MPI_INT, i, MPI_COMM_WORLD);            

            if(!(i==rank))
            {
                for(j=0;j<ro;j+=2)
                col[arr[j]]=arr[j+1];                
            }
            ro=ind.size();
            for0(j,ro)
            arr[j]=ind[j];            

        }
        int cntt=0;
        for1(i,m){
            if(col[i]!=0)
            cntt++;
        }
        if((cntt==m))
            break;
    }
    int vi=0;
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {        
        mx=0;
        for1(i,m)
        mx=max(mx,col[i]);
        ofstream outfile(argv[2]);        
        outfile<<mx<<" ";

        for1(i,m){
        outfile<<col[i]<<" ";
        }        
        outfile.close();

        
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}