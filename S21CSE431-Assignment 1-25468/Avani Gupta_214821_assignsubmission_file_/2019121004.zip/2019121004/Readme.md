## Instructions
mpic++ filename.cpp
mpirun -np 11 a.out input.txt output.txt


# Algorithms


## parallel quicksort
## Coloring

https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/
