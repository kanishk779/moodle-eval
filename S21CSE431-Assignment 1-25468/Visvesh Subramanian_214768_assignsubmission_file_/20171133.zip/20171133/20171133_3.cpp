/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define fn(a) (1/((float)a*(float)a))
#define tag 2001
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
	int rank, numprocs, ierr;

	/* start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	
	/*synchronize all processes*/
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

	/* write your code here */
	char const* const inputFile = argv[1];
	char const* const oututFile = argv[2];
	MPI_Status status;
	int m,colors[500],size,current,node,color,terminate;
	for(int it=0;it<500;it++)
		colors[it]=-1;
	vector<vector<int>> adj;
	if(rank==0)
	{
		int e[501][2],n,i,pivot,u,v;
		string word;
		ifstream file(inputFile);
		getline(file, word, ' ');n=stoi(word);
		getline(file, word);m=stoi(word);
		for(i=0;i<m;i++)
		{
			getline(file, word, ' ');e[i][0]=stoi(word);
			getline(file, word);e[i][1]=stoi(word);
			vector<int> temp;
			adj.push_back(temp);
		}
		file.close();
		for(i=0;i<m;i++)
			for(int j=0;j<m;j++)
				if(i!=j and (e[i][0]==e[j][0] or e[i][1]==e[j][0] or e[i][0]==e[j][1] or e[i][1]==e[j][1]))
					adj[i].push_back(j);
	}
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
	for(int i1=0;i1<m;i1++)
	{
		if(rank==0)
			size=adj[i1].size();
		MPI_Bcast(&size, 1, MPI_INT, 0, MPI_COMM_WORLD);
		if(rank)
		{
			vector<int>temp;
			for(int i2=0;i2<size;i2++)
				temp.push_back(0);
			adj.push_back(temp);
		}
	}
	for(int i1=0;i1<m;i1++)
		MPI_Bcast(adj[i1].data(), adj[i1].size(), MPI_INT, 0, MPI_COMM_WORLD);
	if(rank==0)
	{
		for(int i1=0;i1<m;i1++)
		{
			node=i1;
			MPI_Bcast(&node, 1, MPI_INT, 0, MPI_COMM_WORLD);
			for(int i2=0;i2<=adj[node].size();i2++)
			{
				color=i2;
				MPI_Bcast(&color, 1, MPI_INT, 0, MPI_COMM_WORLD);
				int available=1;
				for(int neigh=rank;neigh<adj[node].size();neigh+=numprocs)
					if(colors[adj[node][neigh]]==color)
					{
						available=0;
						break;
					}
				for(int i3=1;i3<numprocs;i3++)
				{
					int tempavail;
					ierr = MPI_Recv( &tempavail, 1, MPI_INT, i3, tag, MPI_COMM_WORLD, &status);
					if(tempavail==0)
						available=0;
				}
				if(available)
					terminate=1;
				MPI_Bcast(&terminate, 1, MPI_INT, 0, MPI_COMM_WORLD);
				if(terminate)
					break;
			}
			terminate=0;
			colors[node]=color;
			MPI_Bcast(&colors[node], 1, MPI_INT, 0, MPI_COMM_WORLD);
		}
		ofstream file2(oututFile);
		int X=-1;
		for(int i=0;i<m;i++)
			X=max(X,colors[i]);
		file2<<X+1<<endl;
		for(int i=0;i<m;i++)
			file2<<colors[i]<<(i==m-1?'\n':' ');
		file2.close();
	}
	else
	{
		for(int i1=0;i1<m;i1++)
		{
			MPI_Bcast(&node, 1, MPI_INT, 0, MPI_COMM_WORLD);
			while(true)
			{
				MPI_Bcast(&color, 1, MPI_INT, 0, MPI_COMM_WORLD);
				int available=1;
				for(int neigh=rank;neigh<adj[node].size();neigh+=numprocs)
					if(colors[adj[node][neigh]]==color)
					{
						available=0;
						break;
					}
				ierr = MPI_Send( &available, 1, MPI_INT, 0, tag, MPI_COMM_WORLD);
				MPI_Bcast(&terminate, 1, MPI_INT, 0, MPI_COMM_WORLD);
				if(terminate)
					break;
			}
			terminate=0;
			MPI_Bcast(&colors[node], 1, MPI_INT, 0, MPI_COMM_WORLD);
		}
	}
	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}