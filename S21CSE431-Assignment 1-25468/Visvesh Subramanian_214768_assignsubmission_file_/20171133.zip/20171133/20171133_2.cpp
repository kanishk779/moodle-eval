/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define N int(1e6+1)
#define tag 2001
using namespace std;
typedef long long int ll;

void setparent(int parents[11],int left,int right)
{
	if(left==right)
		return;
	if(right==left+2)
		parents[left+1]=parents[left+2]=parents[right];
	int other=(left+right)/2+1;
	parents[other]=left;
	setparent(parents,left,other-1);
	setparent(parents,other,right);
}

int partition(ll a[],int n)
{
	int pivot=rand()%n,j=-1;
	swap(a[pivot],a[n-1]);	
	for(int i=0;i<n;i++)
		if(a[i]<=a[n-1])
			swap(a[i],a[++j]);
	return j;
}

int main( int argc, char **argv ) {
	int rank, numprocs, ierr;

	/* start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	
	/*synchronize all processes*/
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

	/* write your code here */

	char const* const inputFile = argv[1];
	char const* const oututFile = argv[2];
	MPI_Status status;
	time_t t;
	srand((unsigned) time_t(&t));

	/*all nodes read "n" from input file*/
	int n;
	ifstream file(inputFile);
	string word;
	getline(file, word);
    n=stoi(word);
	file.close();

	/*all nodes build heirarchy of nodes to find parent and children*/
	int parents[11],i,j;
	int children[11][5];
	parents[0]=-1;
	setparent(parents,0,numprocs-1);
	for(i=0;i<numprocs;i++)
		children[i][0]=0;
	for(i=0;i<numprocs;i++)
		for(j=numprocs-1;j>=0;j--)
			if(parents[j]==i)
				children[i][++children[i][0]]=j;

	if(rank==0)
	{
		i=0;
		ll a[N];
		ifstream file(inputFile);
		getline(file, word);
		while (getline(file, word, ' '))
			a[i++]=stoi(word);
		file.close();
		int lastindex[5],sendsize[5];
		lastindex[0]=n-1;
		for(int level=1;level<=children[rank][0];level++)
		{
			lastindex[level]=partition(a,lastindex[level-1]+1);
			sendsize[level]=lastindex[level-1]-lastindex[level];
			ierr = MPI_Send( &sendsize[level], 1, MPI_INT, children[rank][level], tag, MPI_COMM_WORLD);
			ierr = MPI_Send( a+lastindex[level]+1, sendsize[level], MPI_LONG, children[rank][level], tag, MPI_COMM_WORLD);
		}
		sort(a,a+1+lastindex[children[rank][0]]);
		cout<<"processes 1  (master) sorts elements: ";
		for(i=0;i<=lastindex[children[rank][0]];i++)
			cout<<a[i]<<(i==lastindex[children[rank][0]]?'\n':',');
		for(int level=children[rank][0];level>=1;level--)
		{
			ll *part=NULL;
			if(sendsize[level])
			{
				part=(ll*)malloc(sendsize[level]*sizeof(ll));
				ierr = MPI_Recv( part, sendsize[level], MPI_LONG, children[rank][level], tag, MPI_COMM_WORLD, &status);
			}
			for(i=0;i<sendsize[level];i++)
				a[i+lastindex[level]+1]=part[i];
		}
		ofstream file2(oututFile);
		for(i=0;i<n;i++)
			file2<<a[i]<<(i==n-1?'\n':' ');
		file2.close();
	}
	else
	{
		int len;
		ll *a=NULL;
		ierr = MPI_Recv( &len, 1, MPI_INT, parents[rank], tag, MPI_COMM_WORLD, &status);
		if(len)
		{
			a=(ll*)malloc(len*sizeof(ll));
			ierr = MPI_Recv( a, len, MPI_LONG, parents[rank], tag, MPI_COMM_WORLD, &status);
		}

		int lastindex[5],sendsize[5];
		lastindex[0]=len-1;
		for(int level=1;level<=children[rank][0];level++)
		{
			if(len==0)
			{
				ierr = MPI_Send( &len, 1, MPI_INT, children[rank][level], tag, MPI_COMM_WORLD);
				continue;
			}
			lastindex[level]=partition(a,lastindex[level-1]+1);
			sendsize[level]=lastindex[level-1]-lastindex[level];
			ierr = MPI_Send( &sendsize[level], 1, MPI_INT, children[rank][level], tag, MPI_COMM_WORLD);
			ierr = MPI_Send( a+lastindex[level]+1, sendsize[level], MPI_LONG, children[rank][level], tag, MPI_COMM_WORLD);
		}
		if(len)
		{
			cout<<"processes "<<rank+1<<" (servant) sorts elements: ";
			for(i=0;i<=lastindex[children[rank][0]];i++)
				cout<<a[i]<<(i==lastindex[children[rank][0]]?'\n':',');
			sort(a,a+1+lastindex[children[rank][0]]);
		}
		else
			cout<<"processes "<<rank+1<<" (servant) is idle\n";
		for(int level=children[rank][0];level>=1;level--)
		{
			ll *part=NULL;
			if(sendsize[level])
			{
				part=(ll*)malloc(sendsize[level]*sizeof(ll));
				ierr = MPI_Recv( part, sendsize[level], MPI_LONG, children[rank][level], tag, MPI_COMM_WORLD, &status);
			}
			for(i=0;i<sendsize[level];i++)
				a[i+lastindex[level]+1]=part[i];
		}
		if(len)
			ierr = MPI_Send( a, len, MPI_LONG, parents[rank], tag, MPI_COMM_WORLD);
	}	

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}