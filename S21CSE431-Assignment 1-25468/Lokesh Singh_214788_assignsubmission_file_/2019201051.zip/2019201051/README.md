A brief report

Q1. An integer N denoting the number of terms in the series that your program has to use.

Sol. Here rank 0 process is our main process which will distribute the task to other process by giving them starting and ending point of the series till which we calculate the sum.

Q2. Given an array of numbers, your task is to return the array in sorted order by implementing parallel quicksort.

Sol. Here rank 0 process will distribute the large array in small chunk of equal size(with help of padding) then each process sort the chunk it has saperately then at last we merge the sorted arrays into a single sorted array.

Q3. Given an undirected graph G, find a proper edge coloring of the graph using Delta(G) + 1 colors or fewer. No 2 adjacent edges should have a same color. Delta(G) is the maximum degree of any vertex in G. 

Sol. Here I have use brute force algorithm of backtracking to find all the edge colors, in this we assign colors to edge in BFS manner and if we find contradicting case we backtrack.


Obervations:-

If task is small and number of process are more then it takes more time as compare to a single process because excution time is less than context switch time.

If task is large and number of process are more then it takes less time as compare to a single process because excution time is more than context switch time.
