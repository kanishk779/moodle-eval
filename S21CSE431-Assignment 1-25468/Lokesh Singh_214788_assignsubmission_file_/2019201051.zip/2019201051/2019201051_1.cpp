#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    

    
    if(rank == 0) {
    int n,i;
    ifstream fin;
    fin.open(argv[1]);

    fin>>n;

    fin.close();

    int p = numprocs-1;

    ld s=0,d;
    d=0;

    if(p==0)
    {
        for(i=1;i<=n;i++)
        {
            d=i*i;
            s+=1/d;
        }
    }
    else
    {
        int x = (n+p-1)/p;
        
        

        int j=1;
        
        
        int a;

        for(i=1;i<=n||j<=p;i+=x)
        {


            if(i>n)
            {
                a=0;
                MPI_Send(&a,1,MPI_INT,j,0,MPI_COMM_WORLD);
                MPI_Send(&a,1,MPI_INT,j,0,MPI_COMM_WORLD);
                j++;
                continue;
            }
            
            
            int limit=i;
            if(limit+(x-1)<=n)
                limit+=(x-1);
            else
                limit=n;

            MPI_Send(&i,1,MPI_INT,j,0,MPI_COMM_WORLD);
            MPI_Send(&limit,1,MPI_INT,j,0,MPI_COMM_WORLD);
            j++;
            

        }

        j=1;
        for(i=1;i<=n&&j<=p;i+=x)
        {
            MPI_Recv(&d, 1, MPI_LONG_DOUBLE, j, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            s+=d;
            j++;
            
        }
    }
    ofstream fout;
    fout.open(argv[2]);    
    fout<< fixed << setprecision( 6 )<<s;
    fout.close();
    }

    else {



        int z,i,a,limit;
        ld s,d;
        s=0;


        MPI_Recv(&a, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&limit, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        z=a;

        if(z==0)
        {
            s=0;
            MPI_Send(&s, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }
        else
        {

            for(z=a;z<=limit;z++)
            {
                d=z*z;
                s+=1.0/d;
                
                
            }
            
            MPI_Send(&s, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}