/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void quick(int * v, int s, int n)
{
  int x, p, i, t;
  
  if (n <= 1)
    return;
 
  x = v[s + n/2];
  
  t = v[s];
  v[s] = v[s+n/2];
  v[s+n/2] = t;
  
  p = s;
  for (i = s+1; i < s+n; i++)
    if (v[i] < x) {
      p++;
      t = v[i];
      v[i] = v[p];
      v[p] = t;
    }
  
  t = v[s];
  v[s] = v[p];
  v[p] = t;
  
  quick(v, s, p-s);
  quick(v, p+1, s+n-p-1);
}


void merge(int * v1,int * v2, int n1 , int n2,int *&result)
{
  
  int i = 0,j=0, k;
  
  for (k = 0; k < n1 + n2; k++) {
    if (i >= n1) {
      result[k] = v2[j];
      j++;
    }
    else if (j >= n2) {
      result[k] = v1[i];
      i++;
    }
    else if (v1[i] < v2[j]) { 
      result[k] = v1[i];
      i++;
    }
    else { 
      result[k] = v2[j];
      j++;
    }
  }
 
}

int main( int argc, char **argv ) {
    int rank, size;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    
    int *arr,*new_arr,*buffer;
    

    ifstream fin;
    fin.open(argv[1]);
    
   
    int n;
    fin>>n;
    int realn=n,act=0;
    int atlast=n;
    
    fin.close();

    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    buffer = new int[size+1];
    if(rank==0)
    {
      ifstream fin;
      fin.open(argv[1]);

      int z;
      fin>>z;

      int x=n%size;
      realn=n;
      if(x<=0)
      {
        arr=new int[n];
      }
      else
      {
        
        z=n+size-x;
        realn=z;
        arr=new int[z];
        for(int i=n;i<z;i++)
          arr[i]=INT_MAX;
      }
      realn=realn/size;
      if(size-x>realn&&x!=0)
      {
        for(int i=0;i<size-2;i++)
        {
          buffer[i]=realn;
        }
        int temp=realn*(size-2);
        buffer[size-2]=n-(temp);
        buffer[size]=1;
        buffer[size-1]=0;
      }
      else
      {
        for(int i=0;i<size-1;i++)
        {
          buffer[i]=realn;
        }
        buffer[size]=0;
        buffer[size-1]=n-realn*(size-1);
        
      }
      for(int i=0;i<n;i++)
      {
        fin>>arr[i];
        //cout<<arr[i]<<" ";
      }
      //cout<<endl;
      fin.close();
      if(size==1)
      {
        quick(arr,0,n);
      }
    }
    MPI_Bcast(buffer,size+1,MPI_INT,0,MPI_COMM_WORLD);
    realn=buffer[0];
    if(buffer[size]==1)
    {
          new_arr= new int[realn];
      MPI_Scatter(arr,realn, MPI_INT,new_arr,realn, MPI_INT, 0, MPI_COMM_WORLD);
      n=realn*(size-1);
      act=buffer[0];
      
      quick(new_arr,0,buffer[rank]);
      size--;
      for(int i=1;i<size;)
      {
        int itr=2*i;
        if(rank%itr!=0)
        {
          
          MPI_Send(new_arr,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
          break;
        }
        if((rank+i)<size)
        { 
          int ss=0;
          int temp=rank+2*i;
          if(realn*temp<=n)
          {
            ss=realn*i;
             
          }     
          else
          {
            ss=n-realn*(rank+i);
          }
          int *nn=new int[ss];
          MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
          
          arr=new int[act+ss];
          merge(new_arr,nn,act,ss,arr);
          new_arr=arr;
          act+=ss;
          
        }
        i=itr;
      }
    }
    else
    {

      new_arr= new int[realn];
      MPI_Barrier(MPI_COMM_WORLD);
      MPI_Scatter(arr,realn, MPI_INT,new_arr,realn, MPI_INT, 0, MPI_COMM_WORLD);
      act=realn;
      if((rank+1)==size){

        quick(new_arr,0,buffer[rank]);
        act=buffer[rank];
        
      }
      else
      {
        quick(new_arr,0,buffer[rank]);

      }
      for(int i=1;i<size;)
      {
        int itr=2*i;
        if(rank%itr!=0)
        {
          MPI_Send(new_arr,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
          break;
        }
       
        if((rank+i)<size)
        { 
          int ss=0;
          int temp=rank+2*i;
          if(realn*temp<=n)
          {
             ss=realn*i;
          }     
          else
          {
            ss=n-realn*(rank+i);
            
          }
          int *nn=new int[ss];
          MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
          
          arr=new int[act+ss];
          merge(new_arr,nn,act,ss,arr);
          act+=ss;
          new_arr=arr;
          
          
        }
        i=itr;
      }
  
    }
    
    MPI_Barrier(MPI_COMM_WORLD);

    
    if(rank==0)
    {
      ofstream fout;
      fout.open(argv[2]);
      for(int i=0;i<atlast;i++)
      {
        fout<<arr[i]<<" ";
      }
      fout<<endl;
      fout.close(); 
    }
   
   
   MPI_Barrier( MPI_COMM_WORLD );
      double elapsedTime = MPI_Wtime() - tbeg;
      double maxTime;
      MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
      if ( rank == 0 ) {
          printf( "Total time (s): %f\n", maxTime );
      }

      /* shut down MPI */
      MPI_Finalize();
      return 0;
  }