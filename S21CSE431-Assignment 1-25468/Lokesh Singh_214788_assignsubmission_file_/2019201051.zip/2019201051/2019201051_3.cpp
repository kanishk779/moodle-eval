/* MPI Prographm Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
   
void colorEdges(int parent, vector<vector<pair<int, int> > >& graph, 
                vector<int>& MColors, vector<bool> &isVisited) 
{ 

	 if (isVisited[parent]) 
        return; 

    queue<int> q; 
     
  
    set<int> setColor;
    setColor.clear(); 
  
    
    isVisited[parent] = true; 
  
    
    for (int i = 0; i < graph[parent].size(); i++) { 
        
        if (MColors[graph[parent][i].second] != -1) 
            setColor.insert(MColors[graph[parent][i].second]); 
        
    } 
    
    for (int i = 0; i < graph[parent].size(); i++) { 
        
        int c=1;
       // cout<<"parent = "<<parent<<"  i=  "<<graph[parent][i].first<<endl;
        
        if (!isVisited[graph[parent][i].first]) 
            q.push(graph[parent][i].first); 
  
        if (MColors[graph[parent][i].second] == -1 ) { 

            
            int x= graph[parent][i].first;

            set<int> st;

            for (int j = 0; j < graph[x].size(); j++) { 
                
                if (MColors[graph[x][j].second] != -1) {

                    setColor.insert(MColors[graph[x][j].second]);
                    st.insert(MColors[graph[x][j].second]);

                }

               
            } 

            while (setColor.find(c) != setColor.end()) 
  
                c++; 
  
            
            MColors[graph[parent][i].second] = c;

           
            setColor.insert(c); 
            c++; 
            for ( auto x:st) { 
                
                    setColor.erase(x); 
                 
            } 

        }
     
    } 
  
    
    while (!q.empty()) { 
        int temp = q.front(); 
        q.pop(); 
  
        colorEdges(temp, graph, MColors, isVisited); 
    } 
  
    return; 
} 
  
int main( int argc, char **argv ) {
    int rank, numprocs;

    
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if(rank==0)
    {
        ifstream fin;
        fin.open(argv[1]);

        set<int> empty; 
      
        vector<vector<pair<int, int> > > graph; 
      
        vector<int> MColors; 
      
        int N; 
        int M; 
        fin>>N>>M;

        //cout<<N<<" "<<M<<endl;

        vector<bool> isVisited(N,false);

        graph.resize(N); 
        MColors.resize(M, -1); 
      
        
        for(int i=0;i<M;i++)
        {
            int x,y;
            fin>>x>>y;
            x--;
            y--;
            graph[x].push_back(make_pair(y, i)); 
            graph[y].push_back(make_pair(x, i)); 
        }

        fin.close();
        
        for(int i=0;i<N;i++)
        {
            if(isVisited[i]==false)
            colorEdges(0, graph, MColors, isVisited); 
        }

        ofstream fout;
        fout.open(argv[2]);
      
        // printing all the M colors 
        fout<<M<<endl;
        for (int i = 0; i < M; i++) 
            fout << MColors[i]  << " "; 
        fout.close();

       
    }
    else
    {

    }
     MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
        if ( rank == 0 ) {
            printf( "Total time (s): %f\n", maxTime );
        }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}