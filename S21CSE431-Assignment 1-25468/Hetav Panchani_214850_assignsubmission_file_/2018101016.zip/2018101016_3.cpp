#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

#define pb push_back
#define mp make_pair

using namespace std;

void set_color(vector<vector<int>> &lgraph, int l, int r, int color[]) {
    while(l<r) {
        set<int> forbid;
        for(int i=0; i<lgraph[l].size(); i++) {
            forbid.insert(color[lgraph[l][i]]);
        }
        for(int i=1; i<forbid.size()+2; i++) {
            if(forbid.find(i) == forbid.end()) {
                color[l] = i;
                break;
            }
        }
        l++;
    }
}

void resolve_conflict(vector<vector<int>> &lgraph, int l, int r, int color[]) {
    while(l<r) {
        if(color[l]) {
            for(int i=0; i<lgraph[l].size(); i++) {
                if(lgraph[l][i] > l && color[lgraph[l][i]] == color[l]) {
                    color[l] = 0; break;
                }
            }
        }
        l++;
    }
}

int main(int argc, char *argv[]) {
    if(argc < 3) {
        cout << "Please provide apropriate arguments" << endl;
        return 0;
    }
    
    MPI_Init(&argc, &argv);

    int my_rank = 0, size = 0, root_rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ifstream infile(argv[1]); 
    int n, m;
    while(!infile.is_open());
    infile >> n >> m;

    vector<vector<int>> graph(n);
    vector<pair<int, int>> list(m);
    vector<vector<int>> lgraph(m);
    for(int i=0; i<m; i++) {
        int u, v; infile >> u >> v; u--; v--;
        graph[u].pb(i); graph[v].pb(i);
        list[i] = mp(u, v);
    }

    infile.close();
    for(int i=0; i<m; i++) {
        for(int j=0; j<graph[list[i].first].size(); j++) 
            if(graph[list[i].first][j] != i) lgraph[i].pb(graph[list[i].first][j]);
    }
    for(int i=0; i<m; i++) {
        for(int j=0; j<graph[list[i].second].size(); j++) 
            if(graph[list[i].second][j] != i) lgraph[i].pb(graph[list[i].second][j]);
    }
    int color[m] = {0};
    int diff = (m+size-1)/size;
    int l = diff*my_rank, r = min(diff*(my_rank+1), m);
    
    if(l >= r) my_rank = -1; 
    
    MPI_Reduce(&my_rank, &size, 1, MPI_INT, MPI_MAX, root_rank, MPI_COMM_WORLD);
    if(my_rank == root_rank) size++;

    if(l >= r) {
        MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

        MPI_Finalize();
        return EXIT_SUCCESS; 
    } 

    if(my_rank == root_rank) {

        int p = 0, q = diff, ll[size], rr[size];
        for(int i=0; i<size; i++) {
            ll[i] = p; rr[i] = min(q, m);
            p += diff; q += diff;            
        }

        while(1) {
            for(int i=1; i<size; i++) MPI_Send(color, m, MPI_INT, i, 0, MPI_COMM_WORLD);

            if(*min_element(color, color+m) != 0) {
                ofstream outfile;
                outfile.open(argv[2]);
                // there should not be any gaps but not sure
                int len = *max_element(color, color+m)+1;
                int encode[len] = {0};
                for(int i=0; i<m; i++) encode[color[i]] = color[i];
                int itr = 1;
                for(int i=1; i<len; i++) {
                    if(encode[i] == 0) continue;
                    encode[i] = 0;
                    while(encode[itr]) itr++; 
                    encode[i] = itr; 
                }
                for(int i=0; i<m; i++) color[i] = encode[color[i]];

                outfile << *max_element(color, color+m) << endl;
                for(int i=0; i<m; i++) outfile << color[i] << ' ';
                outfile << endl;    
                outfile.close();

                // checker
                // for(int i=0; i<m; i++) {
                //     for(int j=0; j<lgraph[i].size(); j++) {
                //         if(color[lgraph[i][j]] == color[i]) {
                //             cout << "PROBLEM\n";
                //         }
                //     }
                // }
                // end_checker

                MPI_Barrier( MPI_COMM_WORLD );
                double elapsedTime = MPI_Wtime() - tbeg;
                double maxTime;
                MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
                printf( "Total time (s): %f\n", maxTime );

                MPI_Finalize();
                return EXIT_SUCCESS;
            }

            set_color(lgraph, l, r, color);

            for(int i=1; i<size; i++) MPI_Recv(color+ll[i], rr[i]-ll[i], MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for(int i=1; i<size; i++) MPI_Send(color, m, MPI_INT, i, 0, MPI_COMM_WORLD);

            resolve_conflict(lgraph, l, r, color);

            for(int i=1; i<size; i++) MPI_Recv(color+ll[i], rr[i]-ll[i], MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }
    else {
        while(1) {
            MPI_Recv(color, m, MPI_INT, root_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
            if(*min_element(color, color+m) != 0) {
                MPI_Barrier( MPI_COMM_WORLD );
                double elapsedTime = MPI_Wtime() - tbeg;
                double maxTime;
                MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

                MPI_Finalize();
                return EXIT_SUCCESS;
            }

            set_color(lgraph, l, r, color);
            
            MPI_Send(color+l, r-l, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
            MPI_Recv(color, m, MPI_INT, root_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            resolve_conflict(lgraph, l, r, color);

            MPI_Send(color+l, r-l, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
