# PROBLEM - 1

### How to run:
```
mpic++ 2018101016_1.cpp
mpirun -np {number_of_processes} ./a.out {path_to_input_file} {path_to_output_file}
```

### Algorithm:
- process all __n__ numbers of the sequence in intervals of size __np__(no. of processes). (__O(n/np)__)    
- each process handles exactly one number of the interval, i.e calculates the square of its inverse and adds it to its __sum__ variable. (__O(1)__)
- after all the numbers are prcoessed __root_process__ sums up all the __sum__ variables using __MPI_Reduce__. (__O(np)__)      
- Time Complexity: __O(n/np + np)__
- Results: 
    - comparison from running with 1 process vs 11 processes:
        - for small value of n: serial is faster because of overhead of parallel.
        - for n > 1e6 : parallel is faster. The time gap increases with the increase in n. 

---
---
# PROBLEM - 2

### How to run:
```
mpic++ 2018101016_2.cpp
mpirun -np {number_of_processes} ./a.out {path_to_input_file} {path_to_output_file}
```

### Algorithm:
- __root_process__ divides the array of size __n__ into __np__(no. of processes) divisions of nearly equal sizes and sends the corresponding intervals to all the processes. (__O(n)__)
- all processes sort their intervals using normal/serial quicksort. (__O( (n/np)*log(n/np) )__)
- __root_process__ recieves all the sorted intervals. (__O(n)__)
- __root_process__ merges all the sorted intervals using min heap. (__O(n*log(np))__)
- Time Complexity: __O( n*log(np) )__
- Results: 
    - comparison from running with 1 process vs 11 processes:
        - for values of n <= 1e6, serial is faster because of high overhead of parallel.
        - in theory, the time complexity of parallel in better by a factor of log(n)/log(np). But to prove this advantage practically, large value of n will be required, which is not possible to check here due to memory constraints.

---
---
# PROBLEM - 3

### How to run:
```
mpic++ 2018101016_3.cpp
mpirun -np {number_of_processes} ./a.out {path_to_input_file} {path_to_output_file}
```

### Algorithm:
- [ __n__ = number of vertices, __m__ = number of edges, __delta__ = max indegree of a vertex in the line graph ]
- Edge coloring of a graph is equivalent to the vertex coloring of its line graph. Thus, first construct the line graph in all processes. (__O(n+m)__)
- divide all the vertices in the new graphs in __np__ parts. Each process will be responsible for coloring one part each. (__O(m)__)
- until a valid coloring is done repeat the following steps:
    - synchronize the color array by communicating with the __root_process__. (__O(m)__)
    - check if the coloring is done and it is valid. (__O(m)__) 
        - if valid : encode the coloring in proper output format, write the output (for __root_process__) and exit. (__O(m)__)
        - else : execute the following steps.
    - set the color greedily for the vertices whose color is unset (only those vertices for which the __current_process__ is responsible for). (__O(m*delta/np)__)
        - By, greedily, I mean assign the lowest color that is available. This ensures that number of colores will not exceed __delta__ + 1. 
    - synchronize the color array by communicating with the __root_process__. (__O(m)__)
    - since, we are assigning colors in parallel, there might be conflicts/invalid colors. For each pair of conflicts, unset the color of the vertice with smaller index. (__O(m*delta/np)__)
        - Note: this ensures that in each iteration at least one edge is validly colored. Thus, the algorithm will terminate in __m__ iterations in the worst case.
    - synchronize the color array by communicating with the __root_process__. (__O(m)__) 
- Time Complexity: (__O(n+m(1+delta/np))__)
- Results: 
    - comparison from running with 1 process vs 11 processes:
        - due to the need of synchronizing the color array at every iteration, the implemented algorithm is not much better than a serial algorithm.
        - practically the serial algorithm is faster in both sparse and dense input graphs. 
            - Note: the implemntation of the algorithm above can definitely be optimized, which can make the parallel program faster. But I have not done so beacuse that would make the code quite complex and i felt it is not needed for our purpose.  
        - for large values of __delta__, theoratically, parallel algorithm should be faster. 