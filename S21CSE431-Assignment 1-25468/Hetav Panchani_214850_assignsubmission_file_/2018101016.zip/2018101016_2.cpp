#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

int my_rank, root_rank=0, size;

void select_pivot(int a[], int n) {
    int l = 0, r = n-1, m = n/2;
    if(a[l] <= max(a[m], a[r]) && a[l] >= min(a[m], a[r])) swap(a[l], a[r]); 
    if(a[m] <= max(a[l], a[r]) && a[m] >= min(a[l], a[r])) swap(a[m], a[r]); 
}

int partition(int a[], int n) {
    select_pivot(a, n);
    int pivot = a[n-1];
    int l=-1;
    for(int r=l+1; r<n-1; r++) {
        if(a[r] < pivot) {
            l++;
            swap(a[l], a[r]);
        }
    }
    swap(a[l+1], a[n-1]);
    return l+1;
}

void qsort(int a[], int n) {
    if(n > 1) {
        int m = partition(a, n);
        qsort(a, m);
        qsort(a+m+1, n-m-1);
    }
}

void merge(int n, int a[], int l[], int r[]) {
    int b[n];
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    for(int j=0; j<size; j++) {
        if(l[j] < r[j]) {
            q.push(make_pair(a[l[j]], j)); l[j]++;
        }
    }
    for(int i=0; i<n; i++) {
        b[i] = q.top().first;
        int temp = q.top().second;
        q.pop();
        if(l[temp] < r[temp]) {
            q.push(make_pair(a[l[temp]], temp)); l[temp]++;
        }
    }
    for(int i=0; i<n; i++) a[i] = b[i];
}

int main(int argc, char*argv[]) {
    if(argc < 3) {
        cout << "Please provide apropriate arguments" << endl;
        return 0;
    }

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if(my_rank == root_rank) {
        ifstream infile(argv[1]); 
        while(!infile.is_open());
        int n;
        infile >> n;
        int a[n];
        for(int i=0; i<n; i++) infile >> a[i];
        infile.close();

        int l[size], r[size];
        int diff = n/size;
        int p=0, q=diff;
        for(int i=0; i<size; i++) {
            l[i] = p; r[i] = q;
            p += diff; q += diff;            
        }
        r[size-1] = n;

        for(int i=1; i<size; i++) {
            int n_ = r[i] - l[i];
            MPI_Send(&n_, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            if(n_ > 0) MPI_Send(a+l[i], n_, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        qsort(a, r[0]);
        for(int i=1; i<size; i++) {
            int n_ = r[i] - l[i];
            if(n_ > 0) MPI_Recv(a+l[i], n_, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        merge(n, a, l, r);

        ofstream outfile;
        outfile.open(argv[2]);
        for(int i=0; i<n; i++) {
            outfile << a[i] << ' ';
            // cout << a[i] << ' ';
        }
        outfile << endl;
        // cout << endl;
        outfile.close();

        MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

        printf( "Total time (s): %f\n", maxTime );
    }
    else {
        int n;
        MPI_Recv(&n, 1, MPI_INT, root_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if(n > 0) {
            int a[n];
            MPI_Recv(a, n, MPI_INT, root_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            qsort(a, n);
            MPI_Send(a, n, MPI_INT, root_rank, 0, MPI_COMM_WORLD);
        }

        MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    }

    MPI_Finalize(); 
    return EXIT_SUCCESS;
}
