#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char *argv[]) {
    if(argc < 3) {
        cout << "Please provide apropriate arguments" << endl;
        return 0;
    }
    
    MPI_Init(&argc, &argv);

    int my_rank = 0, size = 0, root_rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ifstream infile(argv[1]); 
    int n;
    while(!infile.is_open());
    infile >> n;   
    infile.close();

    double reduction_result = 0.0, my_term = 0.0, sum = 0.0;
    for(int i=0; i<((n+size-1)/size); i++) {
        my_term = 1.0/(double)((i*size+my_rank+1)*(i*size+my_rank+1));
        if(i*size+my_rank+1 > n) my_term = 0;
        sum += my_term;
    }
    MPI_Reduce(&sum, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, root_rank, MPI_COMM_WORLD);

    if(my_rank == root_rank) {
        ofstream outfile;
        outfile.open(argv[2]);
        // cout << fixed << setprecision(6) << reduction_result << endl;
        outfile << fixed << setprecision(6) << reduction_result << endl;
        outfile.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    if(my_rank == root_rank) {
        printf( "Total time (s): %f\n", maxTime );
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
