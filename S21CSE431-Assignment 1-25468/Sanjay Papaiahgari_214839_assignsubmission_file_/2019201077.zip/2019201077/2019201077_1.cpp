#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <iomanip> 
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs,n,start,end;
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Status status;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    double sum=0.0,res;
    string file1,file2,line;
    stringstream ss1(argv[argc-2]);
    ss1 >> file1;
    
    stringstream ss2(argv[argc-1]);
    ss2 >> file2;
    ifstream fd;
    ofstream fd1;
    fd.open (file1);
    fd1.open(file2);
    if (fd.is_open())
    {
        while ( getline (fd,line) )
        {
            stringstream ss3(line);
            ss3 >> n;
            break;
        }
        
        fd.close();
    }
	
	if(rank!=0)
	{
		start = ((n*rank)/(numprocs))+1;
		end = (n*(rank+1))/(numprocs);
		for(int i=start;i<=end;i++)
			sum = sum + (1.0/(i*i));
		MPI_Send(&sum,1,MPI_DOUBLE,0,1,MPI_COMM_WORLD);
	}

	else
	{
		float x=0.0;
		for(int i=1;i<=(n/numprocs);i++)
			x = x + (1.0/(i*i));
		for(int j=1;j<numprocs;j++)
		{
			MPI_Recv(&res,1,MPI_DOUBLE,j,1,MPI_COMM_WORLD, &status);
				x = x + res;		
		}
		
		sum=x;
	}
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    
    fd1 << fixed << setprecision(6) << sum;
    fd1.close();
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
