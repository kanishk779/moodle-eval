#   Distributed Systems Assignment 1
## Q1: Estimating pi^2/6
- As the task is to sum 1/i^2 from 1 to n, we divide this task of summing n numbers into subtasks of summing n / num_of_processes each.
- We define a function which will accept two numbers (first & last) as input and return the summation of 1/i^2 from i=first to i=last. 
- The inital process (rank 0) reads the input file to get the value of n and then send the limits across which to do the summation for each other process and sums the result from all of them. 