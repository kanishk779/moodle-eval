#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int * merge(int *v1, int n1, int *v2, int n2);
void swap(int *v, int i, int j);
void qsort(int *v, int left, int right);
int partition(int*,int,int);

void swap(int *v, int i, int j)
{
	int temp=v[i];
    v[i] = v[j];
	v[j] = temp;
}


int * merge(int *arr1, int n1, int *arr2, int n2)
{
	int i=0,j=0,k=0;
	int * result;

	result = (int *)malloc((n1+n2)*sizeof(int));

	
	while(i<n1 && j<n2){
		if(arr1[i]<arr2[j])
			result[k++] = arr1[i++];
			
		else
		  result[k++] = arr2[j++];

    }
		
	if(i==n1)
		while(j<n2)
		 result[k++] = arr2[j++];
		
	else
		while(i<n1)
		 result[k++] = arr1[i++];
		
	return result;
}


int partition(int *arr,int start,int end){
    int i,last;
	if(start>=end)
		return -1;
	swap(arr,start,(start+end)/2);
	last = start;
	for(i=start+1;i<=end;i++)
		if(arr[i]<arr[start])
			swap(arr,++last,i);
	swap(arr,start,last);
    return last;
}

void qsort(int *v, int left, int right)
{
	int pvt=partition(v,left,right);
    if(pvt<0)
        return;
	qsort(v,left,pvt-1);
	qsort(v,pvt+1,right);
}

int main(int argc, char *argv[]) {
    int size;
    int rank;
    const int ROOT = 0; 
    MPI_Status status;
   int N;
   int *data;
    if (argc!=3) {
    fprintf(stderr, "Usage: mpirun -np <num_procs> %s <in_file> <out_file>\n", argv[0]);
    exit(1);
    }

    

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if(rank==0){
         FILE *file=NULL;
        file = fopen(argv[1], "r");
      fscanf(file, "%d", &N);
      data = (int *)malloc(N * sizeof(int));
    for (int i = 0; i < N; i++)
      fscanf(file, "%d", &(data[i]));
    fclose(file);
    }
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    MPI_Bcast(&N, 1, MPI_INT,0,MPI_COMM_WORLD);

    // compute the work distribution
    int remainder = N % size;
    int local_counts[size], offsets[size];
    int sum = 0;
    for (int i = 0; i < size; i++) {
        local_counts[i] = N / size;
        if (remainder > 0) {
            local_counts[i] += 1;
            remainder--;
        }
        offsets[i] = sum;
        sum += local_counts[i];
    }

    int localArray[local_counts[rank]];

  

    MPI_Scatterv(data, local_counts, offsets, MPI_INT, localArray, local_counts[rank], MPI_INT, ROOT, MPI_COMM_WORLD);


   
    qsort(localArray,0,local_counts[rank]-1);
   
     int currentSize;

    if(rank!=0)
         MPI_Send(localArray, local_counts[rank], MPI_INT, 0,0,MPI_COMM_WORLD);
     

    
    else{  currentSize = local_counts[0];
            
              int *totalChunk = localArray;
              
        for(int k=1;k<size;k++)
        {
            //rcv array one by one from each process and merge.
            int *chunk = (int*)malloc(sizeof(int)*local_counts[k]);
             MPI_Recv(chunk, local_counts[k], MPI_INT, k, 0,
             MPI_COMM_WORLD,&status);
                  
            totalChunk = merge(totalChunk,currentSize,chunk,local_counts[k]);
            currentSize+=local_counts[k];

        }
        FILE * fout;

		fout = fopen(argv[2],"w");
		for(int i=0;i<currentSize;i++)
			fprintf(fout,"%d ",totalChunk[i]);
        fprintf(fout,"\n");
		fclose(fout);
        printf("\nParallel QS Done:\n");
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
      
    MPI_Finalize();
    return 0;
}