/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <cstring>
#include <iostream>
#include <iomanip>

using namespace std;
typedef long long int ll;


int readInputFile(string path)
{
    ifstream fin;
    string line; 
    fin.open(path); 
    getline(fin, line);  
    fin.close();
    int ip  = stoi(line);
    return ip;
}

void writeOutputFile(string path,double result)
{
    ofstream fout; 
    fout.open(path);
    fout<<setprecision(6)<<fixed<<result<<endl;
    fout.close();
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    int N = readInputFile(argv[1]);
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    if(rank==0){

        //printf("\n Number of Jobs:%d\n",N);
        //printf("\n Number of Process:%d\n",numprocs);

           int njobs;
           for(int i=1;i<=numprocs-1;i++){
             //P0 sends to each Process from P1...Pn-1 what portion of jobs they'll do.
            
              if(i!=numprocs-1)
                njobs = N/numprocs;
              else
                njobs = N/numprocs + N%numprocs;
            //printf("\nP%d sending %d jobs to P%d\n",0,njobs,i);
             MPI_Send(&njobs, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
           }

           double total_sum = 0;
           njobs = N/numprocs;
        //printf("\n I am P%d and I calculate from %d to %d\n",rank,1,njobs);
           for(int i=1;i<=njobs;i++)
                total_sum += (1.0/pow(i,2));

         //Now receive their part from every other process.
          double total = total_sum;
         for(int i=1;i<=numprocs-1;i++){
            double sum = 0.0;
            MPI_Recv(&sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total+=sum;
         } 
      
        // printf("\n Total series sum is: %lf\n",total);
        writeOutputFile(argv[2],total);

    }
    else{

           double sum=0.0;
           int previous_offset = (rank)*(N/numprocs) +1;
           int nRange;
           MPI_Recv(&nRange, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
           //printf("\nP%d Receiving %d Jobs from P0\n",rank,nRange);
           for(int i=previous_offset;i<=nRange+previous_offset-1;i++)
           {
                sum+=(1/pow(i,2));
           }

           //printf("\n I am P%d and I calculate from %d to %d\n",rank,previous_offset,nRange+previous_offset-1);

           MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}