(1)Problem 1 :  [Solution Approach]
	-	Input is read by Process 0
	-	Based on the N value read, the first N-1 processes get work to make count of N/numProcs terms, where Processes do take care of also the offset of the term they need to start sum from and till what term till they need to take sum.
	Assume N=10 and numProcs=3 so P0 gets to sum series from 1 to 3, P1 from 4 to 6, and P2 from 6 to 10.Last Process gets the remainder of the terms left after division.
	- After each process has computed it's own series sum,they send tir locally computed sum back to P0, which is merged and then result is written onto output file.


(2)Problem 2 : [Solution Approach]
	-	Input is read by Process0.
	-	Each Process computes the elements it will get locally from the global data pool read by Process P0 in step 1.Also, it computes the offset from which these elements will be taken from global data array.
	-	Distribute the Array elements read in step 1, to various processes using scatter_v. So, in case NumElements/NumProcs is not perfectly divisible, 1 process will get the remainder of the elements.
	-	Now every processss sorts it's locally received array in last step, using Quick Sort.
	-	Every process sends it's sorted array back to Process0.
	-	Process0 one by one receives sorted chunks from each remaining N-1 processes and performs merge on them to produce final sorted output.