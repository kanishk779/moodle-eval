#include <bits/stdc++.h>

#include "mpi.h"

using namespace std;

typedef long long int ll;

int main(int argc, char **argv) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /* synchronize all processes */
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    /* BEGIN */

    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " infile outfile" << endl;
        return 1;
    }

    ifstream in(argv[1]);
    ofstream out(argv[2]);

    int n;
    if (rank == 0) {
        in >> n;
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    /**
     * `numprocs` processes, `n` things to distribute
     *
     *  - everyone gets atleast `blocksize`
     *  - first `leftover` get 1 extra
     *
     * how to know from where to start?
     *  - `rank` * `blocksize` atleast
     *  - account for first `leftover` getting extras (`offset`)
     *
     * offset:
     *  - first `leftover` will add `rank` number of elements in excess
     *      because (each rank before them took 1)
     *  - all else will add `leftover`
     */
    int blocksize = n / numprocs, leftover = n % numprocs,
        offset = min(rank, leftover), start = rank * blocksize + offset,
        end = (rank + 1) * blocksize + (rank < leftover) + offset;

    long double x = 0, c, _1 = 1;
    for (int i = start + 1; i < end + 1; i++) {
        c = (i * i);
        x += _1 / c;
    };

    long double sum = 0;
    MPI_Reduce(&x, &sum, 1, MPI_LONG_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    if (rank == 0) out << fixed << setprecision(6) << sum << endl;

    /*  END  */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0,
               MPI_COMM_WORLD);
    if (rank == 0) {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
