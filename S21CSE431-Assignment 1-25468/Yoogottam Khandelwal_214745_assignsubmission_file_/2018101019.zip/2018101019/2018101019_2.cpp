#include <bits/stdc++.h>

#include <functional>
#include <queue>
#include <tuple>
#include <vector>

#include "mpi.h"

using namespace std;

typedef long long int ll;

struct HeapState {
    int val, sourceIdx, arrayIdx, arrayLength;

    bool operator<(const HeapState &a) const { return val < a.val; }
    bool operator>(const HeapState &a) const { return val > a.val; }
    bool operator<=(const HeapState &a) const { return val <= a.val; }
    bool operator>=(const HeapState &a) const { return val >= a.val; }
    bool operator==(const HeapState &a) const { return val == a.val; }
};

/**
 * Min heap specifically tailored for stroring HeapState
 *
 * max capacity, k declared at the beginning
 */
class KHeap {
    int k, insertedCount;
    HeapState *arr;

   public:
    KHeap(int k) {
        this->k = k;
        insertedCount = 0;
        arr = new HeapState[k];
    }

    bool push(HeapState hs) {
        if (insertedCount == k) {
            return false;
        }

        int i = insertedCount, p = (i - 1) >> 1;
        arr[insertedCount++] = hs;
        while (i && arr[p] > arr[i]) {
            swap(arr[p], arr[i]);
            i = p;
            p = (i - 1) >> 1;
        }

        return true;
    }

    HeapState pop() {
        if (insertedCount == 0) {
            // invalid
            return {
                .val = INT_MAX,
                .sourceIdx = INT_MAX,
                .arrayIdx = INT_MAX,
                .arrayLength = INT_MAX,
            };
        }
        if (insertedCount == 1) {
            insertedCount = 0;
            return arr[0];
        }

        HeapState ret = arr[0];

        arr[0] = arr[--insertedCount];
        int curPos = 0;

        while (curPos < insertedCount) {
            int l = (curPos << 1) + 1, r = l + 1, smallest = curPos;

            if (l < insertedCount && arr[l] < arr[smallest]) smallest = l;
            if (r < insertedCount && arr[r] < arr[smallest]) smallest = r;

            if (smallest != curPos) {
                swap(arr[curPos], arr[smallest]);
                curPos = smallest;
            } else {
                break;
            }
        }

        return ret;
    }

    ~KHeap() { delete[] arr; }
};

/**
 * partition helper for quickSort
 *
 * Uses the median of first, mid and last element for pivot
 */
int quickSortPartition(int *arr, int l, int r) {
    int m = (l + r) >> 1, pivotIdx, pivot;

    // find median of l, mid, r
    if (arr[l] > arr[m]) {
        if (arr[l] < arr[r])
            pivotIdx = l;
        else if (arr[r] > arr[m])
            pivotIdx = m;
        else
            pivotIdx = r;
    } else {
        if (arr[m] < arr[r])
            pivotIdx = m;
        else if (arr[r] > arr[l])
            pivotIdx = l;
        else
            pivotIdx = r;
    }

    // use that as pivot
    pivot = arr[pivotIdx];

    // shift pivot to the end
    swap(arr[r], arr[pivotIdx]);
    pivotIdx = r;

    // dont include the pivot for swaps
    r--;

    // actually partition
    while (1) {
        // all these are already at the correct place
        while (l < pivotIdx && arr[l] <= pivot) l++;
        while (r >= l && arr[r] > pivot) r--;

        // now we have something which both left and right don't like
        // i.e., l points to something larger than pivot and r to smaller

        // is that because l and r have crossed the expected pivot position?....
        if (l > r) {
            // pivot is at the end, should swap with larger (which is in l)
            swap(arr[l], arr[pivotIdx]);
            // pivot now at l
            return l;
        };

        // ...or because the elements need swapping?
        swap(arr[l], arr[r]);
    }

    return 0;
}

/**
 * quickSort
 *
 * sorts stuff quickly
 */
void quickSort(int *arr, int l, int r) {
    if (l >= r) return;

    int p = quickSortPartition(arr, l, r);
    quickSort(arr, l, p - 1);
    quickSort(arr, p + 1, r);
}

int main(int argc, char **argv) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /* synchronize all processes */
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    /* BEGIN */

    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " infile outfile" << endl;
        return 1;
    }

    ifstream in(argv[1]);
    ofstream out(argv[2]);

    int n, start = 0, end;
    int *nums;

    if (rank == 0) {
        // get input
        in >> n;
        nums = new int[n];

        for (int i = 0; i < n; i++) in >> nums[i];

        int blocksize = n / numprocs, leftover = n % numprocs;
        end = blocksize + (rank < leftover);

        for (int i = 1; i < numprocs; i++) {
            // `offset`, `blocksize` logic same as from q1
            int offset = min(i, leftover), start = i * blocksize + offset,
                count = blocksize + (i < leftover);

            // send each process how much they'll have to work with...
            MPI_Send(&count, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            // ...and the actual numbers
            MPI_Send(&nums[start], count, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
    } else {
        // get no of elems
        MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // init array
        nums = new int[n];

        end = n;
        // receive actual numbers
        MPI_Recv(nums, n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    quickSort(nums, start, end - 1);

    if (rank == 0) {
        int *sorted = new int[n], cur = 0;
        // my heap will only take first min(n, numprocs) inside itself
        // the last ones anyways never got a slice of the array
        KHeap kh(min(n, numprocs));
        kh.push({
            .val = nums[0],
            .sourceIdx = 0,
            .arrayIdx = 0,
            .arrayLength = end,
        });

        int blocksize = n / numprocs, leftover = n % numprocs;
        for (int i = 1; i < numprocs; i++) {
            int offset = min(i, leftover), start = i * blocksize + offset,
                count = blocksize + (i < leftover);

            MPI_Recv(&nums[start], count, MPI_INT, i, 0, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);

            kh.push({
                .val = nums[start],
                .sourceIdx = start,
                .arrayIdx = 0,
                .arrayLength = count,
            });
        }

        while (cur < n) {
            HeapState hs = kh.pop();
            sorted[cur++] = hs.val;
            hs.arrayIdx++;

            if (hs.arrayIdx == hs.arrayLength)
                hs.val = INT_MAX;
            else
                hs.val = nums[hs.sourceIdx + hs.arrayIdx];

            kh.push(hs);
        }

        for (int i = 0; i < n; i++) out << sorted[i] << " ";
        out << endl;

        delete[] sorted;
    } else {
        MPI_Send(nums, n, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    delete[] nums;

    /*  END  */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0,
               MPI_COMM_WORLD);
    if (rank == 0) {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
