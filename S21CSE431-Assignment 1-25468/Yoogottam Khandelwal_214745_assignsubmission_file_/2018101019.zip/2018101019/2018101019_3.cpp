#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>

#include <cstdio>
#include <fstream>

#include "mpi.h"

using namespace std;

typedef long long int ll;

void recolourVertices(bool* adj, int totalVertices, vector<int>& vertices,
                      int* assignedColours, int delta) {
    bool* isColourUnusable = new bool[delta + 1];

    for (auto vertex : vertices) {
        for (int j = 0; j < delta + 1; j++) isColourUnusable[j] = 0;

        // have to reassign colour for `vertex` :|
        // >= because it's 0 indexed
        if (assignedColours[vertex] >= delta + 1) {
            // checking all vertices in this group
            for (auto neighbour : vertices) {
                // if `neighbour` is adjacent to our vertex
                if (adj[vertex * totalVertices + neighbour] &&
                    // and it has a valid colour
                    assignedColours[neighbour] < delta + 1) {
                    // we can't use it
                    isColourUnusable[assignedColours[neighbour]] = 1;
                }
            }

            for (int j = 0; j < delta + 1; j++) {
                // found a free colour
                if (!isColourUnusable[j]) {
                    assignedColours[vertex] = j;
                    break;
                }
            }
        }
    }

    delete[] isColourUnusable;
}

int main(int argc, char** argv) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /* synchronize all processes */
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    /* BEGIN */

    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " infile outfile" << endl;
        return 1;
    }

    ifstream in(argv[1]);
    ofstream out(argv[2]);

    int m;
    bool* edges;
    int *assignedColours, delta = -1;

    if (rank == 0) {
        int n;
        in >> n >> m;

        vector<pair<int, int>> originalEdges(m);
        for (int i = 0; i < m; i++) {
            int u, v;
            in >> u >> v;
            originalEdges[i] = {u, v};
        }

        edges = new bool[m * m];
        for (int i = 0; i < m * m; i++) edges[i] = 0;

        for (int i = 0; i < m; i++) {
            int _delta = 0;
            for (int j = 0; j < m; j++) {
                if (i == j) continue;

                if (originalEdges[i].first == originalEdges[j].first ||
                    originalEdges[i].first == originalEdges[j].second ||
                    originalEdges[i].second == originalEdges[j].first ||
                    originalEdges[i].second == originalEdges[j].second) {
                    edges[i * m + j] = 1;
                    edges[j * m + i] = 1;
                    _delta++;
                }
            }

            if (_delta > delta) delta = _delta;
        }

        assignedColours = new int[m];
        for (int i = 0; i < m; i++) assignedColours[i] = i;
    }

    // let everyone know how many vertices we are dealing with...
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (rank != 0) {
        edges = new bool[m * m];
        assignedColours = new int[m];
    }
    // ...and the delta...
    MPI_Bcast(&delta, 1, MPI_INT, 0, MPI_COMM_WORLD);
    // ...and the graph itself
    MPI_Bcast(edges, m * m, MPI_CXX_BOOL, 0, MPI_COMM_WORLD);

    while (1) {
        // inform everyone about current state
        MPI_Bcast(assignedColours, m, MPI_INT, 0, MPI_COMM_WORLD);

        // if this was calculated at root and sent, all other processes would've
        // anyways been idle till MPI_Recv
        // this saves me from the overhead of MPI_Send-ing to all processes
        set<int> colours;
        for (int i = 0; i < m; i++) colours.insert(assignedColours[i]);

        // yay
        if (colours.size() <= delta + 1) break;

        int coloursToHandle = colours.size() / numprocs;
        // want the space to reduce ASAP
        //
        // numprocs-- would've made this process slow because each step would
        // reduce any number of colours to delta+1
        //
        // numprocs /= 2 is cool
        while (coloursToHandle < delta + 1) {
            numprocs /= 2;
            coloursToHandle = colours.size() / numprocs;
        }

        // no use of these processes now
        //
        // continue, not break because they will still need to receive the
        // assignedColours BROADCAST
        if (rank >= numprocs) continue;

        // since reading from a set, this will come out sorted
        // `thresholds` mean process i takes < `threshold[i]` colour
        vector<int> thresholds(numprocs);

        int count = 0;
        for (auto col : colours) {
            if (count == coloursToHandle) {
                thresholds.push_back(col);
                count = 0;
            }

            count++;
        }

        // sentinel threshold for the last processor to pick up everything left
        thresholds.push_back(INT_MAX);

        vector<vector<int>> processesVertices(numprocs);
        for (int i = 0; i < m; i++) {
            int j = 0;
            for (; j < numprocs && assignedColours[i] < thresholds[j]; j++)
                ;
            processesVertices[j].push_back(i);
        }

        recolourVertices(edges, m, processesVertices[rank], assignedColours,
                         delta);

        if (rank == 0) {
            int* newColours = new int[m];

            for (int i = 1; i < numprocs; i++) {
                MPI_Recv(newColours, m, MPI_INT, i, 0, MPI_COMM_WORLD,
                         MPI_STATUS_IGNORE);

                // process i handled colours for processesVertices[i]
                // no need to do this for root because its already up to date
                for (auto vertex : processesVertices[i])
                    assignedColours[vertex] = newColours[vertex];
            }

            delete[] newColours;
        } else {
            // send updated colours for vertices to root
            MPI_Send(assignedColours, m, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    if (rank == 0) {
        bool* isColourUsed = new bool[delta + 1];
        for (int i = 0; i < delta + 1; i++) isColourUsed[i] = 0;

        int count = 0;
        for (int i = 0; i < m; i++) {
            count += !isColourUsed[assignedColours[i]];
            isColourUsed[assignedColours[i]] = 1;
        }
        out << count << endl;

        for (int i = 0; i < m; i++) out << assignedColours[i] + 1 << " ";
        out << endl;

        delete[] isColourUsed;
    }

    delete[] edges;
    delete[] assignedColours;

    /*  END  */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0,
               MPI_COMM_WORLD);
    if (rank == 0) {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
