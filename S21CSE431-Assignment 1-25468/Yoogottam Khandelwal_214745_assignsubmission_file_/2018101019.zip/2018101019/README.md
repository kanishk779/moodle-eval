# Assignment 1
Name: Yoogottam Khandelwal  
Roll Number: 2018101019

Terms used in this document:
 - N: number of processors
 - root: process with rank 0

---

## Question 1

### Task
sum (1/i<sup>2</sup>) for i in {1..n}  
### Approach
 - each process takes up atleast `n/N` numbers for summing up
 - the first `n % N` processes sum up an extra number
 - each process calculates from where to start and where to end using it's own rank
### Other details
 - `n` is broadcasted to all processes
 - sum is calculated using `MPI_Reduce`

---

## Question 2
### Task
sort an array, size n using quicksort, distribute the work over all processes
### Approach
 - like Question 1, each process takes up atleast `n/N` numbers for sorting
 - root calculates the amount each process would receive and sends them the **exact slice** of the array they need to sort.
 - After each process sorts it's own slice, they `MPI_Send` it back to root
 - root then uses a K-Heap to perform a K-way merge (here K=N)
### Other details
 - partitioning technique used is median of first,mid,end which makes it harder to deliberately produce a worst case and this is also faster than using an RNG

---

## Question 3
### Task
assign proper edge colouring to a graph G with n edges using <= `delta+1` colours where `delta` is the max degree of a vertex in G's line graph
### Approach
 - vertex colouring is known, need to do edge colouring
 - convert edge -> vertex: construct line graph
 - start with giving each vertex it's own colour (have to reduce `n` to `delta+1`)
 - multiple stages, at each stage root broadcasts the current assigned colours
 - all processes calculate the number of colours still needed to reduce[1]. if less number of processes are required, the higher rank processes 'retire'
 - at each stage, atleast half the number of 'retire', which also means that we are getting closer to the solution
 - each process takes it's set of coloured vertices and reduces the colours needed to `delta+1`
 - after this, root collects the updated colours from all non-retired processes and updates the colours
 - the new state is broadcasted to all
### Other details
 - only root constructs line graph and sends it to all other processes
