   #include <stdio.h>
   #include <mpi.h>
   
   #define  max_rows 100000
   #define send_data_tag 2001
   #define return_data_tag 2002

   double array[max_rows];
   double array2[max_rows];
   
   main(int argc, char **argv) 
   {
      double sum, p_sum;
      MPI_Status status;
      int my_id, root_process, ierr, i, num_rows, num_procs,
         an_id, num_rows_to_receive, avg_rows_per_process, 
         sender, num_rows_received, start_row, end_row, num_rows_to_send;


      ierr = MPI_Init(&argc, &argv);
      
      root_process = 0;
      
      /* find out process ID, and how many processes were started. */
      
      ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
      ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

      if(my_id == root_process) {
         

         printf("please enter the number of numbers to sum: ");
         scanf("%i", &num_rows);
      
         if(num_rows > max_rows) {
            printf("Too many numbers.\n");
            exit(1);
         }

         avg_rows_per_process = num_rows / num_procs;

         /* initialize an array */

         for(i = 1; i <= num_rows; i++) {
            array[i] = (double)(1.0/(double)(i*i));
         }

         /* distribute a portion of the bector to each child process */
   
         for(an_id = 1; an_id < num_procs; an_id++) {
            start_row = an_id*avg_rows_per_process + 1;
            end_row   = (an_id + 1)*avg_rows_per_process;

            if((num_rows - end_row) < avg_rows_per_process)
               end_row = num_rows - 1;

            num_rows_to_send = end_row - start_row + 1;

            ierr = MPI_Send( &num_rows_to_send, 1 , MPI_INT,
                  an_id, send_data_tag, MPI_COMM_WORLD);

            ierr = MPI_Send( &array[start_row], num_rows_to_send, MPI_DOUBLE,
                  an_id, send_data_tag, MPI_COMM_WORLD);
         }

         /* calculate the sum of the values in the segment assigned
          * to the root process */
        
         sum = 0;
         for(i = 0; i < avg_rows_per_process + 1; i++) {
            sum += array[i];   
         } 

         printf("sum %0.6f calculated by root process\n", sum);


         for(an_id = 1; an_id < num_procs; an_id++) {
            
            ierr = MPI_Recv( &p_sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE,
                  return_data_tag, MPI_COMM_WORLD, &status);
  
            sender = status.MPI_SOURCE;

            printf("Partial sum %0.6f returned from process %i\n", p_sum, sender);
     
            sum += p_sum;
         }

         printf("The grand total is: %lf\n", sum);
      }

      else {


         ierr = MPI_Recv( &num_rows_to_receive, 1, MPI_INT, 
               root_process, send_data_tag, MPI_COMM_WORLD, &status);
          
         ierr = MPI_Recv( &array2, num_rows_to_receive, MPI_DOUBLE, 
               root_process, send_data_tag, MPI_COMM_WORLD, &status);

         num_rows_received = num_rows_to_receive;

         /* Calculate the sum of my portion of the array */

         p_sum = 0;
         for(i = 0; i < num_rows_received; i++) {
            p_sum += array2[i];
         }

         /* and finally, send my partial sum to the root process */

         ierr = MPI_Send( &p_sum, 1, MPI_DOUBLE, root_process, 
               return_data_tag, MPI_COMM_WORLD);
      }
      ierr = MPI_Finalize();
   }
