#include <bits/stdc++.h>
#include <mpi.h>

using namespace std;
int cmp(const void *a, const void *b)
{
    int x = *(int *)a;
    int y = *(int *)b;

    return (x - y);
}
int main(int argc, char **argv)
{
    
    int n, rank, id, num, k;
    FILE *fp;
    fp = fopen(argv[1], "rw+");
    fscanf(fp, "%d", &n);
    int ar[n];
    int array[n];
    for (int i = 0; i < n; i++)
        fscanf(fp, "%d", &ar[i]);
    fclose(fp);
    rank = MPI_Init(&argc, &argv);
    rank = MPI_Comm_rank(MPI_COMM_WORLD, &id);
    rank = MPI_Comm_size(MPI_COMM_WORLD, &num);
    k = n / num;
    if (id == 0)
    {
        int sar[num + 1][num];
        int rem = n % num;
        if (num >= n)
        {
            qsort(ar, n, sizeof(int), cmp);
        }
        else
        {
            if (num > 1 && n > num)
            {
                int count = 1;
                for (int i = k + 1; i <= k * num; i += k)
                {
                    MPI_Send(ar + i - 1, k, MPI_INT, count, 0, MPI_COMM_WORLD);
                    count++;
                }
                int tmp[n];
                for (int count = 1; count < num; count++)
                {
                    MPI_Recv(tmp + count * k, k, MPI_INT, count, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    for (int i = 0, j = count * k; i < k; i++, j++)
                        sar[count][i] = tmp[j];
                }
            }
            for (int i = 0; i < k; i++)
            {
                array[i] = ar[i];
            }
            qsort(array, k, sizeof(int), cmp);
            for (int i = 0; i < k; i++)
                sar[0][i] = array[i];
            if (rem != 0)
            {
                int r[rem];
                for (int i = k * num, l = 0; i < n; i++, l++)
                    r[l] = ar[i];
                qsort(r, rem, sizeof(int), cmp);
                for (int i = 0; i < n; i++)
                    sar[num][i] = r[i];
            }

            typedef pair<int, pair<int, int>> pr;
            priority_queue<pr, vector<pr>, greater<pr>> mh;
            for (int i = 0; i < num ; i++)
            {
                mh.push({sar[i][0], {i, 0}});
            }
            if(rem!=0)
            {
                mh.push({sar[num][0],{num,0}});
            }
            int i = 0;
            while (mh.empty() != true)
            {
                pr head = mh.top();

                ar[i] = head.first;
                i++;
                mh.pop();
                if (head.second.first == num)
                {
                    if (head.second.second < rem - 1)
                        mh.push({sar[num][head.second.second + 1], {num, head.second.second + 1}});
                }
                else
                {
                    if (head.second.second < k - 1)
                        mh.push({sar[head.second.first][head.second.second + 1], {head.second.first, head.second.second + 1}});
                }
            }
        }
        fp = fopen(argv[2], "w+");
        for (int i = 0; i < n; i++)
            fprintf(fp, "%d ", ar[i]);
        fclose(fp);
    }
    else
    {
        if (num <= n)
        {
            int arr[k];
            MPI_Recv(arr, k, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            qsort(arr, k, sizeof(int), cmp);
            MPI_Send(arr, k, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }
    rank = MPI_Finalize();
}