#include <bits/stdc++.h>
#include <mpi.h>

int main(int argc, char **argv)
{
    int n, rank, id, num;
    double sum = 0;
    FILE *fp;
    fp = fopen(argv[1], "rw+");
    fscanf(fp, "%d", &n);
    fclose(fp);
    rank = MPI_Init(&argc, &argv);
    rank = MPI_Comm_rank(MPI_COMM_WORLD, &id);
    rank = MPI_Comm_size(MPI_COMM_WORLD, &num);
    if (id == 0)
    {
        if (num > n)
        {
            for (double i = 1; i <= n; i++)
            {
                sum = sum + (double)(1 / (i * i));
            }
        }
        else
        {
            int k = n / num;
            int rem = n % num;
            if (num > 1 && n > num)
            {
                int count = 1;
                for (int i = k + 1; i <= k * num; i += k)
                {
                    int y = i + k - 1;
                    MPI_Send(&i, 1, MPI_INT, count, 0, MPI_COMM_WORLD);
                    MPI_Send(&y, 1, MPI_INT, count, 0, MPI_COMM_WORLD);
                    count++;
                }
            }
            for (double i = 1; i <= k; i++)
            {
                sum = sum + (double)(1 / (i * i));
            }
            if (rem != 0)
            {
                for (double i = k * num + 1; i <= k * num + rem; i++)
                {
                    sum += (double)(1 / (i * i));
                }
            }
            for (int count = 1; count < num; count++)
            {
                double in;
                MPI_Recv(&in, 1, MPI_DOUBLE, count, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                sum = sum + in;
            }
        }
        fp = fopen(argv[2], "w+");
        fprintf(fp, "%f", sum);
        fclose(fp);
    }
    else
    {
        if (num <= n)
        {
            int s, e;
            MPI_Recv(&s, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(&e, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (double i = s; i <= e; i++)
            {
                sum = sum + (double)(1 / (i * i));
            }
            MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }
    }
    rank = MPI_Finalize();
}