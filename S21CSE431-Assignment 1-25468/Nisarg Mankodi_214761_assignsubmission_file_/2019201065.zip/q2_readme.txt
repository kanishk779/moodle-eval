method : 

assuming there are p process and there's N integers in the array. 
I have divided the main array into p sub_arrays with (N/p) elements in each array at max. 
Then each array was assigned to a process. 
Each process will sort the elements of the assigned array with quicksort. 
Each process will send the sorted array to the root process. 

I'd have used K-way merge after that. (the question is incomplete) 
due to time constrains i have have sorted the array on bases of the first element of each sorted subarray. (which does not work). 