#include <stdio.h> 
#include <bits/stdc++.h>
#include <mpi.h>

using namespace std;

void swap (int * , int * );
void partition (int , int); 
void quicksort (int, int, int []); 

int main (int argc, char * argv[] ) {

    int rank, n, numtasks, mem_per_task;

      

    MPI_Init(&argc, &argv); 
    MPI_Comm_size(MPI_COMM_WORLD, &numtasks) ;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    vector<int> temp_array;  
    
    if ( rank == 0 ) {

        ifstream inputfile; 

        inputfile.open (argv[1]); 

        string line; 

        getline (inputfile, line);

        stringstream  lineStream(line); 

        lineStream >> n ; 

        getline (inputfile, line);

        stringstream  lineStream_array(line); 

        int value , input [n] ;

        int s = 0; 
        while(lineStream_array >>value)
        {

            input[s] = value;
            s++;
        } 

   

    mem_per_task = n/(numtasks-1);


    vector < vector < int > > final_vector (numtasks);   

    int root_process [mem_per_task] ;

    for (int i = 0 ; i < mem_per_task ; i ++ ){
        root_process[i] = input[i]; 
    }

    quicksort (0, mem_per_task-1, root_process);

    int i = mem_per_task, j = 1 ; 

    while (i < n){
        vector<int> temp_vec;
        int k = 0;
        while (k < mem_per_task && i < n ) {
            temp_vec.push_back (input[i]);
            k++;
            i++;
        } 



        int new_temp [k] ; 

        for (int l = 0; l < temp_vec.size() ; l++){

            new_temp [l] = temp_vec[l]; 
        }

        // cout << endl;

        MPI_Send (&k, 1, MPI_INT, j, 0, MPI_COMM_WORLD);
        MPI_Send (&new_temp, k, MPI_INT, j, 0, MPI_COMM_WORLD );
        j++;
        
        }

        vector < pair <int, int> > first_entry ; 

        for (int i = 1; i < numtasks; i++ ) {
            int g;

            MPI_Recv (&g, 1, MPI_INT, i, i, MPI_COMM_WORLD , MPI_STATUS_IGNORE) ; 

            final_vector[i].resize (g);

            int temp [g];

            MPI_Recv (&temp, g, MPI_INT, i, i, MPI_COMM_WORLD , MPI_STATUS_IGNORE) ; 


            for (int b = 0 ; b < g ; b ++ ){
                final_vector[i][b] = temp[b];
            }

            
        }

        final_vector[0].resize(mem_per_task);

        for (int i = 0 ; i < mem_per_task ; i ++) {
            final_vector[0][i] = root_process[i];
        }

        for (int i = 0; i < final_vector.size(); i++) {
            first_entry.push_back (make_pair (final_vector[i][0] , i) );
        }


        // for (int i = 0 ; i < first_entry.size() ; i ++) {
        //     cout << first_entry[i].first << first_entry[i].second << endl ;   
        // }

        sort(first_entry.begin(), first_entry.end());



        // for (int i = 0 ; i < first_entry.size() ; i ++) {
        //     cout << first_entry[i].first << first_entry[i].second << endl ;   
        // }

        vector <int> result ; 

        for (int i = 0; i < first_entry.size () ; i ++ ){

            for (j = 0 ; j < final_vector [ first_entry[i].second ].size () ; j ++  ){
                result.push_back (final_vector [ first_entry[i].second ][j] );
            }
        }

        cout << "******final_array******" << endl;  

        for (int i = 0; i < final_vector.size() ; i ++ ) {
            for (int j = 0 ; j < final_vector[i].size(); j++){
                cout << final_vector[i][j] << " " ; 
            }
        } 


        cout << endl << "*******result*************" << endl ; 

        for (int i = 0; i < result.size() ; i ++ ){
            cout << result[i] <<  " " ;
        }

        ofstream outputfile;  

        outputfile.open(argv[2]); 
        
        for (int i = 0 ; i < result.size();  i++) {
            outputfile << result[i] << " "; 
        }
        outputfile.close();
    }  

    // MPI_Bcast(&mem_per_task, 1, MPI_INT, 0, MPI_COMM_WORLD);

    else {
    
        int p;
        
        // cout << "here ?? " << rank << endl;

        MPI_Recv (&p, 1, MPI_INT, 0, 0, MPI_COMM_WORLD , MPI_STATUS_IGNORE) ; 

        // vector <int> po (p,0) ; 

        int po [p];

        // cout << "here __ 1 ?? " << rank << endl;

        MPI_Recv (&po, p, MPI_INT, 0, 0, MPI_COMM_WORLD , MPI_STATUS_IGNORE) ;

        cout << "unsorted array " << rank << " size of array " << p <<endl;

        for (int i = 0 ; i < p; i ++) {
            cout << po [i] << " " ; 
        }

        cout << endl ; 

        quicksort (0, p-1, po);

        cout << endl << "i am the process " << rank << "the sorted array from my part is "<< endl ;

        for (int i = 0 ; i < p ; i ++){
            cout << po [i]  << " "; 
        }

        cout << endl ; 

        MPI_Send (&p, 1, MPI_INT, 0, rank, MPI_COMM_WORLD);

        MPI_Send (&po, p, MPI_INT, 0, rank, MPI_COMM_WORLD);    

    }


    MPI_Finalize ();
    
    return 0;

}


void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 

int partition (int low, int high, int arr[]) 
{ 
    int pivot = arr[high];    
    int i = (low - 1);  
  
    for (int j = low; j <= high- 1; j++) 
    { 

        if (arr[j] <= pivot) 
        { 
            i++; 
            swap(&arr[i], &arr[j]); 
        } 
    } 
    swap(&arr[i + 1], &arr[high]); 
    return (i + 1); 
} 

void quicksort (int low, int high ,int arr[]) {
    
    if (low < high) {

        int pivot = partition (low, high, arr);

        quicksort(low, pivot - 1 ,arr);
        quicksort (pivot + 1, high, arr);
    }
}