method : 

assuming there are p process working at a time with total N integers each process will get at max (N/p) elements. 
each process will add the reciprocate of the squares of the integers assigned to them. and will store the sum.  
And at the I have used MPI_Reduce to add the results.

