#include <mpi.h> 
#include <stdio.h> 
#include <bits/stdc++.h>

#define M_PI 3.14159265358979323846
using namespace std; 
 
int main (int argc, char* argv[]){ 

    int Nprocess, rank, tasksPerProcess; double result = 0.0;

    MPI_Init(&argc, &argv); // Initialization of MPI
    MPI_Comm_size(MPI_COMM_WORLD, &Nprocess) ;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if ( Nprocess == 1 ) {

        ofstream output_file;
        output_file.open (argv[2]);
        output_file << 1 ;
        output_file.close();
        return 0;
    }

    
    int n; double fresult; 

    if(rank == 0) {

        // scanf("%d", &n);
        ifstream input_file;

        input_file.open (argv[1]);

        input_file >> n; 

        

        input_file.close();
        tasksPerProcess = n/(Nprocess-1);
    }

    MPI_Bcast(&tasksPerProcess, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        for(int i = tasksPerProcess*(Nprocess-1)+1; i<=n; i++) {
            result += 1.0/(i*i);
        }
    } 
    else {

        for(int i = tasksPerProcess*(rank-1)+1; i< tasksPerProcess*(rank-1) + 1 + tasksPerProcess; i++) {
            result += 1.0/(i*i);
        }
    }

    MPI_Reduce(&result, &fresult, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {

        ofstream output_file;
        output_file.open (argv[2]);
        output_file << fresult ;
        output_file.close();
        printf("%lf", fresult);
    }

    MPI_Finalize();
    return 0;
}