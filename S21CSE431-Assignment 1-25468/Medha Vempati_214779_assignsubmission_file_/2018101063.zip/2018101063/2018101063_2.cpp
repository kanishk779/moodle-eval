/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <bits/stdc++.h>

using namespace std;

void quicksort(int * v, int s, int n){
  int holder, part, i;
  int temp;

  if (n <= 1)
    return;
  holder = v[s + n/2];
  
  // Swap
  temp = v[s];
  v[s] = v[s+n/2];
  v[s+n/2] = temp;

  part = s;
  for (i = s+1; i < s+n; i++)
    if (v[i] < holder) {
      part++;
      
      // Swap
      temp = v[i];
      v[i] = v[part];
      v[part] = temp;

    }
  
  // Swap
  temp = v[s];
  v[s] = v[part];
  v[part] = temp;

  quicksort(v, s, part-s);
  quicksort(v, part+1, s+n-part-1);
}


int * combine_chunks(int * v1, int n1, int * v2, int n2)
{
  int i = 0, j=0, k=0, l=0;
  int * result = (int *)malloc((n1 + n2) * sizeof(int));
  while(k<n1+n2) {
    if (i >= n1) {
      result[k] = v2[j];
      j++; l++;
    }
    else if (j >= n2) {
      result[k] = v1[i];
      i++; l++;
    }
    else if (v1[i] < v2[j]) {
      result[k] = v1[i];
      i++; l++;
    }
    else { 
      result[k] = v2[j];
      j++; l++;
    }
    k++;
  }
  return result;
}

int main(int argc, char ** argv)
{
    
    int numprocs, rank;
    MPI_Status status;
    double elapsed_time;
    int arr_size, chunk_size, size, recv_chunk_size, step, cond = 0, seq, nums;
    int * arr = NULL, * chunk, * temp;
    FILE * file = NULL;


    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (rank == 0) {
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &arr_size);
        if(arr_size%numprocs!=0){
            chunk_size = arr_size/numprocs+1;
        } 
        else{
            chunk_size = arr_size/numprocs;
        }
        arr = (int *)malloc(numprocs*chunk_size * sizeof(int));
        for (int i = 0; i < arr_size; i++){
            fscanf(file, "%d", &(arr[i]));
        }
        fclose(file);
        for (int i = arr_size; i < numprocs*chunk_size; i++){
            arr[i] = 0;
        }
        nums = arr[0];
    }

    if(cond == 0){
        nums = 0;
    }

    MPI_Bcast(&arr_size, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if(arr_size%numprocs!=0) {
        chunk_size = arr_size/numprocs+1;
    }
    else {
        chunk_size = arr_size/numprocs;
    }

    chunk = (int *)malloc(chunk_size * sizeof(int));
    seq = chunk[0];
    MPI_Scatter(arr, chunk_size, MPI_INT, chunk, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);
    free(arr);
    arr = NULL;

    if (arr_size >= chunk_size * (rank + 1)){
        size = chunk_size;
    } 
    else {
        size = arr_size - chunk_size * rank;
    }
    quicksort(chunk, 0, size);

    step = 1;    
    while (step < numprocs) {

        int checker = 0;
        if (rank % (2*step) != 0) {
            checker = 1;
            MPI_Send(chunk, size, MPI_INT, rank-step, 0, MPI_COMM_WORLD);
            break;
        }

        if (rank+step < numprocs) {
            if(arr_size >= chunk_size * (rank+2*step)){
                recv_chunk_size = chunk_size * step;
            } else{
                recv_chunk_size = arr_size - chunk_size * (rank+step);
            } 

            temp = (int *)malloc(recv_chunk_size * sizeof(int));
            checker = 2;
            MPI_Recv(temp, recv_chunk_size, MPI_INT, rank+step, 0, MPI_COMM_WORLD, &status);
            arr = combine_chunks(chunk, size, temp, recv_chunk_size);

            checker = 2;
            step = 2*step;

            free(chunk);
            free(temp);
        
            chunk = arr;
            size += recv_chunk_size;
        }

        if(checker != 2){
            step = 2*step;
        }
    }


   if (rank == 0) {
        file = fopen(argv[2], "w");
        fprintf(file, "%d\n", size); 
        int i = 0; 

        // ostringstream os;
        // for (int i: chunk) {
        //     os << i;
        // }
    
        // string output_seq(os.str());
        // fprintf(file, "")

        while (i < size){
            fprintf(file, "%d ", chunk[i]);
            i +=1;
        }
        fprintf(file, "\n");
        fclose(file);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

  MPI_Finalize();
  return 0;
}