## Question 1

#### To Run

mpirun -np X 2018101063_1.cpp input_file output_file


#### Code Flow

1. Initalize MPI and synch processes
2. Process 0 reads input from file
3. Broadcast message sent from root process to all other processes about input number
4. In desired sequence, processes parallelly calculate each term
5. Each process sums their respective sums to create partial sums
6. Partial sums are summed 
7. Root process writes final output to output file

## Question 2

#### To Run

mpirun -np X 2018101063_2.cpp input_file output_file

#### Code Flow

1. Initialize MPI and sync processes
2. Root process reads input data
3. Data is broadcasted to other processes
4. Divided into chunks and allocated to different processes
5. Processes indivudually quicksort their chunks
6. Sorted chunks are then merged
7. Final sorted array is output to output file