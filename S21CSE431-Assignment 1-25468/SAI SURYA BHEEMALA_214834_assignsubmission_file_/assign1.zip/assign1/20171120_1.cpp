#include<bits/stdtr1c++.h>
#include <stdio.h>
#include <mpi.h>
using namespace std;
#define max_rows 10000
#define send_data_tag 2001
#define return_data_tag 2002


int main(int argc, char **argv) 
{
    int rank, numprocs,n,ele_per_proc,rec_n,st=0;
    double root_sum=0.0,partial_sum=0.0;
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    if(rank==0)
    {
        fstream inn(argv[1]);
        string word;
        inn>>word;
        n=stoi(word);
        ele_per_proc=n/numprocs;
        for(double i=1;i<=ele_per_proc+(n%numprocs);i++)root_sum+=(1.0/(i*i));
        for(int id=1;id<numprocs;id++)
        {
            st=ele_per_proc+n%numprocs +(id-1)*ele_per_proc+1;
            MPI_Send( &ele_per_proc, 1 , MPI_INT,
                id, send_data_tag, MPI_COMM_WORLD);

            MPI_Send(&st,1, MPI_INT,
                id, send_data_tag, MPI_COMM_WORLD);   
        }
        for(int id=1;id<numprocs;id++)
        {
            MPI_Recv( &partial_sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE,
                return_data_tag, MPI_COMM_WORLD, &status);
            root_sum+=partial_sum;
        }
        ofstream out(argv[2]);
        out<<setprecision(7)<<root_sum;
        out.close();
    }
    else
    {
        MPI_Recv( &rec_n,1, MPI_INT, 
            0, send_data_tag, MPI_COMM_WORLD, &status);
        MPI_Recv( &st,1, MPI_INT, 
            0, send_data_tag, MPI_COMM_WORLD, &status);
    
        partial_sum=0;
        for(double i=st;i<st+rec_n;i++)partial_sum+=(1.0/(i*i));
        MPI_Send( &partial_sum, 1 , MPI_DOUBLE,
                0, return_data_tag, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}