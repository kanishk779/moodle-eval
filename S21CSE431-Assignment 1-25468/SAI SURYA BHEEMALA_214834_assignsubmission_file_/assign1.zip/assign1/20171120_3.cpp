#include<bits/stdtr1c++.h>
#include <stdio.h>
#include <mpi.h>
using namespace std;
#define send_data_tag 2001
#define return_data_tag 2002
int adj[502][502];
int color[502];
int main(int argc, char** argv)
{
    int n,m,rank,numprocs,edgePerProc;
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    if(rank==0)
    {
        fstream inn(argv[1]);
        string nn,mm;
        inn>>nn;inn>>mm;
        n=stoi(nn);m=stoi(mm);
        int a,b,ct=0,ec=0;
        vector<int>v[n+2];
        vector<pair<int,int>>ed(n);
        while(inn>>nn)
        {
            if(ct%2)
            {
                b=stoi(nn);
                v[a].push_back(ec);
                v[b].push_back(ec);
                ec++;
            }
            else a=stoi(nn);
            ct++;
        }
        inn.close();
        for(int i=1;i<=n;i++)
        {
            for(int j=0;j<v[i].size();j++)
            {
                for(int k=j+1;k<v[i].size();k++)adj[v[i][j]][v[i][k]]=adj[v[i][k]][v[i][j]]=1;
            }
        }
        memset(color,0,sizeof(color));
        int temp[502];
        while(1)
        {
            int tm=0;
            for(int i=0;i<m;i++)if(color[i]==0)temp[tm++]=i;
            if(tm==0)break;
            edgePerProc=tm/numprocs;
            for(int ii=0;ii<edgePerProc+tm%numprocs;ii++)
            {
                int i=temp[ii];
                // cout<<i<<" ";
                vector<int>flag(m+1,0);
                for(int j=0;j<m;j++)
                {
                    if(adj[i][j] && color[j]!=0)flag[color[j]]=1;
                }
                int cl=1;
                for(cl=1;cl<=m;cl++)
                {
                    // cout<<cl<<" ";
                    if(!flag[cl])break;
                }
                color[i]=cl;
            }
            for(int i=0;i<m;i++)
            {
                for(int j=i+1;j<m;j++)
                {
                    if(adj[i][j] && color[i]!=0 && color[i]==color[j])color[j]=0;
                }
            }
        }
        int max_=0;
        for(int i=0;i<m;i++)max_=max(max_,color[i]);//cout<<color[i]<<" ";cout<<endl;
        ofstream out(argv[2]);
        out<<max_<<endl;
        for(int i=0;i<m;i++)out<<color[i]<<" ";
        out<<endl;
        out.close();



    }
    else
    {

    }
    MPI_Finalize();
    return 0;
}