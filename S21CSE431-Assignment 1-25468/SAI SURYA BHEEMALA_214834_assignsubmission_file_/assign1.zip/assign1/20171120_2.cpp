#include<bits/stdtr1c++.h>
#include <stdio.h>
#include <mpi.h>
using namespace std;
#define send_data_tag 2001
#define return_data_tag 2002
int arr[1000010];
int partition(int arr[],int n)
{
    int i,j,r=rand()%n;
    swap(arr[r],arr[n-1]);
    for(i=0,j=0;i<n-1;i++)if(arr[i]<arr[n-1])swap(arr[i],arr[j++]);
    swap(arr[j],arr[n-1]);
    return j;
}
int main(int argc, char **argv)
{
    int rank, numprocs,n;
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    if(rank==0)
    {
        fstream inn(argv[1]);
        string nn;
        inn>>nn;
        n=stoi(nn);
        int ct=0;
        while(inn>>nn)arr[ct++]=stoi(nn);
        inn.close();
        // for(int i=0;i<n;i++)cout<<arr[i]<<" ";cout<<endl;
        if(numprocs<=2)sort(arr,arr+n);
        else
        {
            int s1=partition(arr,n),s2=n-s1-1;
            MPI_Send( &s1,     1, MPI_INT,1,send_data_tag, MPI_COMM_WORLD);
            MPI_Send( &arr[0],s1, MPI_INT,1,send_data_tag, MPI_COMM_WORLD);

            MPI_Send( &s2,        1, MPI_INT,2,send_data_tag, MPI_COMM_WORLD);
            MPI_Send( &arr[s1+1],s2, MPI_INT,2,send_data_tag, MPI_COMM_WORLD);

            MPI_Recv( &arr      ,s1, MPI_INT,1,send_data_tag, MPI_COMM_WORLD, &status); 
            MPI_Recv( &arr[s1+1],s2, MPI_INT,2,send_data_tag, MPI_COMM_WORLD, &status);   

            ofstream out(argv[2]);
            for(int i=0;i<n;i++)out<<arr[i]<<" ";out<<endl;          
        }

    }
    else
    {
        int n=0;
        MPI_Recv(&n,1,MPI_INT, 
            (rank-1)/2, send_data_tag, MPI_COMM_WORLD, &status); 
        MPI_Recv( &arr,n, MPI_INT, 
               (rank-1)/2, send_data_tag, MPI_COMM_WORLD, &status); 
        if(n!=0)
        {
            int s1=partition(arr,n),s2=n-s1-1;  
            // cout<<rank<<" "<<n<<" "<<s1<<"->";for(int i=0;i<n;i++)cout<<arr[i]<<" ";cout<<endl; 
            if(rank*2+1<numprocs)
            {
                MPI_Send( &s1,    1 , MPI_INT,rank*2+1,send_data_tag, MPI_COMM_WORLD);
                MPI_Send( &arr[0],s1, MPI_INT,rank*2+1,send_data_tag, MPI_COMM_WORLD); 
                if(rank*2+2<numprocs)
                {
                    MPI_Send( &s2, 1 , MPI_INT,rank*2+2, send_data_tag, MPI_COMM_WORLD);
                    MPI_Send( &arr[s1+1],s2, MPI_INT,rank*2+2, send_data_tag, MPI_COMM_WORLD);     
                }
                else sort(arr+s1+1,arr+s1+s2+1);

            }else sort(arr,arr+n);
            
            if(rank*2+1<numprocs)MPI_Recv( &arr[0],   s1, MPI_INT,rank*2+1, send_data_tag, MPI_COMM_WORLD, &status); 
            if(rank*2+2<numprocs)MPI_Recv( &arr[s1+1],s2, MPI_INT,rank*2+2, send_data_tag, MPI_COMM_WORLD, &status); 

        }
        else
        {
            int s1=0,s2=0;
            if(rank*2+1<numprocs)
            {
                MPI_Send( &s1,     1,MPI_INT,rank*2+1,send_data_tag, MPI_COMM_WORLD);
                MPI_Send( &arr[0],s1,MPI_INT,rank*2+1,send_data_tag, MPI_COMM_WORLD);
            }
            if(rank*2+2<numprocs)
            {
                MPI_Send( &s1    , 1,MPI_INT,rank*2+2,send_data_tag, MPI_COMM_WORLD);
                MPI_Send( &arr[0],s1,MPI_INT,rank*2+2,send_data_tag, MPI_COMM_WORLD);
            }

            if(rank*2+1<numprocs)MPI_Recv( &arr[0],s1, MPI_INT,rank*2+1,send_data_tag, MPI_COMM_WORLD, &status); 
            if(rank*2+2<numprocs)MPI_Recv( &arr[0],s1, MPI_INT,rank*2+2,send_data_tag, MPI_COMM_WORLD, &status); 
        }

        MPI_Send( &arr[0],n, MPI_INT,
            (rank-1)/2, send_data_tag, MPI_COMM_WORLD);

    }
    MPI_Finalize();
    return 0;
}