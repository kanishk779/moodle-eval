/* MPI Program Template */


#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

#define MW MPI_COMM_WORLD

using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) 
{
    int my_id, numprocs,ierr,start,end;
    /* start up MPI */
    ierr=MPI_Init( &argc, &argv );

    ierr= MPI_Comm_rank( MW, &my_id );
    ierr= MPI_Comm_size( MW, &numprocs );
    int N ;


    /*synchronize all processes*/
 
    if(my_id==0)
    {
        std::ifstream f;
        f.open(argv[1]);
        f>>N;
        f.close();
        // cout<<"Number is "<<N<<endl;
        // cin>>N;
        // cout<<N<<endl;
    }
    MPI_Barrier( MW );
    double sum=0,partial_sum=0,tbeg = MPI_Wtime();
    ierr= MPI_Bcast(&N,1,MPI_INT,0,MW);

    int chunks_size = N/numprocs;
    if(N%numprocs!=0)
        chunks_size++;
    start=my_id*chunks_size+1;
    end= min(N,chunks_size*(my_id+1));
    partial_sum=0;
    for(int i=start;i<=end;i++)
        partial_sum+= 1.0/ (i*i);
    // cout<<my_id<<" "<<start<<" "<<end<<" " << partial_sum<<endl;

    ierr = MPI_Reduce(&partial_sum, &sum, 1, MPI_DOUBLE,
            MPI_SUM, 0, MW);

    MPI_Barrier( MW );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    ierr=MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MW );
    if ( my_id == 0 ) 
    {
        printf( "Total time (s): %f\n", maxTime );
        std::ofstream f;
        f.open(argv[2]);
        f << fixed << setprecision(6) << sum<<endl;
        f.close();
    }
    /* shut down MPI */
    ierr=MPI_Finalize();
    return 0;
}

