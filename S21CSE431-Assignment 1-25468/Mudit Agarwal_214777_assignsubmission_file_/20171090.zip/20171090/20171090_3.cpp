/* MPI Program Template */
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define MW MPI_COMM_WORLD
struct pii
{
    int node;
    int color;
};
using namespace std;
typedef long long int ll;
int adj[501][501];
int color[502];
int A[501],B[501];

int main( int argc, char **argv ) 
{
    int my_id, numprocs,ierr,N,M;

    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MW, &my_id );
    MPI_Comm_size( MW, &numprocs );
    
    vector<int> g[101];
    map< pair<int,int>,int > rmp;
    if(my_id==0)
    {
        std::ifstream f;
        f.open(argv[1]);
        f>>N;
        f>>M;
        for(int i=0;i<M;i++)
        {
            int x,y;
            f>>x;
            f>>y;
            g[x].push_back(y);
            g[y].push_back(x);
            rmp[make_pair(x,y)]=i;
            rmp[make_pair(y,x)]=i;
        }
        f.close();

        for(int i=0;i<N;i++)
        {
            for(auto u:g[i])
            {
                for(auto a:g[u])
                {
                    int n1=rmp[make_pair(i,u)];
                    int n2=rmp[make_pair(u,a)];
                    if(n1==n2)
                        continue;
                    adj[n1][n2]=1;
                    adj[n2][n1]=1;
                }
            }
        }
        // for(int i=0;i<M;i++)
        // {
        //     for(int j=0;j<M;j++)
        //         cout<<adj[i][j];
        //     cout<<endl;
        // }
    }
    
    /*synchronize all processes*/
    MPI_Barrier( MW );
    double tbeg = MPI_Wtime();
    /* write your code here */

    ierr= MPI_Bcast(&M,1,MPI_INT,0,MW);
	ierr=MPI_Bcast(adj, 501 * 501, MPI_INT, 0, MW);
    // phase 1    
    int chunks_size = M/numprocs;
    if(M%numprocs!=0)
        chunks_size++;
    int start=my_id*chunks_size;
    int end= min(M,chunks_size*(my_id+1));
    for(int i=start;i<chunks_size*(my_id+1);i++)
    {
        if(i < M)
        {
            set<int> smallest_c;
            for(int j=0;j<M;j++)
            {
                if(adj[i][j])
                {
                    // cout<< i <<"s neightbour " << j<<" ";
                    // cout<<j;
                    if(color[j])
                    {
                        // cout<<j<<" "<<color[j]<<endl;
                        smallest_c.insert(color[j]);
                    }
                }
            }
            // cout<<endl;
            int c=1;
            for( auto it :smallest_c)
            {
                if(it !=c)
                    break;
                c++;
            }
            color[i]=c;
            pii my_value ;
            my_value.node=i;
            my_value.color=c;
            pii buffer[numprocs];
            
            
            MPI_Allgather(&my_value, 1, MPI_2INT, buffer, 1, MPI_2INT, MPI_COMM_WORLD);
            for(int k=0;k<numprocs;k++)
            {
                color[buffer[k].node]=buffer[k].color;
            }
            // cout<<my_id<<" "<<i<<" "<<color[i]<<endl;
        }
        else
        {
            pii my_value ;
            my_value.node=501;
            my_value.color=0;
            pii buffer[numprocs];
            MPI_Allgather(&my_value, 1, MPI_2INT, buffer, 1, MPI_2INT, MPI_COMM_WORLD);
        }
        

        MPI_Barrier( MW );

    }
    for(int i=start;i<end;i++)
    {
        for(int j=0;j<M;j++)
        {
            if(adj[i][j] && (color[i]==color[j]) )
              A[min(i,j)]=1;
        }
    }
    // for(int i=0;i<M;i++)
        // cout<<i<<" " << color[i]<<endl;
    // cout<<"Reduncring"<<endl;
    MPI_Reduce(A, B, M, MPI_INT, MPI_MAX,0,MW); 
    if(my_id==0)
    {
        for(int i=0;i<M;i++)
        {
            if(B[i])
            {
                set<int> smallest_c;
                for(int j=0;j<M;j++)
                {
                    if(adj[i][j])
                        smallest_c.insert(color[j]);
                }
                int c=1;
                for( auto it :smallest_c)
                {
                    if(it !=c)
                        break;
                    c++;
                }
                color[i]=c;
            }
        }  
        int mc=0;
        for(int i=0;i<M;i++)
            mc=max(mc,color[i]);
        std::ofstream f;
        f.open(argv[2]);
        f<<mc<<endl;
        for(int i=0;i<M;i++)
            f<<color[i]<<" ";
        f<<endl;
        f.close();

        // checking 
        // int degree[M],m=0;
        // memset(degree,0,sizeof(degree));
        // for (int i = 0; i < M; ++i) 
		//     for (int j = 0; j < M; ++j)
        //     {
		// 	    degree[i] += adj[i][j];
        //         m=max(m,degree[i]);
        //     } 
        // if(m+1<mc)
        // {
        //     cout<<"Error" <<m+1 << mc<<endl;
        // }
        // for(int i=start;i<end;i++)
        // {
        //     for(int j=0;j<M;j++)
        //     {
        //         if(adj[i][j] && (color[i]==color[j]) )
        //             cout<<"Error"<<endl;
        //     }
        // }
    }


    MPI_Barrier( MW );

    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MW );
    if ( my_id == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}