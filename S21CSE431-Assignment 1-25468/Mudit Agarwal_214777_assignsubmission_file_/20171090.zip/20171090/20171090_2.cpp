/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define MW MPI_COMM_WORLD

using namespace std;
typedef long long int LL;


int cmpfunc (const void * a, const void * b) {
   return ( *(LL*)a - *(LL*)b );
}



int sep(LL *arr, LL l, LL r)
{
    int p1,p2,p3,tp,pivot;
    p1 = rand()%(r-l+1)+l;
    p2 = rand()%(r-l+1)+l;
    p3 = rand()%(r-l+1)+l;
    if(arr[p1]<=arr[p2] &&  arr[p2]<=arr[p3] )
        tp=p2;
    else if(arr[p2]<=arr[p1] &&  arr[p1]<=arr[p3] )
        tp=p1;
    else
        tp=p3;
    swap(arr[tp],arr[r]);
    tp = l;
    for(int i=l;i<r;i++)
        if(arr[i]<arr[r])
            swap(arr[tp++],arr[i]);
    swap(arr[tp],arr[r]);
    return tp;
}

void mqsort(LL *arr, int l, int r)
{
    if(l<r)
    {
        int pivot = sep(arr,l,r);
        mqsort(arr,l,pivot-1);
        mqsort(arr,pivot+1,r);
    }
    return ;
}

LL* merge(LL *c1,int s1,LL *c2,int s2)
{
    int s=s1+s2;
    LL *tmp = (LL*)malloc(s*sizeof(LL));
    int i=0,j=0,k=0;
    while(i<s1 && j <s2 )
    {
        if(c1[i] <  c2[j])
            tmp[k++]=c1[i++];
        else
            tmp[k++]=c2[j++];
    }
    while(i<s1)
        tmp[k++]=c1[i++];
    while(j<s2)
        tmp[k++]=c2[j++];
    return tmp;

}

int main( int argc, char **argv )
{
    int my_id, numprocs;
    LL arr[1000005];

    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MW, &my_id );
    MPI_Comm_size( MW, &numprocs );

    LL temp;
    int N=0,sz=0,M;
    LL *chunk;
    std::ifstream f;
    f.open(argv[1]);
    f>>M;
    while(f>>temp)
    {
        arr[N++]=temp;
    }
    f.close();
    /*synchronize all processes*/
    MPI_Barrier( MW );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    int chunks_size = N/numprocs;
    
    if(N%numprocs!=0)
        chunks_size++;
    if( N < (my_id+1)*chunks_size )
    {
        sz = N- chunks_size*my_id;
        if(sz<=0)
            sz=0;
    }
    else 
        sz=chunks_size;
    chunk = (LL*)malloc(chunks_size*sizeof(LL));
    
    MPI_Scatter(arr, chunks_size, MPI_LONG, chunk, chunks_size, MPI_LONG, 0, MW);
    mqsort(chunk,0,sz-1);    
    // qsort(chunk, sz, sizeof(LL), cmpfunc);
    // cout<< my_id <<endl;
    // for(int i=0;i<sz;i++)
    // {
    //     cout<<chunk[i]<<" ";
    // }
    // cout<<endl;
    
    for(int skip=1;skip<numprocs;skip<<=1)
    {
        int key=2*skip;
        if(  (my_id % key)!=0 )
        {
            // cout<<my_id<<" sending"<<endl;
            MPI_Send(&sz,1,MPI_INT,my_id - skip,0,MW); 
            MPI_Send(chunk,sz,MPI_LONG,my_id - skip,1,MW); 
            break;
        }
        else if( my_id + skip >=numprocs )
        {
            continue;
        }
        else
        {
            // cout<<my_id<<" merging"<<endl;
            int final_sz,r_sz;
            LL *rc,*tmp;
            MPI_Recv(&r_sz,1, MPI_INT, my_id+skip,0, MW, NULL);
            rc = (LL*)malloc(r_sz*sizeof(LL));
            MPI_Recv(rc,r_sz, MPI_LONG, my_id+skip,1, MW, NULL);
            *tmp;
            tmp= merge(chunk,sz,rc,r_sz);
            free(rc);
            free(chunk);
            chunk=tmp;
            sz=sz+r_sz;
            // for(int i=0;i<sz;i++)
                // cout<<chunk[i]<<" ";
            // cout<<"complete"<<endl;
        }
        
    }
    MPI_Barrier( MW );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MW );
    if ( my_id == 0 ) 
    {
        printf( "Total time (s): %f\n", maxTime );
        std::ofstream f;
        f.open(argv[2]);
        for(int i=0;i<N;i++)
            f<<chunk[i]<<" ";
        f<<endl;
        f.close();
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}