# Assignemnt 1 Mpi-Parallel-Algorithms 

*Coded by:* **Mudit Agarwl**


About The Codes
-------------

1. The file named 20171090 contians 3 codes.<br>
    1. Parallel version of numerical identity to calculate $\frac{\pi}{6}$  
    2. Implementing parallel quicksort.  
    3. Parallelized edge coloring  

----------

## Running the program

- First compile
	- `mpic++ 20171090_<#Q_number>.cpp -o 20171090_<#Q_number>`
- Running the program is easy
	- `mpirun -np <number of cores> 20171090_<#Q_number> <input_file> <output_file>`

## Performance
#### For question 1
### Implementation details 

For parallel computation we divided the N in p(no of process) intervals. The sum of the reciprocals of the squares for each interval is calculated parallely in p processes. Then  with the help of MPI_Reduce , we added all the partially calculated partial sums and output the result as our final answer. 

| N |Sequential|Parallelized|
|-------|-----|-----|
|100| 0.000006 |0.000016|
|1000 |0.000024|0.000084|
|10000 |0.000098|0.000089|

We see that as the number N increase the time taken by sequential version increases manifold times but for the parallelized version its not the case. 
For small N the the overhead for parallel computation is large as compared to computation time, but as the value of N increases the overhead is not significant as compared to the computation cost. 



#### For question 2

### Implementation details 

For parallel qsort we divided the array in p (no of process) individual chunks. On each chunk we apply the qsort algorithm parallely in p processes. Now after sorting, we have to merge the p chunks. So to merge chunks parallely we divided the p processes into 2 groups. One grp is the sender group and other is the reciever grp. Each process from the sender grp will send its chunks to the reciever grp. On the reciever end both the chunks are merged into one chunk. (If the number of processes are odd then one grp will be left. He won't sent anything to other and won't recieve anything for this round.) We repeat the above process untill we are left with only one chunk.


| N |Sequential|Parallelized|
|-------|-----|-----|
|1000 |0.000204|0.000155|
|10000 |0.002304|0.00139|
|100000 |0.027558|0.013558|
_______________

We know that sorting is computationaly heavier than calculating sums of square of reciprocal. So because of this we can see the difference between Sequential and parallelized version of qsort for N=1000. The overhead of creating multiple process is negligible as compared to advanytage of using multiple cores for processing our data. As the the value of N increases the difference will be more visible between the two.



#### For question 3

### Implementation details 

For parallelizing the edge coloring of the graph we first converted the original graph into line graph. Then we used "BLOCK PARTITION BASED COLORING" algorithm  to color the nodes of the line graph. It will be same as coloring the edges of the original graph. <br>
The algorithm consists of three phases. In the first phase, the  vertex set V of the line graph is partitioned into p(number of processes) blocks.<br>
### Phase 1 
When coloring a vertex in phase 1, all its previously colored neighbors, both the local ones and those found on other blocks, are taken into account which is followed by a  synchronization barriers at the end of step. Thus the total steps for each paralle will be n/p. <br>

We use the smallest unassigned color to color the vertex v_i. And for for synchronization we use MPI_Barrier at the end of each step and for passing the coloring information MPI_Allgather is used.

### Phase 2
At the end of phase 1, there chances that while coloring in parallel two processors may simultaneously attempt to color vertices that are adjacent to each other. If these vertices are given the same color, the resulting coloring becomes invalid and hence we call the coloring obtained a pseudo coloring.
In this phase, each process pi checks whether vertices in his partition are assigned valid colors by comparing the color of a vertex against all its neighbors that were colored at the same parallel step in the first phase. This checking step is also done in parallel <br>

We initalize a table of size Delta+1/M with 0 for each process pi. We filled tha laocal table  for the  |n/p| vertices which are present in the partition alloted to each process. Then will the help of MPI_Reduce we sent all the tables to the root process with MAX as our MPI_operations.

### Phase 3 
If a conflict is discovered, one of the end points of the edge in conflict is stored in a table. Finally, in the third phase, the vertices stored in this table are colored sequentially <br>

Now the table obtained is to avoid the conflict sequenctially. There is a theorem which bounds the expected number of conflicts created at the end of Phase 1 of Algorithm.  The bound if \frac{\alpha(p-1)}{2}. For proof please refer the following paper "Scalable parallel graph coloring algorithms" 
Time Complexity: O(\delta*n/p)
Number of colors: Bounded from above by \detla + 1



Sequential|Parallelized|
|-----|-----|
|0.004206|0.004032|
|0.001785|0.001485|

_______________



#### 20171090 Mudit Agarwal 