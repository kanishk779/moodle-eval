/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    double reduction_result=0;
    double buffer;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
                                std::ifstream infile("input.txt");
                                string s1;
                                while (infile >> s1)
                                {
                                    int cur=stoi(s1);
                                    int interval=ceil(cur*1.0/numprocs);
                                    // buffer=cur;
                                    int starti=interval*rank+1;
                                    int endi=min((interval)*rank+interval,cur);
                                    cout<<"proc:"<<rank<<":Intv:"<<interval<<":start:"<<starti<<":end:"<<endi<<endl;
                                    double tmp=0;
                                    for(int j =starti; j<=endi; j++){
                                        tmp+=1.0/(j*j);
                                    }
                                    buffer=tmp;
                                    cout<<"tmp:"<<tmp<<endl;
                                }


                        
                                MPI_Reduce(&buffer, &reduction_result,1,MPI_DOUBLE, MPI_SUM,0,MPI_COMM_WORLD);
                                if( rank==0){
                                    // printf("*************\nreduction_result is :%lf\n****************\n",reduction_result );
                                      //write to file
                                    ofstream myfile(argv[2]); 
                                    myfile << to_string(reduction_result)+" " ; 

                                }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}