#include <bits/stdc++.h>
#include <mpi.h>
using namespace std;
double startTime;

void qSort(int * arr, int start, int n)
{
  int pivot;
  int  pivotindex;
  
  if (n <= 1)
    return;
  
  int swapind=start+n/2;
  pivot = arr[swapind];
  
  int tmp=arr[start];
  arr[start]=arr[swapind];
  arr[swapind]=tmp;
  pivotindex = start;
  for (int i = start+1; i < start+n; i++){
    if (arr[i] < pivot) {
      pivotindex++;
      tmp=arr[i];
      arr[i]=arr[pivotindex];
      arr[pivotindex]=tmp;
    }
  }
  tmp=arr[start];
  arr[start]=arr[pivotindex];
  arr[pivotindex]=tmp;
  qSort(arr, start, pivotindex-start);
  qSort(arr, pivotindex+1, start+n-(pivotindex+1));
}


int * mergeArrays(int * v1, int n1, int * v2, int n2)
{
  
  int i = 0;
  int j = 0;
  int index=0;
  int ts=n1+n2;
  int * resultarr = (int *)malloc(ts*sizeof(int));
  while(i<n1 && j< n2){
    if(v1[i]<v2[j]){
      resultarr[index]=v1[i];
      index++;
      i++;
    }else {
      resultarr[index]=v2[j];
      index++;
      j++;
    }
  }
  while(i<n1){
    resultarr[index]=v1[i];
    index++;
    i++;
  }
  while(j<n2){
    resultarr[index]=v2[j];
    index++;
    j++;
  }
  return resultarr;
}

int main(int argc, char ** argv)
{
  int n;
  int * data = NULL;
  int c;
  int * chunk1;
  int chunk2sz;
  int * chunk2;
  int p, id;
  MPI_Status status;
  double elapsed_time;
  FILE * file = NULL;
  int i,nreal;
   int finalsz;
  if (argc!=3) {
    cout<<"give arguments in form of mpirun -np <num_procs> %s <in_file> <out_file>\n";
    exit(1);
  }

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &p);
  MPI_Comm_rank(MPI_COMM_WORLD, &id);

  MPI_Barrier( MPI_COMM_WORLD );

  //start timer
  double tbeg = MPI_Wtime();

  //read input file in data
  if (id == 0) {
    std::ifstream infile("input.txt");
    string s1;
    infile >> s1;
    nreal=stoi(s1);
    n=nreal;
    data = (int *)malloc(n * sizeof(int));
    if(nreal%p!=0){
      c=n/p+1;
    }else{
      c=n/p;
    }
    for(int i =0; i<nreal; i++){
        infile >> s1;
        int cur=stoi(s1);
        data[i]=cur;
    }
    int i =nreal;
    while( i<c*p){
      data[i]=INT_MAX;
      i++;
    }
  }

  // start the timer




  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

  if(n%p==0)
    c=n/p;
  else
    c=n/p+1;

  chunk1 = (int *)malloc(c * sizeof(int));
  MPI_Scatter(data, c, MPI_INT, chunk1, c, MPI_INT, 0, MPI_COMM_WORLD);
  free(data);
  data = NULL;

  
  qSort(chunk1, 0, c);
  // for(int i =0; i<c; i++)
  //   cout<<chunk1[i]<<" ";
  // cout<<endl;

  // compute size of own chunk and sort it
  // s = (n >= c * (id+1)) ? c : n - c * id;
  if(n < c*(id+1) )
     finalsz=n-c*id;
  else
     finalsz=c;
  // up to log_2 p merge steps
  int dist = 1;
  for ( ; dist < p; dist *= 2) {
    int prev=id-dist;
    int next=id+dist;
            // cout<<p<<":"<<step<<":"<<id<<endl<<endl;
    if (id%(dist*2)!=0) {
      // id is no multiple of 2*step: send chunk to id-step and exit loop
            // cout<<"Send from"<<id<<":in:"<<id-step<<endl<<endl;
            // cout<<"Break\n";
      MPI_Send(chunk1,  finalsz, MPI_INT, prev, 0, MPI_COMM_WORLD);
      goto out;
    }
    // id is multiple of 2*step: merge in chunk from id+step (if it exists)
    else  if (p> dist+id) {
      // compute size of chunk to be received
      // o = (n >= c * (id+2*step)) ? c * step : n - c * (id+step);
      if(n<c*(dist*2 + id))
        chunk2sz=n-c*(dist+id);
      else
        chunk2sz=dist*c;
 
      chunk2 = (int *)malloc(chunk2sz*sizeof(int));
      // cout<<"receive from:"<<id+step<<":in:"<<id<<endl<<endl;
      MPI_Recv(chunk2, chunk2sz, MPI_INT, next, 0, MPI_COMM_WORLD, &status);
      
      data = mergeArrays(chunk1,  finalsz, chunk2, chunk2sz);
      
      free(chunk1); free(chunk2);
      chunk1 = data;
      finalsz += chunk2sz;
    }
  }
  out:

  
  //write to file
  if (id == 0) {
    ofstream myfile(argv[2]); 
    for (int i=0 ; i<nreal ; i++ )  {   
        myfile << to_string(chunk1[i])+" " ; 
    }
  }
  
  MPI_Barrier( MPI_COMM_WORLD );
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
  if ( id == 0 ) {
      printf( "Total time (s): %f\n", maxTime );
  }

  
  MPI_Finalize();
  return 0;
}