Problem 1
--------------------------------------------------
Sum of reciprocals of squares of first n numbers
Given num number of processes and n.  I tried to get the average number of (numbers) each process can work upon - that is to get the partial sum of a domain of the numbers.

This is how I implemented the Sum of reciprocals of squares of first n numbers.

Instructiosn to run:
mpic++ first.cpp -o first
mpirun -np x first first_input.txt first_output.txt
(where x represents the number of processes
first_input.txt represents the name of the input file
first_output.txt represents the name of the output file)


Problem 2
----------------------------------------------------------------------

Quick sort
We all know that Quick sort follows divide and conquer policy. Here when we are doing the divide and conquer thing, each time we split the array into left subarray and right subarray after placing the pivot in the right position.
We assign the left subarray to one process and the right subarray to another process. 
Combine both of them in the process where we have split them.

This is how I implemented the paralle Quick sort.

Instructiosn to run:
mpic++ second.cpp -o second
mpirun -np x second second_input.txt second_output.txt
(where x represents the number of processes
second_input.txt represents the name of the input file
second_output.txt represents the name of the output file)




Problem 3
------------------------------------------------------
