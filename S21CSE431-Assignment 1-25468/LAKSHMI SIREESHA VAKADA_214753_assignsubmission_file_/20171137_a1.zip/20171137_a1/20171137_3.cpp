#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    int n,m;
    int edge[m][2];

    if(rank == 0)
    {
        cin >> n >> m;

        for(int i=0; i<m; i++)
            cin >> edge[i][0] >> edge[i][1];
        
        if(m <= 2)
        {   
            if(m == 1)
            {
                cout << "1" << endl;
                cout << "1" <<  endl;
            }
            else if (m == 2)
            {
                if(edge[0][0]!=edge[0][1]!=edge[1][0]!=edge[1][1])
                {
                    cout << "1" << endl;
                    cout << " 1 1" << endl;
                }
                else
                {
                    cout << "2 " << endl;
                    cout << "1 2 " << endl;
                }  
            }
        }
        
        for(int i=0; i<m; i++)
        {
            edge[i][0] -= 1;
            edge[i][1] -= 1;
        }

        // converting to line graph 
        
        int n_new = m ;
        MPI_Bcast(&n_new,1,MPI_INT,0,MPI_COMM_WORLD);


        int adj[n_new][n_new];
        int degree[n_new];
        int final_color[n_new];
        int color_btw[n_new];
        int num_colored = 0;

        for(int i=0; i<n_new; i++)
        {
            final_color[i] = -1;
            degree[i] = 0;
            color_btw[i] = -1;
        }
        
        for(int i=0; i<n_new; i++)
        {
            for(int j=i+1; j<n_new; j++)
            {
                if(!(edge[i][0]!=edge[i][1]!=edge[j][0]!=edge[j][1]))
                {
                    adj[i][j] = 1;
                    adj[j][1] = 1;
                    degree[i]++;
                    degree[j]++;
                }
                else
                    adj[i][j] = 0;  
            }
        }

        int max_degree = degree[0];

        for(int i=0; i<n_new; i++)
            max_degree = max(degree[i], max_degree);
        
        int rem_proc = numprocs-1;
        int num_proc_each = n_new/rem_proc;

        //sending the adjacency matrix for all the remaining processes

        // for(int i= 1; i<=(rem_proc); i++)
        // {
        //     int start_proc = (i-1)*num_proc_each;
        //     int end_proc = (i*num_proc_each);
        //     int proc_tag = 0;
        //     for(int j=start_proc; j<end_proc; j++)
        //     {
        //         MPI_Send(adj[j], n_new, MPI_INT, i, proc_tag, MPI_COMM_WORLD);
        //         c++;
        //     }
        // }



    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}