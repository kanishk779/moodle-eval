#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <vector>
#include <string> 
#include <bits/stdc++.h>

using namespace std;

#define send_tag 10
#define maximum_n 1000001

int pivot_partition(int* array, int low, int high)
{
    int pivot = array[high]; // pivot  
    int i = (low - 1); // Index of smaller element  
  
    for (int j = low; j <= high - 1; j++)  
    {  
        // If current element is smaller than the pivot  
        if (array[j] < pivot)  
        {  
            i++;
            int temp;
            temp = array[i];
            array[i] = array[j];
            array[j] = temp;  
        }  
    }  

    int temp1;
    temp1 = array[i+1];
    array[i+1] = array[high];
    array[high] = temp1;

    // swap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}


void quick_sort(int *array, int low, int high)
{
    // cout  << "low = " << low << " , high = " <<  high << endl;
    if(low < high)
    {
        int index = pivot_partition(array, low, high);
        // cout << "index = " << index <<  endl;
        quick_sort(array, low, index-1);
        quick_sort(array, index+1, high);

    }
}


int main( int argc, char **argv ) 
{

    int rank, numprocs;
    char file_name[220];
    

    MPI_Status status;

    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();


    /* write your code here */

    int n_given = 0;
    int index_of_pivot;
    int a[maximum_n];
    strcpy(file_name,argv[1]);
    // cout << "file name = " << file_name << endl;
    string input;
    
    if(numprocs == 2)
    {
        if(rank == 0)
        {
            int tempp;
            fstream inp(file_name);
            inp>>tempp;
            int count=0;

            n_given = tempp;

            while(inp >> tempp)
            {
                a[count] = tempp;
                count++;
            }
            inp.close();


            index_of_pivot = pivot_partition(&a[0], 0, n_given-1);
            // cout <<"index_of_pivot = " << index_of_pivot << endl;
        }

        MPI_Bcast(&n_given,1,MPI_INT, 0 , MPI_COMM_WORLD);

        if(rank == 0)
        {
            if(index_of_pivot > 0)
                quick_sort(&a[0], 0, index_of_pivot-1);
        }
        else if(rank == 1)
            quick_sort(&a[0], index_of_pivot+1, n_given-1);

    }
    else if(numprocs == 1)
    {
        if(rank == 0)
        {
            int tempp;
            fstream inp(file_name);
            inp>>tempp;
            int count=0;

            n_given = tempp;

            while(inp >> tempp)
            {
                a[count] = tempp;
                count++;
            }
            inp.close();

            index_of_pivot = pivot_partition(&a[0], 0, n_given-1);
        }

        quick_sort(&a[0], 0, n_given-1);


    }
    else if(numprocs > 2)
    {
        /* code */
        if(rank == 0)
        {

            int tempp;
            fstream inp(file_name);
            inp>>tempp;
            int count=0;

            n_given = tempp;

            while(inp >> tempp)
            {
                a[count] = tempp;
                count++;
            }
            inp.close();

            index_of_pivot = pivot_partition(&a[0], 0, n_given-1);
            // cout << "index of pivot = " << index_of_pivot << endl;
        }

        MPI_Bcast(&n_given,1,MPI_INT, 0 , MPI_COMM_WORLD);
	    // MPI_Bcast(&index_of_pivot,1,MPI_INT, 0 , MPI_COMM_WORLD);

        // cout << "broadcasting is also done" << "for " << rank << endl;

        if(rank == 0)
        {
            //sending left array here 
            int le_size = index_of_pivot;
            // cout << "rank 0  le_size " << le_size << endl;

            int ri_size = n_given - index_of_pivot -  1;
            // cout << "rank 0  ri_size " << ri_size << endl;

            MPI_Send(&le_size, 1, MPI_INT, 1, send_tag, MPI_COMM_WORLD);
            MPI_Send(&ri_size, 1, MPI_INT, 2, send_tag, MPI_COMM_WORLD);


                // MPI_Send(&n_given, 1, MPI_INT, 1, send_tag1, MPI_COMM_WORLD );
                
                MPI_Send(&a[0], le_size, MPI_INT, 1, send_tag, MPI_COMM_WORLD);
                MPI_Recv(&a[0], le_size, MPI_INT, 1, send_tag, MPI_COMM_WORLD, &status);

                // cout << "received here from 1" <<  endl;

                // sending the right array here                
                MPI_Send(&a[index_of_pivot+1], ri_size, MPI_INT, 2, send_tag, MPI_COMM_WORLD);
                MPI_Recv(&a[index_of_pivot+1], ri_size, MPI_INT, 2, send_tag, MPI_COMM_WORLD, &status);

                // cout << "received here from 2" <<  endl;


        }
        else
        {
            /* code */
            int source_id = (rank-1)/2;
            int new_n_rece;
            int rece_arr_size;
            int rece_arr[1000];

            // MPI_Recv(&new_n_rece, 1, MPI_INT, source_id, send_tag, MPI_COMM_WORLD, &status);
            MPI_Recv(&rece_arr_size, 1, MPI_INT, source_id, send_tag, MPI_COMM_WORLD, &status);
            // cout << " recec_arr_size = " << rece_arr_size << " , rank = " << rank << endl;


            MPI_Recv(&rece_arr[0], rece_arr_size, MPI_INT, source_id, send_tag, MPI_COMM_WORLD, &status );

            int new_pivot = pivot_partition(&rece_arr[0], 0, rece_arr_size-1);

                // now again parition
            int new_le_size = new_pivot;
            int new_ri_size = rece_arr_size-new_pivot-1;

            if(rece_arr_size == 0)
            {
                new_le_size = 0;
                new_ri_size = 0;
            }

            // cout << "new_le_size = " << new_le_size << " , rank = " << rank << endl;
            // cout << "new_ri_size = " << new_ri_size <<  " , rank = " << rank << endl;


            int left_dest_id = (2*rank)+1;
            int right_dest_id = (2*rank)+2;

            // cout << "here " << rank << endl;

                // 2*x+1 and 2*x+2 processes
            if( (2*rank)+2 == numprocs)
            {
                    // left array will be assigned normally

                MPI_Send(&new_le_size, 1, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD);

                MPI_Send(&rece_arr[0], new_le_size, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD);
                MPI_Recv(&rece_arr[0], new_le_size, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD, &status);

                    // remaining whole process
                quick_sort(&rece_arr[new_pivot+1], 0, new_ri_size-1);

                // cout << " firstone " << rank <<  endl;

            }
            else if( numprocs > (2*rank + 1) )
            {
                MPI_Send(&new_le_size, 1, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD);
                MPI_Send(&new_ri_size, 1, MPI_INT, right_dest_id, send_tag, MPI_COMM_WORLD);

                MPI_Send(&rece_arr[0], new_le_size, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD);
                MPI_Recv(&rece_arr[0], new_le_size, MPI_INT, left_dest_id, send_tag, MPI_COMM_WORLD, &status);

                MPI_Send(&rece_arr[new_pivot+1], new_ri_size, MPI_INT, right_dest_id, send_tag, MPI_COMM_WORLD);
                MPI_Recv(&rece_arr[new_pivot+1], new_ri_size, MPI_INT, right_dest_id, send_tag, MPI_COMM_WORLD, &status);

                // cout << "second one " << rank  <<  endl;

            }
            else if( (2*rank + 1) >= numprocs)
            {
                quick_sort(&rece_arr[0], 0, rece_arr_size-1);
                quick_sort(&rece_arr[new_pivot+1], 0, new_ri_size-1);

                // cout << "third one " << rank  << endl;
            }

            MPI_Send(&rece_arr[0], rece_arr_size, MPI_INT, source_id, send_tag, MPI_COMM_WORLD);
            // cout << "received array " << rank << endl;
            // cout << " sent by child process " << rank << endl;
        }
        // cout << "process done " << rank << endl;
        
    }

    // if(rank == 0)
    // {
    //         for(int i=0; i<n_given; i++)
    //             cout << a[i] << " ";
            
    //         cout << endl;
    // }    
    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    ofstream out(argv[2]);
    for( int i=0; i<n_given; i++)
        out << a[i] << " ";
    out << endl;

    /* shut down MPI */
    MPI_Finalize();

    

    return 0;
}