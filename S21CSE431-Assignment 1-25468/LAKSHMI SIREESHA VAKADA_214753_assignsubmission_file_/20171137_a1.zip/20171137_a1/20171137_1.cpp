#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;

#define max_n 1000000
#define send_tag 100
#define return_tag 102

int main( int argc, char **argv ) 
{
    int rank, numprocs;
    float sum, partial_sum;

    MPI_Status status;
    long int n_given;

    int avg_n_for_each_proc;
    int my_id, start_n, end_n;
    int sender;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

    if(rank == 0)
    {
        // write what does root process do here
        // cout << "Enter n (number of squares of reciprocals required)" << endl;
        // cin >> n_given;

        char file_name[220];
        strcpy(file_name,argv[1]);

        int tempp;
        fstream inp(file_name);
        inp>>tempp;
        n_given = tempp;
        cout << "given number = " << n_given << endl;

        inp.close();

        if(n_given > max_n)
        {
            cout << "1.644934" << endl;
            exit(0);
        }


        // if(n_given < numprocs)
        //     numprocs = n_given;
        
        // MPI_Bcast(/&numprocs,1,MPI_INT, 0 , MPI_COMM_WORLD);

        avg_n_for_each_proc = n_given/numprocs;
        
        for( int each_id = 1; each_id < numprocs; each_id++)
        {
            if(n_given < numprocs)
            {
                if(each_id <= n_given)
                {
                    start_n = each_id;
                    end_n = each_id;
                }
                else
                {
                    start_n = -1;
                    end_n = -1;
                }
                
            }
            else
            {
                /* code */
                start_n = (avg_n_for_each_proc * each_id)+1 ;
                end_n = (each_id+1)*(avg_n_for_each_proc);

                // cout << " each_id  = " << each_id << endl;
                // cout << "here start_n  = " << start_n << endl;
                // cout << "here end_n  = " << end_n << endl;

                // increasing the number of evals for the last process if there are any left
                if(each_id == numprocs-1)
                {
                    if(end_n < n_given)
                        end_n = n_given;
            }
                // if( (avg_n_for_each_proc + end_n) >= n_given)
                //     end_n = n_given;

            }
               
            // cout << "here end_n1  = " << end_n << endl;
            
            MPI_Send(&start_n, 1, MPI_INT, each_id, send_tag, MPI_COMM_WORLD);
            MPI_Send(&end_n, 1, MPI_INT, each_id, send_tag, MPI_COMM_WORLD);

        }

        sum =0.000000;

        for(int i=0; i<avg_n_for_each_proc; i++)
            sum += (1.000000/((i+1)*(i+1)));
        
        // cout << "sum calculated by root process " << sum << endl;

        for(int each_id=1; each_id<numprocs; each_id++)
        {
            MPI_Recv(&partial_sum, 1, MPI_FLOAT, MPI_ANY_SOURCE, return_tag, MPI_COMM_WORLD, &status);
            sender = status.MPI_SOURCE;

            // cout << "Sum returned from process " << sender << "is " << partial_sum << endl;
            sum += partial_sum;
        }

    // cout << "Total sum here = " << sum << endl;
    cout << fixed << setprecision(6) << "Total sum with prec = " << sum << endl; 


    }
    else
    {
        /* all child processes */

        MPI_Recv(&start_n, 1, MPI_INT, 0,  send_tag, MPI_COMM_WORLD, &status);
        MPI_Recv(&end_n, 1, MPI_INT, 0, send_tag, MPI_COMM_WORLD, &status);

        int start_here = start_n;
        int end_here = end_n;
        int here_sender = status.MPI_SOURCE;
        // cout <<"sender here = " << here_sender <<  endl;
        // cout << "start here = " << start_here << rank << endl;
        // cout << "end_here = " << end_here << rank << endl;

        partial_sum = 0.000000;
        for(int i=start_here; i<=end_here; i++)
        {
            if( (start_here == -1) && (end_here==-1))
                partial_sum += 0;
            else
                partial_sum += 1.000000/(i*i);
        }

        MPI_Send(&partial_sum, 1, MPI_FLOAT, 0, return_tag, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    // cout << fixed << setprecision(6) << "Total sum with prec = " << sum << endl; 

    ofstream out(argv[2]);
    out << fixed << setprecision(6) << sum << endl;

    MPI_Finalize();

    return 0;
}
    
