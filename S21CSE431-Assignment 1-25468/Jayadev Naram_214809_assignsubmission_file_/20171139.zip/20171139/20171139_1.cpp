/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Status status;

    if(rank == 0) {
        
        /* Take input from a file */ 
        int n;
        ifstream input_file;
        ofstream output_file;
        output_file.open(argv[2]);

        input_file.open(argv[1]);
        input_file >> n;

        // cin >> n;

        int array[n];

        int n_per_proc = n / numprocs;

        for(int i = 0; i < n; i++)
            array[i] = i + 1;

        int start, end = 0, n_send;
        for(int i = 1; i < numprocs; i++) {
            start = (i-1)*n_per_proc;
            end = i*n_per_proc-1;

            n_send = end - start + 1;

            MPI_Send( &n_send, 1 , MPI_INT,
                    i, 1, MPI_COMM_WORLD );

            MPI_Send( &array[start], n_send, MPI_INT,
                    i, 1, MPI_COMM_WORLD );
        }

        float sum = 0, temp, partial_sum;
        int offset = 0;

        if (numprocs == 1)
            offset = -1;
        
        for(int i = end+1+offset; i < n; i++) {
            temp = array[i]*array[i];
            sum += 1/temp;
        } 

        // printf("sum %f calculated by root process\n", sum);

        for(int i = 1; i < numprocs; i++) {
            partial_sum = 0;

            MPI_Recv( &partial_sum, 1, MPI_FLOAT, MPI_ANY_SOURCE,
                    MPI_ANY_TAG, MPI_COMM_WORLD, &status );

            int sender = status.MPI_SOURCE;

            // printf("Partial sum %f returned from process %d\n", partial_sum, sender);
        
            sum += partial_sum;
        }

        output_file << sum << endl;
        // printf("The grand total is: %f\n", sum);
    }

    else {

        int n_receive;

        MPI_Recv( &n_receive, 1, MPI_INT, 
            0, MPI_ANY_TAG, MPI_COMM_WORLD, &status );

        int array[n_receive];
        
        MPI_Recv( &array, n_receive, MPI_INT, 
            0, MPI_ANY_TAG, MPI_COMM_WORLD, &status );


        float temp, partial_sum = 0;
        for(int i = 0; i < n_receive; i++) {
            temp = array[i]*array[i];
            partial_sum += 1/temp;
        }

        MPI_Send( &partial_sum, 1, MPI_FLOAT, 
            0, 1, MPI_COMM_WORLD );
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}