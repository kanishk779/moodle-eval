#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll; 
typedef pair<int, pair<int, int>> intp; 

// int compare(const void* a, const void* b)
// {
// 	const int* x = (int*) a;
// 	const int* y = (int*) b;

// 	if (*x > *y)
// 		return 1;
// 	else if (*x < *y)
// 		return -1;

// 	return 0;
// }

void quicksort(int arr[], int low, int high) {
    if ( low >= high )
        return;

    int left_pivot_id = low - 1, temp;
    for ( int i = low; i < high; i++) {
        if (arr[i] < arr[high]) {
            left_pivot_id++;
            temp = arr[left_pivot_id];
            arr[left_pivot_id] = arr[i];
            arr[i] = temp;
        }
    }

    left_pivot_id++;
    temp = arr[high];
    arr[high] = arr[left_pivot_id];
    arr[left_pivot_id] = temp;

    quicksort(arr, low, left_pivot_id-1);
    quicksort(arr, left_pivot_id+1, high);

}


int main ( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Status status;

    if (rank == 0) {

        int n;
        
        ifstream input_file;
        ofstream output_file;
        output_file.open(argv[2]);

        input_file.open(argv[1]);
        input_file >> n;

        int array[n];

        for ( int i = 0; i < n; i++ )
            input_file >> array[i];

        int n_per_proc = n / numprocs;

        int start, end = 0, n_send;
        for(int i = 1; i < numprocs; i++) {
            start = (i-1)*n_per_proc;
            end = i*n_per_proc-1;
            n_send = end - start + 1;
            MPI_Send( &n_send, 1 , MPI_INT,
                    i, 1, MPI_COMM_WORLD );
            MPI_Send( &array[start], n_send, MPI_INT,
                    i, 2, MPI_COMM_WORLD );
        }

        int offset = 0;
        if (numprocs == 1)
            offset = -1;
        
        int count = n-(end+1+offset);
        int arr[count];
        
        // cout << endl << "Before[" << rank << "]: ";
        for (int i = 0; i < count ; i++) {
            arr[i] = array[i+(end+1+offset)];
            // cout << arr[i] << " ";
        }
        // cout << endl;

        // qsort(arr, count, sizeof(int), compare);
        quicksort(arr, 0, count-1);

        // cout << endl << "After[" << rank << "]: ";
        // for (int i = 0; i < count; i++)
        //     cout << arr[i] << " ";
        // cout << endl;

        if (numprocs > 1) {
            vector<vector<int>> k_sorted_arr;
            k_sorted_arr.push_back(vector<int>(arr, arr + sizeof arr / sizeof arr[0]));

            for(int i = 1; i < numprocs; i++) {
                int n_receive;
                MPI_Recv( &n_receive, 1, MPI_INT, MPI_ANY_SOURCE,
                    1, MPI_COMM_WORLD, &status );

                int array1[n_receive];
                
                MPI_Recv( &array1, n_receive, MPI_INT, MPI_ANY_SOURCE,
                    2, MPI_COMM_WORLD, &status );
                
                int sender = status.MPI_SOURCE;

                // cout << endl << "After[" << sender << "]: ";
                // for (int j = 0; j < n_receive; j++)
                //     cout << array1[j] << " ";
                // cout << endl;

                if (n_receive)
                    k_sorted_arr.push_back(vector<int>(array1, array1 + sizeof array1 / sizeof array1[0]));
            }

            priority_queue<intp, vector<intp>, greater<intp>> queue;
        
            for (int i = 0; i< k_sorted_arr.size(); i++) 
                queue.push({k_sorted_arr[i][0],{i,0}});

            vector<int> output_array;

            while (!queue.empty()) {
                intp top = queue.top();
                queue.pop();
                output_array.push_back(top.first);
                pair<int,int> index = top.second;
                if (index.second + 1 < k_sorted_arr[index.first].size()) {
                    queue.push({k_sorted_arr[index.first][index.second+1],
                        {index.first, index.second+1}});
                }
            }

            // cout << "Sorted array ";
            for ( int i = 0; i < n; i++ )
                if ( i == n-1 )
                    output_file << output_array[i];
                else 
                    output_file << output_array[i] << " ";
            // cout << endl;
        }
        else {
            // cout << "Sorted array ";
            for ( int i = 0; i < count; i++ ) 
                if ( i == n-1 )
                    output_file << arr[i];
                else 
                    output_file << arr[i] << " ";
            // cout << endl;
        }
    }   

    else {
        int n_receive;

        MPI_Recv( &n_receive, 1, MPI_INT, 
            0, 1, MPI_COMM_WORLD, &status );

        int array[n_receive];
        
        MPI_Recv( &array, n_receive, MPI_INT, 
            0, 2, MPI_COMM_WORLD, &status );

        // cout << endl << "Before[" << rank << "]: ";
        // for (int i = 0; i < n_receive; i++)
        //     cout << array[i] << " ";
        // cout << endl;
        
        // qsort(array, n_receive, sizeof(int), compare);
        quicksort(array, 0, n_receive-1);

        // cout << endl << "After[" << rank << "]: ";
        // for (int i = 0; i < n_receive; i++)
        //     cout << array[i] << " ";
        // cout << endl;

        MPI_Send( &n_receive, 1 , MPI_INT,
            0, 1, MPI_COMM_WORLD );
        MPI_Send( &array[0], n_receive, MPI_INT,
            0, 2, MPI_COMM_WORLD );
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();

    return 0;
}
