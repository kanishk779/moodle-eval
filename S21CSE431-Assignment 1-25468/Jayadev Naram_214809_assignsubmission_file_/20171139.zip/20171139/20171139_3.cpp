#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <algorithm>    // std::shuffle
#include <random>       // std::default_random_engine
#include <chrono>       // std::chrono::system_clock

using namespace std;
typedef long long int ll; 
typedef pair<int, int> intp;

void create_line_graph(vector<intp> edges, vector<int> adjlist_L[]) {
    int M = edges.size();
    for ( int i = 0; i < M; i++ ) {
        intp uv = edges[i];
        int adj_edge = -1;
        for ( int j = 0; j < M && j != i ; j++ ) {
            intp wx = edges[j];
            if ( wx.first == uv.first ||
                    wx.first == uv.second ||
                    wx.second == uv.first ||
                    wx.second == uv.second ) {
                adjlist_L[i].push_back(j);
                adjlist_L[j].push_back(i);
            }
        }
    }

}

void print_adj_lists(int N, vector<intp> edges, vector<int> adjlist[], vector<int> adjlist_L[]) {
    int M = edges.size();
    cout << "Edges list in G:\n";
    for ( auto x : edges ) {
        cout << x.first << " " << x.second << endl;
    }
    cout << endl;

    cout << "Adjlist of G:\n";
    for ( int i = 0; i < N; i++ ) {
        for ( auto x : adjlist[i] )
            cout << x << " ";
        cout << endl;
    }
    cout << endl;

    cout << "Adjlist of L(G):\n";
    for ( int i = 0; i < M; i++ ) {
        for ( auto x : adjlist_L[i] )
            cout << x << " ";
        cout << endl;
    }
    cout << endl;
}

void vtx_partitioner(vector<int> U, vector<int> U_proc[], int numprocs) {
    int M_per_proc = U.size()/numprocs;

    int start, end = 0;

    for(int i = 1; i < numprocs; i++) {
        start = (i-1)*M_per_proc;
        end = i*M_per_proc-1;

        for ( int j = start; j <= end; j++ ) {
            U_proc[i].push_back(U[j]);
        }
    }

    int offset = 0;
    if (numprocs == 1)
        offset = -1;

    for ( int i = 0; i < U.size() - (end+1+offset); i++ ) {
        U_proc[0].push_back(U[i+(end+1+offset)]);
    }
}

void print_proc_partions(vector<int> curr_vtx, int numprocs, vector<int> U_proc[]) {
    
    cout << "\nShuffled vtx set = ";
    for ( auto x : curr_vtx ) {
        cout << x << " ";
    }
    cout << "\n";

    // for ( int i = 0; i < numprocs; i++ ) {
    //     cout << "Vtx set of " << i << " = ";
    //     for ( auto x : U_proc[i] ) {
    //         cout << x << " ";
    //     }
    //     cout << endl;
    // }

    // cout << "Boundary vtx set = ";
    // for ( int i = 0; i < boundary_vtx.size(); i++ ) {
    //     cout << boundary_vtx[i] << "---" << weight_boundary[i] << endl;
    // }
    // cout << endl;
}

void send_data(int rank, int M, vector<int> U, vector<int> adjlist_L[], vector<int> color_vtx) {
    int vtx_num = U.size(), tag = 1;
    MPI_Send( &vtx_num, 1 , MPI_INT,
        rank, tag++, MPI_COMM_WORLD );
    MPI_Send( &U[0], vtx_num, MPI_INT,
        rank, tag++, MPI_COMM_WORLD );
    MPI_Send( &M, 1 , MPI_INT,
        rank, tag++, MPI_COMM_WORLD );
    for ( int i = 0; i < M; i++ ) {
        vector<int> neigbors = adjlist_L[i];
        int num_neigbors = neigbors.size();
        MPI_Send( &num_neigbors, 1 , MPI_INT,
            rank, tag++, MPI_COMM_WORLD );
        MPI_Send( &neigbors[0], num_neigbors, MPI_INT,
            rank, tag++, MPI_COMM_WORLD );
    }
    MPI_Send( &color_vtx[0], M, MPI_INT,
        rank, tag++, MPI_COMM_WORLD );
}

void print_proc_data(int i, int M, vector<int> U, vector<int> adjlist_L[], vector<int> color_vtx) {
    
    cout << "Vtx set of " << i << " = ";
    for ( auto x : U ) {
        cout << x << " ";
    }
    cout << endl;

    // cout << "Adjlist of L(G):\n";
    // for ( int i = 0; i < M; i++ ) {
    //     vector<int> neigbors = adjlist_L[i];
    //     for ( auto x : neigbors )
    //         cout << x << " ";
    //     cout << endl;
    // }
    // cout << endl;

    // cout << "Color of Vtx = ";
    // for ( auto x : color_vtx ) {
    //     cout << x << " ";
    // }
    // cout << endl;
}

void speculative_coloring(vector<int> U, vector<int> adjlist_L[], vector<int> &color_vtx) {
    for ( auto vtx : U ) {
        vector<int> neigbors = adjlist_L[vtx], colors;
        int assign_color = 0;
        for ( auto x : neigbors ) {
            if ( find(colors.begin(), colors.end(), color_vtx[x]) == colors.end() ) 
                colors.push_back(color_vtx[x]);
        }
        while (true) {
            if ( find(colors.begin(), colors.end(), assign_color) == colors.end() )
                break;
            assign_color++;
        }
        color_vtx[vtx] = assign_color;
    }
} 

void print_assigned_colors(int rank, vector<int> U, vector<int> color_vtx) {
    cout << "colors assigned by " << rank << endl;
    for ( auto x : U ) {
        cout << "Color[" << x << "] = " << color_vtx[x] << endl;
    }
}

void print_global_colors(int rank, vector<int> color_vtx) {
    cout << "Global Colors at [" << rank << "]= ";
    for ( auto x : color_vtx ) {
        cout << x << " ";
    }
    cout << endl;
}

void detect_conflicts(vector<int> U, vector<int> adjlist_L[], vector<int> color_vtx, 
    vector<int> vtx_weight, vector<int> &conflict_set) {
    
    for ( auto vtx : U ) {
        vector<int> neigbors = adjlist_L[vtx];
        for ( auto x : neigbors ) {
            if ( color_vtx[x] == color_vtx[vtx] ) { // conflict
                if ( vtx_weight[x] > vtx_weight[vtx] )
                    conflict_set.push_back(x);
                else 
                    conflict_set.push_back(vtx);
            }
        }
    }
}

int main ( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Status status;

    if (rank == 0) {

        int N,M;
        
        ifstream input_file;
        ofstream output_file;
        output_file.open(argv[2]);

        input_file.open(argv[1]);
        input_file >> N;
        input_file >> M;

        vector<intp> edges;
        vector<int> adjlist[N];

        for ( int i = 0; i < M; i++ ) {
            int u, v;
            input_file >> u; input_file >> v;
            u--; v--;
            adjlist[u].push_back(v);
            adjlist[v].push_back(u);
            intp uv (u, v);
            edges.push_back(uv);
        }

        vector<int> adjlist_L[M];
        create_line_graph(edges, adjlist_L);

        // print_adj_lists(N, edges, adjlist, adjlist_L);

        unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
        std::default_random_engine e(seed);

        vector<int> curr_vtx, conflict_vtx, color_vtx;

        for ( int i = 0; i < M; i++ ) {
            curr_vtx.push_back(i);
            color_vtx.push_back(100000);
        }

        while (true) {
            if ( curr_vtx.empty() ) {
                int terminate = -1;
                for ( int i = 1; i < numprocs; i++ ) {
                    MPI_Send( &terminate, 1, MPI_INT,
                        i, 1, MPI_COMM_WORLD );
                }
                // cout << "Global Colors = ";
                output_file << *max_element(color_vtx.begin(), color_vtx.end())+1 << endl;
                for ( int i = 0; i < M; i++ ) {
                    int x = color_vtx[i];
                    if ( i != M-1 ) 
                        output_file << x+1 << " ";
                    else 
                        output_file << x+1;
                }
                // cout << endl;
                break;
            } 

            shuffle(curr_vtx.begin(), curr_vtx.end(), e);
            vector<int> U_proc[numprocs];

            vtx_partitioner(curr_vtx, U_proc, numprocs);

            vector<int> curr_vtx_weight;
            
            // print_proc_partions(curr_vtx, numprocs, U_proc);

            for ( int i = 0; i < M; i++ )
                curr_vtx_weight.push_back(i);

            for ( int i = 1; i < numprocs; i++ ) {
                send_data(i, M, U_proc[i], adjlist_L, color_vtx);
            }

            speculative_coloring(U_proc[0], adjlist_L, color_vtx);

            // print_assigned_colors(0, U_proc[0], color_vtx);

            for ( int i = 1; i < numprocs; i++ ) {
                vector<int> color_received;
                color_received.resize(M);
                MPI_Recv( &color_received[0], M, MPI_INT, 
                    MPI_ANY_SOURCE, 10000, MPI_COMM_WORLD, &status );
                // print_assigned_colors(i, U_proc[i], color_received);
                for ( auto x : U_proc[i] ) {
                    color_vtx[x] = color_received[x];
                }
            }

            // print_global_colors(rank, color_vtx);

            for ( int i = 1; i < numprocs; i++ ) {
                MPI_Send( &color_vtx[0], M, MPI_INT,
                    i, 10001, MPI_COMM_WORLD );
                MPI_Send( &curr_vtx_weight[0], M, MPI_INT,
                    i, 10002, MPI_COMM_WORLD );
            }

            // cout << "vtx_wt = ";
            // for ( auto x : curr_vtx_weight )
            //     cout << x << " ";
            // cout << endl;

            vector<int> conflict_set;

            detect_conflicts(U_proc[0], adjlist_L, color_vtx, curr_vtx_weight, conflict_set);

            // cout << "conflicts[" << rank << "] = ";
            // for ( auto x : conflict_set )
            //     cout << x << " ";
            // cout << endl;

            for ( int i = 1; i < numprocs; i++ ) {
                int num_conflicts;
                vector<int> conflict_set_proc;
                MPI_Recv( &num_conflicts, 1, MPI_INT,
                    MPI_ANY_SOURCE, 10003, MPI_COMM_WORLD, &status );
                conflict_set_proc.resize(num_conflicts);
                MPI_Recv( &conflict_set_proc[0], num_conflicts, MPI_INT,
                    MPI_ANY_SOURCE, 10004, MPI_COMM_WORLD, &status );
                for ( auto x : conflict_set_proc ) {
                    if ( find(conflict_set.begin(), conflict_set.end(), x) == conflict_set.end() )
                        conflict_set.push_back(x);
                }
                // cout << "conflicts[" << i << "]rec = ";
                // for ( auto x : conflict_set_proc )
                //     cout << x << " ";
                // cout << endl;
            }

            // cout << "conflicts total = ";
            // for ( auto x : conflict_set )
            //     cout << x << " ";
            // cout << endl;

            curr_vtx = conflict_set;
        }

    }   

    else {
        
        while (true) {
            int vtx_num, M, tag = 1;
            vector<int> U, color_vtx;

            MPI_Recv( &vtx_num, 1, MPI_INT, 
                0, tag++, MPI_COMM_WORLD, &status );
            cout << "ewfsrsfg\n";
            
            if ( vtx_num == -1 )
                break;
            else {

                U.resize(vtx_num);

                MPI_Recv( &U[0], vtx_num, MPI_INT, 
                    0, tag++, MPI_COMM_WORLD, &status );


                MPI_Recv( &M, 1, MPI_INT, 
                    0, tag++, MPI_COMM_WORLD, &status );
                vector<int> adjlist_L[M];
                for ( int i = 0; i < M; i++ ) {
                    int num_neigbors;
                    vector<int> neigbors;
                    MPI_Recv( &num_neigbors, 1, MPI_INT, 
                        0, tag++, MPI_COMM_WORLD, &status );
                    neigbors.resize(num_neigbors);
                    MPI_Recv( &neigbors[0], num_neigbors, MPI_INT, 
                        0, tag++, MPI_COMM_WORLD, &status );
                    adjlist_L[i] = neigbors;
                }
                color_vtx.resize(M);
                MPI_Recv( &color_vtx[0], M, MPI_INT, 
                    0, tag++, MPI_COMM_WORLD, &status );

                // print_proc_data(rank, M, U, adjlist_L, color_vtx);

                speculative_coloring(U, adjlist_L, color_vtx);

                // print_assigned_colors(rank, U, color_vtx);

                MPI_Send( &color_vtx[0], M, MPI_INT,
                    0, 10000, MPI_COMM_WORLD );

                MPI_Recv( &color_vtx[0], M, MPI_INT, 
                    0, 10001, MPI_COMM_WORLD, &status );

                // print_global_colors(rank, color_vtx);

                vector<int> vtx_weight;
                vtx_weight.resize(M);
                MPI_Recv( &vtx_weight[0], M, MPI_INT, 
                    0, 10002, MPI_COMM_WORLD, &status );

                vector<int> conflict_set;

                cout << "uyasd\n";
                
                detect_conflicts(U, adjlist_L, color_vtx, vtx_weight, conflict_set);

                // cout << "conflicts[" << rank << "]sen = ";
                // for ( auto x : conflict_set )
                //     cout << x << " ";
                // cout << endl;

                int num_conflicts = conflict_set.size();

                MPI_Send( &num_conflicts, 1, MPI_INT,
                    0, 10003, MPI_COMM_WORLD );

                MPI_Send( &conflict_set[0], num_conflicts, MPI_INT,
                    0, 10004, MPI_COMM_WORLD );
            }
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();

    return 0;
}
