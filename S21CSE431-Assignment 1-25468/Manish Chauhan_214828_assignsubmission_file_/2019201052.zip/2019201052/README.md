Analysis for both Q1 and Q2:

1. Increasing the number of processes decreases the total time.
2. Increasing the number of processes after a certain limit increase the time instead of decreasing because of too many context switches.

Q1:
It divides the sum of series upto 1/(n * n) into p processes and the final sum is calculated at process 0.

Q2:
It divides the the array into p subarrays and sort them using quick sort and then merge them into a sorted array.
