#include "mpi.h"
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define lld long long double

int partition(int *arr, int low, int high)
{
	int i = low - 1;
	int pivot = arr[high];
	for(int j = low; j <= high; j++)
	{
		if(arr[j] < pivot)
		{
			i++;
			swap(arr[i], arr[j]);
		}
	}
	swap(arr[i + 1], arr[high]);
	return (i + 1);
}

void quickSort(int *arr, int low, int high)
{
	if(low < high)
	{
		int q = partition(arr, low, high);
		quickSort(arr, low, q - 1);
		quickSort(arr, q + 1, high);
	}

}

int* merge(int *A, int *B, int n, int m)
{
	int *res = (int *)malloc((n + m) * sizeof(int));
	int i = 0, j = 0, k = 0;
	while(i < n && j < m)
	{
		if(A[i] < B[j])
			res[k++] = A[i++];
		else
			res[k++] = B[j++];
	}
	while(i < n)
	{
		res[k++] = A[i++];
	}
	while(j < m)
	{
		res[k++] = B[j++];
	}
	return res;
}

int main(int argc, char **argv)
{
	#ifndef ONLINE_JUDGE
		freopen(argv[1], "r", stdin);
		//freopen(argv[2], "w", stdout);
	#endif
	
	fstream fout;
	fout.open(argv[2], ios::out);

	int rank, numprocs, chunksize, actual_size, act = 0, initialn;
	int n, *arr = NULL, *chunk = NULL, *recv = NULL, *size;
	MPI_Status status;

	/* start up MPI */
	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	size = new int[numprocs + 1];
	if(rank == 0)
	{
		cin >> n;
		initialn = n;
		chunksize = ceil(1.0 * n / numprocs);
		arr = new int[numprocs * chunksize];
		//arr = (int *)malloc(numprocs * chunksize * sizeof(int));
		for(int i = 0; i < n; i++)
			cin>> arr[i];
		for(int i = n; i < numprocs * chunksize; i++)
			arr[i] = INT_MAX;

		actual_size = numprocs * chunksize;
		int x = n % numprocs;
		if(numprocs - x > chunksize && x != 0)
		{
			for(int i = 0; i < numprocs - 2; i++)
				size[i] = chunksize;
			
			size[numprocs] = 1;
			size[numprocs - 2] = n - (chunksize * (numprocs - 2));
			size[numprocs - 1] = 0;
		}
		else
		{
			for(int i = 0; i < numprocs - 1; i++)
				size[i] = chunksize;
			size[numprocs] = 0;
			size[numprocs - 1] = n - (chunksize * (numprocs - 1));		
		}
	}
	/* synchronize all processes */
	MPI_Barrier(MPI_COMM_WORLD);
	double tbeg = MPI_Wtime();

	// code here
	MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(size, numprocs + 1, MPI_INT, 0, MPI_COMM_WORLD);
	
	chunksize = ceil(1.0 * n / numprocs);
	if(size[numprocs] != 1)
	{
		chunk = new int[chunksize];
		//chunk = (int *)malloc(chunksize * sizeof(int));
		MPI_Scatter(arr, chunksize, MPI_INT, chunk, chunksize, MPI_INT, 0, MPI_COMM_WORLD);
		//free(arr);
		//arr = NULL;
		act = chunksize;
		if((rank + 1) != numprocs)
			quickSort(chunk, 0, size[rank] - 1);
		else
		{
			quickSort(chunk, 0, size[rank] - 1);
			act = size[rank];
		}
		for(int i = 1; i < numprocs; i *= 2)
		{
			if(rank % (2 * i) != 0)
			{
				MPI_Send(chunk, act, MPI_INT, rank - i, 0, MPI_COMM_WORLD);
				break;
			}
			if(rank + i < numprocs)
			{
				int recv_size;
				if(n >= chunksize * (rank + 2 * i))
					recv_size = chunksize * i;
				else
					recv_size = n - (chunksize * (rank + i));

				recv = (int *)malloc(recv_size * sizeof(int));
				MPI_Recv(recv, recv_size, MPI_INT, rank + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				arr = merge(chunk, recv, act, recv_size);
				free(chunk);
				free(recv);
				chunk = arr;
				act = act + recv_size;
			}
		}
	}
	else
	{
		chunk = new int[chunksize];
		//chunk = (int *)malloc(chunksize * sizeof(int));
		MPI_Scatter(arr, chunksize, MPI_INT, chunk, chunksize, MPI_INT, 0, MPI_COMM_WORLD);
		//free(arr);
		//arr = NULL;
		act = size[0];
		n = chunksize * (numprocs - 1);
		quickSort(chunk, 0, size[rank] - 1);
		numprocs--;

		for(int i = 1; i < numprocs; i *= 2)
		{
			if(rank % (2 * i) != 0)
			{
				MPI_Send(chunk, act, MPI_INT, rank - i, 0, MPI_COMM_WORLD);
				break;
			}
			if(rank + i < numprocs)
			{
				int recv_size;
				if(n >= chunksize * (rank + 2 * i))
					recv_size = chunksize * i;
				else
					recv_size = n - (chunksize * (rank + i));

				recv = (int *)malloc(recv_size * sizeof(int));
				MPI_Recv(recv, recv_size, MPI_INT, rank + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				arr = merge(chunk, recv, act, recv_size);
				free(chunk);
				free(recv);
				chunk = arr;
				act = act + recv_size;
			}
		}	
	}
	if(rank == 0 && numprocs == 1)
	{
		arr = chunk;
	}

	MPI_Barrier(MPI_COMM_WORLD);
	double elaspedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce(&elaspedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	if(rank == 0)
	{
		printf("Total time (s): %f\n", maxTime);
		for(int i = 0; i < initialn; i++)
			fout << arr[i] << " ";
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}