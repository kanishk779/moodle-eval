#include "mpi.h"
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ld long double

int main(int argc, char **argv)
{
	#ifndef ONLINE_JUDGE
		freopen(argv[1], "r", stdin);
		//freopen(argv[2], "w", stdout);
	#endif

	int rank, numprocs;
	fstream fout;
	fout.open(argv[2], ios::out);

	/* start up MPI */
	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

	/* synchronize all processes */
	MPI_Barrier(MPI_COMM_WORLD);

	ll n;
	cin >> n;

	double tbeg = MPI_Wtime();

	// code here
	if(rank == 0)
	{
		ll start = 1, chunksize;

		if(numprocs > 1)
			chunksize = ceil(1.0 * n / (numprocs - 1));
		ll sent[2] = {start, n};

		for(ll i = 1; i < numprocs; i++)
		{
			sent[0] = start;
			//cout << sent[0] << " " << sent[1] << " " << sent[2] << "\n";
			MPI_Send(sent, 2, MPI_LONG_LONG, i, 0, MPI_COMM_WORLD);
			start += chunksize;
		}

		ld res = 0;
		for(ll i = 1; i < numprocs; i++)
		{
			ld inter_res;
			MPI_Recv(&inter_res, 1, MPI_LONG_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			//cout << inter_res << "\n";
			res += inter_res;
		}
		if(numprocs == 1)
		{
			for(ll i = 1; i <= n; i++)
				res += (1.0 / (i * i));
		}
		fout << fixed << setprecision(8) << res << "\n";
	}
	else
	{
		ll received[3], start, chunksize, n;
		ld res = 0;
		MPI_Recv(received, 2, MPI_LONG_LONG, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		start = received[0];
		n = received[1];
		chunksize = ceil(1.0 * n / (numprocs - 1));

		//cout << received[0] << " " << received[1] << " " << received[2] << "\n";
		for(ll i = 0; i < chunksize; i++)
		{
			if(start + i > n)
				break;
			res += (1.0 / ((start + i) * (start + i)));
		}
		//cout << rank << " " << res << "\n";
		MPI_Send(&res, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Barrier(MPI_COMM_WORLD);
	double elaspedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce(&elaspedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

	if(rank == 0)
	{
		fout.close();
		printf("Total time (s): %f\n", maxTime);
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}