#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
  
    if(rank  == 0){

        double sum = 0;
        int N;
        FILE *file = NULL;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &N);

        if(numprocs == 1){   // if num of process is 1 or if N is less than processes. 
            for(int i = 1; i <= N; i++){
                sum += 1.0 / (i*i);
            }
        }
        else{
            int array[2];
            if(N <= numprocs){
                for(int i= 1; i <= N; i++){
                    sum += 1.0 / (i*i);
                }
                array[0] = -1;
                array[1] = -1;
                for(int i = 1; i < numprocs; i++){
                    MPI_Send(array, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                }
            }

            // ask each process to find sum 
            int n = N / (numprocs - 1);
            for (int i = 1; i < numprocs; i++){
                array[0] = n*(i -1) + 1;
                if(i != numprocs -1){
                    array[1] = n*i;
                }
                else{
                    array[1] = N;
                }
                MPI_Send(array, 2, MPI_INT, i, 0, MPI_COMM_WORLD);   
            }

            for(int i = 1; i < numprocs; i++){
                double value;
                MPI_Recv(&value, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                sum += value;

           
            }
        }
        file = fopen(argv[2], "w");
        fprintf(file, "%f\n", sum);
        fclose(file);
        // cout << fixed << setprecision(6) << sum << endl;

    }
    else{
        int arr[2];
        MPI_Recv(arr, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double ans = 0;
        if(arr[0] != -1){
            for(int i = arr[0]; i <= arr[1]; i++){
                ans += 1.0/(i*i);

            }
        }
        // cout << "Rank is " << rank <<" " << ans << endl;
        MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
        // cout << fixed << setprecision(6) << sum << endl;
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}