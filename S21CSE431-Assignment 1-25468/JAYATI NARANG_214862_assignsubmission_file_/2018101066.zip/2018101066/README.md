# Question 1:
In this we divide the range N to all the processes (except 0) to find the sum ofthe 1/i^2 for that range, and send the sum back to the process 0.
If number of processes is greater than N then pass one value to all the processes and some processes will be redundant. 

##Question 2:
Here I have used the quicksort recursively, based on the need the sibling node is called. I have created a binary tree, based on the depth of that the sibling node is defined. Last element is choosen as the pivot and left is sorted by the process itself and right part is send to the sibling node if it exists. Sibling Node is found by 2^depth + rank of this process. 
This is faster then usual way of sorting the chucks of array by each process and merging them since merging will be costly. Here though some processes will be redunctant but still if the number of processes is large my algorithm will faster.

## Question 3 (Was getting some error, approach explanation)
Changed the edge coloring problem to vertex coloring problem by forming the line graph from the given set of edges. 
For vertex coloring I used this paper: A Parallel Graph Coloring Heuristic 
link : https://www.researchgate.net/publication/2768023_A_Parallel_Graph_Coloring_Heuristic
First we divide the vertices to the processes and then from each process we send the independent set of vertices, then we color them based on their neighbours. Smallest +ve integer color which is not yet assigned to neighbour of that vertex.
This way we color all the vertices.
  
