#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(int *arr, int l, int h){ //return the index of pivot
    int j = l-1;
    for(int i = l; i < h; i++){
        if(arr[i] < arr[h]){
            j++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[j+1], arr[h]);
    return j+1;

}
void sequencial_quicksort(int *arr, int l, int h){
    // implement sequencial quicksort here
    if(l >= h) return;
    int index = partition(arr, l, h);
    sequencial_quicksort(arr, l, index-1);
    sequencial_quicksort(arr, index+1, h);
}
void printArray(int *arr, int l, int h){
    for(int i =l; i <=h; i++){
        cout << arr[i] << " ";
    
    }
    cout <<  endl;
    return;
}
void deactivateChilds_of(int rank, int numprocesses, int depth){
    depth++;
    int value = -1;

    if(rank < numprocesses){
        int current_rank = rank;
        int child_rank = pow(2, depth) + current_rank;
        while(child_rank < numprocesses){
            child_rank = pow(2, depth) + current_rank;
            deactivateChilds_of(child_rank, numprocesses, depth);
            if( child_rank < numprocesses){
                MPI_Send(&value, 1, MPI_INT, child_rank, 5,MPI_COMM_WORLD);
            }
            depth++;
            // current_rank = child_rank;
        }
    }
    return;
}
void parallel_quick_sort(int *arr, int l, int h, int rank_of_this_process, int no_of_processes, int depth){
    int value = -1;
    // cout << "Called by process " << rank_of_this_process << " l is " << l << " h is " << h << endl;
    // cout << "current array is " << endl;
    // printArray(arr,l, h);

    if(l >= h){
        // if this process rank is odd then send all the odd processes greater than this process tag = 5 which means to quit
        // same in case of even ranks
        // cout << " hey I am here in this weird condition: my rank is  " << rank_of_this_process << " and l and h are " << l << " " << h << " depth is " << depth << endl;
        // for(int i = rank_of_this_process+2; i < no_of_processes; i = i+2){
        //     MPI_Send(&value, 1, MPI_INT, i, 5, MPI_COMM_WORLD); // this tag will indicate them to quit the calcuation
        //     // this is to make sure each process gets the notification 
        // If I am a left child, I will deactivate my childs and my sibling's childs
        // if I am right child, then I will deactivate my childs only
        int c = pow(2, depth) + rank_of_this_process;
        if( c < pow(2, depth+1)){ // implies I am left child
            deactivateChilds_of(rank_of_this_process, no_of_processes, depth);

            deactivateChilds_of(c, no_of_processes, depth);
            // deactivating the sibling 
            if(c < no_of_processes){
                MPI_Send(&value, 1, MPI_INT, c, 5, MPI_COMM_WORLD);
            }
        }
        else{
            deactivateChilds_of(rank_of_this_process, no_of_processes, depth);
        }
        
        return;
    }
    int index = partition(arr, l, h);
    // cout << "Called by process " << rank_of_this_process << " with index partition as " << index << endl;
    if(pow(2, depth) + rank_of_this_process < no_of_processes){
        //proc_id = 2*depth + rank_of_this_process;
        int sibling_node = pow(2, depth) +rank_of_this_process;
        depth++;
        //send right to this process
        

        if(index < h -1){ // if index is last second also then no right is there
            // cout << "With  " << "I am process " << rank_of_this_process << " and I am calling my sibling " << sibling_node << " since the depth given was " << depth -1 << endl;
            // cout << "I am rank " << rank_of_this_process << " I am calling process " << sibling_node << " from index  " << index+1 << endl;
            // printArray(arr, index+1, h);
            MPI_Send(arr+index+1, h - index, MPI_INT, sibling_node, 0, MPI_COMM_WORLD);
            // cout << "I am rank " << rank_of_this_process << " I have send message to " << sibling_node << endl;
            MPI_Recv(arr+index+1, h - index, MPI_INT, sibling_node, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        else{
            // cout << "Without  " << "I am process " << rank_of_this_process << " and I am calling my sibling " << sibling_node << " since the depth given was " << depth -1 << endl;
            // deactivate childs of my sibling and my sibling
            
            deactivateChilds_of(sibling_node, no_of_processes, depth - 1);
            MPI_Send(&value, 1, MPI_INT, sibling_node, 5, MPI_COMM_WORLD); 

        }
        parallel_quick_sort(arr, l, index-1, rank_of_this_process, no_of_processes, depth); // this sends the left with updated depth
        // send the left to this process only hence call parallelsort with this new depth
    }
    else{
        sequencial_quicksort(arr, l, index-1);
        sequencial_quicksort(arr, index+1, h);
    }
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if(rank == 0){
        // int N;
        // cout << "Enter N " << endl;
        // cin >> N;
        // cout << "Enter the array " << endl;
        // int arr[N]; // will use malloc here
        // for(int i = 0; i < N; i++){
        //     cin >> arr[i];
        // }
        int N;
        FILE *file = NULL;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &N);
        int arr[N];
        for (int i = 0; i < N; i++)
            fscanf(file, "%d", &(arr[i]));
        fclose(file);
        // int arr[] = {10, 10, 12, 1, 2, 3, 1, 8, 3, 7, 9, 4, 23, 199, 76, 12, 54, 12, 54, 87};  
        // int N = sizeof(arr) / sizeof(arr[0]);
      
        // take input of data
        // call parallel_quicksort with arr, l=0, h= N-1, rank = 0, depth = 0)
        parallel_quick_sort(arr, 0, N-1, 0, numprocs, 0);
        // cout << "I am process 0 printing the array final "<< endl;
        file = fopen(argv[2], "w");
        for (int i = 0; i < N; i++)
        fprintf(file, "%d ", arr[i]);
        fclose(file);
        // for(int i = 0; i < N; i++){
            // cout << arr[i] << " ";
        // }
        // cout << endl;
    }
    else{
        MPI_Status status;
        int  nbytes;
        int *recA;
        int flag = 0;
        // while(flag == 0){
        //     MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        // }
        // if(flag == 0){
        MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            // It will block the caller until a message is ready
        // cout << "I have received message from " << status.MPI_SOURCE << endl;
        if(status.MPI_TAG == 0){
        // Obtain message size...
            MPI_Get_count(&status, MPI_INT, &nbytes); 

            // Allocate memory to receive data
            if ( nbytes != MPI_UNDEFINED )    
                recA = (int*)malloc(nbytes * sizeof(int));


            // Finally, receive the message with a correctly sized buffer...
            MPI_Recv(recA, nbytes, MPI_INT, status.MPI_SOURCE, status.MPI_TAG, MPI_COMM_WORLD, &status);
            // call parallel quicksort with recA, l = 0, h = nbytes, rank = rank of this process, depth -> we need to find
            int depth = (int)log2(rank) +  1;
            // cout << "I am process " << rank << " and I have got array ";
            // printArray(recA, 0, nbytes -1);
            parallel_quick_sort(recA, 0, nbytes-1, rank, numprocs, depth);
            MPI_Send(recA, nbytes, MPI_INT, status.MPI_SOURCE, status.MPI_TAG, MPI_COMM_WORLD);
        }
        else if(status.MPI_TAG == 5){
            // cout << "tag is 5 here for rank " << rank << "source of this is " << status.MPI_SOURCE << endl;
        }
    }
  


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
        // cout << fixed << setprecision(6) << sum << endl;
    }

    /* shut down MPI */
    MPI_Finalize();

    return 0;
}