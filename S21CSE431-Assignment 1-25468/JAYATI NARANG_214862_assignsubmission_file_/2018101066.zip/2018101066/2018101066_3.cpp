#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int line_graph(int arr[][2], int linegraph[][2], int M){
    int newM = 0;
    for(int i = 0; i < M; i++) {
        for(int j = i+1; j < M; j++) {
            if(arr[j][0] == arr[i][0] || arr[j][0] == arr[i][1] || arr[j][1] == arr[i][0] || arr[j][1] == arr[i][1]) {
                linegraph[newM][0] = i;
                linegraph[newM][1] = j;
                newM++;
            }
        }
    }
    return newM;
   
}
int MissPos(vector<int> a)
{

    int size = a.size();
    for (int i = 0; i < size; i++) {
        if (abs(a[i]) - 1 < size && a[abs(a[i]) - 1] > 0)
            a[abs(a[i]) - 1] = -a[abs(a[i]) - 1];
    }
    for (int i = 0; i < size; i++)
        if (a[i] > 0)
            return i + 1;
 
    return size + 1;
}
void sequencial_color(int M, int *color, int graph[][510]){
        vector<int> ThisNodes;
        
        for(int i = 0; i < M; i++){
            ThisNodes.push_back(i);
        }
        int numOf = ThisNodes.size();
        while(true){
            for(int i = 0; i < numOf; i++){
                int flag = true;
                vector<int> FinalSend;
                if(color[ThisNodes[i]] == 0){ // then find if it is greatest among its neighbours non colored neighbous or not
                    for(int j = 0; j < M; j++){
                        if(graph[ThisNodes[i]][j] == 1 &&  color[j] == 0 && ThisNodes[i] < j){
                            flag = false;
                        }
                        FinalSend.push_back(color[j]);
                    }
                    if(flag){
                        //color this node
                        color[ThisNodes[i]] = MissPos(FinalSend);

                    }
                }
            }
            int cnt = 0;
            for(int i =0; i < M; i++){
                if(color[i] != 0) cnt++;
            }
            if(cnt == M){
                break;
            }
    }
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int M;
    int graph[510][510];
    int Graph[510][510] = {0};
    vector<int>ThisNodes;
    int flagWhile = 1;
    if(rank == 0){
        // take input the input
        int N;
        cout << "I am process " << rank << endl;
        cout << "Enter N and M "  << endl;
        cin >> N >> M;
        int arr[M][2];
        int a, b;
        // vector<vector<int>> FirstGraph;
        cout << "Enter the edges " << endl;
        for(int i = 0; i < M; i++){
            cin >> a >> b;
            arr[i][0] = a-1; 
            arr[i][1] = b-1;
        }
        //create line graph out of this edges
        int NewEdges[M*M][2];
        int newM = line_graph(arr, NewEdges, M);
        // old M will be new N and this newM will be the new M 

        for(int i = 0; i < newM; i++){
            a = NewEdges[i][0];
            b = NewEdges[i][1];
            Graph[a][b] = 1;
            Graph[b][a] = 1;
        }
        cout<<"in process 0" << endl;
                for(int i =0; i < M; i++){
            for(int j = 0; j < M; j++){
                cout << Graph[i][j] << " ";
            }
            cout << endl;
            }
        // broadcast all the process the main graph and M and newM
        MPI_Bcast(&(Graph[0][0]), 500*500, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&M, 1, MPI_INT, 0, MPI_COMM_WORLD);

        int array[2];
        // sending each process some set of vertices.
        if(numprocs > 1){
            if(M < numprocs -1){
                // send each process just one vertex and send rest of them send -1 as the first index
                
                array[0] = -1;
                array[1] = -1;
                
                int color0[M] = {0};
                sequencial_color(M, color0, Graph);
                flagWhile = 0;
                // find maximum of color array and print it and print the color array as well;
                int Numofcolors = 1;
                for(int i = 0; i < M; i++){
                    if(Numofcolors > color0[i]){
                        Numofcolors = color0[i];
                    }
                }
                // write the color saving here 
                cout << "No of colors used " << Numofcolors << endl;
                for(int i = 0; i < M; i++){
                    cout <<  color0[i] << endl;
                }
                // FILE *file = NULL;
                // file = fopen(argv[2], "w");

            }
            else{
                int n = M / (numprocs - 1);
                for (int i = 1; i < numprocs; i++){
                    array[0] = n*(i -1);
                    if(i != numprocs -1){
                        array[1] = n*i;
                    }
                    else{
                        array[1] = M;
                    }
                }
            }
            for(int i = 1;  i < numprocs; i++){
                MPI_Send(array, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
   
                MPI_Send(&flagWhile, 1, MPI_INT, i, 0, MPI_COMM_WORLD);  
            }

            
        }
        else{
            int color0[M] = {0};
            sequencial_color(M, color0, Graph);
            flagWhile = 0;
            int Numofcolors = 1;
            for(int i = 0; i < M; i++){
                if(Numofcolors > color0[i]){
                    Numofcolors = color0[i];
                }                
            }
                // write the color saving here 
                                cout << "No of colors used " << Numofcolors << endl;
                for(int i = 0; i < M; i++){
                    cout <<  color0[i] << endl;
                }
        }
        


    }
    else{
        MPI_Bcast(&(graph[0][0]), 500*500, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&M, 1, MPI_INT, 0, MPI_COMM_WORLD);
        int *array;
        array = (int*)malloc(2 * sizeof(int));
        cout << "I am process " << rank<< endl;
        MPI_Recv(array, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&flagWhile, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
 
        if(array[0]  != -1){
            for(int i = array[0]; i < array[1]; i++){
                ThisNodes.push_back(i);
            }
        }
        else{
            ThisNodes.push_back(-1);
        }


    }
    int color[M] = {0};
    int notColored =0;
   
    if(flagWhile){
        while(true){
            if(rank == 0){


                MPI_Bcast(color, M, MPI_INT, 0, MPI_COMM_WORLD);
                // check if all are colored
                cout <<  "Broadcasted the colors  rank " << rank << endl;
                for(int i = 0; i < M; i++){
                    cout << color[i] << " ";
                }
                cout << endl;
                int cnt = 0;
                for(int i =0; i < M; i++){
                    if(color[i] != 0) cnt++;
                }
                if(cnt == M){
                    break;
                }

                if(numprocs == 1){
                    break;
                }
                else{
                    vector<int>nodes;
                    int num = 0;
                    for(int i =1; i < numprocs; i++){
                        MPI_Recv(&num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                        if(num != 0){
                            nodes.resize(num);
                            MPI_Recv(&nodes[0], num, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                            // color these nodes
                            // colorNodes(nodes, color);
                            // make a vector of colors of neighbours

                            for (auto& it : nodes) { 
                                vector<int>ColorsNeighbours;
                                // find the colors of its neighbours and push it here
                                for(int j = 0; j < M; j++){
                                    if(Graph[it][j] == 1){
                                        ColorsNeighbours.push_back(color[j]);
                                    } 
                                }
                                // send this vector to find the number greater than this vector
                                color[it] = MissPos(ColorsNeighbours);

                            } 

                        }

                    }
                }

            }
            else{
                int send = 0;
                vector<int> FinalSend;
                MPI_Bcast(color, M, MPI_INT, 0, MPI_COMM_WORLD);
                            // check if all are colored
                cout <<  "got broadcasted colors  rank " << rank << endl;
                for(int i = 0; i < M; i++){
                    cout << color[i] << " ";
                }
                cout << endl;
                int cnt = 0;
                for(int i =0; i < M; i++){
                    if(color[i] != 0) cnt++;
                }
                if(cnt == M){
                    break;
                }

                if(ThisNodes[0] != -1){
                    // find the nodes which are greatest in their neighbours and are not colored and send them as a vector to the process 0 
                    cout << "In here " << endl;
                    
                    int numOf = ThisNodes.size();
                    cout << " rank is " << rank << " " << numOf << endl; 
                    for(int i = 0; i < numOf; i++){
                        cout  << ThisNodes[i] << " ";
                    }
                    cout << endl;
                    for(int i = 0; i < numOf; i++){
                        int flag = true;
                        if(color[ThisNodes[i]] == 0){ // then find if it is greatest among its neighbours non colored neighbous or not
                            for(int j = 0; j < M; j++){
                                if(graph[ThisNodes[i]][j] == 1 &&  color[j] == 0 && ThisNodes[i] < j){
                                    flag = false;
                                }
                            }
                            if(flag){
                                FinalSend.push_back(ThisNodes[i]);
                            }
                        }
                    }
                    if(FinalSend.empty()){
                        send = 0;
                        MPI_Send(&send, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);   

                    }
                    else{
                        send = FinalSend.size();
                        MPI_Send(&send, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
                        MPI_Send(&FinalSend[0], 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
                    }

                }
                else{
                    send = 0;
                    MPI_Send(&send, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
                }

                    

            }
        }
    }
    if(rank == 0 && flagWhile){
        for(int i = 0; i < M ; i++){
            cout << color[i] << endl;
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
        // cout << fixed << setprecision(6) << sum << endl;
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}