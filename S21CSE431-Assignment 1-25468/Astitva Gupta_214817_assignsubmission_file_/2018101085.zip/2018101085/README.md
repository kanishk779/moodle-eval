### 2018101085
### Astitva Gupta


# Parallel Sum

## Description:

A parallel approach using MPI is followed to find sum of the reciprocals of the squares of integer from 1 to N. Integers from 1 to N are divided equally to each process in their respective code. Each process finds sum of reciprocal of sqaures of integers from this starting to ending point and pass this sum back to root process which is zero. Finally in root process we sum each of the received value and the value computed by it and output it in a file.

## Analysis
- For N = 2
    - if np = 1 - Total time (s): 0.000148
    - if np = 11 - Total time (s): 0.000510
- For N = 10000:
    - if np = 1 - Total time (s): 0.000198
    - if np = 11 - Total time (s): 0.000597
- It is obvious that time will increase almost monotically with increase in N as number of operations would increase.
- A but surprising result is that the more the number of processes, the more time it takes which is counter-intutive. But, it can be justified as the overhead of sending and receiving from processes is more than the time it takes to compute the very simple sum. Hence the time increases.

# Parallel Quick Sort

## Description:

A parallel approach using MPI is followed to sort given array using quick sort algorithm also known as parallel quick sort algorithm. Initially input array is divided into equal continous subarrays with size of each subarray depending upon total number of processes. Subarrays are passed to each process.
Now one process is chosen at random from the current pool(initiall which contains all process) and this random process then choses a random pivot from its Contents.
This pivot is broadcasted to every process in the pool and then all the processes partition their array acc. to this pivot. Next the processes in the upper half of the pool send the values less than pivot to their corresponding process in lower half. Also a process in second half sends its values less than pivot to corresponding process in upper half.
Now upper half contains all the values greater than pivot and lower than it in second half. Now this function is recalled where the pool is devided into two pools upper and lower half and thus this function is called recursively twice for a pool.
If only one process is present in pool, it sorts the array using iterative quicksort. For this a parallel approach has been followed using *Parallel quick sort -1* algorithm as explained [here](https://www.uio.no/studier/emner/matnat/ifi/INF3380/v10/undervisningsmateriale/inf3380-week12.pdf).

## Analysis
*TIME MAY CHANGE ON DIFFERNET MACHINES!*
	- For N = 10 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.000207
		- if np = 11 - Total time (s): 0.001345
	- For N = 1000000 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.520452
		- if np = 11 - Total time (s): 0.694521
	- It is obvious that time will increase almost monotically with increase in N
	- A but surprising result is that the more the number of processes, the more time it takes which is counter-intutive. But, it can be justified as the overhead of sending and receiving a large part of array is more than the very simple quick sort that it has to do.Hence the time increases.

# Parallel Edge Coloring

## Description:

A parallel approach is to be followed to color the edges of given graph in such a way that no two adjacent edges have same color and maximum number of colors used is not more than `1 + max(Delta of the original graph, Delta of the line graph)`. Initially given graph is transformed to its line graph. The line graph of an undirected graph G is another graph L(G) that represents the adjacencies between edges of G. L(G) is constructed in the following way: for each edge in G, make a vertex in L(G); for every two edges in G that have a vertex in common, make an edge between their corresponding vertices in L(G). Now for this line graph our problem is transformed to graph coloring (vertex-coloring). For this a parallel approach has been followed using *Jones-Plassmann* algorithm as explained [here](https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/).

## Analysis
*TIME MAY CHANGE ON DIFFERNET MACHINES!*
	- For N = 1, M = 1, and graph elements randomly initialized
		- if np = 1 - Total time (s): 0.000207
		- if np = 11 - Total time (s): 0.001345
	- For N = 100, M = 500, and graph elements randomly initialized
		- if np = 1 - Total time (s): 0.007933
		- if np = 11 - Total time (s): 0.021300
	- It is obvious that time will increase almost monotically with increase in N
	- A but surprising result is that the more the number of processes, the more time it takes which is counter-intutive. But, it can be justified as the overhead of sending and receiving a large part of array is more than the very simple quick sort that it has to do.Hence the time increases.


### Version Used MPI 4.1.0