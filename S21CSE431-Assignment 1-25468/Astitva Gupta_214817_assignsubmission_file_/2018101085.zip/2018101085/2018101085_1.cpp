#include <bits/stdc++.h>
#include <mpi.h>
using namespace std;

int main(int argc, char *argv[])
{
    int size, my_rank;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    if (argc != 3)
    {
        if (my_rank == 0)
            printf("Provide both input and output file locations!!\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }

    int n;
    double buffer = 0, ans;

    if (my_rank == 0)
    {
        ifstream in(argv[1]);
        auto cinbuf = cin.rdbuf(in.rdbuf());
        cin >> n;
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    for (int i = my_rank; i < n; i += size)
        buffer += 1.0 / ((i + 1) * (i + 1));

    MPI_Reduce(&buffer, &ans, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
    {
        ofstream cout(argv[2]);
        cout << std::setprecision(7) << ans << endl;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
        printf("Total time (s): %f\n", maxTime);

    MPI_Finalize();
    return EXIT_SUCCESS;
}
