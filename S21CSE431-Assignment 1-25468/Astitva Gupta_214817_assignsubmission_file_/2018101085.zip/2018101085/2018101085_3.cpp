#include <bits/stdc++.h>
#include <time.h>
#include "mpi.h"
using namespace std;

int n, m;
vector<unordered_set<int>> graph;
vector<int> w, col;

void getIndependantVertices(int &all_size, vector<int> &my_arr, int my_rank, int size)
{
    my_arr.clear();
    for (int i = my_rank; i < n; i += size)
    {
        if (col[i] != -1)
            continue;
        bool allSmaller = true;
        for (auto j : graph[i])
            if (w[j] >= w[i] && col[j] == -1)
            {
                allSmaller = false;
                break;
            }
        if (allSmaller)
            my_arr.push_back(i);
    }
    int my_arr_size = my_arr.size();
    MPI_Reduce(&my_arr_size, &all_size, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Bcast(&all_size, 1, MPI_INT, 0, MPI_COMM_WORLD);
    return;
}

int getColor(int index, vector<int> &color)
{
    vector<int> nums;
    for (auto i : graph[index])
        if (color[i] != -1)
            nums.push_back(color[i]);
    int len = nums.size();
    for (int i = 0; i < len; i++)
        if (nums[i] <= 0 || nums[i] >= len + 1)
            nums[i] = len + 2;
    int col = len + 1;
    for (int i = 0; i < len; i++)
        if (abs(nums[i]) >= len + 2)
            continue;
        else
            nums[abs(nums[i]) - 1] = -(abs(nums[abs(nums[i]) - 1]));
    for (int i = 0; i < len; i++)
        if (nums[i] >= 0)
        {
            col = i + 1;
            break;
        }
    return col;
}

void syncColors(int loc_col[][2], int loc_size, int my_rank, int size)
{
    if (my_rank != 0)
    {
        MPI_Send(&loc_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
        MPI_Send(&loc_col[0][0], loc_size * 2, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }
    else
    {
        for (int i = 1; i < size; i++)
        {
            int rec_size;
            MPI_Recv(&rec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            int rec_col[rec_size][2];
            MPI_Recv(&rec_col[0][0], rec_size * 2, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (int j = 0; j < rec_size; j++)
                col[rec_col[j][0]] = rec_col[j][1];
        }
    }
    MPI_Bcast(&col[0], n, MPI_INT, 0, MPI_COMM_WORLD);
}

void getRandomWeights()
{
    unordered_set<int> s;
    srand(time(NULL));
    for (int i = 0; i < w.size(); i++)
    {
        int r_val = (rand()) % (3 * n) + 1;
        while (s.find(r_val) != s.end())
            r_val = (rand()) % (3 * n) + 1;
        w[i] = r_val;
        s.insert(r_val);
    }
}

void getGraph(vector<int> &arr1, vector<int> &arr2)
{
    graph = vector<unordered_set<int>>(n);
    for (int i = 0; i < arr1.size(); i++)
    {
        if (arr1[i] == arr2[i])
            continue;
        graph[arr1[i]].insert(arr2[i]);
        graph[arr2[i]].insert(arr1[i]);
    }
}

void generateLineGraph(vector<int> &arr1, vector<int> &arr2)
{
    vector<int> arr1_n, arr2_n;
    int m = arr1.size();
    for (int i = 0; i < m; i++)
    {
        for (int j = i + 1; j < m; j++)
        {
            if (arr1[j] == arr1[i] || arr1[j] == arr2[i] || arr2[j] == arr1[i] || arr2[j] == arr2[i])
            {
                arr1_n.push_back(i);
                arr2_n.push_back(j);
            }
        }
    }
    arr1 = arr1_n;
    arr2 = arr2_n;
}

int main(int argc, char *argv[])
{
    int size, my_rank;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    if (argc != 3)
    {
        if (my_rank == 0)
            printf("Provide both input and output file locations!!\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }

    vector<int> arr1, arr2;
    if (my_rank == 0)
    {
        ifstream in(argv[1]);
        auto cinbuf = cin.rdbuf(in.rdbuf());

        int x, y;
        cin >> n >> m;

        for (int i = 0; i < m; i++)
        {
            cin >> x >> y;
            arr1.push_back(x);
            arr2.push_back(y);
        }
        generateLineGraph(arr1, arr2);
        n = m;
        m = arr1.size();
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);

    arr1.resize(m);
    arr2.resize(m);

    MPI_Bcast(&arr1[0], m, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&arr2[0], m, MPI_INT, 0, MPI_COMM_WORLD);

    getGraph(arr1, arr2);

    col = vector<int>(n, -1);
    w = vector<int>(n);
    if (my_rank == 0)
        getRandomWeights();

    MPI_Bcast(&w[0], n, MPI_INT, 0, MPI_COMM_WORLD);

    vector<int> my_arr;
    int iter = 0;
    int I_size;

    while (true)
    {
        MPI_Barrier(MPI_COMM_WORLD);
        getIndependantVertices(I_size, my_arr, my_rank, size);

        if (I_size == 0)
            break;

        int loc_col[my_arr.size()][2] = {};
        for (int i = 0; i < my_arr.size(); i++)
        {
            loc_col[i][0] = my_arr[i];
            loc_col[i][1] = getColor(my_arr[i], col);
            col[my_arr[i]] = loc_col[i][1];
        }

        syncColors(loc_col, my_arr.size(), my_rank, size);
    }

    MPI_Barrier(MPI_COMM_WORLD);

    if (my_rank == 0)
    {
        ofstream cout(argv[2]);
        cout << *max_element(col.begin(), col.end()) << endl;
        for (auto i : col)
            cout << (i == -1 ? 1 : i) << " ";
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
        printf("Total time (s): %f\n", maxTime);

    MPI_Finalize();
    return 0;
}