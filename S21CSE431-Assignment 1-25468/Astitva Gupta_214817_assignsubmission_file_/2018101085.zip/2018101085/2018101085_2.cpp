#include <bits/stdc++.h>
#include <mpi.h>
#include <time.h>

using namespace std;

int partArray(vector<int> &a, int pivot)
{
	int i = 0;
	for (int j = 0; j < a.size(); ++j)
		if (a[j] <= pivot)
		{
			a[i] = a[j] + a[i] - (a[j] = a[i]);
			i++;
		}
	return i;
}

void quicksort(vector<int> &a, int start, int end, int n)
{
	if (start < end)
	{
		int medean, mid = start + (end - start) / 2;
		if ((a[start] >= a[mid] && a[mid] >= a[end]) || (a[end] >= a[mid] && a[mid] >= a[start]))
		{
			medean = a[mid];
			swap(a[mid], a[start]);
		}
		else if ((a[mid] >= a[start] && a[start] >= a[end]) || (a[mid] <= a[start] && a[start] <= a[end]))
			medean = a[start];
		else
		{
			medean = a[end];
			swap(a[end], a[start]);
		}
		int i = start;
		for (int j = start + 1; j < end + 1; ++j)
		{
			if (a[j] < a[start])
			{
				i++;
				swap(a[i], a[j]);
			}
		}
		swap(a[i], a[start]);
		quicksort(a, start, i - 1, n);
		quicksort(a, i + 1, end, n);
	}
}

void parallel_qs(vector<int> &my_arr, int p_start, int p_size, int my_rank, int count = 0)
{
	if (p_size == 0)
		return;
	if (p_size == 1)
	{
		int n = my_arr.size();
		quicksort(my_arr, 0, n - 1, n);
		return;
	}

	int random_process,
		pivot = 0;

	if (my_rank == p_start)
	{
		srand(time(NULL));
		random_process = rand() % p_size + p_start;
		for (int i = 0; i < p_size; i++)
			if (i + p_start != my_rank)
				MPI_Send(&random_process, 1, MPI_INT, i + p_start, 0, MPI_COMM_WORLD);
	}
	else
		MPI_Recv(&random_process, 1, MPI_INT, p_start, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	if (my_rank == random_process)
	{
		pivot = my_arr.size() ? my_arr[rand() % my_arr.size()] : 0;
		for (int i = 0; i < p_size; i++)
			if (i + p_start != my_rank)
				MPI_Send(&pivot, 1, MPI_INT, i + p_start, 0, MPI_COMM_WORLD);
	}
	else
		MPI_Recv(&pivot, 1, MPI_INT, random_process, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	int numLess = partArray(my_arr, pivot);
	vector<int> sent_array, rec_array;

	vector<int> my_arr2 = my_arr;
	if (my_rank < p_start + p_size / 2)
	{
		sent_array = vector<int>(my_arr.begin(), my_arr.begin() + numLess);
		my_arr = vector<int>(my_arr.begin() + numLess, my_arr.end());

		int sent_size = sent_array.size(), rec_size;

		MPI_Send(&sent_size, 1, MPI_INT, my_rank + p_size / 2, 0, MPI_COMM_WORLD);
		MPI_Recv(&rec_size, 1, MPI_INT, my_rank + p_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		rec_array.resize(rec_size);

		MPI_Send(&sent_array[0], sent_size, MPI_INT, my_rank + p_size / 2, 0, MPI_COMM_WORLD);
		MPI_Recv(&rec_array[0], rec_size, MPI_INT, my_rank + p_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}
	else if (p_size % 2 == 0 || my_rank != p_start + p_size - 1)
	{
		sent_array = vector<int>(my_arr.begin() + numLess, my_arr.end());
		my_arr = vector<int>(my_arr.begin(), my_arr.begin() + numLess);

		int sent_size = sent_array.size(), rec_size;

		MPI_Recv(&rec_size, 1, MPI_INT, my_rank - p_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		MPI_Send(&sent_size, 1, MPI_INT, my_rank - p_size / 2, 0, MPI_COMM_WORLD);

		rec_array.resize(rec_size);

		MPI_Recv(&rec_array[0], rec_size, MPI_INT, my_rank - p_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		MPI_Send(&sent_array[0], sent_size, MPI_INT, my_rank - p_size / 2, 0, MPI_COMM_WORLD);
	}

	my_arr.insert(my_arr.end(), rec_array.begin(), rec_array.end());

	if (p_size % 2 != 0 && my_rank == p_size + p_start - 1)
	{
		sent_array = vector<int>(my_arr.begin() + numLess, my_arr.end());
		my_arr = vector<int>(my_arr.begin(), my_arr.begin() + numLess);

		int sent_size = sent_array.size();

		MPI_Send(&sent_size, 1, MPI_INT, p_start, 0, MPI_COMM_WORLD);
		MPI_Send(&sent_array[0], sent_size, MPI_INT, p_start, 0, MPI_COMM_WORLD);
	}
	else if (p_size % 2 != 0 && my_rank == p_start)
	{
		int rec_size;
		MPI_Recv(&rec_size, 1, MPI_INT, p_size + p_start - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		rec_array = vector<int>(rec_size);
		MPI_Recv(&rec_array[0], rec_size, MPI_INT, p_size + p_start - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		my_arr.insert(my_arr.end(), rec_array.begin(), rec_array.end());
	}

	if (my_rank < p_start + p_size / 2)
		parallel_qs(my_arr, p_start, p_size / 2, my_rank, count + 1);
	else
		parallel_qs(my_arr, p_start + p_size / 2, p_size - p_size / 2, my_rank, count + 1);
}

int main(int argc, char *argv[])
{
	int size, my_rank;

	/* start up MPI */
    MPI_Init(&argc, &argv);

	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

	/*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

	if (argc != 3)
	{
		if (my_rank == 0)
			printf("Provide both input and output file locations!!\n");
		MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
	}

	vector<int> my_arr;
	if (my_rank == 0)
	{
		ifstream in(argv[1]);
		auto cinbuf = cin.rdbuf(in.rdbuf());

		int x, n;
		vector<vector<int>> arr(size);
		cin >> n;
		for (int i = 0; i < n; i++)
		{
			cin >> x;
			arr[i % size].push_back(x);
		}
		my_arr = arr[0];

		for (int i = 1; i < size; i++)
		{
			int my_arr_size = arr[i].size();
			MPI_Send(&my_arr_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
			MPI_Send(&arr[i][0], my_arr_size, MPI_INT, i, 0, MPI_COMM_WORLD);
		}
		arr.clear();
	}
	else
	{
		int my_arr_size;
		MPI_Recv(&my_arr_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		my_arr.resize(my_arr_size);
		MPI_Recv(&my_arr[0], my_arr_size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	parallel_qs(my_arr, 0, size, my_rank);

	int my_arr_size = my_arr.size();
	if (my_rank == 0)
	{
		vector<int> rec_array, ret;
		ofstream cout(argv[2]);
		for (int i = size - 1; i > 0; i--)
		{
			MPI_Recv(&my_arr_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			rec_array = vector<int>(my_arr_size);
			MPI_Recv(&rec_array[0], my_arr_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			for (auto i : rec_array)
				cout << i << endl;
		}
		for (auto i : my_arr)
			cout << i << endl;
	}
	else
	{
		MPI_Send(&my_arr_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
		MPI_Send(&my_arr[0], my_arr_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (my_rank == 0)
        printf("Total time (s): %f\n", maxTime);


	MPI_Finalize();
	return EXIT_SUCCESS;
}
