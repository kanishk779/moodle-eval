Report


How to Run:
mpic++ 2019201037_1.cpp -o 1
mpirun -np 11 1 input.txt output.txt

Note: Here 11 is the number of processes.


Problem 1:Sum of reciprocals of the square of integers upto N
We have to find the sum of reciprocals of the square of integers upto N.

So let suppose if N=100 and we have 5 processes running then we will divide the series
into 5 equal parts with each process calculating the sum of 20 terms of the series i.e first process will calculatethe sum of series 
from 1 to 20 and second process will calculate the sum from 21 to 40 and so on.
Finally we will accumulate all the sum into final result which will be written in the output file.




Problem 2:  Given an array of numbers, your task is to return the array in sorted order by implementing parallel quicksort.

In this problem we have to implement parallel quicksort.
So if we have let 100 elements in our array and say 4 processes which are running in parallel, then we will break the list into arraySize/numProcess i.e 100/4=25 elements 
in each array. So number of array is equal to number of processes. Each process will apply quicksort on the
smaller array and finally the array is merged using two way merge into the final result array.
The final result is written on the output file provided as argument


