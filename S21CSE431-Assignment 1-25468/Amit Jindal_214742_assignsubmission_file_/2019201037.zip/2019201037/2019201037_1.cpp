/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

        ifstream file1;
        ofstream file2;
        string infile=argv[1];
        string outfile=argv[2];
        file1.open(infile);
        file2.open(outfile);
        int n;
        file1>>n;
        file1.close();
        int root_rank = 0;
        int size = 0;
        int my_rank;
        float result = 0;
        float buffer=0;


        if(rank == root_rank)
           for(int i=rank+1; i<=n; i+=(numprocs))
                buffer+=1.0/(  (i) * (i) );

        else
            for(int i=rank+1; i<=n; i+=(numprocs))
                buffer+=1.0/(  (i) * (i) );
        
        MPI_Reduce(&buffer, &result, 1, MPI_FLOAT, MPI_SUM, root_rank, MPI_COMM_WORLD);
        if(rank == root_rank){
            //cout<<"The sum of all ranks is: "<< result<<setprecision(6)<<endl;
            file2 << std::fixed;
    	    file2<< std::setprecision(6);
            file2<<result;
            file2.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
