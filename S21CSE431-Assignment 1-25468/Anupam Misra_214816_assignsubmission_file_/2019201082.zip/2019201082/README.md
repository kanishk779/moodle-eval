Question 1:
    divide n by number of processes
    Example: n = 10, processes = 2
    then 10/2 = 5 numbers per process
    so each process will calculate reciprocal value of 5 numbers
    and using mpi reduce we will sum it up and give the answer.
    