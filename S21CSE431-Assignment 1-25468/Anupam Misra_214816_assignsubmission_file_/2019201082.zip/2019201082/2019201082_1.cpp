#include <stdio.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int pid, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &pid );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
        int n;
        float total_sum=0.0, answer = 0.0;
        ifstream infile(argv[1]);   
        infile>>n;         
               
        if(pid == 0)
           for(ll i=pid+1; i<=n; i+=(numprocs)){
                ll prod = i * i;
                total_sum+=(1.0/prod);
                
            }
        else{
            
            for(ll i=pid+1; i<=n; i+=(numprocs)){
                ll prod = i * i;
                total_sum+=(1.0/prod);
                
            }
        
        }
        MPI_Reduce(&total_sum, &answer, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
        if(pid == 0){
            // printf("The sum of all pids is %f.\n", answer);
            ofstream file2;
            file2.open(argv[2]);
            file2<< setprecision( 6 ) <<answer;
            file2.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( pid == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}