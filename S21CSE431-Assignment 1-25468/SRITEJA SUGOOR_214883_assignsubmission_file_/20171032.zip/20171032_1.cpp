/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include <mpi.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


double compute(int a, int b) {
    double sum = 0;
    for (int i=a;i<=b;i++) {
        sum += 1 / (i*i);
    }
    return sum;
}

double compute(int a, int step, int n) {
    double sum = 0;
    for (int i=a;i<=n;i+=step) {
        sum += 1 / (double) (i*i);
    }
    // cout << a << " " << sum << "\n";
    return sum;
}

int main( int argc, char **argv ) {
    int rank, numprocs;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* wrie your code here */
    if (rank == 0) {
        std::fstream infile(argv[1], std::ios_base::in);
        std::fstream outfile(argv[2], std::ios_base::out);

        int N;
        infile >> N;
        // cout << N;
        int a[2];
        a[1] = N;
        for (int i=0;i<(numprocs-1);i++) {
            a[0] = i+2;
            MPI_Send(a, 2, MPI_INT, i+1, 0, MPI_COMM_WORLD);
        }
        double final = compute(1, numprocs, N);
        double temp = 0;
        for (int i=0;i<(numprocs-1);i++) {
            MPI_Recv(&temp, 1, MPI_DOUBLE, i+1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            final += temp;
        }
        // cout << "Final " << final << "\n";
        outfile << fixed<<setprecision(6) << final;
    } else {
        int b[2];
        MPI_Recv(b, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double sum = compute(b[0], numprocs, b[1]);
        MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }





    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}