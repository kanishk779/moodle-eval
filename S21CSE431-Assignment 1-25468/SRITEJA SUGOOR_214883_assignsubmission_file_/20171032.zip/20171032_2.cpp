/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<int, pair<int, int> > ppi; 

void swap(int* a, int* b)  
{  
    int t = *a;  
    *a = *b;  
    *b = t;  
} 

vector<int> mergeKArrays(vector<vector<int> > arr) 
{ 
    vector<int> output; 
  
    // Create a min heap with k heap nodes. Every 
    // heap node has first element of an array 
    priority_queue<ppi, vector<ppi>, greater<ppi> > pq; 
  
    for (int i = 0; i < arr.size(); i++) { 
        if (arr[i].size() > 0)
            pq.push({ arr[i][0], { i, 0 } }); 
    }
  
    // Now one by one get the minimum element 
    // from min heap and replace it with next 
    // element of its array 
    while (pq.empty() == false) { 
        ppi curr = pq.top(); 
        pq.pop(); 
  
        // i ==> Array Number 
        // j ==> Index in the array number 
        int i = curr.second.first; 
        int j = curr.second.second; 
  
        output.push_back(curr.first); 
  
        // The next element belongs to same array as 
        // current. 
        if (j + 1 < arr[i].size()) 
            pq.push({ arr[i][j + 1], { i, j + 1 } }); 
    } 
  
    return output; 
} 

int partition (int arr[], int low, int high)  
{  
    int pivot = arr[high]; // pivot  
    int i = (low - 1); // Index of smaller element  
  
    for (int j = low; j <= high - 1; j++)  
    {  
        // If current element is smaller than the pivot  
        if (arr[j] < pivot)  
        {  
            i++; // increment index of smaller element  
            swap(&arr[i], &arr[j]);  
        }  
    }  
    swap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}  

void printArray(int arr[], int size)  
{  
    int i;  
    for (i = 0; i < size; i++)  
        cout << arr[i] << " ";  
    cout << endl;  
}  

void quickSort(int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        
        int pi = partition(arr, low, high);  
        
        quickSort(arr, low, pi - 1);  
        quickSort(arr, pi + 1, high);  
    }  
}

void write_to_file(vector<int> v, char* fileName) {
        std::fstream outfile(fileName, std::ios_base::out);
        for (int i=0;i<v.size();i++) {
            outfile << v[i] << " ";
        }

}

void write_to_file(int a[], int n, char* fileName) {
        std::fstream outfile(fileName, std::ios_base::out);
        for (int i=0;i<n;i++) {
            outfile << a[i] << " " ;
        }

}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    // int n = 7;
    /* write your code here */
    MPI_Status status;

    if ( rank == 0 ) {
        int n;
        std::fstream infile(argv[1], std::ios_base::in);
        infile >> n;

        int arr[n];
        for (int i=0;i<n;i++) {
            infile >> arr[i];
        }

        // int arr[] = {15, 46, 48, 93, 39, 6, 72, 91, 14,
        //             36, 69, 40, 89, 61, 97, 12, 21, 54,
        //             53, 97, 84, 58, 32, 27, 33, 72, 20};  
        // // int n = sizeof(arr) / sizeof(arr[0]);
        // quickSort(arr, 0, n - 1);
        int step = (float)n / (float)numprocs;
        int temp;
        int start;
        int counts[numprocs];
        int cnt;
        int displacements[numprocs];
        int my_values[step+1];
        for (int i=0;i<numprocs;i++) {
            start = step * i;
            temp = i != numprocs - 1 ? step : (n - start);
            counts[i] = temp;
            displacements[i] = start;
        }
        int rem = n ;
        int rem_proc = numprocs;
        for (int i=0;i<numprocs;i++) {
            step = (float) rem / (float)rem_proc;
            counts[i] = step;
            displacements[i] = n - rem;
            rem-=step;
            rem_proc--;

        }

        MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);


        printArray(counts, numprocs);



        MPI_Scatter(counts, 1, MPI_INT, &cnt, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Scatterv(arr, counts, displacements, MPI_INT, my_values, counts[0], MPI_INT, 0, MPI_COMM_WORLD);
        


        // phase 1
        quickSort(my_values, 0, cnt-1);

        if (numprocs == 1) {
            write_to_file(my_values, n, argv[2]);

            // cout << "Final\n";
            // for (int i=0;i<n;i++) {
            //     cout << my_values[i] << " ";
            // }
            cout << "\n";
             MPI_Barrier( MPI_COMM_WORLD );
            double elapsedTime = MPI_Wtime() - tbeg;
            double maxTime;
            MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
            if ( rank == 0 ) {
                printf( "Total time (s): %f\n", maxTime );
            }

            /* shut down MPI */
            MPI_Finalize();
            return 0;
        }

        int samples[numprocs*numprocs];
        // temp = n / (numprocs*numprocs);
        for (int i=0;i<numprocs;i++) {
            temp = (i * n) / (numprocs * numprocs);
            // cout << "Temp " << rank << " " << temp << "\n"; 
            if (temp >= cnt) {
                samples[i] = samples[i-1];
                continue;
            
            }
            samples[i] = my_values[temp];
            // samples[i] = my_values[i * temp];
        }
        // cout << rank << "-> ";
        // printArray(my_values, counts[0]);
        // // cout << "samples -> ";
        // printArray(samples, numprocs);


        

        // phase 2
        for (int i=1;i<numprocs;i++) {
            MPI_Recv(samples + i*numprocs, numprocs, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }


        quickSort(samples, 0, numprocs*numprocs-1);
        // cout << rank << "-> ";
        // printArray(my_values, counts[0]);
        // cout << "samples -> ";
        // printArray(samples, numprocs*numprocs);
        temp = numprocs / 2 - 1;
        int pivots[numprocs-1];
        for (int i=0;i<numprocs-1;i++) {
            pivots[i] = samples[temp + (i+1)*numprocs];
        }

        // cout << "pivots -> " << rank << "\n";
        // printArray(pivots, numprocs-1);
        MPI_Bcast(&pivots,numprocs-1,MPI_INT,0,MPI_COMM_WORLD);

        int cnt_sl[numprocs] = {0};
        int dis_sl[numprocs] = {0};
        int ind = 0;

        for (int i=0;i<cnt && ind <(numprocs-1);i++) {
            dis_sl[ind] = i; 
            while (my_values[i] <= pivots[ind] && i < cnt) {
                cnt_sl[ind]++;
                i++;
            }
            ind++;
            i--;
            if (ind == numprocs-1) {
                i++;
                dis_sl[ind] = i;
                cnt_sl[ind] = cnt - i; 
            }
        }
        // cout << "sl =->   " << rank << "\n";
        //          printArray(cnt_sl, numprocs);
        // printArray(dis_sl, numprocs);


        for (int i=0;i<numprocs;i++) {
            if (i == rank) {
                continue;
            }

            MPI_Send(my_values + dis_sl[i], cnt_sl[i], MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        vector<vector<int>> new_values(numprocs);     
        for (int i=0;i<numprocs;i++) {
            if (i == rank) {
                for (int j=0;j<cnt_sl[i];j++) {
                    new_values[i].push_back(my_values[dis_sl[i]+j]);
                }
                continue;
            }
            new_values[i].resize(step+1);
            MPI_Recv(&new_values[i][0], step+1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            MPI_Get_count(&status, MPI_INT, &temp);
            // cout <<"sz " << rank << " " << i << " " << temp <<  "\n";
            new_values[i].resize(temp);


        }
        // cout <<"values -> " << rank << "\n"; 
        // for (int i=0;i<numprocs;i++) {
        //     for (int j=0;j<new_values[i].size();j++) {
        //         cout << new_values[i][j] << " ";
        //     }
        //     cout << endl;
        // }
        vector<int> t2 = mergeKArrays(new_values);
        temp = t2.size();
        int sz;
        // MPI_GATHER
        t2.resize(n);
        for (int i=1;i<numprocs;i++) {
            MPI_Recv(&t2[temp], step+1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            MPI_Get_count(&status, MPI_INT, &sz);
            temp += sz;

        }

        // cout << rank << "-> ";
        // printArray(my_values, counts[0]);
        // printArray(pivots, numprocs-1);
        //  printArray(cnt_sl, numprocs);
        // printArray(dis_sl, numprocs);

                    write_to_file(t2,  argv[2]);


        // cout << "Final\n";
        // for (int i=0;i<n;i++) {
        //     cout << t2[i] << " ";
        // }
        // cout << "\n";

        // printArray(arr, n);
    } else {
        int cnt;
        int n;
        MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
        int step = n / numprocs;
        MPI_Scatter(NULL, 1, MPI_INT, &cnt, 1, MPI_INT, 0, MPI_COMM_WORLD);
        
        int my_values[cnt];
        MPI_Scatterv(NULL, NULL,  NULL,  MPI_INT, my_values, cnt, MPI_INT, 0, MPI_COMM_WORLD);
        
        // phase 1
        quickSort(my_values, 0, cnt-1);
        int samples[numprocs];
        int temp = n / (numprocs*numprocs);
        for (int i=0;i<numprocs;i++) {

            temp = (i * n) / (numprocs * numprocs);
            // cout << "Temp " << rank << " " << temp << " " << numprocs << " " << n << "\n"; 
            if (temp >= cnt) {
                samples[i] = samples[i-1];
                continue;
            }
            samples[i] = my_values[temp];
        }

        // cout << rank << "-> ";
        // printArray(my_values, cnt);
        // printArray(samples, numprocs);

        // phase 2
        MPI_Send(samples, numprocs, MPI_INT, 0, 0, MPI_COMM_WORLD);
        int pivots[numprocs-1];
        MPI_Bcast(&pivots,numprocs-1,MPI_INT,0,MPI_COMM_WORLD);
        
        int cnt_sl[numprocs] = {0};
        int dis_sl[numprocs] = {0};
        int ind = 0;

        for (int i=0;i<cnt && ind <(numprocs-1);i++) {
            dis_sl[ind] = i; 
            while (my_values[i] <= pivots[ind] && i < cnt) {
                cnt_sl[ind]++;
                i++;
            }
            ind++;
            i--;
            if (ind == numprocs-1) {
                i++;
                dis_sl[ind] = i;
                cnt_sl[ind] = cnt - i; 
            }
        }

        // cout << "sl =->   " << rank << "\n";
        //          printArray(cnt_sl, numprocs);
        // printArray(dis_sl, numprocs);

        for (int i=0;i<numprocs;i++) {
            if (i == rank) {
                continue;
            }

            MPI_Send(my_values + dis_sl[i], cnt_sl[i], MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        vector<vector<int>> new_values(numprocs);     
        for (int i=0;i<numprocs;i++) {
            if (i == rank) {
                for (int j=0;j<cnt_sl[i];j++) {
                    new_values[i].push_back(my_values[dis_sl[i]+j]);
                }
                continue;
            }
            new_values[i].resize(step+1);
            MPI_Recv(&new_values[i][0], step+1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            MPI_Get_count(&status, MPI_INT, &temp);
            // cout <<"sz " << rank << " " << i << " " << temp <<  "\n";

            new_values[i].resize(temp);


        }
        // cout <<"values -> " << rank << "\n"; 
        // for (int i=0;i<numprocs;i++) {
        //     for (int j=0;j<new_values[i].size();j++) {
        //         cout << new_values[i][j] << " ";
        //     }
        //     cout << endl;
        //     // cout << new_values[i].size() << endl;
        // }

// vector<vector<int> > arr{ { 2, 6, 12 }, 
//                               { }, 
//                               { 23, 34, 90, 2000 } }; 
//                                   vector<int> output = mergeKArrays(arr); 
        vector<int> t2 = mergeKArrays(new_values);
        
        MPI_Send(&t2[0], t2.size(), MPI_INT, 0, 0, MPI_COMM_WORLD);
        // cout << rank << "-> ";
        // printArray(my_values, cnt);


        
        // printArray(cnt_sl, numprocs);
        // printArray(dis_sl, numprocs);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}