/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;
typedef pair<int, pair<int, int>> point;
bool overlap(point, point);

int main( int argc, char **argv ) {
    int rank, numprocs;
    cout << argc;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n, m;
    random_device rd;
    std::uniform_int_distribution<int> dist(1, 1000);
    mt19937 mt(rd());
    
    ifstream inp; ofstream out;
    inp.open(argv[1], ios::in);
    out.open(argv[2], ios::out);
    
    // input and initialisation
    inp >> n >> m;
    int graph_v[n];
    int graph_e[m];
    int adj_mat[m][m];
    int colours[m];
    int agreement = 0;
    vector<point> V;

    for (int i = 0; i < m; i++)
        colours[i] = 0;

    if (rank == 0) {
        // init graph
        for (int i = 0; i < m; i++)
            graph_e[i] = 0;
        for (int i = 0; i < n; i++)
            graph_v[i] = 0;
        for (int i = 0; i<m; i++){
            for (int j = 0; j<m; j++)
                adj_mat[i][j] = 0;
        }        

        for (int i= 0; i< m; i++){
            int a, b;
            inp >> a >> b;
            graph_v[--a]++;
            graph_v[--b]++;
            V.push_back(make_pair(i, make_pair(a, b)));
        }

        // prepare line graph
        for (int i = 0; i<m; i++) {
            for (int j = i+1; j<m; j++){
                if (overlap(V[i], V[j])) {
                    graph_e[i]++;
                    graph_e[j]++;
                    adj_mat[i][j] = 1;
                }
            }
        }
    }

    // broadcast to all processes
    MPI_Bcast(adj_mat, m*m, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(graph_e, m, MPI_INT, 0, MPI_COMM_WORLD);

    // divide edges among processes
    int colours_checked[m];
    int local_agreement = 0;
    int max_deg = 0;
    map<int, set<int>> M;
    map<int, set<int>> K;
    int chunk_size = ceil(m/(float)numprocs);
    int starts = rank * chunk_size;
    int ends = (rank + 1) * chunk_size;

    for (int i = 0; i < m; i++)
        max_deg = max(max_deg, graph_e[i]);

    for (int i = starts; i < ends && i < m; i++)
        for (int j = 0; j < graph_e[i] + 1; j++){
            M[i].insert(j+1);
            K[i].insert(j+1);
        }

    // phase iteration
    while(true) {
        for (int i = 0; i < m; i++)
            colours_checked[i] = 0;

        for (int i = starts; i < ends && i < m; i++) {
            if (colours[i] == 0) {
                int rng, ln;
                ln = dist(mt);
                
                rng = ln % M[i].size();
                auto it = M[i].begin();
                
                advance(it, rng);
                colours[i] = *it;
            }
        }

        MPI_Barrier( MPI_COMM_WORLD );

        for (int i = 0; i < m; i++)
            MPI_Reduce(&colours[i], &colours_checked[i], 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

        vector<pair<int, int>> colours_to_remove;
        bool agree = true;

        MPI_Bcast(colours_checked, m, MPI_INT, 0, MPI_COMM_WORLD);

        for (int node = starts; node < ends && node < m; node++) {
            for (int i = 0; i < m; i++) {
                bool check = node != i;
                if ((adj_mat[node][i] || adj_mat[i][node]) && check) {
                    if (colours_checked[i] != colours_checked[node])
                        colours_to_remove.push_back(make_pair(node, colours_checked[i]));

                    if (colours_checked[i] == colours_checked[node]) {
                        agree = false;
                        colours[node] = 0;
                        colours[i] = 0;
                    } 
                }
            }
        }

        if (agree){
            local_agreement = 1;
            agree = true;
        }

        MPI_Reduce(&local_agreement, &agreement, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Bcast(&agreement, 1, MPI_INT, 0, MPI_COMM_WORLD);

        bool check = agreement == numprocs;
        // all nodes agree
        if (check) {
            int bigg = 0;
            if (rank == 0) {
                for (int i = 0; i < m; i++)
                    if (colours_checked[i]>bigg)
                        bigg = colours_checked[i];

                out << bigg << "\n";
                
                for (int i = 0; i < m; i++)
                    out << colours_checked[i] << " ";
                
                out << "\n";
            }
            break;
        }

        // removing colours from pallette
        if (rank == 0){
            K = M;
        }

        for (auto it: colours_to_remove)
            if (M[it.first].find(it.second) != M[it.first].end()){
                auto tmp = local_agreement;
                M[it.first].erase(M[it.first].find(it.second));
            }
        
        // integrity check
        if (agree)
            agree = true;
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

bool overlap(point a, point b){
    bool match = a.second.first == b.second.first;
    match = match || a.second.second == b.second.first;
    match = match || a.second.first == b.second.second;
    return match || a.second.second == b.second.second;
}