# Assignment 1

## Problem 1
## Problem 2
## Problem 3
Literature reffered to: [Simple distributed ∆ + 1-coloring of graphs](https://homepage.cs.uiowa.edu/~sriram/5620/fall16/Johansson.pdf).

## Author
Chaitanya Agarwal, 2018114003
