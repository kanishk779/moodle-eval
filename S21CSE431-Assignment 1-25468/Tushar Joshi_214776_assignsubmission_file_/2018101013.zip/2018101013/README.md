# Assignment 1
***
##### Tushar Joshi
##### 2018101013


### Q1)
* The root process reads the input N from the file and 
then divides the work among other processes , 
each worker process performs computation on
{ N/(numproc-1) + rank <= N%(numproc-1) ? 1:0 }  numbers.

* The root process sends two numbers to other processes.

* Each process on receiving these two number , starts
computing sum of 1/(i*2) , for i starting from [ rec[0] , rec[1] ).

* After calculating the sum each worker process sends the
result to the root process.

* The root process than adds up these results and writes the
final output in the file.

### Q2)
* The root process reads the input from the file and 
then divides the work among other processes , 
each worker process performs sort on
{ N/(numproc-1) + rank<= N%(numproc-1) ? 1:0 }  numbers.

* The root process sends N to all the worker processes, so
that they can calculate the length of the array they are going
to recieve.

* The root process then sends chunks of the input to the
worker process from.

* Each process on receiving the array sorts the received chunk
of array by using the quick() function and sends it back to the
root process after sorting.

* The root process on receiving a sorted chunk , merges the
latest received chunk , with chunks that were received earlier
using the merge() function.

* After the root process has received arrays from all the
workers process and has performed merge on these , Prints
the final sorted array in the output file.

### Q3)
* The root process reads the graph from the input file and then
finds the set of independent uncolored edges. Set of
Independent uncolored edges is the set of uncolored edges
such that no two of them are neighbors.

* Since the independent edges consist of no neighboring
edges these can be colored parallely. So after finding the
independent set of uncolored edges the root process
distributes these edges among worker processes to be
colored parallely.

* The root node first sends the size of independent set to all
the worker processes , so they can compute the length of
array they are going to recieve.

* The root process then sends elements of the set to the
worker nodes and the edge matrix to each worker process.

* The worker process then calls the function color() for the
edge received and returns the corresponding marked color
of the edges back to the root process.

* The root process after receiving colors from all the worker
nodes updates the color in the edge matrix for these edges.

* In the next iteration of the while loop , it again finds the set of
independent edges among the remaining uncolored edges.

* The process continues until all the edges are colored.
