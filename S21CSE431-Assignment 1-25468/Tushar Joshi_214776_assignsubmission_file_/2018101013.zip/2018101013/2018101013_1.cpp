#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int size=numprocs;
    if(rank == 0)
    {
       
        
        ifstream inFile(argv[1]);

        if(!inFile.is_open())
        cout<<"Unable to open file\n";


         int n,i,a,c,d;
         string str;
         getline(inFile,str);
       
        double ans=0,r;
        
        n=1;
        n=stoi(str);
    	int bufferUnsorted[20];
	
        a=1;
        d=size-1;
        if(size==1)
        {
            for(i=1;i<=n;i++)
            ans+=1/double(i*i);

            
        }
        else
        {
            c=(n%d);
            for(i=0;i<d;i++)
            {
               
                bufferUnsorted[2*i]=a;
                a+=n/d;
                if(c>0)
                a++;

                c--;
                bufferUnsorted[2*i+1]=a;
            }
           

            for(int i=1;i<size;i++)
                MPI_Send(bufferUnsorted+2*(i-1),2,MPI_INT,i,0,MPI_COMM_WORLD);

            for(int i=1;i<size;i++)
                { 	MPI_Recv(&r, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    ans+=r;
                }
               
               
                    
        }        

        

            ofstream myfile (argv[2]);
            if (myfile.is_open())
            {
              
                myfile<<fixed << setprecision(6)<< ans;
                myfile.close();
            }
            else cout << "Unable to open file";
    }
    else 
    {
	     int received[2];
         double s=0;
         int i;
            MPI_Recv(received, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
           
        
        for(i=received[0];i<received[1];i++)
            s+=1/double(i*i);

	    
	    MPI_Send(&s, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}