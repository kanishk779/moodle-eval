#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int color (int mat[][3] , int m,int ind)
{
    set<int> st;
    int i,a=mat[ind][0],b=mat[ind][1];

    for(i=0;i<m;i++)
    {
        if( i!=ind && mat[i][2]<0 && ( mat[i][0]==a || mat[i][0]==b || mat[i][1]==a || mat[i][1]==b ) )
        {
            st.insert(mat[i][2]);
        }
    }
    int e=-1;
    while(st.find(e)!=st.end())
    {
        e--;
    }
    
    return e;
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int size=numprocs;
    if(rank == 0)
    {
         ifstream inFile(argv[1]);

        if(!inFile.is_open())
        cout<<"Unable to open file\n";

        string str;

        int n,m,a,b,c,d,e,z;
        
        getline(inFile,str,' ');
        n=stoi(str);
        getline(inFile,str);
        m=stoi(str);

    
        int arr[m][3],i,j,brr[m],crr[m];
        int k=0;

       for(i=0;i<m;i++)
       {
        

            getline(inFile,str,' ');
            a=stoi(str);
            getline(inFile,str);
            b=stoi(str);

           arr[i][0]=a;
           arr[i][1]=b;
           arr[i][2]=i+1;
       }

        d=0;
        
        for(int i=1;i<size;i++)
            MPI_Send(&m,1,MPI_INT,i,0,MPI_COMM_WORLD);

        while(1)
        {
            k=0;
            
            for(i=0;i<m;i++)
            {
                c=arr[i][2];
                a=arr[i][0];
                b=arr[i][1];
                for(j=0;j<m;j++)
                {
                    if( i!=j && ( arr[j][0]==a || arr[j][0] == b || arr[j][1]== a || arr[j][1] ==b ) )
                    {
                        c=max(c,arr[j][2]);
                       
                    }   

                }
                if(c==arr[i][2] && c>0)
                    {
                        brr[k]=i;
                        k++;
                    }
            }

            e=size-1;
            a=0;
            if(e>0)
            c=(k%e);

            

            if(k==0)
            {
                k=-1;
                for(int i=1;i<size;i++)
                MPI_Send(&k,1,MPI_INT,i,0,MPI_COMM_WORLD);
                break;

            }

            for(int i=1;i<size;i++)
                MPI_Send(&k,1,MPI_INT,i,0,MPI_COMM_WORLD);



            for( int i=1;i<size;i++)
            {
                if(i<=c)
                z=1;
                else
                z=0;

                MPI_Send(brr+a,k/e+z,MPI_INT,i,0,MPI_COMM_WORLD);

                if(k/e+z > 0)
                MPI_Send(arr,m*3,MPI_INT,i,0,MPI_COMM_WORLD);

                a=a+k/e+z;
            }

            a=0;
            for( int i=1;i<size;i++)
            {
                if(i<=c)
                z=1;
                else
                z=0;

                if(k/e+z > 0)
                MPI_Recv(crr+a,k/e+z, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                
                a=a+k/e+z;

            }

            for(i=a;i<k;i++)
            {
                crr[i]=color(arr,m,brr[i]);
            }

            for(i=0;i<k;i++)
            arr[brr[i]][2]=crr[i];

           
        }
        int mx=0;
        for(i=0;i<m;i++)
        {
            mx=max(mx,abs(arr[i][2]));
           
        }

        ofstream myfile (argv[2]);
        if (myfile.is_open())
        {
            
            myfile<<mx<<'\n';

            for(i=0;i<m-1;i++)
            {
               
                myfile<<abs(arr[i][2])<<' ';
            }
            myfile<<abs(arr[m-1][2]);

            myfile.close();
        }
        else cout << "Unable to open file";

        
    }
    else
    {
         int len,m;
         
         int i,d;
         
           MPI_Recv(&m, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

           
           int mat[m][3];
           
        while(1)
        {
             MPI_Recv(&len, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if(len==-1)
            break;
                
            d=size-1;

            if(rank<=len%d)
            {
                len/=d;
                len++;
            }
            else
            {
                len/=d;
            }
            
            

            int rec[len],send[len];
            
            MPI_Recv(rec, len, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            if(len>0)
            {
                MPI_Recv(mat, m*3, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                for(i=0;i<len;i++)
                {
                   
                    send[i]=color(mat,m,rec[i]);
                }

                MPI_Send(send,len,MPI_INT,0,0,MPI_COMM_WORLD);
            }    
        } 

  
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}