#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>
#include <bits/stdc++.h>
using namespace std;
int part(int arr[],int s,int e)
{
    int i,l=s-1,t;

    for(i=s;i<e;i++)
    {
        if(arr[i]<arr[e] )
        {
            l++;
            t=arr[l];
            arr[l]=arr[i];
            arr[i]=t;        
        }
    }
    
    l++;
    t=arr[l];
    arr[l]=arr[e];
    arr[e]=t; 

    return l;
}

void quick(int arr[],int s,int e)
{
    if(s<e)
    {
        int p=part(arr,s,e);

        quick(arr,s,p-1);
        quick(arr,p+1,e);
    }

}

void merge(int *l1,int n , int *l2 , int m ,int *ret)
{
    
    int i=0,j=0,k=0;

    while(i<n&&j<m)
    {
        if(l1[i]<=l2[j])
        {
            ret[k]=l1[i];
            i++;
            k++;
        }
        else
        {
            ret[k]=l2[j];
            j++;
            k++;
        }
    }

    while(i<n)
    {
        ret[k]=l1[i];
            i++;
            k++;
    }
    
    while(j<m)
    {
        ret[k]=l2[j];
            j++;
            k++;
    }

    

}

int main(int argc, char* argv[])
{

    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int size=numprocs;
   
    if(rank == 0)
    {
    
        ifstream inFile(argv[1]);

        if(!inFile.is_open())
        cout<<"Unable to open file\n";

       

         int n,i,a,c,d,j;
         string str;
         getline(inFile,str);
        
        double ans=0,r;
      
        n=1;
        n=stoi(str);
        int *arr=(int*)malloc(n * sizeof(int)); 
          int *brr=(int*)malloc(n * sizeof(int)); 
            int *crr=(int*)malloc(n * sizeof(int));

        int bufferUnsorted[20];

         int k=0,z=0;
        while(getline(inFile,str,' '))
        {
            arr[k]=stoi(str);
            k++;
        }
        string temp;
       
        
        
      
        a=0;
        d=size-1;

        if(size==1)
        {
            quick(arr,0,n-1);

        
        }
        else
        {
            a=0;
            c=(n%d);

            for(int i=1;i<size;i++)
                MPI_Send(&n,1,MPI_INT,i,0,MPI_COMM_WORLD);

            for( int i=1;i<size;i++)
                {
                    if(i<=c)
                    z=1;
                    else
                    z=0;

                    MPI_Send(arr+a,n/d+z,MPI_INT,i,0,MPI_COMM_WORLD);
                    a=a+n/d+z;
                }
            
                a=0;
            for(int i=1;i<size;i++)
                { 	 if(i<=c)
                    z=1;
                    else
                    z=0;

                    MPI_Recv(crr, n/d+z, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                   
                    merge(crr,n/d+z,arr,a,brr);
                    
                    for(j=0;j<n/d+z+a;j++)
                    {    arr[j]=brr[j];
                      
                    }

                    

                    a=a+n/d +z;
                }

                
                    
        }        
        
        ofstream myfile (argv[2]);
            if (myfile.is_open())
            {
               
                for(i=0;i<n-1;i++)
                myfile<<arr[i]<<' ';

                myfile<<arr[n-1];
               
                myfile.close();
            }
            else cout << "Unable to open file";

       
              

       

    }
    else 
    {
	     int len;
         double s=0;
         int i,d;
         
         MPI_Recv(&len, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        d=size-1;

        if(rank<=len%d)
        {
            len/=d;
            len++;
        }
        else
        {
            len/=d;
        }
        
        int rec[len];
        
         MPI_Recv(rec, len, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        
        quick(rec,0,len-1);

	        MPI_Send(rec,len,MPI_INT,0,0,MPI_COMM_WORLD); 
	   

    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

