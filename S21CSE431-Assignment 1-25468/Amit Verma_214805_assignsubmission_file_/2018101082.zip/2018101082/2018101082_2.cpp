/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void s(ll* b, ll* a)
{
    ll temp = *b;
    *b = *a;
    *a = temp;
}

ll part(ll arr[], ll l, ll h)
{
    ll i = (l - 1);
    ll p = arr[h];
    for (ll j = l; j <= h - 1; j++)
    {
        if (arr[j] < p)
        {
            i++;
            s(&arr[i], &arr[j]);
        }
    }
    s(&arr[i + 1], &arr[h]);
    return (i + 1);
}

void quick_sort(ll arr[], ll l, ll h)
{
    if (l < h)
    {

        ll c = part(arr, l, h);

        quick_sort(arr, l, c - 1);
        quick_sort(arr, c + 1, h);
    }
}

void  merge(ll arr1[], ll arr2[], ll N, ll M)
{
    ll array[N + M];
    ll count = 0;
    ll i = 0;
    ll j = 0;

    for (; i < M;)
    {
        ll value = arr2[i];

        for (; j < N;)
        {
            if (arr1[j] > value)
            {
                array[count++] = value;
                i++;
                break;
            }
            array[count++] = arr1[j];
            j++;
        }

        if (j == N)
        {
            break;
        }
    }

    if (i < M)
    {
        for (ll k = i; k < M; k++)
        {
            array[count++] = arr2[k];
        }
    }
    if (j < N)
    {
        for (ll k = j; k < N; k++)
        {
            array[count++] = arr1[k];
        }
    }

    for (ll l = 0; l < N + M; l++)
    {
        arr1[l] = array[l];
    }
}

int main( int argc, char **argv )
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (numprocs == 1)
    {
        string myText;
        string s[2];

        ifstream ReadFile;
        ReadFile.open(argv[1]);

        int i = 0;
        while (getline (ReadFile, myText))
        {
            s[i] = myText;
            i++;
        }

        stringstream geek(s[0]);
        ll N = 0;
        geek >> N;

        int n = s[1].length();
        char char_array_2[n + 1];
        strcpy(char_array_2, s[1].c_str());

        char delim[] = " ";
        char *ptr = strtok(char_array_2, delim);
        ll values_array[N];
        ll c2 = 0;
        while (ptr != NULL)
        {
            stringstream geek(ptr);
            ll N = 0;
            geek >> N;
            values_array[c2++] = N;
            ptr = strtok(NULL, delim);
        }

        ReadFile.close();

        //quick sort

        quick_sort(values_array, 0, N - 1);

        ofstream outfile;
        outfile.open(argv[2]);
        for (int i = 0; i < N; i++) {
            if (i == N - 1)
            {
                outfile << values_array[i] << endl;
            }
            else
            {
                outfile << values_array[i] << " ";
            }

        }
        outfile.close();
    }

    else
    {

        if (rank == 0)
        {
            string myText;
            string s[2];

            ifstream ReadFile;
            ReadFile.open(argv[1]);

            int i = 0;
            while (getline (ReadFile, myText))
            {
                s[i] = myText;
                i++;
            }

            stringstream geek(s[0]);
            ll N = 0;
            geek >> N;

            int n = s[1].length();
            char char_array_2[n + 1];
            strcpy(char_array_2, s[1].c_str());

            char delim[] = " ";
            char *ptr = strtok(char_array_2, delim);
            ll values_array[N];
            ll c2 = 0;
            while (ptr != NULL)
            {
                stringstream geek(ptr);
                ll N = 0;
                geek >> N;
                values_array[c2++] = N;
                ptr = strtok(NULL, delim);
            }

            ll rem = N % (numprocs - 1);
            ll quo = N / (numprocs - 1);

            ll v_arr[2];

            v_arr[0] = quo;
            v_arr[1] = rem;


            for (int i = 1; i < numprocs; i++)
            {
                MPI_Send(v_arr, 2, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            }

            for (int i = 1; i < numprocs; i++)
            {

                if (i == numprocs - 1)
                {
                    MPI_Send(values_array + (quo * (i - 1)), quo + rem, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
                }

                else
                {
                    MPI_Send(values_array + (quo * (i - 1)), quo, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
                }
            }

            ll recv_values[numprocs - 1][quo + rem];

            for (int i = 1; i < numprocs; i++)
            {
                if (i == numprocs - 1)
                {
                    MPI_Recv(*(recv_values + (i - 1)), quo + rem, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }

                else
                {
                    MPI_Recv(*(recv_values + (i - 1)), quo, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
            }

            //quick sorted arrays merged
            ll final_array[N];
            ll i_c = 0;

            if (numprocs == 2)
            {
                for (ll i = 0; i < quo + rem; i++)
                {
                    final_array[i_c++] = recv_values[0][i];
                }
                ofstream outfile;
                outfile.open(argv[2]);
                for (int i = 0; i < N; i++)
                {
                    if (i == N - 1)
                    {
                        outfile << final_array[i] << endl;
                    }
                    else
                    {
                        outfile << final_array[i] << " ";
                    }
                }
                outfile.close();
            }

            else if (numprocs > 2)
            {
                for (ll i = 0; i < quo; i++)
                {
                    final_array[i_c++] = recv_values[0][i];
                }

                for (ll i = 0; i < numprocs - 3; i++)
                {
                    merge(final_array, *(recv_values + (i + 1)), i_c, quo);
                    i_c += quo;
                }

                merge(final_array, *(recv_values + (numprocs - 2)), i_c, quo + rem);

                ofstream outfile;
                outfile.open(argv[2]);
                for (int i = 0; i < N; i++)
                {
                    if (i == N - 1)
                    {
                        outfile << final_array[i] << endl;
                    }
                    else
                    {
                        outfile << final_array[i] << " ";
                    }
                }
                outfile.close();
            }
        }

        else if (rank == numprocs - 1)
        {
            ll values_array[2];
            MPI_Recv(values_array, 2 , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ll received[values_array[0] + values_array[1] + 1];
            MPI_Recv(received, values_array[0] + values_array[1] , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quick_sort(received, 0, (values_array[0] + values_array[1]) - 1);
            MPI_Send(received, values_array[0] + values_array[1], MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
        }

        else
        {
            ll values_array[2];
            MPI_Recv(values_array, 2 , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ll received[values_array[0] + 1];
            MPI_Recv(received, values_array[0] , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quick_sort(received, 0, values_array[0] - 1);
            MPI_Send(received, values_array[0] , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
        }
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}