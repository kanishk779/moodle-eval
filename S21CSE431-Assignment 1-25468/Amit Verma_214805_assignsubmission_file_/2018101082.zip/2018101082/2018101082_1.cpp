/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

double add(double arr[], int n)
{
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (numprocs == 1)
    {
        string myText;
        string s;

        ifstream ReadFile;
        ReadFile.open(argv[1]);

        while (getline (ReadFile, myText))
        {
            s = myText;
        }

        ReadFile.close();

        stringstream geek(s);
        ll ss = 0;
        geek >> ss;

        double send_buffer[ss];
        double sum = 0.0;
        for (int j = 1; j <= ss; j++)
        {
            send_buffer[j - 1] = 1 / ((float)j * (float)j);
            sum += send_buffer[j - 1];
        }

        ofstream outfile;
        outfile.open(argv[2]);
        outfile << fixed << setprecision(6) << sum << endl;
        outfile.close();
    }

    else
    {

        if (rank == 0)
        {
            string myText;
            string s;

            ifstream ReadFile;
            ReadFile.open(argv[1]);

            while (getline (ReadFile, myText))
            {
                s = myText;
            }

            ReadFile.close();

            stringstream geek(s);
            ll ss = 0;
            geek >> ss;

            ll rem = ss % (numprocs - 1);
            ll quo = ss / (numprocs - 1);

            ll values_array[2];

            values_array[0] = quo;
            values_array[1] = rem;

            double send_buffer[ss];
            double recv_buffer[numprocs - 1];
            for (int j = 1; j <= ss; j++)
            {
                send_buffer[j - 1] = 1 / ((float)j * (float)j);
            }

            for (int i = 1; i < numprocs; i++)
            {
                MPI_Send(values_array, 2, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            }

            for (int i = 1; i < numprocs; i++)
            {

                if (i == numprocs - 1)
                {
                    MPI_Send(send_buffer + (quo * (i - 1)), quo + rem, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
                }

                else
                {
                    MPI_Send(send_buffer + (quo * (i - 1)), quo, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
                }
            }

            for (int i = 1; i < numprocs; i++)
            {
                MPI_Recv(recv_buffer + (i - 1), 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }

            double sum = 0.0;
            for (int i = 0; i < numprocs - 1; i++)
            {
                sum += recv_buffer[i];
            }

            ofstream outfile;
            outfile.open(argv[2]);
            outfile << fixed << setprecision(6) << sum << endl;
            outfile.close();
        }

        else if (rank == numprocs - 1)
        {
            ll values_array[2];
            MPI_Recv(values_array, 2 , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            double received[values_array[0] + values_array[1] + 1];
            MPI_Recv(received, values_array[0] + values_array[1] , MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            double a = add(received, values_array[0] + values_array[1]);
            MPI_Send(&a, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }

        else
        {
            ll values_array[2];
            MPI_Recv(values_array, 2 , MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            double received[values_array[0] + 1];
            MPI_Recv(received, values_array[0] , MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            double a = add(received, values_array[0]);
            MPI_Send(&a, 1 , MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 )
    {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}