#include<bits/stdc++.h>
#include<mpi.h>

using namespace std;

int main(int argc, char* argv[])
{

	int rank, size;
	double res;
	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);  //MPI_COMM_WORLD is default communicator
	MPI_Comm_size(MPI_COMM_WORLD, &size);  // Get number of ranks in a specific communicator
	
	MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

	int n=0;
	double t1, t2; 

	if(rank==0)
	{
		fstream file;
		string fname=argv[1];
		file.open(fname.c_str(), ios:: in); 

		file >> n;
		// cout<<n<<"\n";
		file.close();
	}

	MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

	int x = n / size;
	int l,h,i;
	if(n >= size)
	{
		l = rank * x;
		if(rank != n-2)
			h = l + x;
		else
			h = n;
	}
	else
	{
		l = rank;
		h = l + 1;	
	}
	
	double msum = 0.0;
	for(i=l;i<h && i<n;i++)
	{
		msum += 1/(pow(i+1,2));
	}
	if(rank==size-1 && i<n)
	{
		while(i<n)
		{
			msum += 1/(pow(i+1,2));	
			i++;
		}
	}
	// cout<<rank<<" "<<l<<" "<<h<<" "<<msum<<"\n";
	MPI_Reduce(&msum, &res, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD); 

	MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

	if(rank==0)
	{
		cout<< "Elapsed time is: "<<maxTime<<"\n";
		string f_name=argv[2];
		fstream file;
		file.open(f_name.c_str(), ios::out);
		file << setprecision(7) << res; 
		file.close();
	}

	MPI_Finalize();
	return 0;
}