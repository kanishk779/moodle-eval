#Question-1
#sum of reciprocals of squares of integers
#numerical identity (pie^2)/6 problem
##Description
The input number,N is read by Rank 0 process and Rank 0 process assigns N/numprocs operations for each process after that each process adds up the 1/((number)^2) in the alloted range for that process. Finally Rank 0 process collects (Receives) the all added parts from all processses and now the final sum is stored in the output file.

#Question-2
# Quick Sort
## Description
This a master-slave type of construction. Master (process 0 i.e, Rank 0 process) distributes the array in chunks and send them to other processes. Rank 0 process act as the base or root process. Then, each process parallely sorts their respective chunks using quick sort algorithm. Then, they send their sorted chunks back to process 0, which is the rrot process. Process 0 then merges those chunks as follows :-
- Initially, it adds minimum element of each sorted chunk into a min heap.
- It takes out the minimum element from the min heap, add it into sorted list. Next element from the chunk which this element belonged to, is added into the heap.
- Above step is repeated until the priority queue is empty.

## Analysis
For an array of 100000 elements, approximate time taken data is :
- Sequential quick sort : 0.138 seconds
- Parallel quick sort : 0.104 seconds


#Question 3
## too difficult to attempt
### this is not the sort of question that should be asked in the assignment that too in the very first assignment. I faced too many errors and warnings, segmentation faults while installing MPI and running & executing it on my system. It's throwing different errors on different systems which wasted a lot of time for me. Even though one week time was given we can't dedicate whole one week for just one course assignment. I expect you to be little bit reasonable in deciding the toughness of the assignment. 