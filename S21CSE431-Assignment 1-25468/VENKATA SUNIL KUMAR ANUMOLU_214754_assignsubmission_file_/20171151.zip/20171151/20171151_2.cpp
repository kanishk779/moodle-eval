/* MPI Program temp_pairlate */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

#define ll int
#define PriQue_min priority_queue<pair<ll,ll>,vector<pair<ll,ll> > ,greater<pair<ll,ll> > >

ll partitionFunc(ll l,ll r, ll *arr)
{
    ll i=l-1,pivot=arr[r],j;
    for(j=l;j<r;j=j+1)
        if(arr[j] < pivot)
            swap(arr[i+1],arr[j]),	i=i+1;
    swap(arr[i+1],arr[r]),	i=i+1; 
    return i;
}

void quickSort(ll l,ll r,ll *arr)
{
    if(r<=l){
        return;
    }
	ll pivot= partitionFunc(l,r,arr);
    quickSort(l,-1+pivot,arr);
    quickSort(1+pivot,r,arr);
}

void mergeFunc(ll *ans,ll *a,ll *b,ll a1,ll a2)
{
    ll i=0,j=0;
    while(a1>i && a2>j)
        if(b[j] > a[i]){
	        ans[i+j]=a[i];
            i=i+1;
        }
        else{
        	ans[i+j]=b[j];
            j=j+1;
        }
    while(a1>i){
        ans[i+j]=a[i];
        i=i+1;
    }
    while(a2>j){
        ans[i+j]=b[j];
        j=j+1;
    }
}


int main( ll argc, char **argv )
{
    ll rank, numprocs;
      // /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    //my code starts
    ofstream OUT;
    OUT.open(argv[2]);
    ll N,chunksize=0;
    ll zz,i;
    ll T;
    // ll *par=(ll*)malloc(numprocs*sizeof(ll));
    // ll *mark=(ll*)malloc(numprocs*sizeof(ll));
    ll par[numprocs];
    ll mark[numprocs];
    ll a[1000002];
    if(!rank)
    {
        ll size_proc,extra=0;
        FILE *INP = fopen(argv[1], "r"); // read only 
        if (INP == NULL) 
        {   
            cout << "Error: Unable to open input fine\n"; 
            exit(-1);
        } 
        N=0;
        //a=(ll*)malloc((N+2)*sizeof(ll));

        while(fscanf(INP,"%d",&zz)==1)
            N++;
       	N=N-1;
        extra=N%numprocs;
        chunksize=N/numprocs;

        INP = fopen(argv[1], "r"); // read only 

        //cout << "Array size " << N  << endl;
        int cnt=0,g_size;
        for(i=0;i<N;cnt++){
            if(cnt==0){
                fscanf(INP,"%d",&g_size);
                continue;
            }
            else{
                fscanf(INP,"%d",&a[i]);
                i++;                
            }            
        }
        T = g_size;
        //cout<<"g_size is"<<g_size<<"\n";
        fclose(INP);    
        // for(i=0;i<N;i++)
        // 	cout << a[i] << " ";
       	// cout << endl;
        
        //manual inbuilt sort 
        if(N < numprocs){
            sort(a,a+N);
            for(int i=0;i<N;i++){
                OUT << a[i] << " ";
            }

            MPI_Bcast(&chunksize, 1 ,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(&N, 1 ,MPI_INT,0,MPI_COMM_WORLD); 


            MPI_Barrier( MPI_COMM_WORLD );
            double elapsedTime = MPI_Wtime() - tbeg;
            double maxTime;
            MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
            if ( rank == 0 ) {
                printf( "Total time (s): %f\n", maxTime );
            }

            /* shut down MPI */
            MPI_Finalize();
            return 0;
        }


        mark[0]=0;
        for(i=0;i<numprocs;i++)
        {
			par[i]=chunksize;
            if(extra > i)
                par[i]++;
            if(i)
                mark[i]=par[i-1]+mark[i-1];
        }
    }
    // ll *arr=(ll *) malloc(chunksize * sizeof(ll)),*a1=(ll *)malloc((N)*sizeof(ll));
        MPI_Bcast(&chunksize, 1 ,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(&N, 1 ,MPI_INT,0,MPI_COMM_WORLD);



    ll arr[chunksize];
    ll a1[N];
        if (N < numprocs) {
            MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD ); 
        MPI_Finalize();
    return 0;           
        }
    



        MPI_Bcast(par, numprocs ,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Bcast(mark, numprocs ,MPI_INT,0,MPI_COMM_WORLD);
        MPI_Scatterv(a,par,mark,MPI_INT,arr,par[rank],MPI_INT,0,MPI_COMM_WORLD);

        quickSort(0,par[rank]-1,arr);
    
        MPI_Gatherv(arr,par[rank],MPI_INT,a1,par,mark,MPI_INT,0,MPI_COMM_WORLD);   
   

	PriQue_min heap;
	pair <ll,ll> temp_pair;
    
    if(!rank)
    {
        //ll *final=(ll *)malloc(N*sizeof(ll)),i;
        ll final[N], i;
        for(i=0;i<N;i=i+1){    
            final[i]=0;
        }
        for(i=0;i<numprocs;i=i+1){ 
            final[mark[i]]=1;
        }
        for(i=0;i<numprocs;i=i+1){ 
            heap.push({a1[mark[i]],mark[i]});
        }
        while(!heap.empty())
        {
            temp_pair=heap.top();
            ll next=temp_pair.second+1;
            heap.pop();
            if(next<N && final[next]==0)
            {
                final[temp_pair.second+1]=1;
                heap.push({a1[next],next});
            }
            // if(T>0){
            //     OUT << temp_pair.first << " ";
            //     T--;
            // }
            OUT << temp_pair.first << " ";
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}