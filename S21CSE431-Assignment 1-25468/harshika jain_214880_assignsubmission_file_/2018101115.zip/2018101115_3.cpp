/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void formline(int m,int ori[][2],int v[509][509])
{
    int c=0,lin[3*m][2];
    // v=new int*[m];
    for(int i=0;i<m;i++)
    {
        // v[i] = new int[m];
        for(int j=i+1;j<m;j++)
        {
            // cout<<i<<" "<<j<<endl;
            if(ori[i][0]==ori[j][0] || ori[i][0]==ori[j][1] || ori[i][1]==ori[j][0] || ori[i][1]==ori[j][1] )
            {
                // cout<<i<<" "<<j<<endl;
                lin[c][0]=i;
                lin[c][1]=j;
                c++;
            }
        }
    }
    // cout<<m<<" "<<c<<endl;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<m;j++)
            v[i][j]=0;
    }
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<c;j++)
        {
            // cout<<i<<j<<endl;
            if(lin[j][0]==i)
            // {
            //     **((v+i*m)+lin[j][1])=1;
            // cout<<" hi";
            // }
                v[i][lin[j][1]]=1;
            if(lin[j][1]==i)
                // **((v+i*m)+lin[j][0])=1;
                v[i][lin[j][0]]=1;
        }
    }
    // return v;
}
void coloring(int v[509][509],int col[],int n, int e)
{
    cout<<"************************************\n";
    set<int> tmp;
    for(int i=0;i<n;i++)
    {
        if(v[e][i]==1 && col[i]!=-1)
        // if(v[e][i]==1 && col[i]!=-1)
            tmp.insert(col[i]);
    }
    int mi=1;
    while(1)
    {
        if(tmp.find(mi)==tmp.end())
            break;
        mi++;
    }
    col[e]=mi;
}

int check(int v[509][509],int col[],int e,int n)
{
    int fl=0;
    // cout<<"e: "<<e<<endl;
    // for(int i=0;i<n;i++)
    // {
    //     for(int j=0;j<n;j++)
    //         cout<<*(*(v+i)+j)<<" ";
    //     cout<<endl;
    // }
    // cout<<endl;
    // cout<<"e: "<<e<<" "<<*((v[e])+7)<<endl;
    for(int i=e+1;i<n;i++)
    {
        // cout<<"check:"<<e<<" "<<i<<" ";
        // cout<<*(*(v+e)+i)<<" ";
        // cout<<col[i]<<endl;
        if(col[i]==-1 && v[e][i]==1)
        // if(col[i]==-1 && *(*(v+e)+i)==1)
        {
            fl=1;
            break;
        }
    }
    if(fl==1)
        return 0;
    return 1;
}

int tmpe(int v[509][509],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            cout<<*(v[i]+j)<<" ";
        cout<<endl;
    }
    cout<<"com\n";
}


int main( int argc, char **argv ) {
    int rank, numprocs;
    // int ori[m][2];
    int n,m;
    int col[509];
    int v[509][509];
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    if(rank==0)
    {
        // int n,m;
        cin>>n>>m;
    }
    MPI_Bcast(&m,1,MPI_INT,0,MPI_COMM_WORLD);
    if(rank==0)
    {
        // cout<<m<<endl;
        int ori[m+2][2];
        // int v[m][m];
        for(int i=0;i<m;i++)
        {
            int x,y;
            cin>>ori[i][0]>>ori[i][1];
        }
        // int col[m];
        for(int i=0;i<m;i++)
            col[i]=-1;
        formline(m,ori,v);
        // cout<<"r\n";
        // for(int i=0;i<m;i++)
        // {
        //     for(int j=0;j<m;j++)
        //         cout<<v[i][j]<<" ";
        //     cout<<endl;
        // }
    }
    MPI_Bcast(&v[0][0],509*509,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&col,m,MPI_INT,0,MPI_COMM_WORLD);
    
    // MPI_Bcast(&v,m*m,MPI_INT,0,MPI_COMM_WORLD);
    // MPI_Bcast(&col,m,MPI_INT,0,MPI_COMM_WORLD);
    while(1)
    {
        // tmpe(v,m);
        int chunk=m/numprocs;
        int id=rank*chunk;
        int f=0;
        for(int i=id;i<chunk+id;i++)
        {
            if(col[i]==-1)
            {
                f=1;
                break;
            }
        }
        if(f==0)
            break;
        // int chunk=m/numprocs;
        // int id=rank*chunk;
        if(rank==numprocs-1)
            chunk=m-(chunk*(numprocs-1));
        // cout<<rank<<"RRRR "<<chunk<<" "<<id<<endl;
        cout<<"rank: "<<rank<<endl;
        for(int i=0;i<m;i++)
            cout<<col[i]<<" ";
        cout<<endl;
        for(int i=id;i<chunk+id;i++)
        {
            // cout<<"ranksss "<<i<<endl;
            int fl=check(v,col,i,m);
            // cout<<rank<<"RRR "<<i<<" "<<fl<<endl;
            if(fl==1)
            {
                // cout<<"enter\n";
                coloring(v,col,m,i);
                // cout<<"\n\nyee\n\n";
            }
        }
        // for(int i=0;i<m;i++)
        //     cout<<col[i]<<" ";
        // cout<<endl;
        if(rank==0)
        {
            int color[m];
            // cout<<"hii\n";
            MPI_Recv(color,m,MPI_INT,MPI_ANY_SOURCE,0,MPI_COMM_WORLD,&status);
            int sender = status.MPI_SOURCE;
            // cout<<"bye\n";
            int fl=0;
            for(int i=0;i<m;i++)
            {
                if(color[i]!=col[i])
                {
                    // cout<<"((((((((((((((((((((((\n";
                    col[i]=color[i];
                }
                if(col[i]==-1)
                    fl=1;
            }
            if(fl==0)
            {
                for(int i=0;i<m;i++)
                    cout<<col[i]<<" ";
                cout<<endl;
                break;
            }

            // MPI_Bcast(&col,m,MPI_INT,0,MPI_COMM_WORLD);
        }
        else
        {
             MPI_Send(col,m,MPI_INT,0,0,MPI_COMM_WORLD);
        }
        MPI_Bcast(&col,m,MPI_INT,0,MPI_COMM_WORLD);
    }
    // if(rank==0)
    // {
    //     for(int i=0;i<m;i++)
    //         cout<<col[i]<<" ";
    //     cout<<endl;
    // }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}


// 7 8
// 4 5
// 4 6
// 1 3
// 5 7
// 2 4
// 2 3
// 2 1
// 6 5
