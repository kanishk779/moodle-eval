/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<ll, pair<ll,ll> > pi;
ll m=INT_MIN;

ll partition(ll s,ll e,ll a[])
{
    ll i,j;
    i=s-1;
    ll pi=a[e];
    for(j=s;j<e;j++)
    {
        if (a[j]<=pi)
        {
            i++;
            swap(a[j],a[i]);
        }
    }
    swap(a[i+1],a[e]);
    return i+1;
}

void Sort(ll s,ll e,ll a[])
{
    if(s<e)
    {
        ll p=partition(s,e,a);
        Sort(s,p-1,a);
        Sort(p+1,e,a);
    }
}
int main( int argc, char **argv ) {
    int rank, numprocs;
    
    // ll ma=INT_MAX;
    // for(int i=0;i<n;i++)
    // {
    //     if(ma<a[i])
    //         ma=a[i]+1;
    // }
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    if(rank==0)
    {
        ifstream InFile(argv[1]);
        ofstream OutFile(argv[2]);
        ll n;
        InFile>>n;
        ll a[n+11];
        for(int i=0;i<n;i++)
        {
            InFile>>a[i];
        }
        vector<ll> v[numprocs+4];
        ll chunk,id;
        chunk=n/numprocs;
        if(chunk==0)
        {
            // ll m=a[0];
            for(int i=0;i<n;i++)
            {
                if(m<a[i])
                    m=a[i]+1;
            }
            chunk=1;
            for(int i=n;i<=numprocs;i++)
                a[i]=m;
        }
        // for(int i=0;i<numprocs;i++)
        //     cout<<a[i]<<" ";
        // cout<<endl;
        ll rem=chunk;
        Sort(0,chunk-1,a);
        if(numprocs>=2)
        {
            for(int i=1;i<numprocs-1;i++)
            {
                id=i*chunk;
                MPI_Send(&chunk,1,MPI_LONG_LONG_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&a[id],chunk,MPI_LONG_LONG_INT,i,0,MPI_COMM_WORLD);
            }
            id=(numprocs-1)*chunk;
            rem=max(n,(ll)numprocs)-id;
            MPI_Send(&rem,1,MPI_LONG_LONG_INT,numprocs-1,0,MPI_COMM_WORLD);
            MPI_Send(&a[id],rem,MPI_LONG_LONG_INT,numprocs-1,0,MPI_COMM_WORLD);
        }
        for(int i=1;i<numprocs-1;i++)
        {
            MPI_Recv(a+(chunk*i),chunk,MPI_LONG_LONG_INT,i,0,MPI_COMM_WORLD,&status);
            int sender = status.MPI_SOURCE;
        
        }
        if(numprocs>=2)
        {
            MPI_Recv(a+(chunk*(numprocs-1)),rem,MPI_LONG_LONG_INT,numprocs-1,0,MPI_COMM_WORLD,&status);
            int sender = status.MPI_SOURCE;
        }
        vector<ll> out;
        priority_queue<pi, vector<pi>, greater<pi> > pq;
        for(int i=0;i<numprocs;i++)
            pq.push({a[i*chunk],{i,0}});
        while(!pq.empty())
        {
            pi cur=pq.top();
            pq.pop();
            int i=cur.second.first;
            int j=cur.second.second;
            out.push_back(cur.first);
            if(i!=numprocs-1 && j+1<chunk)
                pq.push({a[chunk*i+j+1],{i,j+1}});
            else if(i==numprocs-1 && j+1<rem)
                pq.push({a[chunk*i+j+1],{i,j+1}});
        }
        for(int i=0;i<n;i++)
            OutFile<<out[i]<<" ";
        InFile.close();
        OutFile.close();
    }
    else
    {
        ll ch;
        MPI_Recv(&ch,1,MPI_LONG_LONG_INT,0,0,MPI_COMM_WORLD,&status);
        ll a2[ch+2];
        MPI_Recv(a2,ch,MPI_LONG_LONG_INT,0,0,MPI_COMM_WORLD,&status);
        Sort(0,ch-1,a2);
        MPI_Send(a2,ch,MPI_LONG_LONG_INT,0,0,MPI_COMM_WORLD);
        // for(int i=0;i<ch;i++)
        // {
        //     cout<<a2[i]<<","<<rank<<endl;
        // }
    }
    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    // cout<<numprocs<<endl;
    // for(int i=0;i<numprocs;i++)
    // {
    //     cout<<"size:"<<i<<endl;
    //     for(int j=0;j<v[i].size();j++)
    //         cout<<v[i][j]<<" ";
    //     cout<<endl;
    // }
    return 0;
}