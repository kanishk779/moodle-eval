/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    if(rank==0)
    {
        int chunk=0,id=0;
        double ans=0;
        ifstream InFile(argv[1]);
        ofstream OutFile(argv[2]);
        int n;
        InFile >> n;
        chunk = n/numprocs;
    
        for(int i=1;i<=chunk;i++)
        {
            // cout<<i<<endl;
            ans+=(1.0)/(i*i*1.0);
        }
        if(chunk<1)
        {
            ans+=1.0;
            for(int i=1;i<numprocs;i++)
            {
                if(i<n)
                {
                    id=i+1;
                    chunk=1;
                }
                else
                {
                    id=1;
                    chunk=0;
                }
                MPI_Send(&chunk,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&id,1,MPI_INT,i,0,MPI_COMM_WORLD);
            }
        }
        else if(numprocs>=2)
        {
            for(int i=1;i<numprocs-1;i++)
            {
                id=(i*chunk)+1;
                MPI_Send(&chunk,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&id,1,MPI_INT,i,0,MPI_COMM_WORLD);
            }
            id=((numprocs-1)*chunk)+1;
            chunk=n+1-id;
            MPI_Send(&chunk,1,MPI_INT,numprocs-1,0,MPI_COMM_WORLD);
            MPI_Send(&id,1,MPI_INT,numprocs-1,0,MPI_COMM_WORLD);
        }
        double rec=0;
        for(int i=1;i<numprocs;i++)
        {
            MPI_Recv(&rec,1,MPI_DOUBLE,MPI_ANY_SOURCE,0,MPI_COMM_WORLD,&status);
            int sender = status.MPI_SOURCE;
            ans+=rec;
        }
        OutFile<<fixed<<setprecision(6)<<ans<<"\n";
        InFile.close();
        OutFile.close();
    }
    else
    {
        int st,chunk;
        MPI_Recv(&chunk,1,MPI_INT,0,0,MPI_COMM_WORLD,&status);
        MPI_Recv(&st,1,MPI_INT,0,0,MPI_COMM_WORLD,&status);
        double par_sum=0;
        int tmp=st;
        for(int i=0;i<chunk;i++)
        {
            par_sum += (1.0)/(tmp*tmp*1.0);
            // cout<<tmp<<endl;
            tmp++;
        }        
        MPI_Send(&par_sum,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD);
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();

    return 0;
}