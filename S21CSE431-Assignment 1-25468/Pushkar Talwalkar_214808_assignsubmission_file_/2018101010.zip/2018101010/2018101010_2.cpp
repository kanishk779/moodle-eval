#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<int, pair<int, int> > ppi; 

int partition(int A[], int l, int r){
    int i = l + 1;
    int pivot = A[l];
    for(int j = l+1; j<=r;j++){
        if( A[j] < pivot){
            swap(A[i++],A[j]);
        }
    }
    swap( A[l], A[i-1]);
    return i-1;
}

void quick_sort(int A[], int l, int r){   
    if(l<r){
        int pivot = partition(A, l, r);
        quick_sort(A, l, pivot - 1);
        quick_sort(A, pivot, r);
    }
}
void writer(char* S, int *A, int n){
    ofstream f_output;
    f_output.open(S);
    for(int i = 0;i<n;i++){
        f_output<<A[i]<<" ";
    }
    f_output.close();
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    int ierr;
    /* write your code here */

    if(rank == 0){
        ifstream f_input;
        int n;
        string S = argv[1];
        f_input.open(S);
        f_input >> n;
        int A[n];
        int i = 0;
        while(i<n){
            f_input>>A[i++];
        }
        f_input.close();
        if(numprocs == 1){
           quick_sort(A,0,n-1);
        }
        else{
            int send_tag = 2000;
            int j = partition(A, 0, n-1);
            quick_sort(A, j+1, n-1);
            ierr = MPI_Send(&j, 1, MPI_INT, 1, send_tag, MPI_COMM_WORLD);
            ierr = MPI_Send(A, j, MPI_INT, 1, send_tag, MPI_COMM_WORLD);
            int len;
            MPI_Status* status;
            ierr = MPI_Recv(&len, 1, MPI_INT, 1, send_tag, MPI_COMM_WORLD, status);
            // cout<<"YEET\n";
            int half[len];
            ierr = MPI_Recv(half, len, MPI_INT, 1, send_tag, MPI_COMM_WORLD, status);
            for(int i = 0; i<n;i++){
                if(i < j){
                    A[i] = half[i];
                }
            }
        }
        writer(argv[2], A, n);
        
        // // for(int i = 1; i < num_procs; i++){
        // //     int per_proc = n/num_procs;
        // //     int offset = (i-1)*per_proc;
        // //     if(i != num_procs - 1){
        // //         MPI_Send(arr + offset,per_proc,MPI_INT,i,send_tag,MPI_COMM_WORLD);
        // //     }
        // //     else{
        // //         MPI_Send(arr + offset, n-(arr+offset), MPI_INT, i, send_tag, MPI_COMM_WORLD);
        // //     }
        // // }
        // // accept the proc number of arrays and merge them using gfg algo!

        
    }
    else{
        int n;
        MPI_Status* status;
        int rec_tag = 2000;
        MPI_Recv(&n, 1, MPI_INT,0, rec_tag, MPI_COMM_WORLD, status);
        int arr[n];
        MPI_Recv(arr, n, MPI_INT,0, rec_tag, MPI_COMM_WORLD, status);
        quick_sort(arr,0,n-1);
        MPI_Send(&n,1, MPI_INT,0, rec_tag, MPI_COMM_WORLD);
        MPI_Send(arr,n, MPI_INT,0, rec_tag, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    
    if(rank == 0){
        cout<<"Time Taken : "<<maxTime<<"\n";
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
