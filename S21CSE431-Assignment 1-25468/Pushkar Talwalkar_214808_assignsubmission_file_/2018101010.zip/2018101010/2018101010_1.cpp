#include<bits/stdc++.h>
#include<mpi.h>
#include<fstream>
#include <iomanip>
using namespace std;

int main(int argc, char **argv){
    cout<<setprecision(7);
    MPI_Status status;
    int send_tag = 2001, rec_tag = 2001;
    int ierr, my_id, num_proc,n;
    double ans = 0;
    double part = 0;
    ierr = MPI_Init(&argc, &argv);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_proc);

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    // if(argc != 4){
    //     cout<<"Invalid number of inputs. Terminating!\n";
    // }
    if (my_id == 0){
        ifstream f_input;
        // string line;
        f_input.open(argv[1]);
        int n;
        f_input >> n;

        for(int i = num_proc;i<=n;i+=num_proc){
            ans+=(1.0)/(i*i);
        }
        for(int i = 1; i<num_proc;i++){
            MPI_Send(&n,1,MPI_INT,i,send_tag, MPI_COMM_WORLD);
        }
        for(int i = 1;i<num_proc;i++){
            MPI_Recv(&part,1,MPI_DOUBLE, MPI_ANY_SOURCE,rec_tag,MPI_COMM_WORLD, &status);
            ans += part;
        }
    }
    else{
        MPI_Recv(&n,1,MPI_INT,0,rec_tag,MPI_COMM_WORLD, &status);
        for(int i = my_id; i<=n; i+=num_proc){
            part += (1.0)/(i*i);
        }
        MPI_Send(&part,1, MPI_DOUBLE,0, send_tag,MPI_COMM_WORLD);
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    if(my_id == 0){
        ofstream f_output;
        f_output.open(argv[2]);
        f_output<<"The answer is : "<<ans<<"\n";
        cout<<"Total Time is : "<<maxTime<<"\n";
        f_output.close();
    }
    ierr = MPI_Finalize();
}