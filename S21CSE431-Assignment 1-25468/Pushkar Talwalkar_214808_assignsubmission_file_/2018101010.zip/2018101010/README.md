Q1 :

In this question, the algorithm followed is simple - We perfom the summation of the terms. We include parallelism by performing the summation of all terms of a particular modulus. For instance, if we have 5 proc
esses, then summation of terms {1,6,11..} is done by process 1, {2,7,12...} is done by process 2, ... {4,9,14...} is done by process 4 and {5,10,15...} is done by process 0 (the root).

The implementation is straightforward.

Q2:

In this question, we first partition the original array, using the standard partition function used to perform quicksort. Then, now that we have 2 subarrays in which the last element of the first subarray is less than or equal to the first element of the second array, we perform quicksort on the 2 subarrays on 2 separate processes. This requires the use of MPI.

There are other ideas, such as doing this recursively, but it would involve a lot of processes and would be hard to implement.
Another idea is to sort k subarrays within themselves (using k distinct processes) and then merge them in the root. But this would take more time (overheads, merging etc.), hence I implemented the method as dedd
scribed above. It has the drawback of effectively using only 2 processes, but still performs well.
~                                                                                            

Q3: 

I was unable to implement this problem due to lack of time. My apologies. 
    
