# Report Assignment 1 - 2018101018

### Q1
Assinged different ranges to different processes.
Each process computes the sum of squares of reciprocals of the range.
In the root process i add the sum from all the subprocesses to get the final answer.

### Q2
Assigned different elements to differnet processess depending on the array size and number of processess.
After each process return its sorted array, i am merging the sorted arrays to get a final sorted array.
Each process uses quicksort to sort the array and pivot is last element in quicksort algorithm.

### Q3
Assigned Random weights to edges.
Created a independent set of edges from the graph which are not yet coloured, as if the weight of ith edge is greater then all of its adjacent edges then i will push ith edge to the independent set.
The edges in independent set can be coloured independently i will asssign these edges to differnt processes to compute parallely and assign colours to them.
