/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(rank == 0)
    {
    	ifstream input_file;
        string filename = argv[1];
        input_file.open(filename.c_str());
    	int n,m;
    	string str;
    	getline(input_file,str,' ');
    	n=stoi(str);
    	getline(input_file,str);
    	m=stoi(str);
    	int edges[m][5];
    	srand(time(NULL));
    	int color[m];
    	for(int i=0;i<m;i++)
    	{
    		getline(input_file,str,' ');
    		int x = stoi(str);
    		getline(input_file,str);
    		int y = stoi(str);
    		edges[i][0]=x;
    		edges[i][1]=y;
    		edges[i][4]=i;
    		edges[i][2]=(int)(rand()%1000) + 1;
    		edges[i][3]=0;
    	}
    	int round=1,edge = m;
    	for(int i=1;i<numprocs;i++)
    		MPI_Send(&edge, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
    	while(edge>0)
    	{
    		int x=0;
    		int temp[m];
    		for(int i=0;i<m;i++)
    		{
    			if(edges[i][3]==0)
    			{
    				int maxi=0;
    				for(int j=0;j<m;j++)
    				{
    					if(j==i)
    						continue;
    					if(edges[j][3]==round || edges[j][3]==0)
    					{
    						if((edges[i][0] == edges[j][0])|| (edges[i][1] == edges[j][0]) || (edges[i][0] == edges[j][1]) || (edges[i][1] == edges[j][1]))
    							maxi = max(maxi,edges[j][2]);
    					}
    				}
    				if(edges[i][2] > maxi)
    				{
    					edges[i][3] = round;
    					temp[x] = edges[i][4];
    					x++;
    				}
    			}
    		}
    		if(numprocs == 1)
    		{
    			for(int i=0;i<x;i++)
    			{
    				vector<int>ar;
    				int r = temp[i];
    				for(int j=0;j<m;j++)
    				{
    					if(j==r)
    						continue;
						if((edges[r][0] == edges[j][0])|| (edges[i][1] == edges[j][0]) || (edges[i][0] == edges[j][1]) || (edges[i][1] == edges[j][1]))
							ar.push_back(color[j]);
    				}
    				sort(ar.begin(),ar.end());
    				int k=0,p=ar.size(),a=1;
    				while(k<p)
    				{
    					if(ar[k]==a)
    					{
    						while(k<p && ar[k]==a)
    							k++;
    						a++;
    					}
    					else
    						break;
    				}
    				color[r] = a;
    			}
    		}
    		else
    		{
    			int size = numprocs - 1, each = x/size;
    			for(int i=1;i<numprocs;i++)
    			{
    				MPI_Send(&m, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
    				MPI_Send(&each, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
    				MPI_Send(&x, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
    				MPI_Send(edges, 5*m, MPI_INT, i, 0, MPI_COMM_WORLD);
    				MPI_Send(color, m, MPI_INT, i, 0, MPI_COMM_WORLD);
    				if(i==numprocs - 1)
    					MPI_Send(temp+each*(i-1), each + x%size, MPI_INT, i, 0, MPI_COMM_WORLD);
    				else
    					MPI_Send(temp+each*(i-1), each, MPI_INT, i, 0, MPI_COMM_WORLD);
    			}
    			for(int i=1;i<numprocs;i++)
    			{
    				int rec[m];
    				MPI_Recv(rec, m, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    				for(int j=0;j<x;j++)
    				{
    					int r = temp[j];
    					color[r] = rec[r];
    				}
    			}
    		}
    		edge-=x;
    		round++;
    	}
    	ofstream output_file;
        output_file.open(argv[2]);
        for(int i=0;i<n;i++)
        {
            if(i==n-1)
                output_file << color[i];
            else
                output_file << color[i] << " ";
        }
    }
    else
    {
    	int edge;
    	MPI_Recv(&edge, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    	while(edge > 0)
    	{
	    	int m, each, x;
	    	int size = numprocs-1;
	    	MPI_Recv(&m, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    	MPI_Recv(&each, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    	MPI_Recv(&x, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    	int edges[m][5];
	    	MPI_Recv(edges, 5*m, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    	int color[m];
	    	MPI_Recv(color, m, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    	int temp[m];
	    	if(rank == numprocs - 1)
	    	{
	    		MPI_Recv(temp, each + x%(numprocs-1) , MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    		for(int i=0;i<each + x%size;i++)
				{
					vector<int>ar;
					int r = temp[i];
					for(int j=0;j<m;j++)
					{
						if(j==r)
							continue;
						if((edges[r][0] == edges[j][0])|| (edges[r][1] == edges[j][0]) || (edges[r][0] == edges[j][1]) || (edges[r][1] == edges[j][1]))
							ar.push_back(color[j]);
					}
					sort(ar.begin(),ar.end());
					int k=0,p=ar.size(),a=1;
					while(k<p)
					{
						if(ar[k]==a)
						{
							while(k<p && ar[k]==a)
								k++;
							a++;
						}
						else
							break;
					}
					color[r] = a;
				}
				MPI_Send(color, m, MPI_INT, 0, 0, MPI_COMM_WORLD);
	    	}
	    	else
	    	{
	    		MPI_Recv(temp, each , MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    		for(int i=0;i<each;i++)
				{
					vector<int>ar;
					int r = temp[i];
					for(int j=0;j<m;j++)
					{
						if(j==r)
							continue;
						if((edges[r][0] == edges[j][0])|| (edges[r][1] == edges[j][0]) || (edges[r][0] == edges[j][1]) || (edges[r][1] == edges[j][1]))
							ar.push_back(color[j]);
					}
					sort(ar.begin(),ar.end());
					int k=0,p=ar.size(),a=1;
					while(k<p)
					{
						if(ar[k]==a)
						{
							while(k<p && ar[k]==a)
								k++;
							a++;
						}
						else
							break;
					}
					color[r] = a;
				}
				MPI_Send(color, m, MPI_INT, 0, 0, MPI_COMM_WORLD);
	    	}
	    	edge-=x;
    	}
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
