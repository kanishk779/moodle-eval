#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void quickSort(int ar[], int l, int r)
{
    if(l >= r)
        return;
    int piv = ar[r], i = (l - 1);
    for (int j = l;j <= r-1;j++)
    {
        if(ar[j] < piv)
        {
            i++;
            int temp = ar[i];
            ar[i] = ar[j];
            ar[j] = temp;
        }
    }
    int temp = ar[i+1];
    ar[i+1] = ar[r];
    ar[r] = temp;
    int mid = i+1;
    quickSort(ar, l, mid - 1);
    quickSort(ar, mid + 1, r);
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(rank == 0)
    {
        ifstream input_file;
        string filename = argv[1];
        input_file.open(filename.c_str());

        string input;
        vector<int>arr;
        while(input_file >> input)
        {
            stringstream word(input);
            int x=0;
            word >> x;
            arr.push_back(x);
        }

        int size = numprocs-1, n = arr[0];
        int ar[n];
        for(int i=1;i<=n;i++)
            ar[i-1] = arr[i];

        if(numprocs == 1)
        {
            quickSort(ar,0,n-1);
            ofstream output_file;
            output_file.open(argv[2]);
            for(int i=0;i<n;i++)
            {
                if(i==n-1)
                    output_file << ar[i];
                else
                    output_file << ar[i] << " ";
            }
        }
        else
        {
            int each = n / size;
            for(int i=1;i<numprocs;i++)
            {
                MPI_Send(&n, 1, MPI_INT, i ,0, MPI_COMM_WORLD);
                if(i==numprocs - 1)
                    MPI_Send(ar+each*(i-1), each + n%size, MPI_INT, i, 0, MPI_COMM_WORLD);
                else
                    MPI_Send(ar+each*(i-1), each, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
            int len=0;
            for(int i=1;i<numprocs;i++)
            {
                if(i == numprocs-1)
                {
                	int s = each + n%(numprocs-1);
                    int *r = (int*)malloc(s * sizeof(int));
                    MPI_Recv(r, each + n%(numprocs-1), MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    int n1 = len,n2 = each + n%(numprocs-1);
                    int idx=0,i1=0,i2=0;
                    int * temp = (int*)malloc((n1+n2) * sizeof(int));
                    while(i1<n1 && i2<n2)
                    {
                        if(ar[i1] < r[i2])
                            temp[idx++] = ar[i1++];
                        else
                            temp[idx++] = r[i2++];
                    }
                    while(i1<n1)
                        temp[idx++] = ar[i1++];
                    while(i2<n2)
                        temp[idx++] = r[i2++];
                    for(int j=0;j<idx;j++)
                        ar[j] = temp[j];
                    len = idx;
                }
                else
                {
                	int s = each;
                    int *r = (int*)malloc(s*sizeof(int));
                    MPI_Recv(r, each, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    int n1 = len,n2 = each;
                    int idx=0,i1=0,i2=0;
                    int * temp = (int*)malloc((n1+n2) * sizeof(int));
                    while(i1<n1 && i2<n2)
                    {
                        if(ar[i1] < r[i2])
                            temp[idx++] = ar[i1++];
                        else
                            temp[idx++] = r[i2++];
                    }
                    while(i1<n1)
                        temp[idx++] = ar[i1++];
                    while(i2<n2)
                        temp[idx++] = r[i2++];
                    for(int j=0;j<idx;j++)
                        ar[j] = temp[j];
                    len = idx;
                }
            }
            ofstream output_file;
            output_file.open(argv[2]);
            for(int i=0;i<n;i++)
            {
                if(i==n-1)
                    output_file << ar[i];
                else
                    output_file << ar[i] << " ";
            }
        }
    }
    else
    {
        int n;
        MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int each = n / (numprocs - 1);
        if(rank == numprocs - 1)
        {
            int r[each + n%(numprocs-1)];
            MPI_Recv(r, each + n%(numprocs-1), MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quickSort(r,0,each + n%(numprocs-1) - 1);
            MPI_Send(r, each + n%(numprocs-1), MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
        else
        {
            int each = n / (numprocs - 1);
            int r[each];
            MPI_Recv(r, each, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quickSort(r,0,each - 1);
            MPI_Send(r, each, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

