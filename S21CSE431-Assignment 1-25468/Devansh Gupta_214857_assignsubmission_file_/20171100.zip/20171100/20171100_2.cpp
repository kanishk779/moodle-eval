#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void swap(int * v, int i, int j)
{
  int t = v[i];
  v[i] = v[j];
  v[j] = t;
}

void quicksort(int * v, int s, int n)
{
  int x, p, i;

  if (n <= 1)
    return;
  x = v[s + n/2];
  
  swap(v, s, s + n/2);
  p = s;
  for (i = s+1; i < s+n; i++)
    if (v[i] < x) {
      p++;
      swap(v, i, p);
    }
  
  swap(v, s, p);
  quicksort(v, s, p-s);
  quicksort(v, p+1, s+n-p-1);
}


int * merge(int * v1, int n1, int * v2, int n2)
{
  int * result = (int *)malloc((n1 + n2) * sizeof(int));
  int i = 0;
  int j = 0;
  int k;
  for (k = 0; k < n1 + n2; k++) {
    if (i >= n1) {
      result[k] = v2[j];
      j++;
    }
    else if (j >= n2) {
      result[k] = v1[i];
      i++;
    }
    else if (v1[i] < v2[j]) {
      result[k] = v1[i];
      i++;
    }
    else { 
      result[k] = v2[j];
      j++;
    }
  }
  return result;
}

int main(int argc, char ** argv)
{
    int n;
    int * data = NULL;
    int c, s;
    int * chunk;
    int o;
    int * other;
    int step;
    int numprocs, rank;
    MPI_Status status;
    double elapsed_time;
    FILE * file = NULL;
    int i;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if (rank == 0) {
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        c = (n%numprocs!=0) ? n/numprocs+1 : n/numprocs;
        data = (int *)malloc(numprocs*c * sizeof(int));
        for (i = 0; i < n; i++)
        fscanf(file, "%d", &(data[i]));
        fclose(file);
        for (i = n; i < numprocs*c; i++)
        data[i] = 0;
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    c = (n%numprocs!=0) ? n/numprocs+1 : n/numprocs;

    chunk = (int *)malloc(c * sizeof(int));
    MPI_Scatter(data, c, MPI_INT, chunk, c, MPI_INT, 0, MPI_COMM_WORLD);
    free(data);
    data = NULL;

    s = (n >= c * (rank + 1)) ? c : n - c * rank;
    quicksort(chunk, 0, s);

    for (step = 1; step < numprocs; step = 2*step) {
        if (rank % (2*step) != 0) {
        MPI_Send(chunk, s, MPI_INT, rank-step, 0, MPI_COMM_WORLD);
        break;
        }
        if (rank+step < numprocs) {
        o = (n >= c * (rank+2*step)) ? c * step : n - c * (rank+step);
        other = (int *)malloc(o * sizeof(int));
        MPI_Recv(other, o, MPI_INT, rank+step, 0, MPI_COMM_WORLD, &status);
        data = merge(chunk, s, other, o);
        free(chunk);
        free(other);
        chunk = data;
        s = s + o;
        }
    }

   if (rank == 0) {
        file = fopen(argv[2], "w");
        for (i = 0; i < s; i++)
        fprintf(file, "%d ", chunk[i]);
        fprintf(file, "\n");
        fclose(file);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

  MPI_Finalize();
  return 0;
}