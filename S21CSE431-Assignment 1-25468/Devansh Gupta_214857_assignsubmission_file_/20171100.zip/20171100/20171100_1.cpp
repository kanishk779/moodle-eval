/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs, elements_per_process;
    int N;

    ifstream inp;
    inp.open(argv[1]);
    int k;
    while(inp >> k)
     N = k;

    ofstream out;
    out.open(argv[2]);
    /* start up MPI */

    MPI_Status status;
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    elements_per_process = N/numprocs;
    /* write your code here */
    if(rank == 0)
    {
        int starting_Num, i;
        if(numprocs > 1)
        {
            for(int i = 1; i <= numprocs - 1; i++){
                starting_Num = (i-1) * elements_per_process + 1;
                MPI_Send(&starting_Num, 1, MPI_INT, i, 0 , MPI_COMM_WORLD);
            }
        }

        double sum = 0;
        for(int i = elements_per_process * (numprocs - 1) + 1;  i <= N; i++){
            sum += (double)1.0/(i*i*1.0);
        }

        double tmp;
        for(int i = 1; i < numprocs; i++)
        {
            MPI_Recv(&tmp, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
            sum += tmp;
        }
        // printf("%f\n", sum);
		out<<fixed<<setprecision(6)<<sum<<endl;
    }
    else
    {
        int start_num;
        MPI_Recv(&start_num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);

        double psum = 0;
        for(int i = start_num; i < start_num + elements_per_process; i++)
            psum += (double)1.0/(i*i*1.0);

        MPI_Send(&psum, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);        
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}