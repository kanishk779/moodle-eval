/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if(rank==0)
    {
        int n;
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n;
        input_file.close();
        int num=0;
        int window;
        if(numprocs==1)
        {
            double ans=0;
            for(int i=1;i<=n;i++)
            {
                ans+=(double(double(1)/double(i)))*(double(double(1)/double(i)));
            }
            ofstream outfile(argv[2]);
            outfile<<ans<<fixed << setprecision(6);
            outfile.close();
        
        }
        else
        {
            if(numprocs==2)
            {
                window=n;
                MPI_Send(&window, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
                MPI_Send(&num, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            }
            else
            {
                window=(n/(numprocs-2));
                for(int i=1;i<numprocs;i++)
                {
                    if(i==numprocs-1)
                    {
                        window = n-(window)*(numprocs-2);
                    }
                    // cout<<window<<"\n";
                    MPI_Send(&window, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
                    MPI_Send(&num, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
                    num+=window;
                }
            }
            double ans=0,received_val;
            for(int i=1;i<numprocs;i++)
            {
                MPI_Recv(&received_val, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                ans+=received_val;
            }
            
            ofstream outfile(argv[2]);
            outfile << fixed << setprecision(6) << ans << endl;
            outfile.close();
        } 
    }
    else
    {
        int window=0;
        int received_val=0;
        MPI_Recv(&window, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&received_val, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double temp_ans=0;
        for(int i=received_val+1;i<=received_val+window;i++)
        {
            temp_ans+=(double(double(1)/double(i)))*(double(double(1)/double(i)));
        }
        MPI_Send(&temp_ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);    
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}