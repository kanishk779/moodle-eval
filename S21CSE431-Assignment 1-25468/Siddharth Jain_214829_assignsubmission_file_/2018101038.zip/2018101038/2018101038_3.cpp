/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define pb push_back
int sizes_proc[12];
int adj[501][501];
int sizes_adj[501];
int color_node[501];
int nodes_proc[12][501];
int color_changes[501][2];
int val;
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    // /synchronize all processes/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    int n,m,x,y;
    int num_colored;
    if(rank==0)
    {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n;
        input_file >> m;
        vector <pair<ll,ll>> vec1;
        vec1.pb({0,0});
        for(int i=0;i<m;i++)
        {
            input_file >> x;
            input_file >> y;
            if(x>y)
                vec1.pb({y,x});
            else
                vec1.pb({x,y});
        }
        input_file.close();
        for(int i=1;i<=m;i++)
        {
            x=vec1[i].first;
            y=vec1[i].second;
            for(int j=i+1;j<=m;j++)
            {
                if(vec1[j].first==x || vec1[j].first==y || vec1[j].second==x || vec1[j].second==y)
                {
                    adj[j][sizes_adj[j]]=i;
                    adj[i][sizes_adj[i]]=j;
                    sizes_adj[i]++;
                    sizes_adj[j]++;
                }
            }
        }
        swap(n,m);
        int window=(n/(numprocs+1));
        int temp=0;
        for(int i=0;i<numprocs-1;i++)
        {
            for(int j=0;j<window;j++)
            {
                nodes_proc[i][j]=temp+j+1;
            }
            sizes_proc[i]=window;
            temp+=window;
        }
        window = n - (numprocs-1)*(window);
        for(int j=0;j<window;j++)
        {
            nodes_proc[numprocs-1][j]=temp+j+1;
        }
        sizes_proc[numprocs-1]=window;
    }

    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&m,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(adj,(501)*(501),MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(sizes_adj,(501),MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(color_node,(501),MPI_INT,0,MPI_COMM_WORLD);



    MPI_Bcast(nodes_proc,(12)*(501),MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(sizes_proc,(12),MPI_INT,0,MPI_COMM_WORLD);


    while(true)
    {
        int ch_cnt=0;
        int copy_changes[501][2];
        int copy_ch_cnt=0;
        for(int k=0;k<sizes_proc[rank];k++)
        {
            int curr=nodes_proc[rank][k];
            if(color_node[curr]!=0)
            {
                continue;
            }
            else
            {
                int fg=1;
                for(int i=0;i<sizes_adj[curr];i++)
                {
                    if(adj[curr][i]>curr && color_node[adj[curr][i]]==0)
                    {
                        fg=0;
                        break;
                    }
                }
                if(fg)
                {
                    set <int> s1;
                    for(int i=0;i<sizes_adj[curr];i++)
                    {
                        if(color_node[adj[curr][i]]!=0)
                        {
                            s1.insert(color_node[adj[curr][i]]);
                        }
                    }
                    int new_color=0;
                    for(int i=1;i<=501;i++)
                    {
                        if(s1.find(i)==s1.end())
                        {
                            new_color=i;
                            color_node[curr]=new_color;
                            color_changes[ch_cnt][0]=curr;
                            copy_changes[ch_cnt][0]=curr;
                            color_changes[ch_cnt][1]=new_color;
                            copy_changes[ch_cnt][1]=new_color;
                            ch_cnt++;
                            copy_ch_cnt++;
                            break;
                        }
                    }
                }
            }
        }
        for(int i=0;i<numprocs;i++)
        {
            MPI_Bcast(&ch_cnt,1,MPI_INT,i,MPI_COMM_WORLD);
            MPI_Bcast(color_changes,(501)*(2),MPI_INT,i,MPI_COMM_WORLD);
        
            if(rank != i)
            {
                int node_ind;
                int new_node_color;
                for(int j=0;j<ch_cnt;j++)
                {
                    node_ind=color_changes[j][0];
                    new_node_color=color_changes[j][1];
                    color_node[node_ind]=new_node_color;
                }
            }
            for(int j=0;j<copy_ch_cnt;j++)
            {
                for(int z=0;z<2;z++)
                    color_changes[j][z]=copy_changes[j][z];
            }
            ch_cnt=copy_ch_cnt;
        }
        int ending=0;
        if(rank==0)
        {
            int colored=0;
            for(int i=1;i<=n;i++)
            {
                if(color_node[i]!=0)
                {
                    colored+=1;
                }
            }
            if(colored==n)
            {
                ending=1;
                val=0;
                for(int i=1;i<=n;i++)
                {
                    val=max(val,color_node[i]);
                }           
            }
            else
                ending=0;

        }
        MPI_Bcast(&ending,1,MPI_INT,0,MPI_COMM_WORLD);
        if(ending)
        {
            break;
        }
    }
    if(rank==0)
    {
        ofstream outfile(argv[2]);    
        outfile<<val<<"\n";
        for(int i=1;i<=n;i++)
        {
            outfile<<color_node[i]<<" ";
        }
        outfile<<"\n";
        outfile.close();
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}