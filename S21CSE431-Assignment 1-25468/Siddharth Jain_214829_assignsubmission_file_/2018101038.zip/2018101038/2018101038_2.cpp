#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int sorted_array[1000006];
int unsorted_array[1000006];
int sorted_chunks[12][1000006];
int partition (int arr[], int low, int high)
{
    int pivot=arr[high];
    int big=high-1;
    int small=low;
    if(low==high)
    {    
        return low;
    }
    while(small < big)
    {
        while(small<high && arr[small]<pivot )
        {
            small++;
        }
        while(big>=low && arr[big]>=pivot )
        {
            big--;
        }
        if(small<big)
        {
            swap(arr[small],arr[big]);
        }
    }
    if(arr[small]>=pivot)
    {
    swap(arr[small],arr[high]);
        return small;
    }
    else if(arr[big]>=pivot)
    {
      swap(arr[big],arr[high]);
       return big;
   }
    else
        return high;
}
void quickSort(int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        int pi = partition(arr, low, high);  
        quickSort(arr, low, pi - 1);  
        quickSort(arr, pi + 1, high);  
    }  
}  
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_process = 0;
    if(rank == root_process)
    {
    	int n;
    	// cin>>n;
    	int window;
    	fstream input_file;
    	input_file.open(argv[1], ios::in);
        input_file >> n; 
    	// int unsorted_array[n];
        for(int i = 0; i < n; i++) 
        {
            input_file >> unsorted_array[i];
        } 
        input_file.close();
    	if(numprocs==1)
    	{

    		quickSort(unsorted_array,0,n-1);
			ofstream outfile(argv[2]);
	        for(int i=0;i<n;i++)
	        {
	            outfile<<unsorted_array[i]<<" ";
	        }
	        outfile.close();
    	}
    	else
    	{
    	if(numprocs!=2)
	    	window=n/(numprocs-2);
	    else
	    	window=n;
    	int start_ind=0;
    	for(int i=1;i<numprocs-1;i++)
    	{
            MPI_Send(&window, 1, MPI_INT, i, 0, MPI_COMM_WORLD);	
            MPI_Send(&unsorted_array[start_ind], window, MPI_INT, i, 0, MPI_COMM_WORLD);	
    		start_ind+=window;
    	}
    	window = n-(window)*(numprocs-2);
        MPI_Send(&window, 1, MPI_INT, numprocs-1, 0, MPI_COMM_WORLD);	
        MPI_Send(&unsorted_array[start_ind], window, MPI_INT, numprocs-1, 0, MPI_COMM_WORLD);

        if(numprocs==2)
        	window=n;
        else
	        window=n/(numprocs-2);
        int sorted_chunks[numprocs][window];
        int last_window=n-(window)*(numprocs-2);
        for(int i=1;i<numprocs;i++)
        {
        	if(i==numprocs-1)
        	{
	        	MPI_Recv(&sorted_chunks[i], last_window, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        	}
        	else
        	{
	        	MPI_Recv(&sorted_chunks[i], window, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	
        	}
        }
        priority_queue<pair<int,pair<int,int>>, vector<pair<int,pair<int,int>>>, greater<pair<int,pair<int,int>>> > pq;
        //{number, ind in array, ind of array}
        for(int i=1;i<numprocs-1;i++)
        {
        	pq.push({sorted_chunks[i][0],{1,i}});
        }
        if(last_window>0)
        {
        	pq.push({sorted_chunks[numprocs-1][0],{1,numprocs-1}});
        }
        int curr_ind_sorted=0;
        int chunk_ind;
        int curr_ind;
        int win_curr;
        while(!pq.empty())
        {
        	auto u=pq.top();
        	pq.pop();
        	sorted_array[curr_ind_sorted]=u.first;
        	curr_ind_sorted++;
        	chunk_ind=u.second.second;
        	curr_ind=u.second.first;
        	win_curr=window;
        	if(chunk_ind==numprocs-1)
        	{
        		win_curr=last_window;
        	}
        	if(curr_ind==win_curr)
        	{
        		continue;
        	}
        	else
        	{
        		pq.push({sorted_chunks[chunk_ind][curr_ind],{++curr_ind,chunk_ind}});
        	}
        }
            ofstream outfile(argv[2]);
            for(int i=0;i<n;i++)
            {
                outfile<<sorted_array[i]<<" ";
            }
            outfile.close();
    	}
    }
    else
    {
    	int window;
    	MPI_Recv(&window, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    	int array_chunk[window];
    	MPI_Recv(&array_chunk, window, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    	quickSort(array_chunk,0,window-1);
        MPI_Send(&array_chunk, window, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}