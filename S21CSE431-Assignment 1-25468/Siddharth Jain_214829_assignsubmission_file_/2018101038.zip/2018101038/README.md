#Distributed Systems Assignment - 1


#Question 1

#solution description

The integers from 1 to N are divided into processes such that all none of the process receive a large number of intergers as compared to other processes, i.e, they are divided equally in the initial p-2 processes and the last processes has the remainder intergers.

Each process (in parallel) then computes the sum of (1//(integer)) ^ 2 , then the root process accumulates the sum and adds these partial sums to get the required value.

#analyis

time taken to run for N=1e4 and 1 processes is 0.000223
time taken to run for N=1e4 and 11 processes is 0.000441


This shows that the overhead of mpi send/receive is far more than the reduction of time that parallelisation gives.

#Question 2

#solution description

Firslty, the array is dritibuted among p processes such that all none of the process receive a large number of numbers as compared to other processes, i.e, they are divided equally in the initial p-2 processes and the last processes has the remainder numbers.

Each process (in parallel) then performs quicksort on the array chunk that the process has, and then sends the sorted chunk back to the root process.

After receving all the sorted chunks, now the task is of combining these chunks into one single (sorted) array.
This is done using a reverse priority queue whose top is the lowest number in the priority queue. Then we use this element and give it to the array, then take the next element from the same sorted chunk which the smallest element belonged to, and then inserting this element in the priority queue, and then again poping the smallest number out of the priority queue and assining it to the array and so on...

#analysis

time taken to run for N=1e4 and 1 processes is 0.343477
time taken to run for N=1e4 and 11 processes is 1.525234

This shows that the overhead of mpi send/receive is far more than the reduction of time that parallelisation gives.



#Question 3

#solution description

https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/
A parallel approach is to be followed to color the edges of given graph in such a way that no two adjacent edges have same color and maximum number of colors used is not more than (1 + max(Delta of the original graph, Delta of the line graph)).

#steps

Firstly, coverting the given graph to line graph so that the problem reduces to vertex coloring instead of edge coloring.
The vertices is dritibuted among p processes such that all none of the process receive a large number of vertices as compared to other processes, i.e, they are divided equally in the initial p-1 processes and the last processes has the remainder vertices.
Each process has to color its nodes.
Each process when processing a node belonging to itself, it only colors it when the weight associated with the node is greater than the adjacent colored-nodes. If that condition satisfies then, the process colors the node with the lowest color that is not used in the adjacent colored nodes.
At the end of each iteration send back colored nodes from each process to every other process and hence update the node_color array corresponding to that process. Then we need to check if all the nodes are colored if they are, then an message is broadcasted saying that the task is done and the break statement executes.

#analysis

time taken to run for N=100 and M=500 and 1 processes is 0.003572
time taken to run for N=100 and M=500 and 1 processes is 0.015496


This shows that the overhead of mpi send/receive is far more than the reduction of time that parallelisation gives.
