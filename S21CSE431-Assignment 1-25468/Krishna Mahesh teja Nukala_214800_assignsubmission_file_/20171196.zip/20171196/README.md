<h1>Question-1</h1>
<hr>
<h4>Divided the range from 1 to n and processed parallely and added the results<h4>

<h1>Question-2</h1>
<hr>
<h4>Divided the Array according to number of process and used quick sort<h4>

<h1>Question-3</h1>
<hr>
<h4>Tried to implement the method in <a href="https://cscapes.cs.purdue.edu/pub/gebremedhin_coloring-cscapes08.pdf">Vertex coloring in parallel</a>Not Completed(No results will come on running the code)<h4>