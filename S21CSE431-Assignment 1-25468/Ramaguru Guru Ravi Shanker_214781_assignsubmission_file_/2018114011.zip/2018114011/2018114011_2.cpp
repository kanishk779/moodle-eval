#include <stdio.h>
#include<iostream>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<ll, ll> pi; 
ll partition(ll *arr,ll l,ll r)
{
    ll pi = arr[r];
    ll i = l - 1 , temp,j = l;
    while(j < r)
    {
        if(arr[j] < pi )
        {
            i++;
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    j++;
    }
    temp = arr[r];
    arr[r] = arr[i + 1];
    arr[i + 1] = temp;
    return i + 1;
}

void quicksort(ll l,ll r,ll *arr)
{
    if(l > r)
    {
        return;
    }
        else
        {
        ll pivot = partition(arr, l, r);
        quicksort(l,pivot - 1,arr);
        quicksort(pivot + 1, r,arr);
        }
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    /* write your code here */
    ifstream inputfile;
    ofstream outputfile;
    inputfile.open(argv[1]);
    outputfile.open(argv[2]);

    if(rank == 0)
    {
	ll N;
	inputfile >> N;
	ll arr[N];
	for(ll i = 0; i < N; i++)
	{
	   inputfile >> arr[i];
	}
	if(numprocs != 1)
	{
	ll diff = N/(numprocs - 1);
	diff = max((ll)1, diff);
	for(ll i = 1;i < numprocs; i++)
	{
	ll send = diff;
	if(i == numprocs - 1)
		send = max(send, N - (i - 1)*diff);
	if(N - (i - 1)*diff <= 0)
		send = -1;
        MPI_Send(&send, 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
	if(send != -1)
	MPI_Send(arr + (i - 1)*diff, send, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
        } 
	//map<ll,ll> mp;
	ll final_arr[numprocs - 1][diff*2 - 1];
	ll leng[numprocs - 1];
	priority_queue <pi, vector<pi>, greater<pi> > pq;
	for(ll i = 1;i < numprocs; i++)
	{
	ll receive;
        MPI_Recv(&receive, 1,MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	leng[i - 1] = receive;
	if(receive == -1)
	    continue;
	ll ans[receive];
        MPI_Recv(ans, receive,MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	for(ll j = 0; j < receive; j++)
	{
		final_arr[i - 1][j] = ans[j];
		if(j == 0)
		{
		    pq.push(make_pair(ans[j], i - 1));
		}
	}
	}
	ll pointers[numprocs - 1] = {0};
	for(ll i = 0; i < numprocs; i++)
	    pointers[i] += 1;
	while (pq.empty() == false)
    	{
		pi top = pq.top();
       		outputfile << pq.top().first << " ";
		if(pointers[top.second] < leng[top.second])
		{
		pq.push(make_pair(final_arr[top.second][pointers[top.second]], top.second));
		pointers[top.second]++;		
		}
        	pq.pop();
    	}
			outputfile << '\n';
	}
	else
	{
    	quicksort(0,N - 1,arr);
	for(ll i = 0; i < N; i++)
	    outputfile << arr[i] << " ";
	outputfile << "\n";
	}
    }
    else
    {
	ll receive;
        MPI_Recv(&receive, 1, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	
	if(receive != -1)
	{
	ll arr[receive];
	MPI_Recv(arr, receive, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
    	quicksort(0,receive - 1,arr);
        MPI_Send(&receive, 1,MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
        MPI_Send(arr, receive, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
    	}
	else
	{
        MPI_Send(&receive, 1,MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
	}
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
