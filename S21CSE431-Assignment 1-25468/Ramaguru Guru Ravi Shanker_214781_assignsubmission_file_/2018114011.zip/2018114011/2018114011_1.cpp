#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include<iostream>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
double Calculate(double l, double r)
{
  double ans = 0.;
  for(int i = l;i <= r; i++)
  {
  	ans += (1.0/i)*(1.0/i);
  }
return ans;
}
int main( int argc, char **argv ) {
    int rank, numprocs;
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    /* write your code here */

    ifstream inputfile;
    ofstream outputfile;
    inputfile.open(argv[1]);
    outputfile.open(argv[2]);
    if(rank == 0) 
    {
	int N;
	//cin >> N;
	inputfile >> N;
	inputfile.close();
	if(numprocs != 1)
	{
	int diff = N/(numprocs - 1);
	double l = 1.0;
	diff = max(1, diff);
   	for(int i = 1;i < numprocs; i++)
	{
	double r = l + double(diff) - 1.0;
	if(i == numprocs - 1 && r < N)
		r = N;
	if(r > N)
	   r = l - 1;	
	double arr[2];
	arr[0] = l;
	arr[1] = r;	
	MPI_Send(arr, 2, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
	l = r + 1;
        } 
	double final_ans = 0;
	for(int i = 1;i < numprocs; i++)
	{
        double ans;
        MPI_Recv(&ans, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	final_ans +=  ans;
	}
    	outputfile << fixed << setprecision(6) << final_ans << "\n";
    	//cout << fixed << setprecision(6) << final_ans << "\n";
    	outputfile.close();
	}
	else if(numprocs == 1)
	{
    	outputfile << fixed << setprecision(6) << Calculate(1,N) << "\n";
    	cout << fixed << setprecision(6) << Calculate(1,N) << "\n";
    	outputfile.close();
	}
    }
    else
    {
	double arr[2];
	MPI_Recv(arr, 2, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
    	double ans = Calculate(arr[0],arr[1]);
        MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
