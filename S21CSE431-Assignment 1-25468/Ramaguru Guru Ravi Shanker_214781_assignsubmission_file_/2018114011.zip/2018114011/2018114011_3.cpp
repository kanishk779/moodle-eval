#include <stdio.h>
#include<iostream>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    /* write your code here */
    ifstream inputfile;
    ofstream outputfile;
    inputfile.open(argv[1]);
    outputfile.open(argv[2]);
    ll N, M;
    ll adj[501][501];
    ll weights[501];
    ll colours[501];
    if(rank == 0)
    {
	inputfile >> N >> M;
	ll edges[M][2];
	for(ll i = 0; i < M; i++)
	{
	   inputfile >> edges[i][0];
	   inputfile >> edges[i][1];
	}
	for(ll i = 0; i < M; i++)
   	{
	    adj[i][i] = 1;
	    for(ll j = i + 1; j < M; j++)
		{
			if(edges[i][0] == edges[j][0] || edges[i][0] == edges[j][1] || edges[i][1] == edges[j][0] || edges[i][1] == edges[j][1])
			{
				adj[i][j] = 1;
				adj[j][i] = 1;	
			}
			else
			{
				adj[i][j] = 0;
				adj[j][i] = 0;
			}
		}
	}
	for(ll i = 0; i < M; i++)
	{
	    weights[i] = i + 1;
            colours[i] = 0;
	}
	random_shuffle(weights, weights + M);
    }
	MPI_Bcast(&N, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&M, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(weights, M, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(colours, M, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(adj, 501*501, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	
    while(1)
    {
	ll f = 0;
	for(ll i = 0; i < numprocs; i++)
	{	
	ll l, r, diff;
	diff = M/numprocs;
	diff = max(diff, (ll)1);
	l = i*diff;
	r = l + diff - 1;
	if(i == numprocs - 1) 			
	{
	    r = max(r, M - 1);
	}
	if(r > M - 1)
	   r = l - 1;
	vector<ll> indep;

	for(ll x = l; x <= r; x++)
	   {
	   ll fl = 0;
	   for(ll y = 0; y < M; y++)
		{
		if(x == y)
		    continue;
		if(colours[x] > 0 || (adj[x][y] == 1 && weights[x] <= weights[y]))
		  {
		  fl = 1;  
                  break;
		  }
		}	
	   if(fl == 0)
	      {
	      weights[x] = -1;
	      indep.push_back(x);
	      }   
	}
	set<ll> cols;
	for(ll z = 1; z <= M; z++)
	    cols.insert(z);
	ll send[indep.size()][2];
	for(ll k = 0; k < indep.size(); k++)
	{
	   for(ll y = 0; y < M; y++)
	   {
	   if(y == indep[k])
	       continue;
	   if(adj[indep[k]][y] == 1 && colours[y] > 0)
	   {
		if(cols.find(colours[y]) != cols.end())
		    cols.erase(colours[y]);
	   } 
	   }
	   colours[indep[k]] = *cols.begin();
	   send[k][0] = indep[k];
	   send[k][1] = colours[indep[k]];
	}
	ll size_send = indep.size();
	for(ll q = 0; q < numprocs; q++)
	{
	    if(q == i)	
	    {
	     MPI_Bcast(&size_send, 1, MPI_LONG_LONG_INT, q, MPI_COMM_WORLD);
	     MPI_Bcast(send, size_send*2 , MPI_LONG_LONG_INT, q, MPI_COMM_WORLD);
            }
	    else
	    {
	    ll size_rec;
	    MPI_Bcast(&size_rec, 1, MPI_LONG_LONG_INT, q, MPI_COMM_WORLD);
	    ll receive[size_rec][2];	
	    MPI_Bcast(receive, size_rec*2, MPI_LONG_LONG_INT, q, MPI_COMM_WORLD);
	    for(ll t = 0; t < size_rec; t++)
	    	{
	        colours[receive[t][0]] = receive[t][1];
	    	}
	    }
	}
	ll c = 0;
	for(ll j = 0; j < M; j++)
	{
	    if(colours[j] > 0)
	    {
		c++;
            }
	}
	if(c == M)
	    f = 1;
	}

	if(f == 1)
	   break;
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
	ll m = 0;
	for(ll i = 0; i < M; i++)
	   m =  max(m, colours[i]);
	outputfile << m << "\n";
	for(ll i = 0; i < M; i++)
	   outputfile << colours[i] << " ";
        outputfile << '\n';
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
