# Assignment - 1(Distributed Systems)
                                        Done by,
                                        R. Guru Ravi Shanker 2018114011
1. Question 1:
    **Describing**
       - Took input(N) in the first process(rank 0).
       - Sent l,r from first process(parent process) to other process which will calculate the sum of inverse squares from l to r (both inclusive) using MPI_SEND.
       - The calculated sum is sent back to the parent process where final sum is the aggregate of sum from all processes.
       - Distribution of l,r happens based on N and number of processes available.
       - All cases of N and number of processes are handled. If only 1 process is present the computation happens at the parent process itself.
    **Analysing**
       - Time increases with increase in N.
       - Time also increases with increase in number of processors because of more send and receive events even for small N. 

2. Question 2:
    **Describing**
       - Took input(N and the input array) in the first process(rank 0)
       - Distributed the array into equal parts to other processes other than first process(parent process) through MPI_SEND.
       - Quick sort on the received array happens at the processes.
       - All sorted array are sent back to the parent process where it is merged using a min_heap.
    **Analysing**
       - Time increases with increase in N as a larger array has to be sorted.
       - Time also increases with increase in number of processors because of more send and receive events even for small N. 

3. Question 3:
    **Describing**
       - Took input(N, M and the edges) in the first process(rank 0). Conveted the graph in to line graph and intialized colour array
       - Broadcasted it to all processes. Weights for each each was intiialized with their rank in the input.
       - Edges or vertices in the line graph are equally distributed to the processes.
       - We get the independent vertices based on weights and colour them according to the neighbours and the process continues in each process.
       - Finally the code terminated when each of the edge is coloured.

    **Analysing**
        - With increase in N, M time increases.
        - With less number of nodes time increases with number of processes.
        - With increase in nodes no time doesn't monotonically increase with number of processes.
    

    

     