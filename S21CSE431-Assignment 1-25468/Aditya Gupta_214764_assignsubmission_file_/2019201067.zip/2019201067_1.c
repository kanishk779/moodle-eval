#include <mpi.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
// #include<iostream>

// using namespace std;
 
   
int main(int argc, char* argv[]) 
{ 
  
    int pid, np;
   int n_elements_recieved,n; 
   int elements_per_process;
   
   MPI_Status status; 

  MPI_Init(&argc, &argv); 
  
   MPI_Comm_size(MPI_COMM_WORLD, &np); 
   MPI_Comm_rank(MPI_COMM_WORLD, &pid); 

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
  
    float a2[1000];
    if (pid == 0) 
    { 
                
        FILE *fp;
        fp = fopen(argv[argc - 2],"r");
       if (fp == NULL)
        {
            printf("Error! opening file");
            exit(1);
        }

        fscanf(fp,"%d", &n);

        
        fclose(fp); 
       float a[n];
       for (int i=0;i<n;i++)
        {
            float b=(i+1)*(i+1);
            
            a[i]=(float)(1.0/b);
        
        }
        int index, i; 
        int extra_elements=n % np;
        elements_per_process = n / np; 
        
         if (np >=2)
          { 
           
            for (i = 0; i < np - 2; i++) 
            { 
                index = (i+1) * elements_per_process; 
  
                MPI_Send(&elements_per_process,1, MPI_INT, i+1, 0,MPI_COMM_WORLD); 
                MPI_Send(&a[index],elements_per_process,MPI_INT, i+1, 0,MPI_COMM_WORLD); 
                
            }

           

            int elements_left =extra_elements+elements_per_process; 
            if(elements_left!=0){

                index = (i+1) * elements_per_process; 
  
                MPI_Send(&elements_left,1, MPI_INT, i+1, 0, MPI_COMM_WORLD); 
                MPI_Send(&a[index], elements_left,MPI_INT, i+1, 0, MPI_COMM_WORLD); 
            }

            
        } 
        float sum = 0; 
        for (i = 1; i <= elements_per_process; ++i) 
            sum += a[i-1]; 
  

        float tmp; 
        for (i = 0; i < np-1; ++i) { 
            MPI_Recv(&tmp, 1, MPI_INT,MPI_ANY_SOURCE, 0,MPI_COMM_WORLD, &status); 
            // int sender = status.MPI_SOURCE; 
  
            sum += tmp; 
        } 
        
        fp = fopen(argv[argc - 1],"w");

        fprintf(fp,"%.6f",sum);
        fclose(fp);

        printf("Sum of array is : %f\n", sum); 


       
    } 
    else { 

        MPI_Recv(&n_elements_recieved,1, MPI_INT, 0, 0,MPI_COMM_WORLD,&status); 
        MPI_Recv(&a2, n_elements_recieved,MPI_INT, 0, 0,MPI_COMM_WORLD,&status); 
  
        
        float partial_sum = 0; 
        for (int i = 0; i < n_elements_recieved; ++i) 
            partial_sum += a2[i]; 
  
        
        MPI_Send(&partial_sum, 1, MPI_INT,0, 0, MPI_COMM_WORLD); 
    }
    MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
        if(pid==0)
        printf( "Total time (s): %f\n", maxTime ); 
    MPI_Finalize(); 
  
    return 0; 
} 