
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <iomanip>
using namespace std;

// void quicksort(int *A,int lo,int hi);
// int partition(int *A,int lo,int hi);
// int* merge(int *out,int n,int *recvArr,int m);

int n1;
vector<int> v1;

int partition(int *arr,int left,int right){
    int j=right;
    int i=left;
    int pivot=arr[left];
    
    while(i<j)
    {
        while(arr[j]>pivot)j--;
        while(arr[i]<=pivot)i++;
        if(i<j)
        {
            swap(arr[i],arr[j]);
        }
    }
    swap(arr[j],arr[left]);
    return j;
}

void quicksort(int *A, int lo, int hi) {
	if (lo < hi) {
		int p = partition(A, lo, hi);
		quicksort(A, lo, p-1);
		quicksort(A, p + 1, hi);
	}
}



int* merge(int *out,int n,int *recvArr,int m) {
	
	int totalsize=n+m;
	int *ans = (int*)malloc(sizeof(int)*totalsize);

	int i=0,j=0,k=0;
	while(j<m && i<n) {
		if(out[i]<recvArr[j]){
			ans[k++] = out[i];
			i++;
		}
		else {
			ans[k++] = recvArr[j];
			j++;
		}
	}
	while(i<n) {
		ans[k++] = out[i];
		i++;
	}
	while(j<m) {
		ans[k++] = recvArr[j];
		j++;
	}
	return ans;
}

int main(int argc, char *argv[]) {	
	
	int nProcesses, rank, chunkSize;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nProcesses);


	 /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    

    /* write your code here */
    if(nProcesses < 1)
    {
        cout << "you have to use at least 1 processors to run this program\n";
        MPI_Finalize();
        exit(0);
    }

	if(rank==0) {
		int size,start, n, *arr, *out;

		ifstream f_input;
        string line;

        f_input.open (argv[argc - 2]);
        
        f_input >> size;

       	arr = (int*)malloc(size * sizeof(int));

        for(int a = 0; a < n; a++)
        {
            f_input >> arr[a];
        }
     
        f_input.close();
		
        int extra = size%nProcesses;
		chunkSize = size/nProcesses;
		
		quicksort(arr,0,chunkSize+extra-1);

		n=chunkSize+extra;
		out = (int*)malloc(n*sizeof(int));
		for(int i=0;i<n;i++) {
			out[i]=arr[i];
		}

		start = chunkSize+extra;
		for(int i=0;i<nProcesses-1;i++) {
			MPI_Send(&chunkSize, 1, MPI_INT, i+1, i+1, MPI_COMM_WORLD);
			MPI_Send(arr+start, chunkSize, MPI_INT, i+1, i+1, MPI_COMM_WORLD);
			start += chunkSize;
		}
		for(int i=0;i<nProcesses-1;i++) {
			int *recvArr = (int*)malloc(chunkSize * sizeof(int));
			MPI_Recv(recvArr, chunkSize, MPI_INT, i+1, i+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			out = merge(out,n,recvArr,chunkSize);
			n += chunkSize;
		}

		v1.resize(n,0);
		for(int i=0;i<n;++i){
			v1[i]=out[i];
			
		}

	} else {
		int recvSize ,*recvArr;
		MPI_Recv(&recvSize, 1, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		recvArr = (int*)malloc(recvSize * sizeof(int));
		MPI_Recv(recvArr, recvSize, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		quicksort(recvArr,0,recvSize-1);
		MPI_Send(recvArr, recvSize, MPI_INT, 0, rank, MPI_COMM_WORLD);
	}
	/* write your code here */
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if(rank==0){
		for(int i=0;i<v1.size();i++)
        {
           cout<< v1[i] << " ";
        }
       
		fstream f_output;
        f_output.open(argv[2]);
        for(int i=0;i<v1.size();i++)
        {
            f_output<< v1[i] << " ";
        }
       
        f_output.close();

        printf( "Total time (s): %f\n", maxTime );
	}

	MPI_Finalize();
	return 0;
}
