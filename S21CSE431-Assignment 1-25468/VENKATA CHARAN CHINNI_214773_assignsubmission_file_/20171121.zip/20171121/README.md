# Assignment-1
This consists of brief explanations of how the codes were implemented for the given Assignment.
## Question 1
- We assign numericals given from 1 to N to the number of processes specified in the command line.
- 1-> P1,2-> P2, 3-> P3....... N->Pk
- Finally every sum was cumulated for the Final answer.

## Question 2
- Process 0 is the main process.
- Every process uses partition function to get a pivot.
- Pivot is selected randomly and seperated the elements about that pivot
- Every process sends first half of elements before the pivot a one process and after pivot to another  process by checking whether the processes are available.
- If all processes are used up then sorting is done by quick sort in the same process.
- All processes send the sorted array to the process that sends the array.
- Process 0 prints the sorted elements into output file.
