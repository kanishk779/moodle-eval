/* MPI Program Template */

#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
#define ll int

ll partition(ll arr[], ll first, ll last)
{
    ll num = last - first + 1, i, j = first;
    ll pivot = rand() % num + first;
    swap(arr[pivot], arr[last]);
    for (i = first; i < last; i++)
    {
        if (arr[i] <= arr[last])
            swap(arr[j++], arr[i]);
    }
    swap(arr[j], arr[last]);
    return j;
}

void qsort(ll arr[], ll first, ll last)
{
    if (first < last)
    {
        ll pivot = partition(arr, first, last);
        qsort(arr, first, pivot - 1);
        qsort(arr, pivot + 1, last);
    }
}



int main( int argc, char **argv ) {
    int rank, numprocs;
    ll n, num, arr[100005], pivot, rem ;
    long double myans = 0, ans;
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    ofstream ofs;
    ofs.open(argv[2],std::ofstream::out | std::ofstream::trunc);
    if (rank == 0)
    {
        ifstream file(argv[1]);
        ll cnt = 0,d;
        while (file >> d)
        {
            if(cnt == 0){
                n = d;
                cnt++;
            }
            else{
                arr[num] = d;
                num++;
            }
        }
    }
    if (rank != 0 && num < rank)
    {
        MPI_Recv(&num, 1, MPI_INT, (rank - 1) / 2, 1, MPI_COMM_WORLD, &status);
        if (num){            
            MPI_Recv(arr, num, MPI_INT, (rank - 1) / 2, 2, MPI_COMM_WORLD, &status);
        }
    }
    ll k=0;
    if(num==0 && rank * 2 + 1 < numprocs)  MPI_Send(&k, 1, MPI_INT, rank * 2 + 1, 1, MPI_COMM_WORLD);
    if(num==0 && rank * 2 + 2 < numprocs)  MPI_Send(&k, 1, MPI_INT, rank * 2 + 2, 1, MPI_COMM_WORLD);

    if (num > 0)
    {
        pivot = partition(arr, 0, num - 1);
        rem = num - pivot - 1;

        if (rank * 2 + 1 < numprocs)
        {
            MPI_Send(&pivot, 1, MPI_INT, rank * 2 + 1, 1, MPI_COMM_WORLD);
            if (pivot != 0)
            {
                MPI_Send(arr, pivot, MPI_INT, rank * 2 + 1, 2, MPI_COMM_WORLD);

                MPI_Recv(arr, pivot, MPI_INT, rank * 2 + 1, 3, MPI_COMM_WORLD, &status);
            }
        }
        else{
            qsort(arr, 0, num - 1);
        }

        if (rank * 2 + 2 < numprocs)
        {
            MPI_Send(&rem, 1, MPI_INT, rank * 2 + 2, 1, MPI_COMM_WORLD);
            if (rem != 0)
            {
                MPI_Send(&arr[pivot + 1], rem, MPI_INT, rank * 2 + 2, 2, MPI_COMM_WORLD);
                MPI_Recv(&arr[pivot + 1], rem, MPI_INT, rank * 2 + 2, 3, MPI_COMM_WORLD, &status);
            }
        }
        else if (rank * 2 + 1 < numprocs){
            qsort(arr, pivot + 1, num - 1);
        }

        if (rank != 0 && num){
            MPI_Send(arr, num, MPI_INT, (rank - 1) / 2, 3, MPI_COMM_WORLD);
        }
    }
    if (rank == 0)
    {
        for (ll i = 0; i < num; i++)
        {
            ofs << arr[i] << " ";
            // cout << arr[i] << " ";
        }
        ofs << endl;
    }
    
    ofs.close();


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}