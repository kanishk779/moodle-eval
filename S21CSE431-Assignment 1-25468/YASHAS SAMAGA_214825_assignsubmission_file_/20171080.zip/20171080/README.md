# Q1

N             | numprocs | time
------------- | -------- | --------
65535         | 1        | 0.00050s
65535         | 2        | 0.00035s
65535         | 3        | 0.00035s
65535         | 4        | 0.00040s
65535         | 10       | 0.004s
65535         | 20       | 0.02s

Each process computes partial sums. The final global sum is then computed using MPI_Reduce. The work is distributed almost equally (equality when N is a multiple of numprocs).

# Q2

The root process partitions the input at `numprocs - 1` points to give a total of `numprocs` partitions in O(numprocs * n) on average. Each parition is sorted independently by each process using quicksort. The final sorted array is obtained by gathering all the sorted paritions.

The whole distributed quicksort is still quicksort. The first quicksort call creates `numprocs` partitions instead of the usual two. The root process then scatters the partitions to the processes. Each process then does 2-way quicksort on each partition. The sorted partitions are then gathered to generate the final output. No merge operation is required.

N = 1,000,000

numprocs | time
-------- | -------------
1        | 0.24s
2        | 0.19s
3        | 0.18s
4        | 0.19s
8        | 0.32s

# Q3

Vertex Coloring Algorithm: https://stanford.edu/~rezab/classes/cme323/S16/projects_reports/bae.pdf

The input graph is converted to its line graph. Therefore, finding a proper vertex coloring of the line graph will provide us a proper edge coloring.

The vertex coloring algorithm first creates a trivial N-colored graph where N is the number of vertices. Each process performs color reduction on a block of nodes with a set of colors. The updates are then broadcasted to all processes and updates from all processes are obtained. The process repeats until the number of colors in the graph reduces to `delta + 1` or less.