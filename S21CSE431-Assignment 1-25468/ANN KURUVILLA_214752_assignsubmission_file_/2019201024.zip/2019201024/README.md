 Observations
 
 Question 2

 Parallel  quicksort  with  initial  fixed  size partitioning  has  again  showed  better  performances  while  increasing  the  number  of processes.

 Increasing number of processes on small dataset shows low performance due to MPI communication overhead.