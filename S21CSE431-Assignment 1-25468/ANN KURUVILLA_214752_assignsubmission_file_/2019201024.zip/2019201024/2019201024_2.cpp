
// 2019201024


#include <bits/stdc++.h>
#include <mpi.h>

using namespace std;

void quicksort(int *A,int lo,int hi);
int partition_quick(int *A,int lo,int hi);

void quicksort(int *A, int lo, int hi) {
	if (lo < hi) {
		int p = partition_quick(A, lo, hi);
		quicksort(A, lo, p-1);
		quicksort(A, p + 1, hi);
	}
}

int partition_quick(int *A, int lo, int hi) {
	int pivot = A[hi];
	int i = lo - 1;
	for (int j = lo; j < hi; j++) {
		if (A[j] <= pivot) {
			i++;
			int temp = A[i];
			A[i] = A[j];
			A[j] = temp;
		}
	}
	int temp = A[i + 1];
	A[i + 1] = A[hi];
	A[hi] = temp;
	return i + 1;
}

vector<pair<int,int>> coordinate(int n) {
	
	int p=0,cnt=n;
	MPI_Status status;
	vector<int> pairs(n+1,-1);
	vector<string> logs;
	while(cnt) {
		MPI_Recv(&p, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		
		if(pairs[status.MPI_SOURCE-n]==-1) {
			pairs[status.MPI_SOURCE-n] = p;
			logs.push_back("funct2 "+to_string(status.MPI_SOURCE-n)+"  "+to_string(p)+"\n");
			--cnt;
		} else {
			logs.push_back("funct2 "+to_string(status.MPI_SOURCE-n)+"  "+to_string(pairs[status.MPI_SOURCE-n])+"\n");
			pairs[status.MPI_SOURCE-n] = p;
			logs.push_back("funct2 "+to_string(status.MPI_SOURCE-n)+"  "+to_string(p)+"\n");
		}
		
	}

	ofstream output_file("./logs.txt");
    ostream_iterator<string> output_iterator(output_file, "\n");
    copy(logs.begin(), logs.end(), output_iterator);
	for(int p=1;p<=2;p++)
	 {

	 }
	for(int i=1;i<=2*n;++i) {
		MPI_Send(&p, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
	}
	vector<pair<int,int>> final;
	for(int i=0;i<n;++i) {
		MPI_Recv(&p, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		final.push_back(make_pair(p,status.MPI_SOURCE));
	}
	return final;
}

void funct1(vector<int> pref,int rank) {
	
	int pointer=0,n=pref.size();
	MPI_Status status;
	while(pointer<n) {
		MPI_Send(&pointer, 1, MPI_INT, pref[pointer]+n, rank, MPI_COMM_WORLD);
		
		MPI_Recv(&pointer, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		
		if(status.MPI_SOURCE==0) break;
		++pointer; 
	}
}

void funct2(vector<int> pref,int rank) {
	
	int p=0,current=-1;
	MPI_Status status;
	
	while(true) {
		MPI_Recv(&p, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		
		if(status.MPI_SOURCE==0) break;
		if(current==-1) {
			current = status.MPI_SOURCE;
			MPI_Send(&current, 1, MPI_INT, 0, rank, MPI_COMM_WORLD);
			
		} 
		else {
			int i;
			for(i=0;i<pref.size();++i) if(pref[i]==current or pref[i]==status.MPI_SOURCE) break;
			
			if(pref[i]==status.MPI_SOURCE) {
				MPI_Send(&p, 1, MPI_INT, current, rank, MPI_COMM_WORLD);
				
				current = status.MPI_SOURCE;
				
				MPI_Send(&current, 1, MPI_INT, 0, 1000, MPI_COMM_WORLD);
				
			} else {
				MPI_Send(&p, 1, MPI_INT, status.MPI_SOURCE, rank, MPI_COMM_WORLD);
				
			}
		}
	}
	
	MPI_Send(&current, 1, MPI_INT, 0, rank, MPI_COMM_WORLD);
}

int main(int argc, char *argv[]) {	
	
	for(int d=0; d<=2;d++)
	{

	}
	int nProcesses, rank, n, p;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nProcesses);

	if(rank==0) {
		cin>>n;
		
		for(int i=1;i<=2*n;++i) {
			MPI_Send(&n, 1, MPI_INT, i, i, MPI_COMM_WORLD);
			vector<int> pref(n);
			for(int j=0;j<n;++j) {
				cin>>p;
				pref[j] = p+1;
			}
			MPI_Send(&pref[0], n, MPI_INT, i, i, MPI_COMM_WORLD);
		}
		auto ans = coordinate(n);
		sort(ans.begin(),ans.end());
		
		for(int i=0;i<ans.size();++i) printf("%d\t%d\n",ans[i].first-1,ans[i].second-n-1);
	} else {
		int size;
		MPI_Recv(&size, 1, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		vector<int> pref(size);
		MPI_Recv(&pref[0], size, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
		if(rank>=1 and rank<=size) funct1(pref,rank);
		else funct2(pref,rank);
	}

	MPI_Finalize();
	return 0;
}
