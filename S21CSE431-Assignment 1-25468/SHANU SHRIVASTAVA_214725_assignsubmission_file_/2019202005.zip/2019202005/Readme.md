1)To solve this problem of finding the sum of the series, the parent process distributes the no of element upto which a child process should compute the result using MPI_send.Then the child process receives the value using MPI_Recv performs the required operation and compute the result and sends back to the parent process. The parent process sums up the result of each individual child process and computes the result and writes to the file.

2)To implement parallel quick sort, first the parent process divides the array in chunks and distributes it to the child process.On receiving their respective chunks each child process applies quicksort on the array and returns the sorted array to the parent process. The parent process on receiving the sorted array from the child process merges them in ascending order using the merge procedure and writes the sorted array to the file.




