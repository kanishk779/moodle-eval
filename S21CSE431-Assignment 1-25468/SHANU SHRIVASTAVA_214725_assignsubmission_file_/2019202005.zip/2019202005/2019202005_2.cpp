/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>


using namespace std;
typedef long long int ll;

int partition(int arr[],int left,int right){

    int pivot=arr[right],j=left-1;

    for(int i=left;i<right;i++){
        if(arr[i]<=pivot)
            swap(arr[i],arr[++j]);
    }

    swap(arr[right],arr[++j]);
    return j;
}

void quicksort(int arr[],int left,int right){
    if(left<right){
        int p=partition(arr,left,right);
        quicksort(arr,left,p-1);
        quicksort(arr,p+1,right);
    }
}

int getNum(char *src,int **arr){

    
    ifstream myfile (src);
    string line;
    int i=0,j=0,n;

    if (myfile.is_open())
    {
        while ( getline (myfile,line) )
        {
            if(i++==0){

                n=stoi(line);
                (*arr)=(int*)malloc((n+1)*sizeof(int));
                continue;  
            } 

            stringstream ss(line);
            string temp;

            while(ss>>temp){
               (*arr)[j++]=stoi(temp);
               cout<<(*arr)[j-1]<<"\t";
            }
            cout<<"\n";
        }
        myfile.close();
    }

    return n;
}

int *merge(int arr1[],int *arr1size,int arr2[],int size2){

    int *result=(int*)malloc(((*arr1size)+size2)*sizeof(int));
    
    int i=0,j=0,k=0;
    for(;j<(*arr1size)&&k<size2;i++){

        if(arr1[j]<arr2[k])
            result[i]=arr1[j++];
        else
            result[i]=arr2[k++];
    }

    while(j<(*arr1size))
        result[i++]=arr1[j++];

    while(k<size2)
        result[i++]=arr2[k++];

    *arr1size=i;
    return result;

}

void write_to_file(char *dest,int arr[],int n){
    ofstream output(dest);
    if (output.is_open()) {
        
        for(int i=0;i<n;i++)
            output<<arr[i]<<" ";
        output.close();
    }
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    
    if(rank==0){
        int *arr;
        int n=getNum(argv[1],&arr);
        int flag=1;
        int dummy[1];
        if(numprocs>n){
            quicksort(arr,0,n-1);

            for(int i=1;i<numprocs;i++){
                MPI_Send(&flag,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(arr,flag,MPI_INT,i,0,MPI_COMM_WORLD);
            }

            for(int i=1;i<numprocs;i++){

                MPI_Recv(&flag, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                MPI_Recv(&dummy, flag, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
            
            write_to_file(argv[2],arr,n);
        }
        else{
            
            int start,end,chunkSize,element,shift;

            chunkSize=n/numprocs;

            for(int i=1;i<numprocs;i++){

                start=(i*chunkSize)+1;
                end=(i+1)*chunkSize;
                

                if(n-end<chunkSize)
                    end=n-1;

                element=end-start+1;

                
                MPI_Send(&element,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&arr[start],element,MPI_INT,i,0,MPI_COMM_WORLD);
            }

            quicksort(arr,0,chunkSize);

            int *t=(int*)malloc((chunkSize+1)*sizeof(int));
            int *recsorted=(int*)malloc((chunkSize+1)*sizeof(int));

            int tsize=chunkSize+1;

           
            for(int i=0;i<=chunkSize;i++){
                t[i]=arr[i];
            }

            quicksort(t,0,chunkSize);
            
            for(int i=1;i<numprocs;i++){

                MPI_Recv(&element, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
                MPI_Recv(recsorted, element, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                t=merge(t,&tsize,recsorted,element);
            }
            write_to_file(argv[2],arr,n);
        }
        
    }
    else{

        int *temparr;
        int no;

        MPI_Recv(&no, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        temparr=(int*)malloc((no+1)*sizeof(int));
        MPI_Recv(temparr, no, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        quicksort(temparr,0,no-1);

        MPI_Send(&no,1,MPI_INT,0,0,MPI_COMM_WORLD);
        MPI_Send(temparr,no,MPI_INT,0,0,MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}