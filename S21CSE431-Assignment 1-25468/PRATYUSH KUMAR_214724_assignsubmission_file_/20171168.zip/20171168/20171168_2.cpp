/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
void swap(ll * x, ll * y){
    ll temp = *x;
    *x = *y;
    *y = temp;
}
int partition(ll *arr, ll l, ll r){
    ll pivot=rand()%(r-l+1)+l;
    swap(&arr[pivot],&arr[r]);
    ll ind = l;
    for(int i=l;i<r;i++)
        if(arr[i]<arr[r])
            {
                swap(&arr[ind],&arr[i]);
                ind++;
            }
    swap(&arr[ind],&arr[r]);
    return ind;
}
void QuickSort(ll *arr, ll l, ll r){
    if(l>=r)
        return;
    ll pivot = partition(arr,l,r);
    QuickSort(arr,l,pivot-1);
    QuickSort(arr,pivot+1,r);
}
void merge(ll *buffer1,int buffer1_size,ll *buffer2, int buffer2_size, ll *merged_array){
    int a=0,b=0,c=0;
    while(a<buffer1_size or b<buffer2_size){
        if(a<buffer1_size and b<buffer2_size)
            {
                if(buffer1[a]<=buffer2[b])
                {
                    merged_array[c++]=buffer1[a++];
                }
                else
                {
                    merged_array[c++]=buffer2[b++];
                }
            }
        else if(a<buffer1_size){
            merged_array[c++]=buffer1[a++];
        }
        else{
            merged_array[c++]=buffer2[b++];
        }
    }
}
ll get_block_size(ll rank, ll arr_size, ll numprocs)
{
     ll size=arr_size/numprocs;
     ll st=rank*size;
     if(rank==numprocs-1)
        {
            size=arr_size-st;
        }
    return size;
}   
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
//------------------------------------------------------------------
    std::ifstream fin;
    fin.open(argv[1]);
    ll num;
    ll arr_size=0;
    ll *arr = (ll *)malloc(1000002*sizeof(ll));
        while(fin>>num)
        {
            arr[arr_size]=num;
            arr_size++;
        }
    fin.close();
    // QuickSort(arr, 0, arr_size-1);
    ll blk_size = arr_size/numprocs;
    ll buffer_size=get_block_size(rank, arr_size, numprocs);
    ll *buffer = (ll *)malloc(buffer_size*sizeof(ll));
 if(rank == 0) {
     for(int i=0;i<buffer_size;i++)
     {
         buffer[i]=arr[i];
     }
	for(int i=1;i<numprocs;i++)
		MPI_Send(arr+blk_size*(i), get_block_size(i, arr_size, numprocs), MPI_LONG_LONG_INT,i,0,MPI_COMM_WORLD);
	// for(int i=1;i<11;i++)
    //         	MPI_Recv(bufferSorted+10*(i-1), 10, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    else {
        MPI_Recv(buffer, buffer_size, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    // MPI_Send(received, 10, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }
    free(arr);
	QuickSort(buffer, 0, buffer_size-1);
    int step=1;
    for(;step<numprocs;step*=2)
    {
        if(rank%(2*step))
        {
            MPI_Send(&buffer_size, 1, MPI_LONG_LONG_INT, rank-step, 1,MPI_COMM_WORLD);
            MPI_Send(buffer, buffer_size, MPI_LONG_LONG_INT, rank-step,0,MPI_COMM_WORLD);
            break;
        }
        else if(rank+step<numprocs)
        {
            ll sz1;
            MPI_Recv(&sz1, 1, MPI_LONG_LONG_INT, rank+step, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ll sz2=buffer_size;
            ll tot_size=sz1+sz2;
            ll *merged = (ll *)malloc(tot_size*sizeof(ll));
            ll *buffer1=(ll *)malloc(sz1*sizeof(ll));
            MPI_Recv(buffer1, sz1, MPI_LONG_LONG_INT, rank+step, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            merge(buffer1, sz1, buffer, sz2, merged);
            free(buffer1);
            free(buffer);
            buffer=merged;
            buffer_size=tot_size;
        }
    }





    //--------------------------------------------------------------------
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
        std::ofstream fout;
        fout.open(argv[2]);
        // printf("Final sorted array\n");
        for(ll i=0;i<buffer_size;i++)
            fout<<buffer[i]<<" ";
        fout<<endl;
        fout.close();
    }


    /* shut down MPI */
    MPI_Finalize();
    return 0;
}