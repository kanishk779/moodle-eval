# Mpi-Parallel-Algos

*Coded by:*
**Pratyush Kumar**


About The Codes
-------------

1. This folder contains 3 codes.
2. Paralized version of finding pi*pi/6, quick sort and edge coloring of a line graph.

----------
#### For question 1
Each thread finds the sum of reciprocals of a chunk of numbers. They are merged later into the root process. Time complexity- n/p


#### For question 2
The array is split into chunks and each chunk is separately sorted. Then the chunks are merged in pairs where merging of each pair is parallelised, hence total log(p)steps occur.(p is no of processes). Overall time complexity of n/p*log(p)+n/p*log(n/p)

#### For question 3
First random assignment of colors is done to edges. Then if a node has a higher degree(no of uncolored nodes adjacent) to it with the same assigned color, the assignment of color to the current node is rejected. This checking of colors of a node and its neighbours is parallelised. The iterations go on till all the nodes are colored. 

----------

## Performance
#### For question 1
|Sequential|Paralized|
|---|---|
|0.0005s| 0.000164s|
|0.0006s|0.000364s|

#### For question 2
|Sequential|Paralized|
|---|---|
|0.002s|0.001149s|
|0.0024s|0.001149s|

#### For question 3
|Sequential|Paralized|
|---|---|
|0.1s|0.067925s|
|0.1s|0.057825s|
_______________

#### Prajwal Krishna Maitin