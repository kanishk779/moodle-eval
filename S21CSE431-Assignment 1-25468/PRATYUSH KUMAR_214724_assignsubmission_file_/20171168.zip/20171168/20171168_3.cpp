#include "bits/stdc++.h"
#include <mpi.h>
using namespace std;
bool intersect(int* p1,int* p2)
{
	if(p1[0]==p2[0] or p1[0]==p2[1])
	{
		return true;
	}
	if(p1[1]==p2[0] or p1[1]==p2[1])
	{
		return true;
	}
	return false;
}
void edge_coloring_unit(int u)
{
	return ;
}
void init_color(int* choice_color, int adjusted_n, int delta)
{
	for(int i=0;i<adjusted_n;i++)
	 {
		 if(choice_color[i]==-1)
		   {
			   choice_color[i]=(rand()%(delta+1))+1;
		   }
	 }
}
void reduce_degree(int i, int m, int* degree, int adj[][502])
{
	for(int j=0;j<m;j++){
		degree[j]-=adj[i][j];
	}
}
int main(int argc, char ** argv)
{
	MPI_Init(&argc, &argv);
	int numprocs,rank;
	MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Barrier(MPI_COMM_WORLD);
	double tbeg = MPI_Wtime();
////////////////////////////////////////////////////////////////////////////////////

	srand(time(NULL));
	std::ifstream fin;
	fin.open(argv[1]);
	int n,m;
	fin>>n>>m;
	int edge[m][2];
	for(int i=0;i<m;i++)
	{
		fin>>edge[i][0]>>edge[i][1];
		edge[i][0]--;
		edge[i][1]--;
	}
    fin.close();
	//code the case of numprocs=1
		if(m==1 or numprocs==1)
		{
			edge_coloring_unit(0);
		}
		int adjusted_n;
		int rem=m%(numprocs-1);
		adjusted_n = m+(numprocs-1-rem)%(numprocs-1);
		int degree[adjusted_n];
		int color[adjusted_n];
		int choice_color[adjusted_n];
		int blk_size = adjusted_n/(numprocs-1);
		MPI_Bcast(&adjusted_n,1,MPI_INT, 0,MPI_COMM_WORLD);
		MPI_Bcast(&blk_size,1,MPI_INT,0,MPI_COMM_WORLD);
		int edge_map[502];
		int C=0;
     if(!rank)
	{
		int delta=0;
		memset(degree, 0, sizeof(degree));
		memset(color, -1, sizeof(color));
		memset(choice_color, -1, sizeof(choice_color));
		int adj[502][502]={0};
		for(int i=0;i<m;i++)
			{
				for(int j=0;j<m;j++)
				{
					if(j!=i and intersect(edge[i],edge[j]))
					{		
						adj[i][j]=1;
						degree[i]++;
						delta=max(delta, degree[i]);
					}
				}
			}

		for(int i=1;i<numprocs;i++)
		{
			int c=0;
			for(int j=(i-1)*blk_size;j<i*blk_size;j++)
				{
					MPI_Send(adj[j],adjusted_n,MPI_INT,i,c,MPI_COMM_WORLD);
					c++;
				}
		}
		int colored_edges=0;
		int end=0;
		int * updated = new int[blk_size];
		while(colored_edges<m)
		{
			init_color(choice_color, adjusted_n, delta);
			for(int i=1;i<numprocs;i++)
			{
				MPI_Send(&end,1,MPI_INT,i,i,MPI_COMM_WORLD);
				MPI_Send(degree,adjusted_n,MPI_INT,i,i,MPI_COMM_WORLD);
				MPI_Send(choice_color,adjusted_n,MPI_INT,i,i,MPI_COMM_WORLD);			
			}
			for(int i=1;i<numprocs;i++)
			{
				MPI_Recv(updated,blk_size,MPI_INT,i,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				int c=0;
				int j=(i-1)*blk_size;
				int sz=i*blk_size;
				for(;j<sz;j++)
					choice_color[j]=updated[c++];
			}
			for(int i=0;i<m;i++)
			 {
				 if(choice_color[i]==-1)
				 {
					continue;
				 }
				if(color[i]==-1)
				{
					color[i]=choice_color[i];
					colored_edges++;
					reduce_degree(i, m, degree, adj);
				}
			 }
		}
		end=1;
		for(int i=1;i<numprocs;i++)
		{
			MPI_Send(&end,1,MPI_INT,i,i,MPI_COMM_WORLD);
		}
		memset(edge_map, 0, delta+2);
		for(int i=0;i<m;i++)
		{
			if(!edge_map[color[i]])
				{
					C++;
					edge_map[color[i]]=C;
				}
		}
	}
	else
	{
		int adj[502][502];
		int st=(rank-1)*blk_size, end;
		int * degree = new int[adjusted_n];
		int * choice_color = new int[adjusted_n];
		int * upd_colors = new int[blk_size];
		for(int i=0;i<blk_size;i++)
		{
			MPI_Recv(adj[i],adjusted_n,MPI_INT,0,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		}
		while(1)
		{
			MPI_Recv(&end,1,MPI_INT,0,rank,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			if(end)
			{
				break;
			}
			MPI_Recv(degree,adjusted_n,MPI_INT,0,rank,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			MPI_Recv(choice_color,adjusted_n,MPI_INT,0,rank,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			for(int i=0;i<blk_size;i++)
			{
				int pos=0;
				for(int j=0;j<adjusted_n;j++)
				{
					pos|= (adj[i][j] and choice_color[i+st]==choice_color[j] and degree[i+st]<=degree[j]);
				}
				upd_colors[i]=pos?-1:choice_color[i+(rank-1)*blk_size];
				choice_color[i+(rank-1)*blk_size]=pos?-1:choice_color[i+(rank-1)*blk_size];
			}
			MPI_Send(upd_colors,blk_size,MPI_INT,0,rank,MPI_COMM_WORLD);
		}
	}
/////////////////////////////////////////////////////////////////////////////////////
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
		std::ofstream fout;
        fout.open(argv[2]);
		fout<<C<<endl;
		for(int i=0;i<m;i++)fout<<edge_map[color[i]]<<" ";
		fout<<endl;
        fout.close();
    }

	MPI_Finalize();
	return 0;
}