/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
//--------------------------------------------------------------------------------------
    /* write your code here */
    double reduction_result = 0;
    ll n;
              std::ifstream fin;
    fin.open(argv[1]);
    fin>>n;
    fin.close();
    MPI_Bcast(&n,1,MPI_LONG_LONG_INT, 0,MPI_COMM_WORLD);
    ll root_rank = 0;
    double sum=0;
    ll blk_size = n/numprocs;
    // cout<<rank<<endl;
    for(int i=rank*blk_size+1;i<rank*blk_size+blk_size+1;i++)
    {
        sum+=((double)1/(double)(i*i));
    }
    if(rank==numprocs-1)
    {
        for(int i=rank*blk_size+blk_size+1;i<=n;i++)
        {
            sum+=((double)1/(double)(i*i));
        }
    }
    // cout<<sum<<endl;
    MPI_Reduce(&sum, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, root_rank, MPI_COMM_WORLD);
//--------------------------------------------------------------------------------------
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
        std::ofstream fout;
        fout.open(argv[2]);
        fout<<reduction_result<<endl;
         fout.close();
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}