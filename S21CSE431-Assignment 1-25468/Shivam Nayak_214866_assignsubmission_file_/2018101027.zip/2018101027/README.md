# Q1 Parallel Sum

## Description:

Parallel approach is used with the help of MPI to find the sum of reciprocal of squares of integers from 1 to n. The numbers are divided into almost equal groups and assigned to different processes which parallely compute the required function and then return their partial result to root process which then sums all of these together to get the answer.

## Analysis

- For N = 1e4 and 11 processes: Time Taken: 0.0002151 seconds



# Q2 Parallel Quick Sort

## Description:
The implemented algorithm  is a  parallelized  implementation  of  the  quicksort  algorithm and it will avoid merging step by dividing input set through regular sampling.
An initial partitioning of data is performed until all the available processes were given a subset to sort sequentially. Then the received data set is sorted by each process in parallel. All data is gathered, corresponding to the exact partitioned offsets without performing any merging.

## Analysis

- For N = 1e6 with random values of array from 0 till 1e9 and 11 processes: Time Taken: 0.7935

# Q3 Parallel Edge Coloring

## Description:

A parallel approach is followed for edge coloring of the graph such that no adjacent edges share same color and number of colors used is not more than `1 + max(Delta of the original graph, Delta of the line graph)`. Initially given graph is transformed to its line graph(line graph of an undirected graph G is another graph L(G) that represents the adjacencies between edges of G. L(G) is constructed in the following way: for each edge in G, make a vertex in L(G); for every two edges in G that have a vertex in common, make an edge between their corresponding vertices in L(G)). So the question is now to vertex-coloring this line graph. For this a parallel approach has been followed using Jones-Plassmann algorithm.

## Analysis

- For 128 vertices and 774 edges(random) and 11 processes: Time Taken: 0.052936 seconds
