# Problem 1

Language : MPI in C++

Task :
We have implemented a program which an input of number of terms in series and outputs the 
floating point number denoting the estimated value of (pi)^2 / 6 rounded to six decimal places.









