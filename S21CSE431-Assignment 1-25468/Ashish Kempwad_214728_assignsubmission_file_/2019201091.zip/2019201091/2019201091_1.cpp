#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <iomanip> 
using namespace std;


int main(int argc, char **argv)
{

    MPI_Init( &argc, &argv );
    MPI_Status status;
    int rank;
    int numprocs;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
	double res;
    double sum=0.0;
    string file1;

    stringstream sgst1(argv[argc-2]);
    sgst1 >> file1;

    string file2;
    stringstream sgst2(argv[argc-1]);
    sgst2 >> file2;

	string line;
    ifstream filedesc1;
    ofstream filedesc2;
    filedesc1.open (file1);
    filedesc2.open(file2);

	int n;
	int start;
	int end;
    if (filedesc1.is_open())
    {
        while ( getline (filedesc1,line) )
        {
            stringstream sgst3(line);
            sgst3 >> n;
            break;
        }
        
        filedesc1.close();
    }
	
	if(rank!=0)
	{
		int i;
		start = ((n*rank)/(numprocs))+1;
		end = (n*(rank+1))/(numprocs);
		i=start;
		while(i<=end)
		{
			sum = sum + (1.0/(i*i));
			i++;
		}
		MPI_Send(&sum,1,MPI_DOUBLE,0,1,MPI_COMM_WORLD);
	}

	else
	{
		float ans1=0.0;
		int cnt = (n/numprocs);
		for(int i=1;i<=cnt;i++)
		{
			ans1 = ans1 + (1.0/(i*i));
		}
		for(int j=1;j<numprocs;j++)
		{
			MPI_Recv(&res,1,MPI_DOUBLE,j,1,MPI_COMM_WORLD, &status);
				ans1 = ans1 + res;		
		}
		
		sum=ans1;
	}
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    if ( rank == 0 )
	{
        printf( "Total time (s): %f\n", maxTime );
    
    filedesc2 << setprecision(7) << sum;
    filedesc2.close();
    }
    MPI_Finalize();
    return 0;
}