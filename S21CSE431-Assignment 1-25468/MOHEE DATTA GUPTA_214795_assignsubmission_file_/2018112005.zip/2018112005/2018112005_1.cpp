#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


float func(int l, int r){
    float send=0;
    while(l<=r){
        send+=1/(((float) l)*((float) l));
        l++;
    }
    return send;
}

int main( int argc, char **argv ) {
    int rank, numprocs;
    ifstream input;
    FILE *output;
    int count=1;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    float tbeg = MPI_Wtime();

    /* write your code here */
    if(rank == 0) {
        int n,span,start;
        count++;
        input.open(argv[1]);
        input >> n;
        count++;
        count++;

	    span = n/numprocs;        count++;

        start = 1;        count++;

        
        float result=0;
        
        for (int i=1;i<numprocs;i++)
        {
		    int a[] = {start,start+span-1};
            count++;

            MPI_Send(a,2,MPI_INT,i,0,MPI_COMM_WORLD);
            start = start+span;
            
        }

        result += func(start,n);        count++;

        
        for (int i=1;i<numprocs;i++)
        {
            float ans_rec;
            MPI_Recv(&ans_rec, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            result+=ans_rec;
            
        }
        
        output = fopen(argv[2], "w");
        fprintf(output, "%6f\n", result);
        fclose(output);
	    
    }
    else {
	    int a[2];
        float result = 0;
        MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	    int a0=a[0];
        int a1=a[1];
        result = func(a0,a1);        count++;

        
        MPI_Send(&result, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }

    

    MPI_Barrier( MPI_COMM_WORLD );
    float elapsedTime = MPI_Wtime() - tbeg;
    float maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}