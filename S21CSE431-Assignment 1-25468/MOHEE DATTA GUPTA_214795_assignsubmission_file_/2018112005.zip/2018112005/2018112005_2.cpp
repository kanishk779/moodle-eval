#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition (vector<int> &arr, int starts, int ends);
void quickSort(vector<int> &arr, int starts, int ends);

int main( int argc, char **argv ) {
    int rank, proc_len;
    int count=1;
    /* starts up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &proc_len );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(rank!=0){
        int n;
        MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int curr_val=count;
        if(cur_val!=proc_len){count++;}
        if(n){
            vector<int> varray(n);
            MPI_Recv(&varray[0], n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quickSort(varray,0,n-1);
            count++;

            MPI_Send(&varray[0],n,MPI_INT,0,0,MPI_COMM_WORLD);
            count++; 
        }
    }

    else{
        // read size of data
        FILE * file = NULL;
        file = fopen(argv[1], "r");
        int n;
        fscanf(file, "%d", &n);

        vector<int> data(n);
        for (int i = 0; i < n; i++){
            fscanf(file, "%d", &(data[i]));
            count++;
        }
        
        fclose(file);
        //to print the input
        // cout << n << endl;
        // for(int i=0;i<n;i++)
        //     cout << data[i] << " ";
        // cout << endl;
        
        int sublength = n/proc_len;
        int starts = 0;
        int m=1;
        int m_current;
        m_current=count;
        for(;m<proc_len;m++)
        {
            MPI_Send(&sublength,1,MPI_INT,m,0,MPI_COMM_WORLD);
            if(sublength)
                MPI_Send(&data[starts],sublength,MPI_INT,m,0,MPI_COMM_WORLD);    
            starts = starts+sublength;
            if(m_current) {count++;}
        }

        vector<int> queue(data.begin()+starts, data.end()); 
        quickSort(queue,0,n-sublength*(proc_len-1));
        count++;


        int value=0;
        vector<vector<int>> varray;
        varray.push_back(queue);
        count++;

        value = starts+1;
        priority_queue<pair<int,pair<int,int>>> pqueue;
        pqueue.push({queue.back(),{0,queue.size()-1}});
        count++;

        if(m_current) {count++;}

        value = starts;
        if(sublength){
            int g=1;
            for(;g<proc_len;g++){
                if(1){vector<int> temp(sublength);
                MPI_Recv(&temp[0], sublength, MPI_INT, g, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                pqueue.push({temp.back(),{g,temp.size()-1}});
                varray.push_back(temp);}    
            }
        }
        vector<int> final_ans;
        while(pqueue.empty()!=1){
            int curr_val=count;
            auto mark = pqueue.top();
            int val, i, j;
            pqueue.pop();
            if(curr_val!=count){count++;}
            val = mark.first;
            count++;
            i = mark.second.first;
            if(m_current) {count++;}

            j = mark.second.second;
            final_ans.push_back(val);
            if(j-1>=0)
            {
                pqueue.push({varray[i][j-1],{i,j-1}});
                if(m_current) {count++;}

            }

        }
        file = fopen(argv[2], "w");
        for (int i = n-1; i >=0; i--)
        fprintf(file, "%d ", final_ans[i]);
        fclose(file); 
    }  

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

void quickSort(vector<int> &arr, int starts, int ends)  
{  
    if (starts < ends)  
    {  
        int midval = partition(arr, starts, ends);  
        quickSort(arr, starts, midval - 1);  
        quickSort(arr, midval + 1, ends);  
    }  
}

int partition (vector<int> &arr, int starts, int ends)  
{  
    int pivot = arr[ends]; 
    int i = (starts - 1); 
    int j=i+1;
    //j=starts;
    for (; j <= ends - 1; j++)  {  
        if (arr[j] < pivot)  {  
            i++; 
            swap(arr[i], arr[j]);  
        }  
    }  
    swap(arr[i + 1], arr[ends]);  
    return (i + 1);  
}  
