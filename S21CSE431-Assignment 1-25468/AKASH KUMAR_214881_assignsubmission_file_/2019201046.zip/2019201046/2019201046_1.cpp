/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

        ifstream infile(argv[1]);
        ofstream outfile;
        outfile.open (argv[2],ios::out);
        int n;
        infile>>n;
        infile.close();

        
        int root_rank = 0;
        int flag1=0;
        int size = 0;
        int temp_size=size;
        int my_rank;
        int temp_rank=my_rank;
        float reduction_result = 0;
        if(n>0)
            flag1=1;
        float buffer=0;

        // int ept = n/numprocs-1;
        if(rank == root_rank)
           for(int i=rank+1; i<=n; i+=(numprocs)){
                float res1;
                res1=(i) * (i);
                buffer+=1.0/(res1 );
                // printf("%f \n", i*i*1.0);
            }
        else{
            // buffer=1.0/(  (rank+1) * (rank+1) );
            for(int i=rank+1; i<=n; i+=(numprocs)){
                float res2=(i) * (i);
                buffer+=1.0/(res2);
                // printf("%f \n", i*i*1.0);
            }
        
        }
        MPI_Reduce(&buffer, &reduction_result, 1, MPI_FLOAT, MPI_SUM, root_rank, MPI_COMM_WORLD);
        if(rank == root_rank){
            int flag=0;
            printf("The sum of all ranks is %f.\n", reduction_result);
            float reduction_result1=reduction_result;
            outfile<<reduction_result;
            outfile.close();
        }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}