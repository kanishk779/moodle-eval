/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


void quicksort(int *A,int lo,int hi);
int partition(int *A,int lo,int hi);
int* merge(int *out,int n,int *recvArr,int m);

void quicksort(int *A, int lo, int hi) {
    if (lo < hi) {
        int p1=lo;
        int p = partition(A, lo, hi);
        int high=hi;
        quicksort(A, lo, p-1);
        quicksort(A, p + 1, hi);
    }
}

int partition(int *A, int lo, int hi) {
    int pivot = A[hi];
    int temp_pivot=pivot;
    int i = lo - 1;
    int high1=hi;
    for (int j = lo; j < hi; j++) {
        if (A[j] <= pivot) {
            i++;
            int temp = A[i];
            A[i] = A[j];
            A[j] = temp;
        }
    }
    int temp = A[i + 1];
    A[i + 1] = A[hi];
    A[hi] = temp;
    return i + 1;
}

int* merge(int *out,int n,int *recvArr,int m) {
    int i=0,j=0,k=0;
    int *ans = (int*)malloc((n+m) * sizeof(int));
    while(i<n && j<m) {
        if(out[i]<recvArr[j]) ans[k++] = out[i++];
        else ans[k++] = recvArr[j++];
    }
    while(i<n) {
        ans[k++] = out[i++];
    }
    while(j<m) {
        ans[k++] = recvArr[j++];
    }
    return ans;
}


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    
    if(rank==0) {
        int size ,extra, chunkSize ,start, n, *arr, *out;

        ifstream infile(argv[1]);
        ofstream outfile;
        outfile.open (argv[2],ios::out);

        infile>>size;
        int size2=size;
        arr = (int*)malloc(size * sizeof(int));
        bool f=0;
        int a; int i=0;
        if(size>0)
            f=1;
        while (infile >> a)
        {
            // cout<<a<<endl;
            arr[i++] = a;
            // outfile<<a<<" ";
        }
        infile.close();
        // outfile.close();


        
        // for(int i=0;i<size;++i) arr[i] = atoi(argv[i+2]);

        chunkSize = size/numprocs;
        int temp_size1=chunkSize;
        extra = size%numprocs;
        int remaining1=extra;
        quicksort(arr,0,chunkSize+extra-1);

        n=chunkSize+extra;
        out = (int*)malloc(n * sizeof(int));
        int Total_size1=n;
        for(int i=0;i<n;++i) out[i]=arr[i];
        int temp1=extra,temp2=n;
        start = chunkSize+extra;
        if(temp1<temp2)
            temp1=temp2;
        for(int i=1;i<numprocs;++i) {
            int flag1=0,flag2=0;
            MPI_Send(&chunkSize, 1, MPI_INT, i, i, MPI_COMM_WORLD);
            flag1=flag2;
            MPI_Send(arr+start, chunkSize, MPI_INT, i, i, MPI_COMM_WORLD);
            temp1=start;
            start += chunkSize;
        }
        for(int i=1;i<numprocs;++i) {
            int flag1=0,flag2=0;
            int *recvArr = (int*)malloc(chunkSize * sizeof(int));
            if(temp1<temp2)
                flag2=1;
            MPI_Recv(recvArr, chunkSize, MPI_INT, i, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            temp_size1=n;
            out = merge(out,n,recvArr,chunkSize);
            n += chunkSize;
        }
        for(int i=0;i<n;++i) outfile<<out[i]<<" ";
        printf("\n");
        outfile.close();
    } 
    else 
    {
        int recvSize ,*recvArr;
        bool flag=0;
        MPI_Recv(&recvSize, 1, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if(recvSize>0)
            flag=1;
        recvArr = (int*)malloc(recvSize * sizeof(int));
        int cnt=0;
        MPI_Recv(recvArr, recvSize, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if(flag==1)
            cnt++;
        quicksort(recvArr,0,recvSize-1);
        MPI_Send(recvArr, recvSize, MPI_INT, 0, rank, MPI_COMM_WORLD);
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}