# include <cstdlib>
# include <ctime>
# include <iomanip>
# include <iostream>
# include <mpi.h>
#include <fstream> 

using namespace std;
// format : 

// Compiling your program : mpic++ <roll-number>_<problem-number>.cpp
// Executing your program : mpirun -np <number-of-processes> a.out <input-file> <output-file>




int main(int argc, char **argv)
{

    string ifp = argv[1];
    ifstream fin;
    string ln; 
    fin.open(ifp); 
    getline(fin, ln);  
    fin.close();
    int number = stoi(ln);

    int rk,sz;
    MPI_Status status;


    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&rk);
    double result = 0;
    MPI_Comm_size(MPI_COMM_WORLD,&sz);
    int lpsz = 1 + ((number - 1) / sz), i=0;
    while(i<lpsz)
    {
        int num = rk*lpsz + i;
        if(num+1 > number) break;
        num++;
        int sqr = num*num;
        double reciSquare = double(1)/double(sqr);
        result += reciSquare;
        i++;
    }

    if(rk>0)
    {
        MPI_Send(&result,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
    }
    else
    {
        int i=0;
        while(i<sz)
        {
            double temp = 0;
            MPI_Recv(&temp,1,MPI_DOUBLE,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
            result += temp;
            i++;
        }

        ofstream fout; 
        fout.open(argv[2]);
        fout<<fixed<<setprecision(6)<<result<<endl;
        fout.close();

    }

    MPI_Finalize();
    return 0;
}