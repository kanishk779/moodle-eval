Approach : let N = 100 , np = 7(no of cores )
to find : 1/1^2 + 1/2^2 + ...... 1/N^N

Sol: I have split N numners into np 
such as N/np
Special case: see for last core , it should not hold extra values


***int num = rank*loopSize + i;***
Example :
100/7 = 14   N/np

core 1: [1,2,...14]  computation(1/1^1 + 1/2^2 + ... 1/14^14)
core 2: [15 .... 28]
core 3..  .....  


core 7  [....100]

send all answers to core 1(rank0)
add there and write back to op-file.txt