#include "mpi.h"
#include <stdio.h>
#include<iostream>
#include<fstream>
#include <iomanip>
using namespace std;


int main(int argc, char* argv[])
{
	int rank, size;
	int n;
	MPI_Init(&argc, &argv);
	MPI_Comm comm = MPI_COMM_WORLD;
	int  comm_size;
	MPI_Comm_size(comm, &comm_size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	if (rank == 0)
	{
		ifstream infile;
		infile.open(argv[1]);
		infile >> n;
		infile.close();
	}
	// starting time
	double st = MPI_Wtime();
	MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
	float value = 0;
	float ans = 0;
	if (n <= size)
	{
		if (rank < n)
			value = 1 / ((float)(rank + 1) * (rank + 1));
	}
	else
	{
		int low = rank * (n / size) + 1, high;
		if (rank == size - 1)
		{
			high = n;
		}
		else
		{
			high = (rank + 1) * (n / size);
		}
		for (float i = low; i <= high; i += 1)
		{
			value += (1 / (i * i));
		}
	}
	MPI_Reduce(&value, &ans, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
	if (rank == 0)
	{
		ofstream outfile;
		outfile.open(argv[2]);
		outfile << fixed << std::setprecision(7) << ans;
		outfile.close();
		//ending time
		double en = MPI_Wtime();
		cout << en - st << " seconds";
	}

	MPI_Finalize();
	return 0;
}

