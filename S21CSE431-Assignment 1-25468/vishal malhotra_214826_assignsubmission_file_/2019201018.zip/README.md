# Question 1

 - Initially the value of **n** (input) is read by rank-0 process and then broadcasted to everyone.
 - If the value of **n  <= number of process(size)** then the process with rank = [0,n-1] calculate  $\frac{1}{(rank+1)*(rank+1)}$ and send it to the root rank process (rank = 0) remaining sends 0.
 
 - If the value of  **n > size** then each rank i != (size-1),calculates $\sum_{j = rank*(n/size)+1}^{j = (rank+1)*(n/size)} \frac{1}{(j)*(j)}$ and rank = size-1 calculates $\sum_{j = rank*(n/size)+1}^{j = n} \frac{1}{(j)*(j)}$  where n/size is the integer division. After computing they send their value to rank = 0 process where it is added (using MPI_REDUCE).



# Question 2

 - Initially rank-0 process reads the input and broadcasts the value of size of the array(n).
 - Then rank-0 process scatters the input such that every process except the one with max rank gets $\frac{n}{size}$ and the highest rank process gets the remaining elements. 
 - Each of the processor performs quicksort on smaller portion of the array and then it is gathered at rank-0 process.
 - The rank-0 process then merges these sizes number of sorted arrays using k-way merge.

