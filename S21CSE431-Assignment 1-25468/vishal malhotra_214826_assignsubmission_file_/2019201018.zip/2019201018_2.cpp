#include <iostream>
#include "mpi.h"
#include <stdio.h>
#include <algorithm>
#include<set>
#include <iomanip>  
#include <fstream>
using namespace std;

int cmpfunc(const void* a, const void* b) {
	return (*(int*)a - *(int*)b);
}
void quick_sort(int* a, int l, int h)
{
	qsort(a, h - l + 1, sizeof(int), cmpfunc);

}

// performing k-way merge where k = no.of process
// a = [0,10,20 1,11,21 ,2,12,22,23]
// disp = [0,3,6]
// counts = [3,3,4]
// ith sorted array starts from disp[i] and has count[i] values
void Merge(int* a, int* disp, int* counts, int* ans, int n, int num_of_process)
{

	int* curr_ix = (int*)malloc(num_of_process * sizeof(int));
	for (int i = 0; i < num_of_process; i++)
	{
		curr_ix[i] = disp[i];
	}


	set<pair<int, int>> st;
	for (int i = 0; i < num_of_process; i++)
	{
		if (curr_ix[i] < disp[i] + counts[i])
		{
			st.insert({ a[curr_ix[i]],i });
			curr_ix[i]++;
		}
	}
	int ans_ix = 0;
	while (st.size() != 0)
	{
		pair<int, int> p1 = *st.begin(); // p1.f = value, p1.s = rank_no
		ans[ans_ix++] = p1.first;
		st.erase(st.begin());   // erasing smallest element
		if (curr_ix[p1.second] < disp[p1.second] + counts[p1.second])
		{
			st.insert({ a[curr_ix[p1.second]],p1.second });
			curr_ix[p1.second]++;
		}
	}
	free(curr_ix);

}

int main(int argc, char* argv[])
{
	int rank, size;

	MPI_Init(&argc, &argv);

	MPI_Comm comm = MPI_COMM_WORLD;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	int n, bincount;
	if (rank == 0)
	{
		ifstream infile;
		infile.open(argv[1]);
		ofstream outfile;
		outfile.open(argv[2]);
		infile >> n;
		bincount = n / size;
		MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

		int* a = (int*)malloc(n * sizeof(int));
		for (int i = 0; i < n; i++)
		{
			infile >> a[i];
		}
		infile.close();

		int* counts_send = (int*)malloc(size * sizeof(int));
		int* displacements = (int*)malloc(size * sizeof(int));
		int count_recv = (rank == size - 1) ? n - (bincount) * (size - 1) : bincount;
		int* ans_arr = (int*)malloc(n * sizeof(int));
		for (int i = 0; i < size - 1; i++)
			counts_send[i] = bincount;
		counts_send[size - 1] = n - (bincount) * (size - 1);
		int* buffer_recv = (int*)malloc(count_recv * sizeof(int));
		displacements[0] = 0;
		for (int i = 1; i < size; i++)
		{
			displacements[i] = displacements[i - 1] + bincount;
		}
		double st = MPI_Wtime();
		// distributing data 
		MPI_Scatterv(a, counts_send, displacements, MPI_INT, buffer_recv, count_recv, MPI_INT, 0, MPI_COMM_WORLD);
		//performing quick sort on small portion of data
		quick_sort(buffer_recv, 0, count_recv - 1);
		// gathering num_of_process sorted arrays
		MPI_Gatherv(buffer_recv, count_recv, MPI_INT, a, counts_send, displacements, MPI_INT, 0, MPI_COMM_WORLD);
		// merging the num_of process sorted array to make ans_array
		Merge(a, displacements, counts_send, ans_arr, n, size);
		// writing to output file
		for (int i = 0; i < n; i++)
			outfile << ans_arr[i] << " ";
		outfile.close();
		double en = MPI_Wtime();
		printf("%lf time taken\n", en - st);
		free(a);
		free(counts_send);
		free(displacements);
		free(ans_arr);
		free(buffer_recv);
	}
	else
	{
		MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
		bincount = n / size;
		int count_recv = (rank == size - 1) ? n - (bincount) * (size - 1) : bincount;
		int* buffer_recv = (int*)malloc(count_recv * sizeof(int));
		MPI_Scatterv(NULL, NULL, NULL, MPI_INT, buffer_recv, count_recv, MPI_INT, 0, MPI_COMM_WORLD);
		quick_sort(buffer_recv, 0, count_recv - 1);
		MPI_Gatherv(buffer_recv, count_recv, MPI_INT, NULL, NULL, NULL, MPI_INT, 0, MPI_COMM_WORLD);
		free(buffer_recv);
	}
	MPI_Finalize();
	return 0;
}

