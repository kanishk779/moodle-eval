# include <iostream>
# include <mpi.h>
# include <cstdlib>
# include <ctime>
# include <iomanip>
#include <fstream> 

using namespace std;

int main(int argc, char **argv)
{

int rank;
int size;
ifstream fin;
ofstream fop; 
string inpFile = argv[1];
string line; 
fin.open(inpFile); 
getline(fin, line);  
fin.close();
int n = stoi(line);

MPI_Status status;

MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);
double res = 0;
int store = (n-1)/size;
int lc = 1 + store;
for(int i=0; i<lc; i++)
{
    int value = rank*lc + i;
    value += 1;
    if(value > n)
    {
        break;
    }

    int square = value*value;
    double r = double(1)/double(square);
    res = res + r;
}

if(rank != 0)
    MPI_Send(&res , 1, MPI_DOUBLE, 0, 123, MPI_COMM_WORLD);
else
{
	int i=1;
    for(; i<size; i++)
    {
        double temp = 0;
        MPI_Recv(&temp, 1, MPI_DOUBLE, i, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        res = res + temp;
    }

    
    fop.open(argv[2]);
    fop << fixed << setprecision(6) << res <<endl;
    fop.close();
}

MPI_Finalize();
return 0;
}