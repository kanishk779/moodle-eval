1). Approach :
Suppose, N = 100  and np = 7(no of cores )
We have to find : 1/(1^2) + 1/(2^2) + ...... 1/(N^2)

split N (dividing it by np) 
such as N/np
Special case: Last core should not hold extra values.


int num = rank*loopSize + i;
Example :
N = 100
np = 7
N/np = 100/7 = 14

core 1: [1,2...14]  computation(1/1^1 + 1/2^2 + ... 1/14^14)
core 2: [15,16...28]
core 3: [29,30...42]  
core 4: [43,44...56]
....................
....................
core 7  [85....]

send all results to core 1 (rank0) where it will add be added and finally will be written back into
output text file.

