#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>
#include <math.h>


int partition(int  *arr, int left, int right) {  
    int i = left, j = right;  
    int tmp;  
    int pivot = arr[(left + right) / 2]; /* partition */  
    while (i <= j) {      
        while (arr[i] < pivot)
            i++;      
        while (arr[j] > pivot)           
            j--;           
        if (i <= j) {              
            tmp = arr[i];              
            arr[i] = arr[j];                   
            arr[j] = tmp;                   
            i++;                   
            j--;                  
        }           
    }           
    return j; 
} 

void quick_sort(int* arr,int left, int right){ /* recursion */  
    int part_index = partition(arr, left, right); 
    if (left < part_index) 
        quick_sort(arr, left, part_index);           
    if (part_index + 1 < right)           
        quick_sort(arr, part_index + 1, right); 
} 

int sort_recursive(int* arr,  int size, int pr_rank, int max_rank, int rank_index){
    MPI_Status dtIn;
    int share_pr  = pr_rank + pow(2, rank_index); /* Calculate the rank of sharing process*/ 
    rank_index ++; /*Increment the count index*/ 
    int left = 0;
    int right = size - 1; 
    if(share_pr  > max_rank){ //If no process to share sort_rec_seq(arr, size);          
        quick_sort(arr,left,right);
        return 0; 
    }                
   
    int partition_pt = partition(arr,left,right);  /* partition array */  
    int offset = partition_pt  + 1;
    if (offset > size - offset){ 
        MPI_Send((arr + offset), size - offset, MPI::INT, share_pr, 0, MPI_COMM_WORLD); 
        sort_recursive (arr, offset, pr_rank,  max_rank,  rank_index); 
        MPI_Recv((arr + offset), size - offset, MPI::INT, share_pr, 0, MPI_COMM_WORLD, &dtIn);   
        }   
    else{ 
        MPI_Send(arr, offset, MPI::INT, share_pr, 0, MPI_COMM_WORLD); 
        sort_recursive ((arr + offset), size - offset, pr_rank, max_rank, rank_index); 
        MPI_Recv(arr, offset, MPI::INT, share_pr, 0, MPI_COMM_WORLD, &dtIn);   
    }
    return 0;
}    


int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    srand(time(NULL));
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    int max_rank = size - 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    ifstream readfile(argv[1]);
    long long n = 0;
    readfile >> n;
    if(rank == 0) {
    	int *bufferUnsorted = NULL;
        bufferUnsorted = (int*)malloc(N * sizeof(int));
	    for(int i=0;i<N;i++)
		    std::cin >> bufferUnsorted[i];
        sort_recursive(bufferUnsorted,N,0,max_rank,0);
        for(int i=0;i<N;i++)
            printf("%d ", bufferUnsorted[i]);	
        free(bufferUnsorted);
        }
    else {
	    int* subarray = NULL;
        MPI_Status msgSt, dtIn;     
        int sub_arr_size = 0;     
        int index_count = 0;     
        int pr_source = 0; 
        while(pow(2, index_count) <=  rank) /* calculate the index_count ++; index_count as 2 n-1≤ rank < 2n         n = index_count */ 
            index_count++;
        MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&msgSt);     
        MPI_Get_count(&msgSt, MPI::INT, &sub_arr_size);    
        pr_source = msgSt.MPI_SOURCE; 
        // pr_source = rank - pow(2,(index_count-1));     /* Get the sending process rank */     
        subarray = (int*)malloc(sub_arr_size * sizeof(int));  
        MPI_Recv(subarray, sub_arr_size, MPI::INT, pr_source,0, MPI_COMM_WORLD, &dtIn);   
        sort_recursive(subarray, sub_arr_size, rank,max_rank,index_count); /* sort recursively */ /*   send sorted sub array */    
        MPI_Send(subarray, sub_arr_size, MPI::INT, pr_source,0, MPI_COMM_WORLD);    
        free(subarray);
    }
    	 
    MPI_Finalize(); 
    return EXIT_SUCCESS;
}

