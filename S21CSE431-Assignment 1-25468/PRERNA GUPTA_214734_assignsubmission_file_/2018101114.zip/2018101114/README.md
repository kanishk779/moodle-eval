REPORT 
2018101114
PRERNA GUPTA

DS- ASSIGNMENT 1 
MPI PROGRAMMING

QUESTION 1

compile- mpic++ 2018101114_1.cpp
execute- mpirun -np <no_of_processes> ./a.out <input_filename> <output_filename>

Input - N

DESCRIPTION OF THE CODE - 

No. of values to be given to each process is decided using the below formula-

if(p>=n)
    {
        c=1;sz=1;
    }  
else
    {
        c=n/p; // number of elements for each (p-1) processes
        sz=n-((p-1)*c); number of elements for the main process.
    } 
let p - no. of processes
and n - no of elements
if the number of processes will be greater than the number of elements in the series, then I will assign each process one-one element. otherwise (p-1) processes will get n/p elements and main root process will get the remaining number of elements. i.e n-((p-1)*n/p)

Then each process will calculate the answer for its part and send to the main process.
    
    for (int i = val; i < receive+val; i++)
        {
            partial_sum += (float)(1/(float(i*i)));
        }

    MPI_Send(&partial_sum, 1, MPI_DOUBLE,
                 0, 0, MPI_COMM_WORLD);

For the case when p>n, for the processes with rank>n, I am returning zero as the partial sum of the series to the main process.
        
        double w=0.0;
        MPI_Send(&w, 1, MPI_DOUBLE,
                 0, 0, MPI_COMM_WORLD);

Then finally main process receives the values from all the other processes and adds to its calculated value.
And prints the final result in the file.

        double tmp;
        for (int ii = 1; ii <= p-1; ii++)
        {
            MPI_Recv(&tmp, 1, MPI_DOUBLE,
                     MPI_ANY_SOURCE, 0,
                     MPI_COMM_WORLD,
                     &status);
            int sender = status.MPI_SOURCE;
            sum += tmp;
        }
        printf("%0.6f\n",sum);
        file = fopen(argv[2], "a");
        fprintf(file, "%0.6f\n", sum);   
        fclose(file);

ANALYSIS:-


QUESTION-2

compile- mpic++ 2018101114_2.cpp
execute- mpirun -np <no_of_processes> ./a.out <input_filename> <output_filename>

Input - N ( no of elements of an array),
    elements of an array

DESCRIPTION OF THE CODE - 

All the array elements are divided among the p processes equally.
in case when (n%p!=0), I have added zero till the end.
So No of elements are changed to p*c;
     n=p*c;
    // compute chunk size
    c = (n%p!=0) ? n/p+1 : n/p;
each process calls quicksort function for its part.
    quicksort(chunk, 0, s);
    where chunk is the vector which contains the array elements upto size s.

After applying quicksort to all the elements assigned to p processes. I got p sorted arrays and then merged those one by one in maximum logn steps.

For merging arrays, the mapping scheme i used was i saw from some tutorial pdf on parallel quicksort.
So if rank is the multiple of 2*step, then I will merge the chunk with rank -> (id+step) [if process with this rank exists] to this process's array.

if (id+step < p) {
      if(c * (id+2*step)<=n)
      o=c*step;
      else
      o=n - c * (id+step);
      vector<int>other(o);
      MPI_Recv(&other[0], o, MPI_INT, id+step, 0, MPI_COMM_WORLD, &status);
      data = merge(chunk, s, other, o);
      chunk.clear();
      other.clear();
      chunk = data;
      s+=o;
    }

otherwise, if will send this array to the process with rank -> (id-step) and exit from the loop.

if (id % (2*step) != 0) {
      MPI_Send(&chunk[0], s, MPI_INT, id-step, 0, MPI_COMM_WORLD);
      break;
}
this merging continues till logn steps till we get the final merged sorted array.

ANALYSIS:-

QUESTION-3

compile- mpic++ 2018101114_3.cpp
execute- mpirun -np <no_of_processes> ./a.out <input_filename> <output_filename>

Input - 

DESCRIPTION OF THE CODE - 


