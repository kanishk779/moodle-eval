#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include<vector>
#include <time.h>
#include <bits/stdc++.h>
using namespace std;
double startTime;
static inline 

void quicksort(vector<int> &v, int s, int n)
{
  int x, p, i;
  if (n <= 1)
    return;
  int mid=s+n/2;
  x = v[mid];
  swap(v[s],v[mid]);
  p = s;
  i=s+1;
  while(i<s+n)
  {
    if (v[i] < x) {
      p++;
      swap(v[i],v[p]);
    }
    i++;
  }
  swap(v[s],v[p]);
  quicksort(v, s, p-s);
  quicksort(v, p+1, s+n-p-1);
}
vector <int> merge(vector <int> &v1, int n1, vector<int> &v2, int n2)
{
  vector<int>result(n1+n2);
  int i,j,k;
  i=0;j=0,k=0;
  while(k<n1+n2)
  {
    if (i >= n1) 
      result[k] = v2[j++];
    else if (j >= n2) 
      result[k] = v1[i++];
    else if (v1[i] < v2[j]) 
      result[k] = v1[i++];
    else 
      result[k] = v2[j++];
      k++;
  }
  return result;
}

int main(int argc, char ** argv)
{
  int n,c,s,o,step,p,id;
  MPI_Status status;
  double time_taken;
  FILE * file = NULL;
  int i;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &p);
  file = fopen(argv[1], "r");
  int cnt=0;
  fscanf(file, "%d", &n);
  if(n%p==0)
  c=n/p;
  else
  c=n/p+1;
  vector<int>data;
  string ss=argv[1];
  ifstream file1(ss);
  int x=0;
  int word;
  while (file1 >> word) {
    x++;
    if(x>1)
  data.push_back(word);
}
    for(int i=0;i<n;i++)
    {
      if(data[i]==0)
      cnt++;
    }
  MPI_Comm_rank(MPI_COMM_WORLD, &id);
 
   if (id == 0) {
     i=n;
     while(i<p*c)
     {
       data[i]=0;i++;
     }
  }
  //cout<<"llll "<<cnt<<endl;
  time_taken = - MPI_Wtime();
  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
  n=p*c;
  if(n%p==0)
  c=n/p;
  else
  c=n/p+1;
  
  vector<int>chunk(c);
  MPI_Scatter(&data[0], c, MPI_INT, &chunk[0], c, MPI_INT, 0, MPI_COMM_WORLD);
  data.clear();
  if(c*(id+1)<=n)
  s=c;
  else
  {
    s=n-c*id;
  }
  quicksort(chunk, 0, s);
   //for(int i=0;i<5;i++)
   //cout<<chunk[i]<<" ";
   //cout<<endl;
   step=1;
   while(step<p)
   {
    if (id % (2*step) != 0) {
      MPI_Send(&chunk[0], s, MPI_INT, id-step, 0, MPI_COMM_WORLD);
      break;
    }
    if (id+step < p) {
      if(c * (id+2*step)<=n)
      o=c*step;
      else
      o=n - c * (id+step);
      vector<int>other(o);
      MPI_Recv(&other[0], o, MPI_INT, id+step, 0, MPI_COMM_WORLD, &status);
      data = merge(chunk, s, other, o);
      chunk.clear();
      other.clear();
      chunk = data;
      s+=o;
    }
    step*=2;
  }
  time_taken += MPI_Wtime();
  if (id == 0) {
     file = fopen(argv[2], "w");
    for (i = 0; i < s; i++)
    {
      if(chunk[i]==0 && cnt>0 && i<s-1)
      {
      fprintf(file, "%d ", chunk[i]);cnt--;
      }
      else if(chunk[i]==0 && cnt>0 && i==s-1)
      {
      fprintf(file, "%d", chunk[i]);cnt--;
      }
      else if(chunk[i]!=0 && i<s-1)
      fprintf(file, "%d ", chunk[i]);
       else if(chunk[i]!=0 && i==s-1)
      fprintf(file, "%d", chunk[i]);
    }
    fclose(file);
    cout<<"Time taken "<<time_taken<<"secs"<<endl;
  }
  MPI_Finalize();
  return 0;
}

