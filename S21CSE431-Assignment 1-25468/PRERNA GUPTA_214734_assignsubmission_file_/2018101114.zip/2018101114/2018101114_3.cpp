#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <unistd.h>
#include <bits/stdc++.h>
using namespace std;
double startTime;
//int vertices, edges;
int M,edges;
//vert=edges;
int genline(int ed[][2], int LineEd[][2], int e)
{
	int i, cnt = 0, j, N;
	i=0;
	while(i<e)
	{
		for (j = i + 1; j < e; j++)
		{
			if (ed[j][0] == ed[i][0])
			{
				LineEd[cnt][0] = i;
				LineEd[cnt][1] = j;
				cnt++;
			}
			else if(ed[j][0] == ed[i][1])
			{
				LineEd[cnt][0] = i;
				LineEd[cnt][1] = j;
				cnt++;
			}
			else if(ed[j][1] == ed[i][0])
			{
				LineEd[cnt][0] = i;
				LineEd[cnt][1] = j;
				cnt++;
			}
			else if(ed[j][1] == ed[i][1])
			{
				LineEd[cnt][0] = i;
				LineEd[cnt][1] = j;
				cnt++;
			}
		}
		i++;
	}
	N = cnt;
	return N;
}
void createadj(int Adj[][1000+1], int arr[][2])
{
	Adj[edges+1][edges+1]={0};
	int i=0;
	while(i<M)
	{
		Adj[arr[i][0]][arr[i][1]] = 1;
		Adj[arr[i][1]][arr[i][0]] = 1;
		i++;
	}
}
int rn()
{
	return (rand() % 7 + rand() % 11 + rand() % 29 + rand() % 31);
}
int main(int argc, char **argv)
{
	int id, nprocs;

	MPI_Status status;
	int number;

	//cout << "hi " << endl;
	int dataRec[3];
	int dataSnd[nprocs + 1][3];
	int colored[1000]={-1};
	int weights[1000];
	int vertices,edges;
	//int graph[1000][1000];
	int maxcolor_no = 0;
	//int vertices, edges;
	FILE *file = NULL;

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	MPI_Request request[nprocs + 1];
	std::fstream myfile(argv[1], std::ios_base::in);
	//file = fopen(argv[1], "r");
	myfile >> vertices >> edges;
	//cout << vertices << " " << edges << endl;
	int ed[edges][2];
	int LineEd[edges * edges][2];
	for (int i = 0; i < edges; i++)
	{
		myfile >> ed[i][0];
		myfile >> ed[i][1];
	}
	vertices=edges;
	if (id == 0)
	{

		M = genline(ed, LineEd, edges);
		//cout << "M is " << M << endl;
		int graph[edges + 1][1000 + 1];
		createadj(graph, LineEd);
		int i, j;
		i=0;
		while(i<vertices)
		{
			weights[i] = rn();
			colored[i] = -1;
			i++;
		}
		int maxi = -1;
		i=0;
		while(i<vertices)
		{
			maxi = 0;
			for (j = 0; j < vertices; j++)
			{
				if (graph[i][j] != 0)
					maxi++;
			}
			maxcolor_no=max(maxi,maxcolor_no);
			i++;
		}

		maxcolor_no += 1;
		int eachprocess,lastprocess;
		int quot=vertices / (nprocs - 1);
		int rem= (vertices % (nprocs - 1));
		if(nprocs>=2)
		{
			eachprocess = quot;
			lastprocess = quot+rem;
		}
		else
		{
			 eachprocess=0;
			 lastprocess=vertices;
		}
		
		int fromVertex = 0, toVertex,send_coloured=0;
		int z=1;
		while(z<nprocs-1)
		{
			MPI_Send(&vertices, 1, MPI_INT, z, z, MPI_COMM_WORLD);
			int k = 0,sending=0;
			while(k<vertices)
			{
				MPI_Send(&graph[k], vertices, MPI_INT, z, z, MPI_COMM_WORLD);k++;
			}

			k=0;
			dataSnd[z][k] = fromVertex;
			toVertex = dataSnd[z][k] + eachprocess - 1;
			k=k+1;
			dataSnd[z][k] = toVertex;k=k+1;
			dataSnd[z][k] = maxcolor_no;
			MPI_Send(dataSnd[z], 3, MPI_INT, z, z, MPI_COMM_WORLD); 
			sending=z;
			MPI_Send(colored, vertices, MPI_INT, sending, sending, MPI_COMM_WORLD);
			k=sending+maxcolor_no;
			MPI_Send(weights, vertices, MPI_INT, sending, sending, MPI_COMM_WORLD);
			fromVertex = toVertex + 1;
			z++;
		}
		MPI_Send(&vertices, 1, MPI_INT, i, i, MPI_COMM_WORLD);

		int k = 0;
		while(k<vertices)
		{
			MPI_Send(&graph[k], vertices, MPI_INT, i, i, MPI_COMM_WORLD);k++;
		}
		k=0;
		dataSnd[i][k] = fromVertex;
		toVertex = dataSnd[i][k] + eachprocess - 1;
		k=k+1;
		dataSnd[i][k] = toVertex;k=k+1;
		dataSnd[i][k] = maxcolor_no;
		send_coloured=i;k=k+1;
		MPI_Send(dataSnd[send_coloured], k, MPI_INT, send_coloured, send_coloured, MPI_COMM_WORLD);
		maxi = -1;
		MPI_Send(colored, vertices, MPI_INT, send_coloured, send_coloured, MPI_COMM_WORLD);
		int q=0;
		MPI_Send(weights, vertices, MPI_INT, send_coloured, send_coloured, MPI_COMM_WORLD);
		i=1;
		while(i<=nprocs-1)
		{
			MPI_Recv(colored, vertices, MPI_INT, i, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);i++;}
		while(q<vertices)
		{
			maxi=max(maxi,colored[q]);q++;
		}
		printf("%d\n", maxi + 1);
		file = fopen(argv[2], "w");
		fprintf(file, "%d\n", maxi + 1);
		for (i = 0; i < vertices; i++)
		{
			printf("%d\n", colored[i] + 1);
			fprintf(file, "%d ", colored[i] + 1);
		}
		fclose(file);
	}
	else
	{
		int vertices;
		MPI_Recv(&vertices, 3, MPI_INT, 0, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		int graph[vertices+1][vertices+1];
		//cout<<"hey "<<vertices<<endl;
		int i, j;
		int ii=0;
		while(ii<vertices)
		{
			MPI_Recv(&graph[ii], vertices, MPI_INT, 0, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);ii++;}
		int k=0;
		MPI_Recv(dataRec, 3, MPI_INT, k, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		int colored[vertices];
		MPI_Recv(colored, vertices, MPI_INT, k, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		int weights[vertices];
		MPI_Recv(weights, vertices, MPI_INT, k, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		int curr_ver;
		int round = 0;
		while (round < vertices)
		{
			int all_colored = 1;
			curr_ver = dataRec[0];
			while(curr_ver <= dataRec[1])
			{
				if (colored[curr_ver] == -1)
				{
					all_colored = 0;
					int my_weight = weights[curr_ver];

					int is_my = 1;

					int nbr=0;
					while(nbr<vertices)
					{
						int value=0;
						if ((nbr - curr_ver)!=0)
						{
							if (graph[curr_ver][nbr] == 1)
							value+=1;
							if(colored[nbr] == -1)
							value+=1;
							if(weights[nbr] > weights[curr_ver])
							value+=1;
							if(value==3)
							{
								is_my = 0;
								break;
							}
						}
						nbr++;
					}
					if (is_my!=0)
					{
						int asgn_color = -1;
						asgn_color=0;
						while(asgn_color < dataRec[2])
						{
							int given = 1;
							nbr=0;
							while(nbr<vertices)
							{
								int value1=0;
								if(graph[curr_ver][nbr] == 1)
								value1+=1;
								if(colored[nbr] != -1)
								value1+=1;
								if(asgn_color == colored[nbr])
								value1+=1;
								if(value1==3)
								{
								given = 0;
								break;
								}
								nbr++;
							}
							if (given != 0)
							{
								colored[curr_ver] = asgn_color;
								break;
							}
							asgn_color++;
						}
					}
				}
				curr_ver++;
			}
			int m;
			int m1=1;
			while(m1 <= nprocs - 1)
			{
				if (m1 != id)
					MPI_Send(colored, vertices, MPI_INT, m1, m1, MPI_COMM_WORLD);
				m1++;
			}
			int m2=1;
			while(m2 <= nprocs - 1)
			{
				int local[vertices];
				if ((m2-id)!=0)
					MPI_Recv(local, vertices, MPI_INT, m2, id, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

				int cnt = 0;
				while(cnt<vertices)
				{
					int value3=0;
					if (colored[cnt] == -1) value3+=1;
					if(local[cnt] != -1) value3+=1;
					if(local[cnt] < dataRec[2]) value3+=1;
					if(local[cnt] >= 0) value3+=1;
					if(value3==4)
					colored[cnt] = local[cnt];
					cnt++;
				}
				m2++;
			}
			int cnt;
			round++;
			sleep(3);
		}
		MPI_Send(colored, vertices, MPI_INT, 0, id, MPI_COMM_WORLD);
	}
	MPI_Finalize();
	return 0;
}