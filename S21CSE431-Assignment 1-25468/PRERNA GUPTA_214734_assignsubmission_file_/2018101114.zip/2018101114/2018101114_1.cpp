#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>
#include <bits/stdc++.h>
#define ll long long int
#define float double
using namespace std;
double startTime;

int main(int argc, char **argv)
{
    int n;
    int c, s;
    int p, id;
    int receive=0;
    int val=0;
    MPI_Status status;
    double timetaken;
    FILE *file = NULL;
    double i;
    int sz,index;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &p);
    //cout << "hiii " << p << endl;
    MPI_Comm_rank(MPI_COMM_WORLD, &id);

     file = fopen(argv[1], "r");
         fscanf(file, "%d", &n);
         timetaken = - MPI_Wtime();
    if (id == 0)
    {
        if(p>=n)
        {
            c=1;sz=1;
        }  
        else
        {
        c=n/p;
        sz=n-((p-1)*c);
        }
        index=sz+1;

        if (p > 1)
        {
            for (i = 1; i <= p-1; i++)
            {
                MPI_Send(&c,
                         1, MPI_INT, i, 0,
                         MPI_COMM_WORLD);
                MPI_Send(&index,
                         1, MPI_INT, i, 0,
                         MPI_COMM_WORLD);
                index+=c;
            }
        }

        double sum = 0.0;
        for (i = 1; i <= sz; i++)
            sum += (float)(1/(float(i*i)));
        double tmp;
        for (int ii = 1; ii <= p-1; ii++)
        {
            MPI_Recv(&tmp, 1, MPI_DOUBLE,
                     MPI_ANY_SOURCE, 0,
                     MPI_COMM_WORLD,
                     &status);
            int sender = status.MPI_SOURCE;
            sum += tmp;
        }
        timetaken += MPI_Wtime();
        //printf("%0.6f\n",sum);
        file = fopen(argv[2], "a");
        fprintf(file, "%0.6f\n", sum);   
        fclose(file);
        cout<<"Time taken "<<timetaken<<"secs"<<endl;
    }
    else if(id<n)
    {
        MPI_Recv(&receive,
                 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD,
                 &status);
        MPI_Recv(&val,
                 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD,
                 &status);
        double partial_sum = 0.0;
        for (int i = val; i < receive+val; i++)
        {
            partial_sum += (float)(1/(float(i*i)));
        }
        MPI_Send(&partial_sum, 1, MPI_DOUBLE,
                 0, 0, MPI_COMM_WORLD);
    }
    else
    {   
        MPI_Recv(&receive,
                 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD,
                 &status);
        MPI_Recv(&val,
                 1, MPI_INT, 0, 0,
                 MPI_COMM_WORLD,
                 &status);
        double w=0.0;
        MPI_Send(&w, 1, MPI_DOUBLE,
                 0, 0, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}
