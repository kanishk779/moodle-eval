#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

#define pb push_back
using namespace std;
typedef long long int ll;

std::vector <ll> in_vec, temp_vec;
std::string input_file, output_file;

ll read_input_file(std::string input_file){
    
    std::fstream in_file(input_file, std::ios_base::in);

    ll a;
	int n;
	in_file >> n;
    while (in_file >> a)
    {
        in_vec.pb(a);
    }

    in_file.close();

    return n;
}

ll write_output_file(std::string output_file){
    
    std::ofstream out_file(output_file);

    std::ostream_iterator<ll> output_iterator(out_file, " ");
    std::copy(temp_vec.begin(), temp_vec.end(), output_iterator);
	out_file << "\n";
    out_file.close();
}

ll get_element_count(ll sz, ll numprocs, ll rank){
    ll cnt;

    if(sz % numprocs == 0)
	{
        cnt = sz/numprocs;
    } 
	else
	{
        cnt = sz/numprocs + 1; 
    }
    return cnt;
}

ll get_batch_size(ll sz, ll cnt, ll rank){

    if(sz >= cnt * (rank+1)){
        return cnt;
    } else {
        return (sz - cnt * rank); 
    }
}

ll get_recv_size(ll sz, ll cnt, ll rank, ll inc){

    if(sz >= cnt * (rank + 2 * inc)){
        return cnt * inc;
    } else {
        return (sz - cnt * (rank + inc)); 
    }
}

ll get_max(ll a, ll b){
    if(a > b){
        return a;
    } else {
        return b;
    }
}

void swap(ll * x, ll * y)
{
  ll temp = *x;
  *x = *y;
  *y = temp;
}

ll getPivot(ll low, ll high)
{
    ll mid = (low+high)/2;

    if(temp_vec[low] > temp_vec[high])
    {
        swap(&low, &high);
    }

    if(temp_vec[mid] < temp_vec[low])
    {
        swap(&low, &mid);
    }

    if(temp_vec[high] < temp_vec[mid])
    {
        swap(&mid, &high);
    }

    return mid;

}

ll partition(ll low, ll high)
{
    ll pivotIdx = getPivot(low, high);
    ll pivot = temp_vec[pivotIdx];

    swap(&temp_vec[pivotIdx], &temp_vec[high]);

    ll storeIdx = low;

    for(int i = low; i < high; i++)
    {
        if(temp_vec[i] < pivot)
        {
            swap(&temp_vec[i], &temp_vec[storeIdx]);
            storeIdx++;
        }
    }

    swap(&temp_vec[storeIdx], &temp_vec[high]);
    return storeIdx;
}

void qsort(ll low, ll high)
{
    if(low < high)
    {
        ll p = partition(low, high);
        qsort(low, p - 1);
        qsort(p + 1, high);
    }
}

std::vector <ll> merge_sorted(std::vector <ll> v1, std::vector <ll> v2){
    ll sz1 = v1.size();
    ll sz2 = v2.size();

    std::vector <ll> merged_vec;
    ll i = 0, j = 0;

    while(i < sz1 && j < sz2){
        if(v1[i] <= v2[j]){
            merged_vec.pb(v1[i]);
            i++;
        } else {
            merged_vec.pb(v2[j]);
            j++;
        }
    }

    while(i >= sz1 && j < sz2){
        merged_vec.pb(v2[j]);
        j++;
    }

    while(i < sz1 && j >= sz2){
        merged_vec.pb(v1[i]);
        i++;
    }

    return merged_vec;
}

int main( int argc, char **argv ) {
    int rank, numprocs;
    ll sz, cnt, batch_sz;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (rank == 0){
        input_file = argv[1];
        output_file = argv[2];

        sz = read_input_file(input_file);
    }


    MPI_Bcast(&sz,1,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);

    cnt = get_element_count(sz, numprocs, rank);
    temp_vec.resize(cnt);

    MPI_Scatter(in_vec.data(), cnt, MPI_LONG_LONG_INT, temp_vec.data(), cnt, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);

    batch_sz = get_batch_size(sz, cnt, rank);
    batch_sz = get_max(batch_sz, 0);

	
	// cout << batch_sz << " " << rank << endl;

    qsort(0, get_max(batch_sz - 1,0));


    MPI_Status st;

    ll inc = 1;

    while(inc < numprocs){
        if(rank % (2 * inc) != 0){
            if ((rank - inc) >= 0){
                MPI_Send(temp_vec.data(), batch_sz, MPI_LONG_LONG_INT, rank - inc, 0, MPI_COMM_WORLD);
                break;
            }
        }

        if(rank + inc < numprocs){
            ll recv_sz = get_recv_size(sz, cnt, rank, inc);
		// cout << "inside " << recv_sz << " " << rank << endl;
            if (recv_sz <= 0)
			{
				inc *= 2;
			 	continue;
			}

            std::vector <ll> recv_vec(recv_sz);

            MPI_Recv(recv_vec.data(), recv_sz, MPI_LONG_LONG_INT, rank + inc, 0, MPI_COMM_WORLD, &st);
        
            temp_vec = merge_sorted(temp_vec,recv_vec);

            batch_sz += recv_sz;
        }

        inc *= 2;
    }


    if(rank == 0)
    {
        write_output_file(output_file);
    }
 
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}