/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Status status; 
    FILE *inp;
    char *input_filename;
    char *output_filename;
    int n;
    int start_recv;
    int num_recv;
    
    if(rank==0)
    {
        if(argc < 3)
        {
            cout << "Invalid Syntax. Check the command line arguements" << endl;
            return 0;
        }
        else
        {
            input_filename = argv[1];
            output_filename = argv[2];
            std::ifstream infile(input_filename);
            infile >> n;
        }
        // #################################################################
        int start_num,each_process_nums,i;
        each_process_nums = n/numprocs;
        if(numprocs > 1)
        {
            for(i=1;i<numprocs-1;i++)
            {
                start_num = i*each_process_nums;
                MPI_Send(&start_num,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&each_process_nums,1,MPI_INT,i,0,MPI_COMM_WORLD);
                // cout << "here " << start_num << endl;
            }
            start_num = i*each_process_nums;
            int last_process_nums = n-start_num;
            MPI_Send(&start_num,1,MPI_INT,i,0,MPI_COMM_WORLD);
            MPI_Send(&last_process_nums,1,MPI_INT,i,0,MPI_COMM_WORLD);
        }
        double ans = 0.000000000;
        for(i=1;i<=each_process_nums;i++)
        {
            double a = 1.0/pow(i,2.0);
            ans = ans + a;
        }
        double rest_ans ;
        for(i=1;i<numprocs;i++)
        {
            MPI_Recv(&rest_ans,1, MPI_DOUBLE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
            ans = ans+ rest_ans;
            // cout << "here3 " << ans << " " << rest_ans << endl;
        }
        // cout << setprecision(7) << "answer is: "  << ans << endl; 
        ofstream output(output_filename);
        double check = 0.00000001;
        ans = ans+check;
        output<<setprecision(7)<<ans<<endl; 
    }
    else
    {
        MPI_Recv(&start_recv,1,MPI_INT,0,0,MPI_COMM_WORLD,&status);
        MPI_Recv(&num_recv,1,MPI_INT,0,0,MPI_COMM_WORLD,&status);
        double ret_ans = 0.0000000000001;
        for(int i=1;i<=num_recv;i++)
        {
            double a = 1/pow(i+start_recv,2.0);
            ret_ans+=a;
        }
        MPI_Send(&ret_ans,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD);
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}