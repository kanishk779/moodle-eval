/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define pb push_back

using namespace std;
typedef long long int ll;

std::vector <pair<int,int>> in_vec,line_vec;
std::vector <ll> temp_vec;
std::string input_file, output_file;
int max_degree;
vector <int> final_coloring(1000,-1);
vector<vector<int>> graph( 1000 , vector<int> (1000, 0));
vector <int> arr_degree(1000,0);
int nodes,edges;
ll read_input_file(std::string input_file){
    
    std::fstream in_file(input_file, std::ios_base::in);

    ll a,b;
	int n,m;
	in_file >> n >> m;
    while (in_file >> a >> b)
    {
        in_vec.pb(make_pair(a-1,b-1));
    }

    in_file.close();

    return n;
}

ll write_output_file(std::string output_file){
    
    std::ofstream out_file(output_file);
    out_file << *max_element(temp_vec.begin(),temp_vec.end()) << "\n";
    std::ostream_iterator<ll> output_iterator(out_file, " ");
    std::copy(temp_vec.begin(), temp_vec.end(), output_iterator);
	out_file << "\n";
    out_file.close();
}
void coloring(vector<int> &coloring,int node_pad)
{
    for(int i=0;i<node_pad;i++)
    {
        coloring[i] = i;
    }
}
void linegraph(int nodes,int edges)
{
    int new_nodes = 0;
    for(int i=0;i<edges;i++)
    {
        for (int j=i+1;j<edges;j++)
        {
            if(in_vec[i].first==in_vec[j].first || in_vec[i].first==in_vec[j].second || in_vec[i].second==in_vec[j].first ||  in_vec[i].second == in_vec[j].second)
            {
                graph[i][j] = 1;
                graph[j][i] = 1;
            }
        }
    }
}
void calc_degree()
{
    for(int i=0;i<edges;i++)
    {
        for(int j=0;j<edges;j++)
        {
            if(graph[i][j])
            {
                arr_degree[i]++;
            }
        }
    }
    max_degree = *(max_element(arr_degree.begin(),arr_degree.end()));
}

vector<int> assigncolors(int mid, int l,int r) {
    set<int> used;
    stack<int> st;
    for (int j = l; j < mid; j++)
    {
        used.insert(j);
    }
    vector<int> ret;
    for (int i = 0; i < edges; i++) 
    {
        if ( final_coloring[i] >= mid || final_coloring[i] < l)
        {
            for (int j = 0; j < edges; j++) {
                if (graph[j][i]==0)
                {
                    continue;
                }
                else if (used.erase(final_coloring[j]))
                {
                    st.push(final_coloring[j]);
                }
        }
            // assert(!used.empty());
            final_coloring[i] = *used.begin();
            ret.pb(final_coloring[i]);

            while (true) 
            {
                if(st.empty())
                {
                    break;
                }
                int t = st.top();
                st.pop();
                used.insert(t);
            }
        }
    }
    return ret;
}
int main( int argc, char **argv ) {
    int rank, numprocs;
    srand(time(NULL));
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if (rank == 0)
    {
        input_file = argv[1];
        output_file = argv[2];

        nodes = read_input_file(input_file);
        edges = in_vec.size();
        linegraph(nodes,edges);
        // max_degree = *max_element(arr_degree.begin(),arr_degree.end());
    }

    MPI_Bcast(&edges, 1, MPI_INT,0, MPI_COMM_WORLD);
    MPI_Bcast(graph[0].data(), 1000000, MPI_BYTE,0, MPI_COMM_WORLD);
    
    coloring(final_coloring,edges);
    calc_degree();
    // cout << "check max " << max_degree << endl;
    if(rank == 0)
    {
        int colored = 0;
        int cnt = 0;
        while(true)
        {
            if(cnt>9)
            {
                break;
            }
            colored = set<int>(final_coloring.begin(),final_coloring.end()).size();
            if(colored <= max_degree+1)
            {
                break;
            }
            else if(colored > max_degree*2+2)
            {
                MPI_Bcast(final_coloring.data(),edges, MPI_INT,0, MPI_COMM_WORLD);
                
                int  padded  ;
                if((colored/numprocs)&1)
                {
                    padded = colored/numprocs+1;
                }
                else
                {
                    padded = colored/numprocs;
                }
                int left = 0;
                if(2*max_degree+2 > padded)
                {
                    left = 2*max_degree+2;
                }
                else
                {
                    left = padded;
                }
                for(int i=1;i<numprocs;i++)
                {
                    if(left+max(2*max_degree+2,padded)-1 < nodes)
                    {
                        MPI_Send(&left,1,MPI_INT,i,0,MPI_COMM_WORLD);
                        int test = max(2*max_degree+2,padded);
                        MPI_Send(&test,1,MPI_INT,i,0,MPI_COMM_WORLD);
                    }
                    else
                    {
                        int a = -1,b = -1;
                        MPI_Send(&a,1,MPI_INT,i,0,MPI_COMM_WORLD);
                        MPI_Send(&b,1,MPI_INT,i,0,MPI_COMM_WORLD);
                        
                    }
                    left += max(2*max_degree+2,padded);
                }
                assigncolors(max(2*max_degree+2,padded)/2,0,max(2*max_degree+2,padded));
                if(2*max_degree+2 > padded)
                {
                    left = 2*max_degree+2;
                }
                else
                {
                    left = padded;
                }
                int i=1;
                while(i<numprocs)
                {
                    int flag ;
                    if(left+max(2*max_degree+2,padded)-1 < nodes )
                    {
                     MPI_Recv(&flag, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                     vector<int> temp;
                     if(flag)
                     {
                         temp.resize(flag);
                         MPI_Recv( temp.data() ,flag , MPI_INT, i ,0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
                     }
                     int res = 0;
                     for(int j=0;j<edges;j++)
                     {
                         auto &a = final_coloring[j];
                         if(a < left || a >= left+ max(2*max_degree+2,padded)/2)
                         {
                             res++;
                             a = temp[res];
                         }
                     }
                    }
                    else
                    {
                        break;  
                    }
                    i++;
                    left += max(2*max_degree+2,padded);
                }
            }
            else if(colored>max_degree+1 && colored <= 2*max_degree+2)
            {
                assigncolors(max_degree+1,0,colored);
            }
            cnt++;
        }
    
       

        // cout << "check coloring" << endl;
        // for(int i=0;i<nodes;i++)
        // {
        //     cout << check_coloring[i] << " ";
        // }
        // cout << endl;

        // cout << "coloring " << colored << endl;
        // for(int i=0;i<edges;i++)
        // {
        //     cout << final_coloring[i]+1 << " ";
        // }
        // cout << endl;
        for(int i=0;i<edges;i++)
        {
            temp_vec.pb(final_coloring[i]+1);
        }
        write_output_file(output_file);
        final_coloring[2] = -1;
        MPI_Bcast(final_coloring.data(),edges, MPI_INT,0, MPI_COMM_WORLD);
    }
    else
    {
        while(true)
        {
            int flag;
            MPI_Bcast(final_coloring.data(),edges, MPI_INT,0, MPI_COMM_WORLD);
            if(final_coloring[2]==-1)
            {
                break;
            }
            MPI_Recv(&flag, 1,MPI_INT,0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            int sz;
            MPI_Recv(&sz, 1,MPI_INT,0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if(flag!=-1)
            {
                vector<int> check = assigncolors(flag+(2*max_degree+2)/2,flag,flag+2*max_degree+2);
                int ct = check.size();
                MPI_Send(&ct, 1, MPI_INT,0, 0, MPI_COMM_WORLD);    
                MPI_Send(check.data(),check.size(), MPI_INT,0, 0, MPI_COMM_WORLD);
            }
        }

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (st): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}