## Assignment Report
### Reciprocal
#### Implementation
- We divide the computation of N/procs to each process.
- Each process independently calculates the sum of reciprocals
- We then receive these sums and add to get final result.

### Quicksort
#### Implementation
- The size of the input array of number is broadcasted to all the processes from the root
- Elements are distributed to each process based on the condition :-
	- if array_sz % numproc == 0: the elements are equally divided
	- else zeros are appended to the input values and then scattered

- Then qsort is applied to elements in each process
- The sorted arrays in each process are merged by combining elements between adjacent processes using MPI_Send and MPI_Recv. Example :-
	- 0 <-> 1 2 <-> 3 4 <-> 5
- This is repeated till we are left with a single sorted vector 

|    Input Size   |    Sequential  |    Parallel    |
|:---------------:|:--------------:|:--------------:|
|      10000      |     0.002971   | 	0.002749    |
|      100000     |     0.032280   | 	0.042202	|
|      1000000    |     0.379910   | 	0.435982	|

### Edge Coloring
#### Implementation 
- We model this problem as vertex coloring in line graph.
- We thus transform the input graph to line graph.
- We then start with a coloring initially.
- Now we divide the nodes among processes and see if the subgraph has a valid coloring.
- If it doesnt have then we redo the color.
- We repeat this for whole graph until we have a valid coloring.
