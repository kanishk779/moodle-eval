											Distributed System Assignment 1
												MPI Programming

												Indranil Pradhan
												  M.Tech CSIS
											    ROll number - 2019202008


Question - 1

Input - An integer N denoting the number of terms in the series.
Output - A floating point number, denoting the estimated value of (pi)^2/6 rounded off to six decimal places.

Algorithm - 
	1. The process with rank 0 takes input from the file.
	2. The process with rank 0 divides the input N in uniform range for remaining processes and gives the range of numbers for which sum is to be calculated to remaining processes. 
		Example- If the input number is 6 and there are 3 processes. Then rank 0 process divides the input 6 in 2 ranges of numbers (6/2) for remaining 2 processes.
			Rank 1 process calulcates the sum for range 1 to 3. Rank 2 process calculates the sum for range 4 to 6.
	3. Each of the remaining process calculates the sum for given range and return the sum to rank 1 process.
	4. Rank 1 process collects respective sum from each remaining processes and calculate the cumulative sum rounding off the value to siz decimal places denoting the estimated
	   value of (pi)^2/6.

Sample output and Time Taken -

Input - 200
Output - 1.639947
Number of processes - 8
Time Taken - 0.000357 seconds

Input - 300
Output - 1.641606
Number of processes - 11
Time Taken - 0.000252



Question - 2

Input - The first line of input contains size of array N . The second line of input contains N space separated integers.
Output - The output is a space separated sorted array.

Algorithm - 
	1. The process with rank 0 takes input from the file.
	2. The process with rank 0 divides the input N in uniform range of indices for remaining processes and gives the range of indices to other process for which remaining process will sort the array 		   of given range of indices.
		Example- If the array size is 6 and there are 3 processes. Then rank 0 process divides the input 6 in 2 ranges of indices (6/2) for remaining 2 processes.
			Rank 1 process sorts the array of indices ranging from 0 to 2. Rank 2 process sorts the array of indices ranging from 3 to 5.
	3. Each of the remaining processes sorts the array of given range of indices using randomized quick sort process. Below are the steps for randomized quick sort process - 
		a. Randomized Quicksort(A, low, high)
			a.1. if low < high
				a.1.1. mid = Random Partition(a, low, high)
				a.1.2. Randomized Quicksort(A, low, mid-1)
				a.1.3. Randomized Quicksort(A, mid+1, high)
		b. Random Partition(A, low, high)
			b.1. i = Random(low, hgih)
			b.2. swap A[high] with A[i]
			b.3. return Partition (A, low, high)
		c. Partition(A, low, high)
			c.1. set min to low-1 and max to high-1 and pivot to A[high]
			c.2. Increment min until A[min] is less than pivot.
			c.3. Decrement max until A[max] is greater than pivot.
			c.4. If min is greater than max exit loop.
			c.5. Else swap A[min] with A[max]
			c.6. After exiting the loop swap A[min] with A[max].
	4. After collecting each chunk sorted array from remaining processes, the rank 0 process merge the chunks and generates the accumulated sorted array.
	5. for merging below Algorithm is used
		a. algorithm merge(A, B) is
		b. C is a new empty list
		c. while A is not empty and B is not empty do
			if A[i] is less than B[i] then
				append A[i] to C
			else
				append B[i] to C
		d. while A is not empty do
			append A[i] to C
		e. while B is not empty do
			append B[i] to C

Sample output and Time Taken - 

Input - 7
	9 3 -11 100 2 2 4
Outout - -11 2 2 3 4 9 100 
Number of Processes - 5
Time taken - 0.000633 seconds


Input - 20
	7 22 90 12 -12 23 87 33 33 86 10 32 69 54 65 32 58 59 16 20
Output - -12 7 10 12 16 20 22 23 32 32 33 33 54 58 59 65 69 86 87 90 
Number of Processes - 3
Time taken - 0.000435 seconds


Question 3 -

Input - First line contains two integers N M , denoting the number vertices and edges of the graph. Then, there are M lines, each of which contains 2 integers u and v, which means there is an edge in 	graph joining vertices u and v. i th line here corresponds to edge i.
Output - First line should contain a single integer x denoting the number of colors used. Second line should contain M integers (c 1 , c 2 , ..., c N ), where c i represents color of the edge i. 
	1 ≤ c i ≤ x

Algorithm - 
	1. The process with rank 0 takes input from the file.
	2. The process with rank 0 distributes the vertices in ranges uniformly to the remaining processes which will color the edge between the vertices present in the range of vertices given to that 	   process.
		Examples - If the number of vertices is 6 and there are 3 processes. Then rank 0 process divides the number of vertices, 6 in 2 ranges of vertices (6/2) for remaining 2 processes.
			Rank 1 process color the edges of the graph whose vertices ranging from 0 to 2. Rank 2 process color the edges of the graph whose vertices ranging from 3 to 5.

	3. Each of the remaining processes color the edge between the vertices present in the range of vertices given to the process. The below algorithm is used to color the edges - 
		a. For the i th edge from edges of the graph
			a.1. set the initial color, c is 1.
			a.2. if the u and v vertices of the i th edge belongs the range of vertices for that process and the edge is not colorured yet
			a.3. set the color of the edge to c.
			a.4. for all the edges, j which are adjacent to the edge of the i and whose u and v vertices belongs to the range of vertices given to that process
				a.4.1 if the color of the i th edge and j th edge is same
				a.4.2. increment color and go to step a.3.
				a.4.3. Else go to step a.4.
	4. After collecting all the coloured edges from the processes, the rank 0 process colours remaining uncoloured edges using the algorithm mentioned in the step 3.


Sample Output and Time taken - 
Input - 
3 3
1 2
2 3
3 1
Output - 
3
1 2 3
Numbe of processes - 5
Time taken - 0.001941 seconds


Input - 
5 6
1 2
1 3
2 4
3 4
3 5
4 5
Output - 
4
1 2 2 1 3 4 
Number of processes - 11
Time taken - 0.001491 seconds

