/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int a2[1000];
int main( int argc, char *arg[]) 
{
    int rank, np, elements_per_process, n_elements_recieved; 
    string s = arg[1];
    // int n = stoi(s);
    int n;
    FILE *ifile = fopen(arg[1], "r");
    fscanf(ifile, "%d\n", &n);
    // cout<<n<<endl;
    fclose(ifile);

    int *a = new int[n]; 

    for(int i=0; i<n; i++)
    a[i] = i+1;
    MPI_Init(&argc, &arg); 
  
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
    MPI_Comm_size(MPI_COMM_WORLD, &np); 
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if (rank == 0) 
    { 
        int index, i; 
        elements_per_process = n / np; 
  
        if (np > 1) 
        { 
           
            for (i = 1; i < np - 1; i++) 
            { 
                index = i * elements_per_process; 
  
                MPI_Send(&elements_per_process, 1, MPI_INT, i, 0, MPI_COMM_WORLD); 
                MPI_Send(&a[index], elements_per_process, MPI_INT, i, 0, MPI_COMM_WORLD); 
            } 
  
            index = i * elements_per_process; 
            int elements_left = n - index; 
  
            MPI_Send(&elements_left, 1, MPI_INT, i, 0, MPI_COMM_WORLD); 
            MPI_Send(&a[index], elements_left, MPI_INT, i, 0, MPI_COMM_WORLD); 
        } 
  
        float sum = 0; 
        for (i = 0; i < elements_per_process; i++) 
            sum += 1.0/(a[i]*a[i]); 
  
        float tmp; 
        for (i = 1; i < np; i++) 
        { 
            MPI_Recv(&tmp, 1, MPI_FLOAT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);   
            sum += tmp; 
        } 
        
        FILE *ofile = fopen(arg[2], "w");
        fprintf(ofile, "%0.6f", sum);
        fclose(ofile);

        // printf("Sum of array is : %0.6f\n", sum); 
    } 
    else 
    { 
        MPI_Recv(&n_elements_recieved, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
  
        MPI_Recv(&a2, n_elements_recieved, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
        // printf("process %d received %d elements\n",rank, n_elements_recieved);

        float partial_sum = 0; 
        for (int i = 0; i < n_elements_recieved; i++) 
        {    
            // printf("Element - %d\n",a2[i]);
            partial_sum += (1.0/(a2[i]*a2[i])); 
            // printf("Sum calculated : %f\n",partial_sum);
        }
        // printf("Sum calculated by process %d is %f\n",rank, partial_sum);

        MPI_Send(&partial_sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD); 
    } 
    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    MPI_Finalize(); 
  
    return 0;     
    
}