#include<bits/stdc++.h>
#include <mpi.h>
using namespace std;
#define max1 2147483647
void s1(int &a, int &b,int flag)
{
	int temp = a;
	a = b;
	 b = temp;
}
int pivot(int *q,int l,int h)
{
	int i=l-1;
	int p=q[h-1];
	for(int j=l;j<=h-1 && l<h;j++)
	{
		if(q[j]<p)
		{
			i++;
			s1(q[i],q[j],1);
		}
	}
	s1(q[i+1],q[h-1],0);
	return i+1;
}
void quickSort(int *q,int l,int h)
{
	if(l>=h)
	return ;
	else
	{
		int p=pivot(q,l,h);
		quickSort(q,l,p);
		quickSort(q,p+1,h);
	}

}
int* merge(int *a,int *b,int n1,int n2)
{
	int * result = (int *)malloc((n1 + n2) * sizeof(int));
	int i=0,j=0,k=0;
	// for(int i=0,j=0,k=0;i<n1||j<n2;)
	while(i<n1&& j<n2)	
	{
		if(a[i]<=b[j])
		{
			result[k++]=a[i++];	
		}
		else
		{
			result[k++]=b[j++];
		}
	}
	while(i<n1)
	{
		result[k++]=a[i++];
	}
	while(j<n2)
	{
		result[k++]=b[j++];
	}

	return result;
}
int main(int argc, char* arg[])
{
	FILE *ifile=NULL;
	
	int n;
	// cin>>n;
	int *arr,*ch;
	int final_=n;
	int *res;
	int *data;
	int iteration=0;
	int index1 = 1;
	int flag1 = true;
	int flag2 = false; 
	int actual=n,act=0;
	MPI_Init(&argc, &arg); 
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
	
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	

	// data = new int[size+2];
	data = (int *)malloc((size+2 )* sizeof(int));
	
	if(rank==0)
	{
		int x=n%size;
		actual=n;
		if(x<=0)
			// arr=new int[n];
			arr = (int *)malloc(n * sizeof(int));
		else
		{
			// arr=new int[n+(size-x)];
			arr = (int *)malloc((n+(size-x)) * sizeof(int));
			for(int i=n;i<n+size-x;i++)
				arr[i]=max1;
			actual=n+size-x;
		}
		
		actual=actual/size;
		if(size-x>actual&&x!=0 || iteration!=0)
		{
			for(int i=0;i<size-2 && flag1;i++)
			{
				data[i]=actual;
			}
			int temp1 = actual*(size-2)+iteration;
			data[size]=iteration+1;
			data[size-2]=n-temp1;
			data[size-1]=0;
		}
		else
		{
			for(int i=0;i<size-1;i++)
			{
				data[i]=actual;
			}
			int temp3 = actual*(size-1)+iteration;
			data[size-1]=n-temp3;
			data[size]=0;
		}

		ifile = fopen(arg[1], "r");
		fscanf(ifile, "%d\n", &n);
		 cout<<n<<endl;
		// a = new int[n];
		for (int i = 0; i < n; i++)
		   	fscanf(ifile, "%d ", &(arr[i]));
		fclose(ifile);
		
		// for(int i=0;i<n;i++)
		// {
			// arr[i]=(rand()%n);
		// 	cout<<arr[i]<<" ";
		// }
		// cout<<endl;
	}
	MPI_Bcast(data,size+1,MPI_INT,0,MPI_COMM_WORLD);
	actual=data[0];
	if(data[size]!=1)
	{
		ch= (int *)malloc(actual * sizeof(int));
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		act=actual+iteration;
		
		if((rank+1)==size && !flag2)
		{
			quickSort(ch,0,data[rank]);
			act=data[rank];

		}
		else
			quickSort(ch,0,data[rank]);
		for(int i=1;i<size;)
		{
			int itr=2*i +iteration;
			if(rank%itr!=0)
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			if((rank+i)<size || iteration!=0)
			{	
				int elements=0;
				elements = iteration;
				int temp = rank + 2*i+iteration;
				if((actual*temp)>n)
				{
					 elements=n-actual*(rank+i);
				}			
				else if((actual*temp)<=n)
				{
					elements=actual*i+index1-1;
				}
				// int *tempArray=new int[elements];
				int *tempArray ;
				tempArray = (int *)malloc(elements * sizeof(int));
				MPI_Recv(tempArray,elements,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				
				res = merge(ch,tempArray,act,elements);
				act+=elements;
				ch=res;
			}
			if(iteration>=0)
			i=itr;
		}
	}
	else
	{
		ch = (int *)malloc(actual * sizeof(int));
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		if(flag1)
		{
			n=actual*(size-1);
			act=data[0];
		}
		quickSort(ch,0,data[rank]);
		size--;
		for(int i=1;i<size && flag1;)
		{
			int itr=2*i;
			if(rank%itr!=0 )
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			if((rank+i)<size && !flag2)
			{	
				int elements=0;
				int temp4 = (rank+2*i)+iteration;
						
				if((actual*temp4)<=n)
				{
					elements=actual*i;
				}
				else
				{
					 elements=n-actual*(rank+i);
				}	
				// int *tempArray=new int[elements];
				int *tempArray = (int *)malloc(elements* sizeof(int));
				MPI_Recv(tempArray,elements,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);

				res = merge(ch,tempArray,act,elements);
				act+=elements;
				ch=res;
			}
			if(iteration>=0)
			i=itr;
		}
	}
	// MPI_Barrier(MPI_COMM_WORLD);
	if(rank==0)
	{
		for(int i=0;i<final_;i++)
		{
			cout<<ch[i]<<" ";
		}
		cout<<endl;	

		FILE *ofile = fopen(arg[2], "w");
	    // fprintf(file, "%d\n", s);   // aelementsert (s == n)
	    for (int i = 0; i < final_; i++)
	      fprintf(ofile, "%d ", ch[i]);
	    fclose(ofile);
	}
	MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
	MPI_Finalize(); 
return 0;
}
		

