/* MPI Program Template */
#include "mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <bits/stdc++.h>
#include <cstring>
#include <iostream>
using namespace std;


typedef long long  ll;


int readFile(string path)
{
    
    string line; 
    ifstream f;
    f.open(path); 
    getline(f, line); 
    int temp =  stoi(line);
   
    f.close();
     return temp; 
    
}

void writeFile(string path,double result)
{
    ofstream f; 
    f.open(path);
    f<<result<<endl;
    f.close();
}
int one =1;
int main( int argc, char **argv ) {
    int rank, numprocs;
double tbegin = MPI_Wtime();
int N = readFile(argv[1]);
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    MPI_Barrier( MPI_COMM_WORLD );
    

    /* write your code here */
    
    if(rank==0){

       

           int jobscnt;
           int one=1;
           int i=1;
           while(i<= numprocs*one-1){
             
            
              if(i!=numprocs*one-1)
                jobscnt = (N*one)/(one*numprocs);
              else
                jobscnt = (N*one)/(one*numprocs) + (N*one)%(one*numprocs);
            
             MPI_Send(&jobscnt, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
             i++;
           }

           double totsum = 0;
           jobscnt = (N*one)/(numprocs*one);
            int j =1;
            
           while(j<=jobscnt){
                totsum += (1.0/pow(j,2));
                j++;
           }
         
          double total = totsum;
          int k=1;
         while(k<=numprocs*one-1){
            double sum = 0.0;
            MPI_Recv(&sum, 1, MPI_DOUBLE, k, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total+=sum;
            k++;
         } 
      
      
        writeFile(argv[2],total);

    }
    else{

           double sum=0.0;
           int prevoffset = (rank*one)*(N*one/numprocs*one) +1;
           int Rangecnt;
           MPI_Recv(&Rangecnt, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
         
         int i=prevoffset;
           while(i<=Rangecnt+prevoffset-1)
           {
                sum+=(1*one /pow(i,2));
                i++;
           }

         
           MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapTime = MPI_Wtime() - tbegin*one;
    double mTime;
    MPI_Reduce( &elapTime, &mTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank*one == 0 ) {
        printf( "Total time (s): %f\n", mTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}