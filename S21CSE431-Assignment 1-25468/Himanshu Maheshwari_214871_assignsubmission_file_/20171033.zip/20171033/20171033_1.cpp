#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define send_data_tag 2001
#define return_data_tag 2002

int main( int argc, char **argv ) {
    int rank, numprocs,n,start=1,end,avg,rem;
    string line;
    double val = 0.0000000000000,child_val=0.000000000000; 
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Status status;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    
    if(rank == 0)
    {
        ifstream MyFile(argv[1]);
        while(getline(MyFile,line))
        {
            n = atoi(line.c_str());
            // cout<<line<<endl;
        }
        MyFile.close();
        avg = n/numprocs;
        rem = n%numprocs;
        for(int i=1;i<numprocs;i++)
        {
            end = start + avg - 1;
            if(rem>0)
            {
                rem--;
                end++;
            }
            //send to child process, start and end
            MPI_Send(&start, 1 , MPI_INT, i, send_data_tag, MPI_COMM_WORLD);
            MPI_Send(&end, 1 , MPI_INT, i, send_data_tag, MPI_COMM_WORLD);

            start = end + 1;
        }
        val = 0.0;
        for(int i=start;i<=n;i++)
        {
            val += pow(double(i),-2.0);
        }

        // cout<<"Value by: "<<rank<<" is: "<<val<<endl;
        
        for(int i=1;i<numprocs;i++)
        {
            MPI_Recv( &child_val, 1, MPI_DOUBLE, MPI_ANY_SOURCE,return_data_tag, MPI_COMM_WORLD, &status);
            val += child_val;
            // cout<<"Value by: "<<i<<" is: "<<child_val<<endl;
        }
        ofstream MyFilew(argv[2]);
        MyFilew<<setprecision(7)<<val<<endl;
        // cout<<"Final Value: ";
        MyFile.close();
    }
    else
    {
        //get starting
        //get ending

        MPI_Recv( &start, 1, MPI_INT, 0,send_data_tag, MPI_COMM_WORLD, &status);
        MPI_Recv( &end, 1, MPI_INT, 0,send_data_tag, MPI_COMM_WORLD, &status);

        child_val = 0.0;
        for(int i=start;i<=end;i++)
        {
            child_val += pow(double(i),-2.0);
        }

        //send to parent process
        MPI_Send(&child_val, 1 , MPI_DOUBLE, 0, return_data_tag, MPI_COMM_WORLD);
        // cout<<"Value by: "<<rank<<" is: "<<child_val<<endl;
    }

    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}