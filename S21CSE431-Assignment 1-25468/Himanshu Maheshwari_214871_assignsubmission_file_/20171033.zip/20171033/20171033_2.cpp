#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

vector <ll> input;
vector <ll> my_buffer;

void insertion_sort(int low,int high)
{
	for(int i=low;i<=high;i++)
	{
		for(int j=i;j>low && (my_buffer[j] < my_buffer[j-1]);j--)
		{
			ll temp = my_buffer[j];
			my_buffer[j] = my_buffer[j-1]; 
			my_buffer[j-1] = temp;
		}
	}
}

int median(int low,int high)
{
	srand(time(NULL));
	
	int a = low + rand()%(high-low);
	int b = low + rand()%(high-low);
	int c = low + rand()%(high-low);
	int d = low + rand()%(high-low);
	int e = low + rand()%(high-low);
	int f = low + rand()%(high-low);

	if(my_buffer[a]>=my_buffer[b])
	{
		int ret = b;
		if(my_buffer[a]>my_buffer[c])
			ret = a;
		if(my_buffer[b]<my_buffer[c])
			ret = c;
		return ret;
	}
	else
	{
		int ret = a;
		if(my_buffer[b]<my_buffer[c])
			ret = b;
		if(my_buffer[a]<my_buffer[c])
			ret = c;
		return ret;
	}
}

void quicksort(ll low,ll high)
{

	if(low >= high)
	{
		return;
	}

	
	if((high-low) <= 20)
	{
		insertion_sort(low,high);
		return;
	}

	ll pivot,i,j,p,med;
	i = (low-1);

	med = median(low,high);
	pivot = my_buffer[high];
	my_buffer[high] = my_buffer[med];
	my_buffer[med] = pivot;
	pivot = my_buffer[high];
		

	for(j=low;j<high;j++)
	{
		if(my_buffer[j]<pivot)
		{
			i++;
			ll temp;
			temp = my_buffer[i];
			my_buffer[i] = my_buffer[j];
			my_buffer[j] = temp;
		}
	}

	ll temp;
	temp = my_buffer[i+1];
	my_buffer[i+1] = my_buffer[high];
	my_buffer[high] = temp;

	quicksort(low,i);
	quicksort(i+2,high);
}

vector <ll> merge(vector <ll> v1,vector <ll> v2,ll n1,ll n2)
{
	ll t=0,i=0,j=0,k=0;
	vector <ll> aux(n1+n2);
	
	while(i < n1 && j < n2)
	{
		if(v1[i] > v2[j])
		{
			aux[t++] = v2[j++];
		}
		else
		{
			aux[t++] = v1[i++];
		}
	}

	while(i>= n1 && j < n2)
	{
		aux[t++] = v2[j++];
	}

	while(j >= n2 && i<n1)
	{
		aux[t++] = v1[i++];
	}
	return aux;
}


int main(int argc, char ** argv)
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ll i,j,k,l,m,n;
    string input_filename = "",output_filename = "";

    if(rank == 0)
    {
       ifstream input_file(argv[1]);

       ll count=0;
       while(input_file >> k)
       {
       		if(count == 0)
       		{
       			count=1;
       			n=k;
       		}
       		else
       			input.push_back(k);
       }

       input_file.close();

    }


    
    MPI_Bcast(&n,1,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);

    if(n%numprocs != 0)
    	l = n/numprocs+1;
    else
    	l = n/numprocs;

	my_buffer.resize(l);


    MPI_Scatter(input.data(),l,MPI_LONG_LONG_INT,my_buffer.data(),l,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);
	ll N = input.size();    

    if(n < l*(rank+1))
    	m = (n-l*rank);
    else
    	m = l;
    
    if(m<0)
    	m=0;

    quicksort(0,m-1);

    
    MPI_Status st;

    for(ll step = 1;step < numprocs; step *= 2)
    {

    	if(rank % (2*step) == 0)
    	{
	    	ll check = rank+step; 
	    	if(check < numprocs)
	    	{
	    		if(l*(rank+2*step) <= n)
	    			j = l*step;
	    		else
	    			j = n - l*(rank+step);
	    		int temppp;
	    		if(j>0)
	    		{
		    		vector <ll> o(j);

		    		MPI_Recv(o.data(),j,MPI_LONG_LONG_INT,(rank+step),0,MPI_COMM_WORLD,&st);
		    		ll ttt = m;
		    		m += j;
		    		my_buffer = merge(my_buffer,o,ttt,j);
		    	}
	    	}
	    }
	    else
	    {
	    	MPI_Send(my_buffer.data(),m,MPI_LONG_LONG_INT,rank-step,0,MPI_COMM_WORLD);
	    	break;
	    }

    } 


    if(rank == 0)
    {
    	
		ofstream out_file;
		out_file.open(argv[2]);
		ll temp=0;
		for(ll i=0;i<my_buffer.size();i++)
		{
			temp++;
			out_file << my_buffer[i] << " ";
		}
		// cout<<temp<<endl;
		out_file << '\n';
		out_file.close();
    }



    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        cout << "Total time (s): " << maxTime << '\n';
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
