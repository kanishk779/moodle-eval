# Assignment 1

### Student
- Himanshu Maheshwari (20171033)

### Problem 1
- **Analysis**:
    - For N = 4
        - if np = 1 - Total time (s): 0.000240
        - if np = 11 - Total time (s): 0.000891
    - For N = 10000 (maximum):
        - if np = 1 - Total time (s): 0.000188
        - if np = 11 - Total time (s): 0.000398
    - The results are a bit suprising as I thought that by increasing number of processes, time will decrease. But I guess due to overhead of sending and recieving values, the time increased.

---

### Problem 2
- **Analysis**:
    - For N = 10 
        - if np = 1 - Total time (s): 0.000232
        - if np = 5 - Total time (s): 0.000310
        - if np = 11 - Total time (s): 0.00938
    - For N = 1000 
        - if np = 1 - Total time (s): 0.001130
        - if np = 5 - Total time (s): 0.001302
        - if np = 11 - Total time (s): 0.002698
    - For N = 100000
        - if np = 1 - Total time (s): 0.05596
        - if np = 5 - Total time (s): 0.05997
        - if np = 11 - Total time (s): 0.08965
    - The results are a bit suprising as I thought that by increasing number of processes, time will decrease. But I guess due to overhead of sending and recieving values, the time increased.

---

### Problem 3s
- **Analysis**:
    - For N = 5, M = 10
        - if np = 1 - Total time (s): 0.000296
        - if np = 5 - Total time (s): 0.002110
        - if np = 11 - Total time (s): 0.007829
    - For N = 80, M = 400 
        - if np = 1 - Total time (s): 0.003400
        - if np = 5 - Total time (s): 0.003032
        - if np = 11 - Total time (s): 0.01330
    - For N = 100, M = 500
        - if np = 1 - Total time (s): 0.007383
        - if np = 5 - Total time (s): 0.006637
        - if np = 11 - Total time (s): 0.012012
    - If nodes are less then there is a significant overhead of sending adjancency matrix and that increased time when we increased number of process. However once we increased the number of nodes and edges, the time first decreased till the number of process were 5 and then incearsed. I believe that due to large number of process, the overhead of sending matrices is more than the benifits of parallelization.
    
---

