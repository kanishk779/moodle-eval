#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

const int L = 5e2 + 5,M = 1e2 + 5;
int adj[L][L], value[L], color[L], adj_edge[M][M];

int main( int argc, char **argv ) 
{
    int rank, numprocs;

    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    fstream fin;
    fin.open(argv[1], ios::in);

    fstream fout;
    fout.open(argv[2], ios::out);

    int n = 0, m = 0, original_n, original_m, u, v,m_copy;
    if(rank == 0)
    {
        vector <pair <int, int> > edge;
        edge.push_back(make_pair(-1, -1));
        fin >> original_n >> original_m;

        for(int i = 0; i < original_m; i++)
        {
            fin >> u >> v;
            edge.push_back(make_pair(u, v));
            adj_edge[u][v] = 1;
            adj_edge[v][u] = 1;
        }

        n = original_m;
        m = 0;

        vector <int> weights;
        for(int i = 0; i < n; i++)
            weights.push_back(i+1);
        
        random_shuffle(weights.begin(),weights.end());
        for(int i = 1; i <= original_m; i++)
        {
            for(int j = i + 1; j <= original_m; j++)
            {
                int i_first = edge[i].first;
                int j_first = edge[j].first;
                int i_second = edge[i].second;
                int j_second = edge[j].second;

                if( i_first == j_first || i_first == j_second || i_second == j_first || i_second == j_second)
                {
                    adj[i][j]++;
                    m++;
                    adj[j][i]++;
                }
            }
        }

        for(int i = 1; i <= n; i++)
            value[i] = weights[i - 1];
        m_copy = m;
    }

    
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(adj, L * L, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(value, n + 1, MPI_INT, 0, MPI_COMM_WORLD);

    int each = n / numprocs,rem = n % numprocs;
    int sdf=0;
    int start = 1 + rank * each + min(rem, rank);
    int iter_cnt = 0;
    int end = start + each + (rank < rem ? 1 : 0) - 1;

    while(true)
    {

        int this_iter = 0,i;
        vector <pair <int, int> > ind_set;
        iter_cnt++;

        for(i = start; i <= end; i++)
        {
            set <int> s;
            bool greatest = true;
            
            if(color[i])
            {
                continue;
            }

            for(int j = 0; j < n; j++)
            {
                s.insert(j+1);
                if(!color[j+1] && adj[i][j+1]  && value[i] < value[j+1] )
                {
                    greatest = false;
                    break;
                }
            }

            if(!greatest)
                s.clear();
            else
            {
                this_iter++;

                for(int j = 0; j < n; j++)
                {
                    if(color[j+1] && adj[i][j+1])
                    {
                        s.erase(color[j+1]);
                    }
                }

                int cur_color = *(s.begin());
                s.clear();
                color[i] = cur_color;
                ind_set.push_back(make_pair(i, cur_color));
            }

        }

        int toColor[this_iter][2],toColor_copy[L][2],this_iter_copy = this_iter;

        for(i = 0; i < this_iter; i++)
        {
            int f =  ind_set[i].first, s=ind_set[i].second;
            toColor[i][0] = f;
            toColor[i][1] = s;
            toColor_copy[i][0] = f;
            toColor_copy[i][1] = s;
        }

        ind_set.clear();

        for(i = 0; i < numprocs; i++)
        {
            int tempp = 0;
            MPI_Bcast(&this_iter_copy, 1, MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(toColor_copy, this_iter_copy * 2, MPI_INT, i, MPI_COMM_WORLD);

            if(rank == i)
            {}
            else
            {
                for(int j = 0; j < this_iter_copy; j++)
                {
                    tempp+=1;
                    color[toColor_copy[j][0]] = toColor_copy[j][1];
                }
                // cout<<temp;
            }

            this_iter_copy = this_iter;
            tempp=0;
            for(int ii = 0; ii < L; ii++)
            {
                int f = toColor[ii][0],s = toColor[ii][1]; 
                toColor_copy[ii][0] = f;
                toColor_copy[ii][1] = s;
            }
        }

        bool finish = false;

        if(rank == 0)
        {
            int already_colored = 0;
            for(int i = 1; i <= n; i++)
            {
                if(!color[i])
                    break;
                already_colored++;
            }
            if(already_colored == n)
            {
                finish = true;
            }
        }

        MPI_Bcast(&finish, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);

        if(finish)
        {
            break;
        }
    }

    if(rank == 0)
    {
        set <int> unique_colors;

        for(int i = 1; i <= n; i++)
        {
            unique_colors.insert(color[i]);
        }

        fout << unique_colors.size() << '\n';
        for(int i = 1; i <= n; i++)
        {
            fout << color[i] << " ";
        }
        fout << '\n';
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}