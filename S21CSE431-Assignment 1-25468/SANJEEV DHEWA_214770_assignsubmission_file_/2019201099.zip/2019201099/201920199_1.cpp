// mpi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
# include <cstdlib>
# include <ctime>
# include <iomanip>
# include <iostream>
# include <mpi.h>
#include <fstream> 
#include <string>


using namespace std;


int main(int argc, char **argv)
{

	string filepath = argv[1];
	ifstream fin;
	fin.open(filepath);
	string line;
	getline(fin, line);
	fin.close();
	
	int n = stoi(line);
	MPI_Status status;

	int rank, size;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);


	MPI_Barrier(MPI_COMM_WORLD);
	double tbeg = MPI_Wtime();


	double ans = 0;
	int start_value = 1 + ((n - 1) / size);
	int i = 0;
	while(i< start_value){
		int calc_num = rank * start_value + i;
		++calc_num;
		if (calc_num > n)
			break;
		int square = calc_num * calc_num;
		double value = (double)(double(1) / double(square));
		ans += value;
		++i;
	}


	if (rank == 0){
		int j = 1;
		while (j < size) {
			double res = 0;
			MPI_Recv(&res, 1, MPI_DOUBLE, j, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
			ans += res;
			++j;
		}

		ofstream fout;
		fout.open(argv[2]);
		fout << fixed << setprecision(6) << ans << endl;
		fout.close();
	}
	else{
		MPI_Send(&ans, 1, MPI_DOUBLE, 0, 123, MPI_COMM_WORLD);
	}


	MPI_Barrier(MPI_COMM_WORLD);

	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
	if (rank == 0) {
		printf("Total time (s): %f\n", maxTime);
	}
	MPI_Finalize();
	return 0;
}

