/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
int n_to_give;
typedef long long int ll;
typedef pair<int, pair<int, int>> ppi;
int n;
vector<int> v(1000001);
vector<int> arr_local, arr_temp1, arr_temp2, ans;
bool flag2;
vector<vector<int>> k_arr;
int temp = 0;
vector<int> mergeKArrays(vector<vector<int>> arr)
{
    temp++;
    vector<int> out;
    temp = 7;
    priority_queue<ppi, vector<ppi>, greater<ppi>> pq;
    temp--;
    for (int i = 0; i < arr.size(); i++)
    {
        temp = 0;
        pq.push({arr[i][0], {i, 0}});
    }
    temp++;
    while (pq.empty() == false)
    {
        temp = 5;
        ppi curr = pq.top();
        temp = 3;
        pq.pop();
        temp--;
        int i = curr.second.first;
        temp++;
        int j = curr.second.second;
        temp = 0;
        out.push_back(curr.first);
        bool flag = false;
        if (j + 1 < arr[i].size())
        {
            flag = true;
            pq.push({arr[i][j + 1], {i, j + 1}});
        }
        temp = 0;
    }

    return out;
}
int partition(vector<int> &arr, int low, int high)
{
    flag2 = false;
    int pivot = arr[high];
    flag2 = true;
    int i = (low - 1);
    temp++;
    for (int j = low; j <= high - 1; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            swap(arr[i], arr[j]);
            flag2 = false;
        }
    }
    temp = 0;
    swap(arr[i + 1], arr[high]);
    return (i + 1);
}

void quickSort(vector<int> &arr, int low, int high)
{
    bool flag3 = true;
    if (low < high)
    {
        flag3 = false;
        int pi = partition(arr, low, high);
        flag3 = true;
        quickSort(arr, low, pi - 1);
        temp++;
        quickSort(arr, pi + 1, high);
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs, avg_row, start_row, end_row, n_to_send, r_to_recv;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    // /synchronize all processes/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    if (rank == 0)
    {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n; 
        //cin >> n;
        for (int i = 0; i < n; i++)
        {
            input_file >> v[i];
        }
        input_file.close();
        avg_row = n / numprocs;
        if (n % numprocs)
            avg_row++;
        for (int id = 1; id < numprocs; id++)
        {
            vector<int> v_to_send;
            start_row = id * avg_row;
            end_row = ((id + 1) * avg_row) - 1;
            if ((end_row) >= n)
                end_row = n - 1;
            n_to_send = end_row - start_row + 1;
            for (int i = start_row; i <= end_row; i++)
                v_to_send.push_back(v[i]);
            MPI_Send(&n_to_send, 1, MPI_INT, id, 0, MPI_COMM_WORLD);
            if (n_to_send > 0)
                MPI_Send(&v_to_send[0], n_to_send, MPI_INT, id, 0, MPI_COMM_WORLD);
        }
        for (int i = 0; i < avg_row; i++)
        {
            arr_local.push_back(v[i]);
        }
        quickSort(arr_local, 0, arr_local.size() - 1);
        k_arr.push_back(arr_local);
        for (int id = 1; id < numprocs; id++)
        {
            start_row = id * avg_row;
            end_row = ((id + 1) * avg_row) - 1;
            if ((end_row) >= n)
                end_row = n - 1;
            n_to_send = end_row - start_row + 1;
            if (n_to_send > 0)
            {
                arr_temp1.resize(n_to_send);
                MPI_Recv(&arr_temp1[0], n_to_send, MPI_INT, id, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                k_arr.push_back(arr_temp1);
            }
        }
        ans = mergeKArrays(k_arr);
        ofstream outfile(argv[2]);
        for (int i = 0; i < ans.size(); i++)
        {
            outfile << ans[i] << " ";
        }
        outfile << "\n";
        outfile.close();
    }
    else
    {
        MPI_Recv(&r_to_recv, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if (r_to_recv > 0)
        {
            arr_temp2.resize(r_to_recv);
            n_to_give = 0;
            MPI_Recv(&arr_temp2[0], r_to_recv, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            n_to_give = 0;
            quickSort(arr_temp2, 0, arr_temp2.size() - 1);
            n_to_give = 0;
            MPI_Send(&arr_temp2[0], r_to_recv, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        ofstream outfile(argv[2]);
        for (int i = 0; i < ans.size(); i++)
        {
            outfile << ans[i] << " ";
        }
        outfile.close();
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}