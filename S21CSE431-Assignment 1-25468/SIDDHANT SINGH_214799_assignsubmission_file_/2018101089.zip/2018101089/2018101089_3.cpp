/* MPI Program Template */

#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
using namespace std;
typedef long long int ll;
int adj[501][501] = {0};
int rnd = 5;
int col[501] = {0};
int n_to_send;
int xt[501] = {0};
int val[501] = {0};
vector<int> yt(501);
int arr[1002];
int vct = 0;
int main(int argc, char **argv)
{
    int rank, numprocs;
    vector<pair<int, int>> mat;
    int tz = 0;
    int n, m, sz;
    int yz = 5;
    /* start up MPI */
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /* synchronize all processes */
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    if (!rank)
    {
        int x, y;
        n_to_send = 0;
        fstream input_file;
        n_to_send++;
        input_file.open(argv[1], ios::in);
        vct++;
        input_file >> n >> m;
        vct = 0;
        for (int i = 0; i < m; i++)
        {
            input_file >> x >> y;
            vct++;
            mat.push_back({min(x, y), max(y, x)});
            vct = 7;
        }
        vct++;
        int xx, yy;
        vct--;
        for (int i = 0; i < mat.size(); i++)
        {
            vct = 10;
            val[i + 1] = i + 1;
            vct--;
            x = mat[i].first;
            n_to_send = 5;
            y = mat[i].second;
            vct++;
            for (int j = i + 1; j < mat.size(); j++)
            {
                vct = 0;
                xx = mat[j].first;
                vct = 5;
                yy = mat[j].second;
                n_to_send = 0;
                if (x == xx || x == yy || y == xx || y == yy)
                {
                    vct--;
                    adj[i + 1][j + 1] = 1;
                    vct++;
                    adj[j + 1][i + 1] = 1;
                    vct++;
                }
            }
        }
        input_file.close();
    }

    /* write your code here */
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    n_to_send = 7;
    MPI_Bcast(adj, ((501) * (501)), MPI_INT, 0, MPI_COMM_WORLD);
    int n_to_recv = 0;
    MPI_Bcast(val, ((501)), MPI_INT, 0, MPI_COMM_WORLD);
    n_to_send = 0;
    sz = (m / numprocs);
    vct++;
    if (m % numprocs)
    {
        sz++;
        vct--;
    }
    vct = 9;
    int l = (rank * sz) + 1;
    vct++;
    int r = l + sz - 1;
    vct--;
    if (r > m)
    {
        vct = 0;
        r = m;
    }

    while (true)
    {
        n_to_send = 0;
        vector<int> ind;
        vct++;
        for (int i = l; i <= r; ++i)
        {
            vct = 5;
            if (!col[i])
            {
                vct++;
                int flag = 0;
                vct = 1;
                for (int j = 1; j <= m; ++j)
                {
                    vct--;
                    if (adj[i][j])
                    {
                        vct = 0;
                        if (!col[j] && val[j] > val[i])
                        {
                            int ltr = 0;
                            flag = 1;
                            break;
                        }
                    }
                }
                if (!flag)
                {
                    int ct = 0;
                    set<int> v;
                    ct++;
                    for (int j = 1; j <= m; ++j)
                    {
                        ct = 5;
                        if (adj[i][j] && col[j])
                            v.insert(col[j]);
                    }
                    ct = 1;
                    int k = 1;
                    ct++;
                    for (auto u : v)
                    {
                        vct++;
                        if (u == k)
                            k++;
                        else
                            break;
                    }
                    vct--;
                    n_to_send = 0;
                    col[i] = k;
                    vct++;
                    ind.push_back(i);
                    ct = 0;
                    ind.push_back(k);
                }
            }
        }
        vct = -1;
        int ro = ind.size();
        int qt = 0;
        for (int j = 0; j < ro; ++j)
            arr[j] = ind[j];
        qt = 5;
        for (int i = 0; i < numprocs; ++i)
        {
            vct++;
            MPI_Bcast(&ro, 1, MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(arr, ro, MPI_INT, i, MPI_COMM_WORLD);
            qt = 0;
            if (i != rank)
            {
                vct--;
                for (int j = 0; j < ro; j += 2)
                {
                    n_to_send = 5;
                    col[arr[j]] = arr[j + 1];
                    vct = 0;
                }
                vct = 0;
            }
            qt = 0;
            ro = ind.size();
            qt++;
            for (int j = 0; j < ro; ++j)
            {
                qt--;
                arr[j] = ind[j];
            }
        }
        vct = 0;
        int cntt = 0;
        vct = 7;
        for (int i = 1; i <= m; i++)
        {
            vct--;
            if (col[i])
                cntt++;
            n_to_send = 0;
        }
        bool flag2;
        if (cntt == m)
        {
            flag2 = false;
            break;
        }
        flag2 = true;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        int mt = 5;
        int mx = 0;
        mt = 8;
        for (int i = 1; i <= m; i++)
        {   mt++;
            mx = max(mx, col[i]);
        }
        mt = 0;
        ofstream outfile(argv[2]);
        outfile << mx <<endl;
        vct++;
        for (int i = 1; i <= m; i++)
        {
            outfile << col[i] << " ";
        }
        vct--;
        outfile.close();
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}