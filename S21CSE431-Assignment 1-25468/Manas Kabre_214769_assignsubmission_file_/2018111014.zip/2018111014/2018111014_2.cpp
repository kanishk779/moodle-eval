/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    if (rank == 0)
    {
        // This is your master process, do the calc and all here
        // //printf("%s", argv[4]);
        ifstream InFile(argv[1]);
        ofstream OutFile(argv[2]);
        int N; //This is going to be from the input file
        InFile >> N;
        // //printf("%s",argv[1]);
        // //printf("Value fo N %d",N);
        int arr[N];
        for(int i = 0; i< N;i++)
        {
            InFile >> arr[i];
        }
        InFile.close();
        int buffer_sent = N;
        //printf("input taken %d\n", N);
        for(int i = 0; i<N;i++)
        {
            //printf("%d ", arr[i]);
        }
        // int t = N;
        // for (int i = 0; i < N; i++)
        // {
        //     arr[i] = t--;
        // }
        // for(int i = 0; i<N;i++)
        // {
        //     //printf("%d ",arr[i]);
        // }
        // //printf("\n");
        // //printf("MPI process %d sends value %d.\n", my_rank, buffer_sent);
        // double ans = 0.0;
        queue<int> fin[numprocs];
        vector<int> finarr;
        if (N <= numprocs)
        {
            sort(arr, arr + N);
            for (int i = 0; i < N; i++)
            {
                finarr.push_back(arr[i]);
            }
        }
        else
        {
            int num = numprocs;
            // if (N % num != 0)
            // {
            //     num--;
            // }
            for (int i = 1; i < numprocs; i++)
                MPI_Send(&buffer_sent, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            //printf("N value sent successfulyy\n");
            for (int i = 1; i < numprocs; i++)
            {
                int size = N/num;
                if(i == numprocs -1)
                    size += N%num;
                MPI_Send(&arr[i * (N / num)], size , MPI_INT, i, 1, MPI_COMM_WORLD);
                //printf("sent array to process %d\n", i);
            }
            int newarr[N / num];
            for (int i = 0; i < (N / num); i++)
            {
                newarr[i] = arr[rank * (N / num) + i];
            }
            sort(newarr, newarr + (N / num));
            for (int j = 0; j < N / num; j++)
            {
                fin[0].push(newarr[j]);
            }
            for (int i = 1; i < numprocs; i++)
            {
                int size = N / num;
                if(i == numprocs -1)
                    size += N%num;
                int temp[size];
                MPI_Recv(&temp, size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                // //printf("Recieved N value by 0 : %d\n", i);

                for (int j = 0; j < size; j++)
                {
                    fin[i].push(temp[j]);
                }
            }
            // Merging operation using heap
            // We have numproc number of sorted arrays in array of queue fin;
            priority_queue<pair<int, int>> pq;
            // //printf("Created heap\n");
            // pushing first element of every sorted array we have;
            for (int i = 0; i < numprocs; i++)
            {
                pq.push({-1 * fin[i].front(), i}); //multiplying by -1 coz we need min heap;
                fin[i].pop();
            }
            while (!pq.empty())
            {
                pair<int, int> p = pq.top();
                pq.pop();
                finarr.push_back(-1 * p.first);
                if (!fin[p.second].empty())
                {
                    pq.push({-1 * fin[p.second].front(), p.second});
                    fin[p.second].pop();
                }
            }
        }
        for (auto i : finarr)
            OutFile << i<<" ";
        OutFile.close();
        //printf("\n");
    }
    else
    {
        int N;
        MPI_Recv(&N, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // //printf("Recieved N value : %d\n", rank);
        // int num = numprocs;
        // if (N % num != 0)
        // {
        //     num--;
        // }
        int size = N / numprocs;
        if(rank == numprocs -1)
            size += N%numprocs;
        int newarr[size];
        MPI_Recv(&newarr, size, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        //printf("Recieved array: %d\n", rank);
        // for(int i = 0; i<size;i++)
        // {
        //     //printf("%d ",newarr[i]);
        // }
        // //printf("\n");
        sort(newarr, newarr + size);
        MPI_Send(&newarr, size, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}