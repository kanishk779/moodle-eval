## README

#### Q1 
* The code divides the vaule N into the number of processes. By using send and recieve it sends the value of N to all the process and by using the formula rank*(N/numprocs) , (rank+1)*(N/numprocs) and handling the corner cases each process calculates the required values

#### Q2
* The array is divided in to numprocs chunks and each process recieves a chunk of the array. Each process quick sorts the array and then send its back to process 0. In process 0 each of the chunks is merged by maintaining a min heap whoes size never increaes the value of numprocs

#### Q3
* The problem of edge colouring is converted to vertex colouring
* The line graph of the given graph is made. Now the problem is of vertex colouring this graph
* By the given constraint we can use delt(LG) +1 colours.
* The algorithm used makes sure that the we use no more than the constraint number of colours to colour the vertices of the graph.
* The algorithm used has reference from here : https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/

* The nodes of the LG are split among the processes to calculate the given value. The the adjacency matrix of the graph is broadcasted to all the processes. With the help of broadcast, every change done in the colour array, which maintains the colour of the vertices is updated in each process by the use of broadcast. Each process follows the algo where it choses a set of independent vertices(where no two vertices in the set are connected ). For each of these vertices it checks all its neighbours and chooses the least colour which is not yet used in the vertices and assigns the edge this colour. Hence we can prove that max of delta(LG) + 1 colours will be used as a vertex can at max have delta(LG) neighbours. This is repeated again till all the edges are coloured. After each iteration in a process they broadcast their information therby all processes remain consistent. The method to choose the independent vertices is by giving random values to the vertices initially and choosing all those vertices which have their value greater than all its neighbours.

