/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    int n, m;

    int New_n, New_m;
    int adj_mat[502][502];
    int color[502];
    int value[502];
    int tresh;
    // int update[501][2];
    int k;
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    ofstream OutFile(argv[2]);
    if (rank == 0)
    {
        set<int> check;
        ifstream InFile(argv[1]);
        int N, M; //This is going to be from the input file
        InFile >> N >> M;
        int temp_mat[N + 1][N + 1];
        for (int i = 1; i <= N; i++)
        {
            for (int j = 1; j <= N; j++)
            {
                temp_mat[i][j] = 0;
                // adj_mat[i][j]
            }
        }
        map<pair<int, int>, int> mp;
        for (int i = 1; i <= M; i++)
        {
            int p, q;
            // scanf("%d%d", &p, &q);
            InFile >> p >> q;
            //printf("%d %d \n", p, q);
            mp[{p, q}] = i;
            mp[{q, p}] = i;
            temp_mat[p][q] = 1;
            temp_mat[q][p] = 1;
        }
        for (int i = 1; i <= M; i++)
        {
            for (int j = 1; j <= M; j++)
            {
                adj_mat[i][j] = 0;
                // adj_mat[i][j]
            }
        }
        for (auto i : mp)
        {
            int p = i.second;
            for (int k = 1; k <= N; k++)
            {
                if (temp_mat[i.first.first][k] == 1)
                {
                    int q = mp[{i.first.first, k}];
                    if (p != q)
                    {

                        adj_mat[p][q] = 1;
                        adj_mat[q][p] = 1;
                    }
                }
                if (temp_mat[i.first.second][k] == 1)
                {
                    int q = mp[{i.first.second, k}];
                    if (p != q)
                    {

                        adj_mat[p][q] = 1;
                        adj_mat[q][p] = 1;
                    }
                }
            }
        }
        n = M;
        m = 1;
        for(int i = 1; i<=N;i++)
        {
            for(int j = 1; j<=N;j++)
            {
                //printf("%d ", temp_mat[i][j]);
            }
            //printf("\n");
        }
        //printf("--------------------------------------\n");
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                //printf("%d ", adj_mat[i][j]);
            }
            //printf("\n");
        }
        // scanf("%d%d", &n, &m);
        for (int i = 1; i <= n; i++)
        {
            color[i] = -1;
            srand(i);
            int ran = rand() % 1000;
            // //printf("%d")
            while (check.find(ran) != check.end())
            {
                ran = rand();
            }
            value[i] = ran;
            check.insert(ran);
        }

        tresh = n / numprocs;
        //taking input of line graph, will see how to cpnvert later
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    // MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&tresh, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&adj_mat, sizeof(adj_mat) / sizeof(int), MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&color, sizeof(color) / sizeof(int), MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&value, sizeof(value) / sizeof(int), MPI_INT, 0, MPI_COMM_WORLD);

    //printf("%d Broadcast sucessful \n", rank);
    // if (rank == 2)
    // {

    //     for (int i = 1; i <= n; i++)
    //     {
    //         for (int j = 1; j <= n; j++)
    //         {
    //             //printf("%d ", adj_mat[i][j]);
    //         }
    //         //printf("\n");
    //     }
    //     //printf("Values\n");
    //     for (int i = 1; i <= n; i++)
    //     {
    //         //printf("%d ", value[i]);
    //     }
    //     //printf("\n");
    // }

    while (1)
    {
        //printf("Values\n");
        //printf("\n");
        //printf("Entering while\n");

        int start = rank * tresh + 1;
        // if(start > n)
        // {

        // }
        int end = (rank + 1) * tresh;
        if (rank == numprocs - 1)
            end += n % numprocs;
        //printf("\n\nrank %d %d %d \n", rank, start, end);
        int kdash = 0;
        vector<pair<int, int>> v;
        for (int i = start; i <= end; i++)
        {
            if (color[i] == -1)
            {
                int flag = 0;
                for (int j = 1; j <= n; j++)
                {
                    if (adj_mat[i][j] == 1 && color[j] == -1)
                    {
                        if (value[j] > value[i])
                        {
                            flag = 1;
                            break;
                        }
                    }
                }
                if (flag == 0)
                {
                    priority_queue<int> pq;
                    set<int> s;
                    for (int j = 1; j <= n; j++)
                    {
                        if (adj_mat[i][j] == 1 && color[j] != -1 && s.find(color[j]) == s.end())
                        {
                            pq.push(-1 * color[j]);
                            s.insert(color[j]);
                        }
                    }
                    int c = 1;
                    while (!pq.empty() && -1 * pq.top() == c)
                    {
                        c++;
                        pq.pop();
                    }
                    // color[i] = c;
                    v.push_back({i, c});
                }
            }
        }

        int arr[502];
        int crr[502];
        // arr = (int *)malloc(v.size() * sizeof(int));
        // crr = (int *)malloc(v.size() * sizeof(int));

        for (int j = 0; j < v.size(); j++)
        {
            arr[j] = v[j].first;
            crr[j] = v[j].second;
        }
        int send_k = v.size();
        // int copy_send_k
        //printf("%d rank before doing the second broadcast\n", rank);
        for (int i = 0; i < numprocs; i++)
        {
            //printf("rank is %d send_k %d\n", rank, send_k);
            MPI_Bcast(&send_k, 1, MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(arr, send_k, MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(crr, send_k, MPI_INT, i, MPI_COMM_WORLD);
            //printf("%d rank and i = %d send_k %d after doing the second broadcast\n", rank, i, send_k);
            for (int i = 0; i < send_k; i++)
            {
                //printf("Colours sent with node num %d %d \n", arr[i], crr[i]);
            }
            // for(int i = 0; i)

            for (int j = 0; j < send_k; j++)
            {
                color[arr[j]] = crr[j];
            }

            send_k = v.size();
            for (int j = 0; j < v.size(); j++)
            {
                arr[j] = v[j].first;
                crr[j] = v[j].second;
            }
        }
        //printf("rank %d iteration success \n", rank);
        // I think its done here, color assign kar diya and broadcast karke sab update ho gaya hai
        // Write the termination condition late, and then i think we're done !!!!s
        int terminate = 1;
        for (int i = 1; i <= n; i++)
        {
            if (color[i] == -1)
            {
                //printf("This is still not coloured %d \n", i);
                terminate = 0;
                // break;
            }
        }
        if (terminate)
            break;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        set<int> s;
        for(int i = 1; i<=n;i++)
        {
            s.insert(color[i]);
        }
        OutFile<<s.size()<<endl;
        for (int i = 1; i <= n; i++)
        {
            OutFile << color[i]<<" ";
        }
        //printf("\n");
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}