/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    if (rank == 0)
    {
        // This is your master process, do the calc and all here
        int N ; //This is going to be from the input file
        ifstream InFile(argv[1]);
        ofstream OutFile(argv[2]);
        // int N; //This is going to be from the input file
        InFile >> N;
        InFile.close();
        int buffer_sent = N;
        // printf("MPI process %d sends value %d.\n", my_rank, buffer_sent);
        double ans = 0.0;
        if (N <= numprocs)
        {
            for (int i = 1; i <= N; i++)
            {
                ans += ((double)1) / ((double)i * i);
            }
        }
        else
        {
            int num = numprocs;
            if (N % num != 0)
            {
                num--;
            }
            for (int i = rank * (N / num) + 1; i <= (rank + 1) * (N / num); i++)
            {
                ans += ((double)1) / ((double)i * i);
            }
            for (int i = 1; i < numprocs; i++)
                MPI_Send(&buffer_sent, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            // divided it with the formula - N/num*rank +1 , N/num *(rank+1)

            for (int i = 1; i < numprocs; i++)
            {
                double temp;
                MPI_Recv(&temp, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                ans += temp;
            }
        }
        OutFile << fixed << setprecision(6) << ans;
        OutFile.close();
    }
    else
    {
        int N;
        MPI_Recv(&N, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double ans = 0.0;
        int num = numprocs;
        if (N % num != 0)
        {
            num--;
        }
        for (int i = rank * (N / num) + 1; i <= min(N, (rank + 1) * (N / num)); i++)
        {
            ans += ((double)1) / ((double)i * i);
        }
        MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}