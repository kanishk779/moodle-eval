Q1.  
	n=input
	cp= number of child processes
	mod=n%cp
	part= ceil(n/cp)

    we divide the no. of elements into chunks such that, mod number of processes get chunks of size part and the rest get chunks of size part-1.
    In the root process we send the 2 different type of chunk sizes in 2 different for loops using MPI_send(in the form of starting and ending index of the range), the child process receives this using MPI_receive and computes the sum of inverse of squares of the received range. The root process receives the sum calculated by each process p_i in su[i]. We then sum all the elements of array su, to get the final answer.


Q2.
   Using the same split as in Q1, we also send which process has to receive what size of chunks as this time we send the entire elements in the chunk to child process, not just the starting and ending indices. The sorted chunks get returned to the parent process.