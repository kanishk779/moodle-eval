/* MPI Program Template */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n;
    int part;
    int mo;
    //printf("Enter input: ");
    ifstream in(argv[1]);
    ofstream out(argv[2]);
        in>>n;

    // printf("n=%d\n",n );

    if(rank==0)
    {
		float sum=0;

    	if(numprocs==1)
    	{
    		for (int i = 1; i < n+1; ++i)
    		{
    		sum+=float(float(1)/float((i*i)));

    		}
    		// printf("hell sum=%f, rank=%d\n",sum , rank );

    	}
    	else
    	{
    		// printf("entered first else loop for parent process which is for than 1 total processes\n");
	    	mo=n%(numprocs-1);
	    	int arr[2];
	    	float su[numprocs-1];

	    	/*

	    	for (int i = 0; i < numprocs-1; ++i)
			{
				cout<<"initial sum array with random values for each process,su = "<<su[i]<<" ";
			}
			cout<<"\n";

			*/

    		part= (n / (numprocs-1)) + ((n % (numprocs-1)) != 0);

    		// printf("just before for loop, partition size is %d \n",part);

	    	for ( int i = 0; i < mo; ++i)
	    	{
	    	  // arr=[i*part+1,(i+1)*part];
	    	  // printf("iteration i = %d \n",i);
	    	  arr[0]= i*part+1;
	    	  arr[1]= (i+1)*part;
	    	  // printf("partition for ith process, i=%d is left %d and right %d \n",i,arr[0],arr[1]);
	   		  MPI_Send(arr,2,MPI_INT,i+1,0,MPI_COMM_WORLD);
	   		  
			}

			if(mo==0)
			{
				part = part+1;
			}

			for (int i = 0; i < numprocs-1-mo  ; ++i)
			{
				// printf("iteration i = %d \n",i);
				// arr=[mo*part+i*(part-1)+1,(i+1)*(part-1)+mo*part];

				arr[0]=mo*part+i*(part-1)+1;
				arr[1]=(i+1)*(part-1)+mo*part;
				// printf("partition for ith process, i=%d is left %d and right %d \n",i,arr[0],arr[1]);
	   		MPI_Send(arr,2,MPI_INT,i+1+mo,0,MPI_COMM_WORLD);


			}

			for ( int i = 0; i < mo; ++i)
	    	{
	   		MPI_Recv(&su[i],1,MPI_FLOAT,i+1,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			}

			for (int i = 0; i < numprocs-1-mo  ; ++i)
			{
	   		MPI_Recv(&su[i+mo],1,MPI_FLOAT,i+1+mo,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			}

			for (int i = 0; i <sizeof(su)/sizeof(su[0]) ; ++i)
			{
				sum+=su[i];

			}
			// printf("heee\n");

			// for (int i = 0; i < numprocs-1; ++i)
			// {
			// 	cout<<"ith element of sum array "<<su[i]<<" ";
			// }

			// cout<<"number of child processes\n"<<numprocs-1 <<"\n";
		}

		out<<fixed<<	setprecision(6)<<sum<<"\n";

    }

    else
    {
    	// printf("entered child process with rank %d \n", rank);
		int rec[2];
		float sum=0;
   		MPI_Recv(&rec,2,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);

   		if(rec[0]<=rec[1])
   		{
   			for (int i = rec[0]; i < rec[1]+1; ++i)
   			{
				sum+=float(float(1)/float((i*i)));
				// printf("sum is %f \n",sum);
   			}	
   			// printf("rec=%d %d and rank is %d \n",rec[0],rec[1],rank );

    	}
    	else
    	{
			// printf("else loop of child process\n");
			// printf("rec=%d %d\n",rec[0],rec[1] );
			sum=0;
    	}

   		MPI_Send(&sum,1,MPI_FLOAT,0,0,MPI_COMM_WORLD);

    }


    // code ends here

    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    // if ( rank == 0 ) 
    // {
        // printf( "Total time (s): %f\n", maxTime );
    // }

    

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}