#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>

#include <math.h>
#include <string.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


int partition (int arr[],int lo, int hi) 
{ 
    int pivotInd = rand()%(hi - lo+1) + lo;
     int tem=arr[pivotInd];
     arr[pivotInd]=arr[hi];
     arr[hi]=tem;
    int pivot = arr[hi];     
    int i = (lo - 1);   

    for (int i1 = lo; i1 <= hi- 1; i1++) 
    { 
        if (arr[i1] < pivot) 
        { 
            i++;    
            int temp = arr[i];
            arr[i]=arr[i1];
            arr[i1]=temp;
        } 
    } 
    int temp = arr[i+1];
    arr[i+1]=arr[hi];
    arr[hi]=temp;
    return (i + 1); 
} 

void norm_quickSort(int arr[],int lo, int hi) 
{ 
    if (lo < hi) 
    { 

        int pi = partition(arr, lo, hi); 
        norm_quickSort(arr, lo, pi - 1); 
        norm_quickSort( arr,pi + 1, hi); 
    } 
} 





int main(int argc, char* argv[])
{

  


    MPI_Init(&argc, &argv); 
    int numprocs, rank;
    srand(time(NULL));
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    enum role_ranks { SENDER, RECEIVER }; 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();





    if(rank == 0) 
    {
        // read the input
        int sizeofarray;
        int div;
        int mod;
        int len;
         ifstream in(argv[1]);
        ofstream out(argv[2]);
        in >> sizeofarray;
        int bufferUnsorted[sizeofarray];
        
        for (int i = 0; i < sizeofarray; ++i)
        {
            in >> bufferUnsorted[i];
        }
        int bufferSorted[sizeofarray];

        // only parent process

        if(numprocs==1)
        {
             // printf("procees==1\n");
            norm_quickSort(bufferUnsorted,0,sizeofarray-1);
            for (int i = 0; i < sizeofarray; ++i)
            {
                out << bufferUnsorted[i];
            }
            
        }
        //if child processes also there

        else
        {
            mod = sizeofarray%(numprocs-1);
            div =  (sizeofarray / (numprocs-1)) + ((sizeofarray % (numprocs-1)) != 0);
            
            //send array


            len=div;
            // printf("more than one process len=%d\n",len);

            for(int i=0;i<mod;i++)
                MPI_Send(&len,1,MPI_INT,i+1,0,MPI_COMM_WORLD);

            if(mod==0)
            {
                div = div+1;
            }
            len=div-1;
            // printf("more than one process len2=%d\n",len);

            for(int i=0;i<numprocs-1-mod;i++)
                MPI_Send(&len,1,MPI_INT,i+1+mod,0,MPI_COMM_WORLD);



            for(int i=0;i<mod;i++)
                MPI_Send(bufferUnsorted+div*i,div,MPI_INT,i+1,0,MPI_COMM_WORLD);

            


            for(int i=0;i<numprocs-1-mod;i++)
                MPI_Send(bufferUnsorted + mod*div + (div-1)*i,div-1,MPI_INT,i+1+mod,0,MPI_COMM_WORLD);

            //receive array

            for(int i=0;i<mod;i++)
                MPI_Recv(bufferSorted+div*i, div, MPI_INT, i+1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            for(int i=0;i<numprocs-1-mod;i++)
                MPI_Recv(bufferSorted + mod*div + (div-1)*i, div-1, MPI_INT, i+1+mod, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            // for(int i=1;i<3;i++)
            //     MPI_Recv(bufferSorted + mod*div + div*(i-1), 5, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);


            for(int i=0;i<sizeofarray;i++)
                    out<<bufferSorted[i]<<" ";

        }

                    

    }



    else 
    {

        // printf("entered child process\n");
        int le;
        MPI_Recv(&le, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // printf("entered child process, received once len=%d rank=%d\n",le,rank);

        int received[le];
        MPI_Recv(received, le, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // printf("entered child process, received twice received=%d\n",received[0]);

        norm_quickSort(received,0,le-1);
        MPI_Send(received, le, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    //code end

     MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    // if ( rank == 0 ) 
    // {
    //     printf( "Total time (s): %f\n", maxTime );
    // }

         
    MPI_Finalize(); 
    return EXIT_SUCCESS;
}

