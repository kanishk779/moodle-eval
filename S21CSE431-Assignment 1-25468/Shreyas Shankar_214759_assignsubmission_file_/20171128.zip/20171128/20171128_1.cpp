#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iomanip>
#include<queue>
#include<vector>
#include<algorithm>
#include<iostream>
#include<utility>
#include <cmath>
#include <math.h> 
#include <cstring> 
#include <sstream>

using namespace std;
typedef long long int ll;

#define For(i,begin,end) for(int i=(begin);i<(end);i++)

int str_to_int(string s_num) {
	int n = 0;
	for(int i = 0; i < s_num.size(); i++) {
		n = n*10 + (s_num[i]-'0');
	}
	return n;
}

int main( int argc, char **argv ) {
	int rank, numprocs;

	/* start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	
	/* synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

	/* write your code here */

	MPI_Status status;
	int sender;

	int n;
	int increment, rem;
	int start_n, end_n = 0;
	long double sum, child_sum;

	if(rank == 0) {
		ifstream inp_file(argv[1]);
		string num; 
		inp_file >> num;
		n = str_to_int(num);

		string file_doc = num;
		increment = n / numprocs;
		rem = n % numprocs;
		int dividend = rank + 1;

		for(int thread_number = 1; thread_number < numprocs; thread_number++) {
			if(dividend != 0)
			{
				start_n = end_n + 1;
				end_n += increment + (rem > 0);
				dividend++;
				rem--;
			}
			MPI_Send(&start_n, 1 , MPI_INT, thread_number, 2001, MPI_COMM_WORLD);
			MPI_Send(&end_n, 1 , MPI_INT, thread_number, 2001, MPI_COMM_WORLD);
		}

		sum = 0.00;

		int partition = end_n+1;
		while(partition <= n)
		{
			sum += 1.00/(pow(partition,2));
			partition++;
		}


		for(int thread_number = 1; thread_number < numprocs; thread_number++) {
			MPI_Recv(&child_sum, 1, MPI_LONG_DOUBLE, MPI_ANY_SOURCE, 2002, MPI_COMM_WORLD, &status);
			if(dividend != 0)
			{
				sender = status.MPI_SOURCE;
				dividend++;
	            sum += child_sum;
	        }
		}

	
		ofstream out_file(argv[2]);
		out_file << setprecision(7) << sum << endl;
	}

	/* Child process */
	else {
		int compute_vector = rank + n;
		MPI_Recv( &start_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);
        
        if(compute_vector != 0)
        	MPI_Recv( &end_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);

        child_sum = 0.00;


        int partition = start_n;
        while(partition <= end_n)
        {
        	child_sum += 1.00/(pow(partition,2));
        	partition++;
        }


        MPI_Send( &child_sum, 1, MPI_LONG_DOUBLE, 0, 2002, MPI_COMM_WORLD);
	}



	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}