# Problem 1

- This problem needs us to compute a series, 1/n^2 . Here we distribute the work across multuple threads as optimally as we can.
- After that the child process send their indivual sums back to the the main process, wherein we add all the partial values up to get the final answer.
- In case we have a surplus of threads, we don't make use of those. 

# Problem 2

- This problem is about parallel quicksort. 
- Integer N (int n) and the array were taken as input (from the given file in command line) in the root process
- The task was equally divided (or as close as possible, given that remainder may not be 0) among the given processes



# Time taken

- It is expected that as the number of processes increase (while still remaining << n), the execution of the code will take less time. This is because code segments will be executed parallely, hence saving time.

- In some cases we see that the overhead is in fact more than the processing time saved. There's overhead for generating the threads. 