#include <cassert>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define SENDER 0
#define mpld MPI_LONG_DOUBLE
#define mpi MPI_INT

// instead of sending contiguous groups, we should be summing
// proc_count modulo ranges as otherwise the tail values sum to zero

int n, proc_count, proc_rank; 
MPI_Comm comm;
double tbeg;

long double sum(int i) {
    long double res = 0;

    // std::cout << i << " " << n << std::endl;

    while (i <= n) {
        res += 1.0l / i / i;
        i += proc_count;
    }

    return res;
}

void send_int(int val, int rec) {
    MPI_Send(&val, 1, mpi, rec, 0, comm);
}

int receive_int(int other) {
    int a;
    // std::cout << "Receiving from " << other << " to " << proc_rank << std::endl;
    MPI_Recv(&a, 1, mpi, other, 0, comm, MPI_STATUS_IGNORE);
    return a;
}

void send_ld(long double val, int rec) {
    // std::cout << "Sending from " << proc_rank << " to " << rec << std::endl;
    MPI_Send(&val, 1, mpld, rec, 0, comm);
}

long double receive_ld(int other) {
    long double a;
    // std::cout << "receiving from " << other << " to " << proc_rank << std::endl;
    MPI_Recv(&a, 1, mpld, other, 0, comm, MPI_STATUS_IGNORE);
    return a;
}

void proc_complete() {
    MPI_Barrier(comm);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (proc_rank == 0) {
        std::cout << "Total time (s): " << maxTime << std::endl;
    }

    MPI_Finalize();
}

streambuf* stream_buffer_cout;
streambuf* stream_buffer_cin ;
std::fstream out_file, in_file; 

void redirect_io(char* input_filename, char* output_filename) {
    out_file.open(output_filename, ios::out); 
    stream_buffer_cout = cout.rdbuf(); 
    streambuf* output_buffer = out_file.rdbuf(); 
    cout.rdbuf(output_buffer); 
    
    in_file.open(input_filename, ios::in);
    stream_buffer_cin = cin.rdbuf(); 
    streambuf* input_buffer = in_file.rdbuf(); 
    cin.rdbuf(input_buffer);
}

void unlink_io() {
    cout.rdbuf(stream_buffer_cout); 
    out_file.close(); 
    in_file.close();
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);
    comm = MPI_COMM_WORLD;

    MPI_Comm_size(comm, &proc_count);
    MPI_Comm_rank(comm, &proc_rank);

    MPI_Barrier(comm);
    tbeg = MPI_Wtime();

    if (proc_rank == SENDER) {
        redirect_io(argv[1], argv[2]);
        std::cin >> n;
    }

    long double res = 0;

    if (proc_rank == SENDER) {
        for (int p = 1; p < proc_count; p++)
            send_int(n, p);

        res += sum(proc_count);

        for (int p = 1; p < proc_count; p++) {
            long double ret = receive_ld(p);
            res += ret;
        }
    } else {
        n = receive_int(SENDER);
        long double ret = sum(proc_rank);
        send_ld(ret, SENDER);
    }

    if (proc_rank == SENDER) std::cout << std::fixed << std::setprecision(6) << res << std::endl;

    if (proc_rank == 0) unlink_io();

    proc_complete();
    return EXIT_SUCCESS;
}
