#include <cassert>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define SENDER 0
#define vi std::vector<int>
#define DEBUG 0

int proc_count, proc_rank, n;
double tbeg;

void send_vector(vi& vec, int beg, int count, int dest) {
    MPI_Send(&count, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);

    if (DEBUG) std::cout << "SENT: " << proc_rank << " to " << dest << std::endl;

    if (count > 0)
        MPI_Send(&vec[beg], count, MPI_INT, dest, 0, MPI_COMM_WORLD);
}

vi receive_vector(int source_proc_rank) {
    vi vec;
    int size;


    MPI_Recv(&size, 1, MPI_INT, source_proc_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);


    if (size == 0) {
        if (DEBUG) std::cout << "DEAD-RECEIVE: " << source_proc_rank << " to " << proc_rank << std::endl;
        return vec;
    }

    if (DEBUG) std::cout << "RECEIVE: " << source_proc_rank << " to " << proc_rank << " (" << size << ")" << std::endl;

    vec.resize(size);
    MPI_Recv(&vec[0], size, MPI_INT, source_proc_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    return vec;
}

// [beg, end)
int partition(int b, int end, vi& arr) {
    if (b >= end - 1) return b;

    int size = end - b;
    int idx = rand() % size + b;
    end--; // make end inclusive

    int p = arr[idx]; // store pivot value for later use
    int pi = end; // index of the pivot

    // bring pivot to the end
    // and ignore pivot itself
    swap(arr[end--], arr[idx]);

    while (true) {
        // exclude the good boundaries
        while (b < pi && arr[b] <= p) b++;
        while (end >= b && arr[end] > p) end--;

        // take action on bad boundary

        if (b > end) {
            // business over
            swap(arr[b], arr[pi]);
            return b;
        }

        // can fix these two
        swap(arr[b], arr[end]);
    }

    // not happening
    assert(false);
}

// [beg, end)
void quick_sort(int me, int depth, int beg, int end, vi& arr) {
    // if (DEBUG) cout << "!" << arr.size() << " " << beg << " " << end << endl;
    int mid, next_process;
    next_process = me + (1 << depth);

    // <= 1 element
    if (beg >= end - 1) goto exiter;

    mid = partition(beg, end, arr);
    // assert(mid < end);

    // if (DEBUG) cout << "DOING: (" << me << ") " << beg << " " << mid << " " << end << endl;

    if (mid <= beg + 1) {
        // if (DEBUG) cout << "REPEAT: (" << me << ") " << beg << " " << mid << " " << end << endl;
        quick_sort(me, depth, mid + 1, end, arr);
    } else if (mid + 1 >= end - 1) {
        // if (DEBUG) cout << "REPEAT: (" << me << ") " << beg << " " << mid << " " << end << endl;
        quick_sort(me, depth, beg, mid, arr);
    } else if (next_process < proc_count) {
        int nd = depth + 1;

        send_vector(arr, mid + 1, end - (mid + 1), next_process);

        if (DEBUG) std::cout << "KEEP: " << me << " " << mid - beg << endl;
        quick_sort(me, nd, beg, mid, arr);

        vi res = receive_vector(next_process);
        for (int i = mid + 1; i < end; i++) {
            arr[i] = res[i - mid - 1];
        }
    } else {
        // if (DEBUG) cout << ": " << beg << " " << mid << " " << end << endl;
        quick_sort(me, depth, beg, mid, arr);
        quick_sort(me, depth, mid + 1, end, arr);
    }

exiter:
    while (next_process < proc_count) {
        send_vector(arr, 0, 0, next_process);
        depth++;
        next_process = me + (1 << depth);
    }
}

void proc_complete() {
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if (proc_rank == 0) {
        std::cout << "Total time (s): " << maxTime << std::endl;
    }

    MPI_Finalize();
}

streambuf* stream_buffer_cout;
streambuf* stream_buffer_cin ;
std::fstream out_file, in_file; 

void redirect_io(char* input_filename, char* output_filename) {
    out_file.open(output_filename, ios::out); 
    stream_buffer_cout = cout.rdbuf(); 
    streambuf* output_buffer = out_file.rdbuf(); 
    cout.rdbuf(output_buffer); 
    
    in_file.open(input_filename, ios::in);
    stream_buffer_cin = cin.rdbuf(); 
    streambuf* input_buffer = in_file.rdbuf(); 
    cin.rdbuf(input_buffer);
}

void unlink_io() {
    cout.rdbuf(stream_buffer_cout); 
    out_file.close(); 
    in_file.close();
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);
    MPI_Comm comm = MPI_COMM_WORLD;

    MPI_Comm_size(comm, &proc_count);
    MPI_Comm_rank(comm, &proc_rank);

    MPI_Barrier(MPI_COMM_WORLD);
    tbeg = MPI_Wtime();

    vi arr;

    if (proc_rank == 0) {
        redirect_io(argv[1], argv[2]);

        std::cin >> n;
        arr.resize(n);

        for (auto &x : arr) std::cin >> x;
    }

    if (proc_rank == SENDER) {
        quick_sort(proc_rank, 0, 0, n, arr);
    } else {
        if (DEBUG) cout << "Waiting " << proc_rank << endl;

        int r2 = proc_rank;
        int depth = 0;

        while (r2 > 0) {
            r2 >>= 1;
            depth++;
        }
        int source = proc_rank - (1 << (depth - 1));
        int child = proc_rank + (1 << depth);

        while (true) {
            vi vec = receive_vector(source);
            if (vec.empty()) {
                while (child < proc_count) {
                    send_vector(vec, 0, 0, child);
                    depth++;
                    child = proc_rank + (1 << depth);
                }
                break;
            } else {
                quick_sort(proc_rank, depth, 0, vec.size(), vec);
                send_vector(vec, 0, vec.size(), source);
            }
        }
    }

    if (proc_rank == SENDER) {
        for (auto i : arr) std::cout << i << " ";
        cout << endl;
    }

    if (DEBUG) std::cout << "QUIT: " << proc_rank << std::endl;

    if (proc_rank == 0) 
        unlink_io();

    proc_complete();
    return EXIT_SUCCESS;
}
