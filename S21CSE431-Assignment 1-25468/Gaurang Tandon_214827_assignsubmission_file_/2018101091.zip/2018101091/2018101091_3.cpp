#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define READ_DSC 0
#define SENDER 0
#define vi std::vector<int>
#define vv std::vector<std::vector<char>>
#define vpii std::vector<std::pair<int, int>>
#define DEBUG 0
#define mpi MPI_INT

int proc_count, proc_rank, n, m, max_deg;
double tbeg;
char arr[1000][1000];
vpii edges;
int colors[1000];

void read_clq(string file_name){
    int i,x,y;
    string type,line;
    ifstream fin(file_name.c_str());
    if(!fin.is_open()){
        cout<<"ERROR opening file"<<endl;
        exit(1);
    }

    //eliminate comment lines
    // string comment;
    while(fin.peek()=='c'){
        getline(fin,line);
        // comment=comment+"#"+line+'\n';
    }

    fin>>type; // type of image/matrix (P1)
    fin>>type; // edge
    fin>>n; // vertexes
    fin>>m; // edges

    for(i=0;i<m;i++){
        fin>>type; // e
        if(type=="e"){
            fin>>x;fin>>y;
            edges.push_back({ x-1, y - 1});
            // cout << x - 1 << " " << y - 1 << endl;
        }
    }
    fin.close();
}

void send_int(int val, int rec) {
    MPI_Send(&val, 1, mpi, rec, 0, MPI_COMM_WORLD);
}

int receive_int(int other) {
    int a;
    MPI_Recv(&a, 1, mpi, other, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    return a;
}

void send_data(int dest, int start, int count) {
    send_int(start, dest);
    send_int(count, dest);
}

void receive_data(int dest, int &start, int &count) {
    start = receive_int(dest);
    count = receive_int(dest);
}

void send_vector(vi& vec, int dest, int start, int count) {
    send_int(count, dest);
    MPI_Send(&vec[start], count, MPI_INT, dest, 0, MPI_COMM_WORLD);
}

vi receive_vector(int source_rank) {
    int size = receive_int(source_rank);

    vi vec;
    if (size == 0) return vec;

    vec.resize(size);
    MPI_Recv(&vec[0], size, MPI_INT, source_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    return vec;
}

void proc_complete() {
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    if (proc_rank == 0) {
        std::cout << "Total time (s): " << maxTime << std::endl;
    }

    MPI_Finalize();
}

// transform all colors from [mid, end) to [beg, mid)
vi colors_reduction(int beg, int mid, int end) {
    std::set<int> colors_used;
    for (int j = beg; j < mid; j++) colors_used.insert(j);

    std::stack<int> ops;
    vi cols;
    // cout << beg << " " << mid << " " << end << endl;

    for (int i = 0; i < m; i++) {
        if (not (colors[i] >= beg and colors[i] < mid)) {
            for (auto neigh = 0; neigh < m; neigh++) {
                if (!arr[neigh][i]) continue;

                if (colors_used.erase(colors[neigh]))
                    ops.push(colors[neigh]);
            }

            assert(!colors_used.empty());
            colors[i] = *colors_used.begin();
            cols.push_back(colors[i]);

            while (not ops.empty()) {
                colors_used.insert(ops.top());
                ops.pop();
            }
        }
    }

    return cols;
}

streambuf* stream_buffer_cout;
streambuf* stream_buffer_cin ;
std::fstream out_file, in_file; 

void redirect_io(char* input_filename, char* output_filename) {
    out_file.open(output_filename, ios::out); 
    stream_buffer_cout = cout.rdbuf(); 
    streambuf* output_buffer = out_file.rdbuf(); 
    cout.rdbuf(output_buffer); 

    if (!READ_DSC) {
        in_file.open(input_filename, ios::in);
        stream_buffer_cin = cin.rdbuf(); 
        streambuf* input_buffer = in_file.rdbuf(); 
        cin.rdbuf(input_buffer);
    }
}

void unlink_io() {
    cout.rdbuf(stream_buffer_cout); 
    out_file.close(); 
    if (!READ_DSC) in_file.close();
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &proc_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &proc_count);

    MPI_Barrier(MPI_COMM_WORLD);
    tbeg = MPI_Wtime();

    if (proc_rank == 0) {
        redirect_io(argv[1], argv[2]);
    }

    max_deg = 0;

    if (proc_rank == 0) {
        if (READ_DSC) {
            read_clq(string(argv[1]));
        } else {
            // take normal graph input
            std::cin >> n >> m;

            for (int _ = 0; _ < m; _++) {
                int x, y; std::cin >> x >> y;
                edges.emplace_back(x, y);
            }
        }

        for (int i = 0; i < m; i++) {
            for (int j = i + 1; j < m; j++) {
                // edge adjacency condition
                if (edges[i].first == edges[j].first || edges[i].first == edges[j].second || edges[i].second == edges[j].first || edges[i].second == edges[j].second) {
                    arr[i][j] = arr[j][i] = true;
                }
            }
        }
        // for (int i = 0; i < m; i++) {
        //     for (int j = 0; j < m; j++) {
        //         cout << int(arr[i][j]) << " ";
        //     }
        //     cout << endl;
        // }
    }

    MPI_Bcast(&m, 1, MPI_INT, SENDER, MPI_COMM_WORLD);
    auto x_x = &arr[0][0];
    MPI_Bcast(x_x, 1000 * 1000, MPI_BYTE, SENDER, MPI_COMM_WORLD);

    // get max degree of graph
    for (int i = 0; i < m; i++) {
        int deg = 0;
        for (int j = 0; j < m; j++) {
            // cout << int(arr[i][j]) << " ";
            deg += arr[i][j];
        }
        // cout << endl;
        max_deg = std::max(deg, max_deg);
    }
    // cout << max_deg << endl;

    std::iota(colors, colors + m, 0);

    if (proc_rank == 0) {
        int unique;
        int bin_size = 2 * (max_deg + 1);
        int iters = 0;

        while (iters++ < 10) {
            unique = std::set<int>(colors, colors + m).size();
            // cout << unique << " " << max_deg << endl;
            if (unique <= max_deg + 1) break;

            if (unique <= bin_size) {
                colors_reduction(0, max_deg + 1, unique);
                // for (int i = 0; i < m; i++) cout << colors[i] << " ";
                // cout << endl;
            } else {
                MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);

                int chunk = unique / proc_count;
                if (chunk & 1) chunk += 1;

                int this_bin_size = std::max(bin_size, chunk); 

                int low = this_bin_size;

                for (int i = 1; i < proc_count; i++) {
                    if (low + this_bin_size - 1 >= n) send_data(i, -1, -1);
                    else send_data(i, low, this_bin_size);

                    low += this_bin_size;
                }

                colors_reduction(0, this_bin_size / 2, this_bin_size);

                low = this_bin_size;

                for (int i = 1; i < proc_count; i++) {
                    if (low + this_bin_size - 1 >= n) break;

                    auto res = receive_vector(i);
                    auto res_p = 0;

                    for (int i = 0; i < m; i++) {
                        auto &x = colors[i];
                        if (not (x >= low and x < low + this_bin_size / 2))
                            x = res[res_p++];
                    }

                    low += this_bin_size;
                }
            }
        } 

        std::cout << unique << std::endl;
        for (int i = 0; i < m; i++) {
            auto x = colors[i];
            std::cout << x + 1 << " ";
        }
        std::cout << std::endl;

        colors[1] = -1;
        MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);
    } else {
        while (true) {
            // cout << "Waiting " << proc_rank << endl;
            MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);

            if (colors[1] == -1) {
                break; 
            }

            int low, bin_size;
            receive_data(SENDER, low, bin_size);
            if (low != -1) {
                auto cols = colors_reduction(low, low + bin_size / 2, low + bin_size);
                send_vector(cols, SENDER, 0, cols.size());
            }
        }
    }

    if (proc_rank == 0) 
        unlink_io();

    proc_complete();
    return EXIT_SUCCESS;
}
