# DS Assignment 1 Solutions

Author: Gaurang Tandon (2018101091)

## Question 1

The $i$-th rank processor sums up $f(j)$ for all $j$ values such that $j \le n$ and $j \% \text{proc\_count} = i$. This scheme ensures almost equal distribution of values to each process, as in a modulo group each value repeats cyclically. Short pseudocode:

- $f(j)$ is defined as $1/(j^2)$
- The rank 0 process sends the value of $n$ to every other process. 
- Each process (including the sender) compute the sums for their modulo value. 
- The computed sums are resent by other processes to the rank 0 process.
- The rank 0 process adds them up and reports the answer.

**Communication complexity**: Constant (only integer $n$ is shared)  
**Time complexity**: linear (for each value <= n, $f$ of that value is computed exactly once)

## Question 2

tl;dr = Each process is alloted partitions of the array recursively. 

Initially the sender has depth 0, and rank 0, and it operates on the whole array. The following steps describe quicksort for a general state of `(array, process_rank, depth)`

- I have used the median(begin, middle, end) value scheme, although in practice even random pivot appraoch was just as fast.
- Process $i$ will partition the array given to it after computing the associated pivot. Now there are two cases:
    - the pivot is an extremal value, that is, only one array remains after the partitioning. In that case, process $i$ will recursively sort the remaining array.
    - the pivot leaves two disjoint unsorted arrays. In such case, process $i$ will recursively sort the left unsorted array, and send the right unsorted array to some other process for sorting.
        - the process which will receive the right array is `process\_rank + (1 << depth)`. If no such process exists then the existing process will solve for the right half also. Otherwise, this new process (with depth+1) will be alloted the right array, and the computation will recurse.
        - when operating on the left array, the process will update its depth to (depth + 1)
        - finally the other process will return the right sorted half, and it will then be put in place by the current process.
- current process will return the sorted array, or print it if it was the sender

It is easy to see (by experimentation or theoretically) that:

- the above formulation results in a binary tree similar to a sequential quick sort
- that each process has a unique parent (and each parent has multiple children at different depths)
- that no two different subtrees will ever overlap at the bottom (because of how binary numbers work, at each depth same binary prefix is begin shared)

It may so happen that we may finish sorting the array without using all processes. To handle this situation each parent sends a `-1` to its children (recursively), so that each child knows that it's now time to exit the party.

**Communication complexity**: num\_procs * linear (subarrays of the original array are received - and sent back - by each process exactly once)    
**Time complexity**: $n\log n$ (average case). Each process spends linear time partitioning the array and then uses a divded-and-conquer strategy to solve the two subparts. On average case this strategy will result in $\log n$ such steps.

## Question 3

I use a scheme similar to the Kuhn-Wattenhofer color-reduction. The idea is as follows:

0. Assume number of nodes $N = 2^k(\delta+1)$ for some $k$ (we can add extra isolaed vertices to make it possible)
1. We initially color the $i$-th vertex with color $i$.
2. The first processor will broadcast the list of current colors to all the processes (so that they maintain latest color)
2. Now, form groups of vertices such that each group contains $\delta+1$ vertices, we will have $2^k$ groups in this manner.
3. Use first processor to merge first two groups, next processor to merge next two groups, and so on. This step is done in **parallel.**
    - the merge step is performed such that for each vertex (in the two groups) which has color greater that $\delta + 1$, it is reduced to the lower half (below $\delta+1$ colors)
4. Now we are left with $2^{k-1}$ groups. Repeat step 2 again, until $k$ is 0.

If complextiy of step 3 is $T$, then overall operation takes $T\log\left(\frac{N}{\delta+1}\right)$. The complexity of step 3 - calculated theoretically in the original paper [1] - is $\delta$. The original paper does this step 3 in parallel (per vertex, each vertex assumed to have a processor, so we can send a single broadcast). Overall, therefore, this **complexity becomes $\delta \log\left(\frac{N}{\delta+1}\right)$ theoretically**.

In my implementation, as number of processors is limited (from 1 to 11), for step 3, instead of using buckets of size $\delta + 1$, I have used buckets of size $\frac {N}{\text{proc\_count}}$.

**Communication complexity**: $(m*m + m\log(n / \log(\delta+1))$, i.e., at each step of the communication (logarithmic steps), the processors exchange the color information of all the edges. Before start of the communication, the processes exchange the adjacency matrix of size $m*m$ via a broadcast.

**Time complexity**: roughly $T\log(n / \text{bin\_size})$. Here $\text{bin\_size}$ is roughly $\frac {N}{\text{proc\_count}}$, and $T$ has a theoretical lower bound of $\delta$. However in our implementation it can go upto $\delta^2$, because of lack of number of processors required theoretically.

References
---

[1] On the Complexity of Distributed Graph Coloring, 2006. Fabian Kuhn, Roger Wattenhofer
