#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

void swap (int *a, int i, int j) {
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

int pick_pivot (int *a, int lo, int hi) {
    return a[(lo + hi) / 2];
    // TODO: Implement better pivot picking, e.g. median
}

// returns pivot_idx (inclusive, counting from 0) after partitioning
int partition (int *a, int lo, int hi, int pivot) {
    int i = lo - 1;
    int j = hi + 1;

    while (1) {
        do {
            i++;
        } while (a [i] < pivot);
        do {
            j--;
        } while (a [j] > pivot);
        if (i >= j) {
            return j;
        }
        swap (a, i, j);
    }
}

void serial_quicksort(int *a, int lo, int hi) {
    if (lo < hi) {
        int p = partition (a, lo, hi, a[(hi + lo) / 2]);
        serial_quicksort (a, lo, p);
        serial_quicksort (a, p + 1, hi);
    }
}

int parallel_partition (int *array, int lo, int hi, MPI_Comm comm, int master) {
    int ierr, num_procs, my_id, global_id;

    ierr = MPI_Comm_rank(comm, &my_id);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &global_id);
    ierr = MPI_Comm_size(comm, &num_procs);

    if (num_procs <= 1 || lo >= hi) {
        serial_quicksort (array, lo, hi);
        return -1;
    }

    int pivot, *subarray, subarray_len, global_pivot_idx, left_proc_count, right_proc_count, *left_proc_ranks, *right_proc_ranks;

    // Used only by master. Memory allocated later.
    int *subarray_lens, *subarray_displacements;

    // all processes take same sized chunks of same size of original array, and
    // last process picks up left over chunk
    if (my_id != num_procs - 1) {
        subarray_len = (hi - lo + 1) / num_procs;
    } else {
        subarray_len = (hi - lo + 1) / num_procs + (hi - lo + 1) % num_procs;
    }

    subarray = (int *) malloc (sizeof (int) * subarray_len);

    // master distributes appropriate subarrays to all processes
    if (my_id != master) {
        ierr = MPI_Scatterv (NULL, NULL, NULL, MPI_INT, subarray, subarray_len, MPI_INT, master, comm);
    } else { /* my_id == master */
        subarray_lens = (int *) malloc (sizeof(int) * num_procs);
        subarray_displacements = (int *) malloc (sizeof(int) * num_procs);

        pivot = pick_pivot(array, lo, hi);

        for(int i = 0; i < num_procs - 1; i++) {
            subarray_lens[i] = (hi - lo + 1) / num_procs;
        }
        subarray_lens[num_procs - 1] = (hi - lo + 1) / num_procs + (hi - lo + 1) % num_procs;

        for (int i = 0; i < num_procs; i++) {
            subarray_displacements[i] = i * subarray_len;
        }

        ierr = MPI_Scatterv (array, subarray_lens, subarray_displacements, MPI_INT, subarray, subarray_len, MPI_INT, master, comm);
    }

    ierr = MPI_Bcast (&pivot, 1, MPI_INT, master, comm);

    int pivot_idx = partition (subarray, 0, subarray_len - 1, pivot);

    int *pivot_idxs = (int *) malloc (sizeof(int) * num_procs);
    ierr = MPI_Gather(&pivot_idx, 1, MPI_INT, pivot_idxs, 1, MPI_INT, master, comm);

    if (my_id != master) {
        ierr = MPI_Gatherv(subarray, pivot_idx + 1, MPI_INT, NULL, NULL, NULL, MPI_INT, master, comm);
        ierr = MPI_Gatherv(subarray + pivot_idx + 1, subarray_len - pivot_idx - 1, MPI_INT, NULL, NULL, NULL, MPI_INT, master, comm);
    } else {
        int *counts = (int *) calloc (num_procs, sizeof(int));
        for (int i = 0; i < num_procs; i++) {
            counts[i] = pivot_idxs[i] + 1;
        }

        int *displacements = (int *) calloc (num_procs, sizeof(int));
        for (int i = 1; i < num_procs; i++) {
            displacements[i] = displacements[i - 1] + counts[i - 1];
        }

        global_pivot_idx = displacements[num_procs - 1];

        ierr = MPI_Gatherv(subarray, pivot_idx + 1, MPI_INT, array, counts, displacements, MPI_INT, master, comm);

        displacements[0] = displacements[num_procs - 1] + counts[num_procs - 1];
        for (int i = 0; i < num_procs; i++) {
            counts[i] = subarray_lens[i] - pivot_idxs[i] - 1;
        }

        for (int i = 1; i < num_procs; i++) {
            displacements[i] = displacements[i - 1] + counts[i - 1];
        }

        ierr = MPI_Gatherv(subarray + pivot_idx + 1, subarray_len - pivot_idx - 1, MPI_INT, array, counts, displacements, MPI_INT, master, comm);

        // select master for each group and make recursive calls

        //free(subarray_displacements);
        //free(subarray_lens);
        //free(displacements);
        //free(pivot_idxs);
        //free(counts);
    }

    ierr = MPI_Bcast(&global_pivot_idx, 1, MPI_INT, master, comm);

    //free(left_proc_ranks);
    //free(right_proc_ranks);
    //free(subarray);

    return global_pivot_idx;
}

void parallel_quicksort (int *array, int lo, int hi, MPI_Comm comm, int master) {
    if (lo >= hi) {
        return ;
    }
    int ierr, num_procs, my_id, global_id;
    
    ierr = MPI_Comm_rank(comm, &my_id);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &global_id);
    ierr = MPI_Comm_size(comm, &num_procs);

    if (num_procs <= 1) {
        serial_quicksort (array, lo, hi);
        return ;
    }

    int pivot, *subarray, subarray_len, global_pivot_idx, left_proc_count, right_proc_count, *left_proc_ranks, *right_proc_ranks;

    // Used only by master. Memory allocated later.
    int *subarray_lens, *subarray_displacements;

    MPI_Group left_proc_group, right_proc_group;

    MPI_Comm left_proc_comm, right_proc_comm;

    MPI_Group comm_group;

    ierr = MPI_Comm_group(comm, &comm_group);

    // all processes take same sized chunks of same size of original array, and
    // last process picks up left over chunk
    if (my_id != num_procs - 1) {
        subarray_len = (hi - lo + 1) / num_procs;
    } else {
        subarray_len = (hi - lo + 1) / num_procs + (hi - lo + 1) % num_procs;
    }

    subarray = (int *) malloc (sizeof (int) * subarray_len);

    // master distributes appropriate subarrays to all processes
    if (my_id != master) {
        ierr = MPI_Scatterv (NULL, NULL, NULL, MPI_INT, subarray, subarray_len, MPI_INT, master, comm);
    } else { /* my_id == master */
        subarray_lens = (int *) malloc (sizeof(int) * num_procs);
        subarray_displacements = (int *) malloc (sizeof(int) * num_procs);

        pivot = pick_pivot(array, lo, hi);

        for(int i = 0; i < num_procs - 1; i++) {
            subarray_lens[i] = (hi - lo + 1) / num_procs;
        }
        subarray_lens[num_procs - 1] = (hi - lo + 1) / num_procs + (hi - lo + 1) % num_procs;

        for (int i = 0; i < num_procs; i++) {
            subarray_displacements[i] = i * subarray_len;
        }

        ierr = MPI_Scatterv (array, subarray_lens, subarray_displacements, MPI_INT, subarray, subarray_len, MPI_INT, master, comm);
    }

    ierr = MPI_Bcast (&pivot, 1, MPI_INT, master, comm);

    int pivot_idx = partition (subarray, 0, subarray_len - 1, pivot);

    int *pivot_idxs = (int *) malloc (sizeof(int) * num_procs);
    ierr = MPI_Gather(&pivot_idx, 1, MPI_INT, pivot_idxs, 1, MPI_INT, master, comm);

    if (my_id != master) {

        ierr = MPI_Gatherv(subarray, pivot_idx + 1, MPI_INT, NULL, NULL, NULL, MPI_INT, master, comm);

        ierr = MPI_Gatherv(subarray + pivot_idx + 1, subarray_len - pivot_idx - 1, MPI_INT, NULL, NULL, NULL, MPI_INT, master, comm);

    } else {
        int *counts = (int *) calloc (num_procs, sizeof(int));
        for (int i = 0; i < num_procs; i++) {
            counts[i] = pivot_idxs[i] + 1;
        }

        int *displacements = (int *) calloc (num_procs, sizeof(int));
        for (int i = 1; i < num_procs; i++) {
            displacements[i] = displacements[i - 1] + counts[i - 1];
        }

        global_pivot_idx = displacements[num_procs - 1];

        ierr = MPI_Gatherv(subarray, pivot_idx + 1, MPI_INT, array, counts, displacements, MPI_INT, master, comm);

        displacements[0] = displacements[num_procs - 1] + counts[num_procs - 1];
        for (int i = 0; i < num_procs; i++) {
            counts[i] = subarray_lens[i] - pivot_idxs[i] - 1;
        }

        for (int i = 1; i < num_procs; i++) {
            displacements[i] = displacements[i - 1] + counts[i - 1];
        }

        ierr = MPI_Gatherv(subarray + pivot_idx + 1, subarray_len - pivot_idx - 1, MPI_INT, array, counts, displacements, MPI_INT, master, comm);

        // select master for each group and make recursive calls

        free(subarray_displacements);
        free(subarray_lens);
        free(displacements);
        free(pivot_idxs);
        free(counts);
    }

    ierr = MPI_Bcast(&global_pivot_idx, 1, MPI_INT, master, comm);

    left_proc_count = ceil((hi - global_pivot_idx) * num_procs / (hi - lo + 1.0));
    right_proc_count = num_procs - left_proc_count;

    left_proc_ranks = (int *) malloc(sizeof(int) * left_proc_count);
    right_proc_ranks = (int *) malloc(sizeof(int) * right_proc_count);

    for(int i = 0; i < num_procs; i++) {
        if (i < left_proc_count) {
            left_proc_ranks[i] = i;
        } else {
            right_proc_ranks[i - left_proc_count] = i;
        }
    }

    ierr = MPI_Group_incl(comm_group, left_proc_count, left_proc_ranks, &left_proc_group);

    ierr = MPI_Group_incl(comm_group, right_proc_count, right_proc_ranks, &right_proc_group);
    ierr = MPI_Comm_create(comm, left_proc_group, &left_proc_comm);
    ierr = MPI_Comm_create(comm, right_proc_group, &right_proc_comm);

    ierr = MPI_Bcast(array, hi - lo + 1, MPI_INT, master, MPI_COMM_WORLD);

    int old = my_id;
    if(my_id < left_proc_count) {
        MPI_Barrier(left_proc_comm);
        ierr = MPI_Comm_rank(left_proc_comm, &my_id);
        parallel_quicksort (array, lo, global_pivot_idx, left_proc_comm, 0);
        MPI_Bcast(array, global_pivot_idx - lo + 1, MPI_INT, 0, left_proc_comm);
        ierr = MPI_Bcast(array, global_pivot_idx - lo + 1, MPI_INT, 0, left_proc_comm);
    } else {
        MPI_Barrier(right_proc_comm);
        ierr = MPI_Comm_rank(right_proc_comm, &my_id);
        parallel_quicksort (array, global_pivot_idx + 1, hi, right_proc_comm, 0);
        ierr = MPI_Bcast(array + global_pivot_idx + 1, hi - global_pivot_idx, MPI_INT, 0, right_proc_comm);
    }

    MPI_Group_union(left_proc_group, right_proc_group, &comm_group);
    MPI_Comm_create(MPI_COMM_WORLD, comm_group, &comm);

    ierr = MPI_Bcast(array, global_pivot_idx - lo + 1, MPI_INT, left_proc_count - 1, comm);
    ierr = MPI_Bcast(array + global_pivot_idx + 1, hi - global_pivot_idx, MPI_INT, left_proc_count, comm);

    free(left_proc_ranks);
    free(right_proc_ranks);
    free(subarray);

}

int main(int argc, char **argv) {
    int ierr, num_procs, my_id, master, *array, array_len, i;

    master = 0;

    ierr = MPI_Init(&argc, &argv);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

    if (my_id == master) {

        scanf ("%d", &array_len);
        array = (int *) malloc (sizeof(int) * array_len);

        for (i = 0; i < array_len; i++) {
            scanf ("%d", &array[i]);
        }
    }

    // all processes need to know this to set up respective subarray_lens
    // correctly
    MPI_Bcast (&array_len, 1, MPI_INT, master, MPI_COMM_WORLD);

    if (my_id != master) {
        array = (int *) malloc (sizeof(int) * array_len);
        MPI_Bcast(array, array_len, MPI_INT, master, MPI_COMM_WORLD);
    } else { /* no need to malloc again, just need to bcast scanf'd input array */
        MPI_Bcast(array, array_len, MPI_INT, master, MPI_COMM_WORLD);
    }

    parallel_quicksort (array, 0, array_len - 1, MPI_COMM_WORLD, master);

    if (my_id == master) {
        for (i = 0; i < array_len; i++) {
            printf ("%d ", array[i]);
        }
        printf("\n");
    }

    free (array);
    ierr = MPI_Finalize ();
}
/* 7            
 * 5 2 1 4 7 3 6
 * */
