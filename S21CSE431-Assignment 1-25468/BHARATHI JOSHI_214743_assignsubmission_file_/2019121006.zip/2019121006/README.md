# README

# Approximation

Entire length of approximation is divided into chunks, i.e. for n approximation
and p processes each process sums n/p chunk. Master process then adds all these
individual chunks. If n < p, each process just returns inverse square of 1
natural number, which the master process then adds up.

# Parallel Quicksort

At a high level, this is how my parallel quicksort works

1. Entire array of length `n` is divided into subarrays such that each process
   gets a contiguous subarray of length `n/p`, where `p` is the number of
   processes. The master process performs this allocation.
2. A pivot is picked by the master process and broadcasted to all processes. Now
   all the processes perform partitioning of their respective subarrays
   according to this pivot.
3. These local partitions are merged to get attain global array-level partition.
4. Master process divides processes into two groups, one to recursively sort the
   left subarray and one to recursively sort the right subarray. Base case of
   recursion is when only one process is in the group, and the single process
   uses serialized quicksort to sort the subarray.

   NOTE : master process is always process with rank 0
