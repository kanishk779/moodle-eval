#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) 
{
    int ierr, num_procs, my_id, master_process, approx_length, i, chunk_size;
    double sum_fragment, total_sum;

    master_process = 0;
    total_sum = 0;

    ierr = MPI_Init(&argc, &argv);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

    if (my_id == master_process) {
        scanf ("%d", &approx_length);
        chunk_size = approx_length / num_procs;
    }

    ierr = MPI_Bcast (&chunk_size, 1, MPI_INT, master_process, 
            MPI_COMM_WORLD);
    ierr = MPI_Bcast (&approx_length, 1, MPI_INT, master_process, 
            MPI_COMM_WORLD);

    sum_fragment = 0;
    if (chunk_size) {
        for (i = (my_id * chunk_size) + 1;
                i < (my_id * chunk_size) + chunk_size + 1;
                i++) {
            sum_fragment += 1.0 / (i * i);
        }
        if (my_id == (num_procs - 1)) {
            for (int i = approx_length;
                    i > approx_length - (approx_length % num_procs);
                    i--) {
                sum_fragment += 1.0 / (i * i);
            }
        }
    } else {
        if (my_id + 1 <= approx_length) {
            sum_fragment = 1.0 / ((my_id + 1) * (my_id + 1));
        }
    }

    ierr = MPI_Reduce(&sum_fragment, &total_sum, 1, MPI_DOUBLE,
            MPI_SUM, master_process, MPI_COMM_WORLD);

    if (my_id == master_process) {
        printf("%lf\n", total_sum);
    }


    ierr = MPI_Finalize();
}
