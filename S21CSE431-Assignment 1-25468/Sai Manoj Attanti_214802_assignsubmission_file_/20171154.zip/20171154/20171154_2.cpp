#include<stdio.h>
#include<string.h>
#include <vector>
#include <bits/stdc++.h>


int main(){
    int t;
    scanf("%d",&t);

    for(int l=0;l<t;l++){
        int flag = 1;
        int n;
        scanf("%d",&n);
        //printf("---%d\n\n",n);
        int a0 ;
        int ai;

        for(int i=0;i<n;i++){
            int k;
            scanf("%d",&k);

            if(i==0){
                a0 = k;
            } else {
                if(k!=a0){
                    flag = 0;
                }
            }
        }

        if(flag==1){
            printf("%d\n",n);
        } else {
            printf("1\n");
        }
    }

    return 0;
}