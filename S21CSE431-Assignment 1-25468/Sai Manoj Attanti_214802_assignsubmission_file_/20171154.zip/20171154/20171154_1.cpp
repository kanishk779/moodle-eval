#include<stdio.h>
#include<string.h>
#include <vector>
#include <bits/stdc++.h> 
using namespace std;

int main(){
    int k;
    scanf("%d",&k);

    for(int j=0;j<k;j++){
    int n;
    scanf("%d",&n);
    vector<int> arr(n);
    char str[1000000];
    scanf("%s",str);
    unordered_map<int, int> umap; 
    umap.clear();
    int len = n;
    long long int sum = 0;
    long long int count = 0;

    for(int i=0;i<len;i++){
        int t = str[i] - '0'-1;

        sum+=t;
       
        if(sum==0)
        count++;

        if(umap.find(sum) == umap.end()){
            umap[sum]=1;
        } else {
            count += umap[sum];
            umap[sum] = umap[sum] + 1;
        }
        //printf("%d %d\n",t,count);
    }

    printf("%lld\n",count);
    }

    return 0;
}