#include<stdio.h>
#include<string.h>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

int main(){
    int l;
    scanf("%d",&l);

    for(int j=0;j<l;j++){
    long long int k;
    int n;

    scanf("%d %lld",&n,&k);
    vector<int> arr(n);
    int min = 1000000001;
    int max = -1000000001;
    
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);

        if(arr[i]>max)
        max = arr[i];

        if(arr[i]<min)
        min = arr[i];
    }

    for(int i=0;i<n;i++){
        if(k%2==0){
            printf("%d ",arr[i]-min);
        } else {
            printf("%d ",max - arr[i]);
        }
    }

    printf("\n");
    }

    return 0;
    

}