Distributed Systems Assignment 1
MPI Programming
Due: January 22, 11:55PM
1
Overview
This assignment deals with parallel programming using the message passing model. In this assignment
you will construct parallel solutions to certain problems and implement them using the Message Passing
Interface: MPI in either C or C++.
2
Important Points
For this assignment, you will be using the Open MPI library to code solutions to different problems in
C/C++.
• Installation Guide: https://ireneli.eu/2016/02/15/installation/
• Introduction to MPI in C: http://condor.cc.ku.edu/ grobe/docs/intro-MPI-C.shtml
• MPI Documentation: https://www.rookiehpc.com/mpi/docs/index.php
• Template: Link
• All your programs should run for minimum 1 and maximum 11 processes.
• For those who are not able to run their programs with 11 or less process use one of the following
commands:
– mpirun -np 11 –use-hwthread-cpus ./a.out
– mpirun -np 11 –oversubscribe ./a.out
3
Problems
You are supposed to use the above given template for implementing each of the below given programs.
Additionally, your program will be given two arguments, path to an input file and an output file from which
your program will obtain the input and output the result into respectively.
Problem 1 (10 points)
Use the numerical identity that the sum of the reciprocals of the squares of integers converges to
π 2
6 .
Input
An integer N denoting the number of terms in the series that your program has to use.For N = 4, series
would be 1 1 2 + 2 1 2 + 3 1 2 + 4 1 2 .
Output
A floating point number, denoting the estimated value of
1
π 2
6
rounded off to six decimal places.Constraints
2 ≤ N ≤ 10 4
Sample Test Cases
Sample Input 1
2
Sample Output 1
1.250000
Sample Input 2
100
Sample Output 1
1.634984
Problem 2 (30 points)
Given an array of numbers, your task is to return the array in sorted order by implementing parallel quicksort.
Input
The first line of input contains size of array N . The second line of input contains N space separated integers.
Output
The output is a space separated sorted array.
Constraints
2 ≤ N ≤ 10 6
Sample Test Cases
Sample Input
7
9 3 -11 100 2 4 1
Sample Output
-11 1 2 3 4 9 100
Problem 3 (60 points)
Given an undirected graph G, find a proper edge coloring of the graph using Delta(G) + 1 colors or fewer.
No 2 adjacent edges should have a same color. Delta(G) is the maximum degree of any vertex in G.
Input
First line contains two integers N M , denoting the number vertices and edges of the graph. Then, there are
M lines, each of which contains 2 integers u and v, which means there is an edge in graph joining vertices u
and v. i th line here corresponds to edge i.
Output
First line should contain a single integer x denoting the number of colors used. Second line should contain
M integers (c 1 , c 2 , ..., c N ), where c i represents color of the edge i. 1 ≤ c i ≤ x
2Constraints
1 ≤ N ≤ 100
1 ≤ M ≤ 500
Sample Test Cases
Sample Input
33
12
23
31
Sample Output
3
123
4
Submission Instructions
Your submission is expected to be a <RollNumber>.zip file containing a directory with the same name as
your roll number that holds the following files:
• A program file for each of the mentioned problems with the name: <RollNumber> <ProblemNumber>.cpp
• A brief report describing and analyzing your solution as: README.md
Since your codes will be evaluated automatically, you have to follow the output format strictly.
NOTE: Strict actions would be taken against anyone found involved in any kind of plagia-
rism either from the internet or from other students. If we find any of the codes implementing
the question in serial manner or using other algorithms than mentioned in the question, then
it will result in serious penalties.
3