#include<bits/stdc++.h>
#include <mpi.h>
#include <stdio.h>
using namespace std;
int piviot(int *&q,int l,int h)
{
	int p=q[h-1];
	int i=l-1;
	for(int j=l;j<h;j++)
	{
		if(q[j]<p)
		{
			i++;
			swap(q[i],q[j]);
		}
	}
	swap(q[i+1],q[h-1]);
	return i+1;
}
void quick(int *&q,int l,int h)
{	
	if(l<h)
	{
		int p=piviot(q,l,h);
		quick(q,l,p);
		quick(q,p+1,h);
	}
}
int merge(int *a,int *b,int n1,int n2,int *&arr)
{
	int i=0,j=0,k=0;
	while(i<n1||j<n2)
	{
		if(i>=n1)
		{
			arr[k++]=b[j++];
		}
		else if(j>=n2)
		{
			arr[k++]=a[i++];
		}
		else if(a[i]>b[j])
		{
			arr[k++]=b[j++];	
		}
		else
		{
			arr[k++]=a[i++];
		}
	}
}
int main(int argc, char* argv[])
{
	int n;
	int final_;
	int *arr,*ch,*data;
	FILE *ptr;
	int actual,act=0;
	MPI_Init(&argc, &argv); 
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();
	if(size==1)
	{
		ptr=fopen(argv[1],"r");
		fscanf(ptr,"%d",&n);
		arr=new int[n];
		final_=n;
		for(int i=0;i<n;i++)
		{
			int pp;
			fscanf(ptr,"%d",&pp);
			arr[i]=pp;
		}
		quick(arr,0,n);
		fclose(ptr);
		ptr=fopen(argv[2],"w");
		for(int i=0;i<final_;i++)
		{
			fprintf(ptr,"%d ",arr[i]);
		}
		fclose(ptr);
		double elapsedTime = MPI_Wtime() - tbeg;
		double maxTime;
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
		if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
		}
		MPI_Finalize(); 
		return 0;
	}	
	data = new int[size+1];
	if(rank==0)
	{
		ptr=fopen(argv[1],"r");
		fscanf(ptr,"%d",&n);
		final_=n;actual=n;
		int x=n%size;
		actual=n;
		if(x>0)
		{
			arr=new int[n+(size-x)];
			for(int i=n;i<n+size-x;i++)
				arr[i]=INT_MAX;
			actual=n+size-x;
		}
		else
		{
			arr=new int[n];
		}
		actual=actual/size;
		if(size-x>actual&&x!=0)
		{
			for(int i=0;i<size-2;i++)
			{
				data[i]=actual;
			}
			data[size-2]=n-(actual*(size-2));
			data[size-1]=0;
			data[size]=1;
		}
		else
		{
			for(int i=0;i<size-1;i++)
			{
				data[i]=actual;
			}
			data[size-1]=n-actual*(size-1);
			data[size]=0;
		}
		for(int i=0;i<n;i++)
		{
			int pp;
			fscanf(ptr,"%d",&pp);
			arr[i]=pp;
		}
		fclose(ptr);
	}
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(data,size+1,MPI_INT,0,MPI_COMM_WORLD);
	actual=data[0];
	if(data[size]!=1)
	{
		ch= new int[actual];
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		act=actual;
		if((rank+1)!=size)
			quick(ch,0,data[rank]);
		else
		{
			quick(ch,0,data[rank]);
			act=data[rank];

		}
		for(int i=1;i<size;)
		{
			int itr=2*i;
			if(rank%itr==0)
			{
				
			}
			else
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			if((rank+i)<size)
			{	
				int ss=0;
				if((actual*(rank+2*i))>n)
				{
					 ss=n-actual*(rank+i);
				}			
				else
				{
					ss=actual*i;
				}
				int *nn=new int[ss];
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				arr=NULL;
				arr=new int[act+ss];
				merge(ch,nn,act,ss,arr);
				act+=ss;
				ch=arr;
			}
			i=itr;
		}
	}
	else
	{
		ch= new int[actual];
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		act=data[0];
		n=actual*(size-1);
		quick(ch,0,data[rank]);
		size--;
		for(int i=1;i<size;)
		{
			int itr=2*i;
			if(rank%itr==0)
			{
				
			}
			else
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			if((rank+i)<size)
			{	
				int ss=0;
				if((actual*(rank+2*i))>n)
				{
					 ss=n-actual*(rank+i);
				}			
				else
				{
					ss=actual*i;
				}
				int *nn=new int[ss];
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				arr=NULL;
				arr=new int[act+ss];
				merge(ch,nn,act,ss,arr);
				act+=ss;
				ch=arr;
			}
			i=itr;
		}
	}
	if(rank==0)
	{
		ptr=fopen(argv[2],"w");
		for(int i=0;i<final_;i++)
		{
			fprintf(ptr,"%d ",arr[i]);
		}
		fclose(ptr);
	}
	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if(rank==0) 
	{
		printf( "Total time (s): %f\n", maxTime );
	}
	MPI_Finalize(); 
return 0;
}
		
