#include<iostream>
#include <mpi.h>
#include <stdio.h>
using namespace std;
int main(int argc, char* argv[])
{
	int n;
	FILE *ptr;
	MPI_Init(&argc, &argv); 
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);	
	MPI_Barrier( MPI_COMM_WORLD );
    	double tbeg = MPI_Wtime();
	if(rank==0)
	{
		ptr=fopen(argv[1],"r");
		fscanf(ptr,"%d", &n);
		fclose(ptr);
		double ans=0;
		if(ptr==NULL)
		{
			return 0;	
		}
		int x=n/size;
		for(int i=1;i<size;i++)
		{
			MPI_Send(&x,1,MPI_INT,i,0,MPI_COMM_WORLD);
		}
		int data_start=1,data_end=x;
		if(x<1)
		{
			for(int i=data_start;i<=n;i++)
			{
				ans+=(1/((i*i)*1.0));
			}
		}
		else
		{
			for(int i=1;i<size;i++)
			{
				int a[]={data_start,data_end};
				MPI_Send(a,2,MPI_INT,i,0,MPI_COMM_WORLD);
				data_start+=x;
				data_end+=x;
			}
			double k=0;
			for(int i=data_start;i<=n;i++)
			{
				ans+=(1/((i*i)*1.0));
			}
			for(int i=1;i<size;i++)
			{
				MPI_Recv(&k,1,MPI_DOUBLE,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				ans+=k;
			}
		}
		ptr=fopen(argv[2],"w");
		fprintf(ptr,"%0.6f\n",ans);
		fclose(ptr);
	}
	else
	{
		int x;
		MPI_Recv(&x,1,MPI_INT,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		if(x>0)
		{
			int a[2];
			MPI_Recv(a,2,MPI_INT,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			double ans=0;
			for(int i=a[0];i<=a[1];i++)
			{
				ans+=(1/((i*i)*1.0));
			}
			MPI_Send(&ans,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD);
		}
	}	
	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
	printf( "Total time (s): %f\n", maxTime );
	}
	MPI_Finalize(); 
	return 0;
}

