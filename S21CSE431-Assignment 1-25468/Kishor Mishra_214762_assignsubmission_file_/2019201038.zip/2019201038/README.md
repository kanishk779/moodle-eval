1. In first question we analyze that when we run N parallelly it run fast and when we increase the value of N is converges towards (pie*pie)/6.
	N             	value
	2		1.250000
	50		1.625133
	100		1.634984
	200		1.639947
	500		1.642936
	1000		1.643935

We have to split N numbers into np 
such as N/np
Special case: see for last core , it should not hold extra values


int num = rank*loopSize + i;
Example :
100/7 = 14   N/np

core 1: [1,2,...14]  computation(1/1^1 + 1/2^2 + ... 1/14^14)
core 2: [15 .... 28]
core 3..  .....  


core 7  [....100]

send all answers to core 1(rank0)
add there and write back to op-file.txt

2. In the second question we analyze that parallel quicksort is very fast.
	we split the array in equal chunks by using extra padding INT_MAX and then apply quick sort and last we merge the all the array.
