#Assignment report
#####Roll no :2019201033
#### Problem 1
- Use the numerical identity that the sum of the reciprocals of the squares of integers converges to π2/6 .

#### Approach
- All the processes are assigned certain terms in the series and return the sum of those elements.
- The criteria for division of terms is as follows : All the terms having same value whih is calculated using (term no.)%number of processes, are assigned to same process
- After the computation, all processes send their value to the main (rank 0) process which adds up all partial sums to arrive at the final answer.
