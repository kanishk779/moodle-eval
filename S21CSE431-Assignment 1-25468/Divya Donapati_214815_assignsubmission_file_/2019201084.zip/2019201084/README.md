#1

Broadcasted N to all the processes.

Using their rank each process calculated 1/(rank)^2 + 1/(rank+numprocs)^2 + 1/(rank+2numprocs)^2 till x*numprocs <= N where numprocs is the number of processes

Using reduce I calculated the sum of the partial results from all the processes

#2
Split the given array into N(number of processes) partitions. 

Did quicksort over the partitions and returned the result.

#3
