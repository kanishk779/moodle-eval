/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(vector<int> &arr, int start, int end)
{
    int pivot = arr[start];
    int t;
    for (int i = start + 1, j = end; i < j;)
    {
        while (i < j && arr[i] < pivot)
        {
            i++;
        }
        while (i < j && arr[j] >= pivot)
        {
            j--;
        }
        if (i >= j)
        {
            t = arr[i - 1];
            arr[i - 1] = arr[start];
            arr[start] = arr[i - 1];
            return i;
        }
        t = arr[i];
        arr[i] = arr[j];
        arr[j] = t;
        i++;
        j++;
    }
    return start + 1;
}
void quicksort(vector<int> &arr, int start, int end)
{
    cout<<start<<" : "<<end<<endl;
    if (start < end)
    {
        int mid = partition(arr, start, end);
        quicksort(arr, start, mid);
        quicksort(arr, mid + 1, end + 1);
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;
    // vector<vector<map<int, int>>> right(4, vector<map<int, int>>);
    int right[5][4] = {
        // 5 is the processor, 4 is the number of levels
        {2, 3, 5, 9},
        {0, 4, 7, 0},
        {0, 0, 6, 11},
        {0, 0, 8, 0},
        {0, 0, 0, 10},
    };

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    vector<int> arr(1000000);
    int n;
    if (rank == 0)
    {
        string input;
        ifstream inpFile(argv[1]);
        getline(inpFile, input);
        n = atoi(input.c_str());
        cout << "n " << n << endl;
        // arr = new int[n];
        arr.resize(n);
        getline(inpFile, input);
        inpFile.close();
        stringstream s(input);
        for (int i = 0; i < n && s.good(); i++)
        {
            s >> arr[i];
        }
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << endl;
        }
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int start = -1, end = -1;
    int coun;
    if (rank == 0)
    {
        int level = 0;
        start = 0, end = n - 1;
        int i;
        queue<pair<int, int> > split;
         queue<pair<int, int> > temp;
        cout<<"splitting\n";
        split.push(make_pair(start, end));
        for (int i = 1; i < numprocs; i *= 2)
        {
            for (int j = 0; j < split.size(); j++)
            {
                start = split.front().first;
                end = split.front().second;
                cout<<" split "<<start<<", "<<end<<endl;
                split.pop();
                int mid = partition(arr, start, end);
                cout<<" mid : "<<mid<<endl;
                if (start < mid - 1)
                    split.push(make_pair(start, mid - 1));
                if (mid + 1 < end)
                    split.push(make_pair(mid + 1, end));
            }
            int mid = partition(arr, start, end + 1);
        }
        cout<<"splitting 2\n";
        bool flag = true;
        while (split.size() < numprocs - 1 && flag)
        {
            flag = false;
            for (int j = 0; j < split.size() && split.size() < numprocs; i++)
            {
                start = split.front().first;
                end = split.front().second;
                split.pop();
                if (start >= end - 1)
                {
                    split.push(make_pair(start, end));
                }
                else
                {
                    int mid = partition(arr, start, end);
                    if (start < mid - 1)
                        split.push(make_pair(start, mid - 1));
                    if (mid + 1 < end)
                        split.push(make_pair(mid + 1, end));
                    flag = true;
                }
            }
            int mid = partition(arr, start, end + 1);
        }
        i = 1;
        pair<int, int> ele;
        cout<<"sending ...\n";
        while(split.size()>0)
        {
            ele = split.front();
            temp.push(ele);
            split.pop();
            if (ele.first < ele.second)
            {
                i++;
                coun = ele.second - ele.first + 1;
                MPI_Send(&coun, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
                MPI_Send(&arr[ele.first], coun, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
        }
        while (i < numprocs)
        {
            coun = 0;
            MPI_Send(&coun, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        i = 1;
        while(temp.size()>0)
        {
            ele = temp.front();
            temp.pop();
            if (ele.first < ele.second)
            {
                i++;
                coun = ele.second - ele.first + 1;
                MPI_Recv(&arr[ele.first], coun, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    }
    else
    {
        start = 0;
        MPI_Recv(&end, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        cout<<rank<<" : "<<end<<endl;
        if (end > 1)
        {
            arr.resize(end);
            MPI_Recv(&arr, end, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quicksort(arr, start, end - 1);
            cout << "i : " << rank << " : ";
            for (int i = 0; i < end; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
            MPI_Send(&arr, coun, MPI_INT, 0, rank, MPI_COMM_WORLD);
        }
    }
    if (rank == 0)
    {
        printf("Sorted List\n");
        for (int i = 0; i < n; i++)
        {
            printf("%d, ", arr[i]);
        }
        printf("\n");
        string out = to_string(arr[0]);
        for (int i = 1; i < n; i++)
        {
            out += " " + to_string(arr[i]);
        }
        cout << out << endl;
    }
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
