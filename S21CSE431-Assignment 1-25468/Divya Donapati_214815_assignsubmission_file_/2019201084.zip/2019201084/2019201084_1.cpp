/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{
  int rank, numprocs;

  /* start up MPI */
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  /*synchronize all processes*/
  MPI_Barrier(MPI_COMM_WORLD);
  double tbeg = MPI_Wtime();

  /* write your code here */

  int N = 0;
  if (rank == 0)
  {
    string input;
    ifstream inpFile(argv[1]);
    getline(inpFile, input);
    N = atoi(input.c_str());
    inpFile.close();
    // cout<<"N "<<N<<endl;
  }
  MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

  long double result = 0.0L, final_result = 0.0L;

  if (rank != 0)
  {
    numprocs--;
    for (long long unsigned int i = rank; i <= N; i += numprocs)
    {
      result += (1.0 / (i * i));
      // if(rank==1 && i%10000==0)
      // printf("%llu : result is %Lf\n", i, result);
    }
    //  printf("%d : result is %Lf\n", rank, result);
  }

  MPI_Reduce(&result, &final_result, 1, MPI_LONG_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

  if (rank == 0)
  {
    ofstream outFile(argv[2]);
    outFile << std::fixed;
    outFile << std::setprecision(6);
    outFile << final_result;
    outFile.close();
    // printf("Result is %.6Lf   %Lf\n", final_result, final_result);
  }
  MPI_Barrier(MPI_COMM_WORLD);
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (rank == 0)
  {
    printf("Total time (s): %f\n", maxTime);
  }

  /* shut down MPI */
  MPI_Finalize();
  return 0;
}
