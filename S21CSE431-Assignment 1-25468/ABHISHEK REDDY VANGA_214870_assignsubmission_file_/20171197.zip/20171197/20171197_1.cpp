#include <bits/stdc++.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>

using namespace std;

float calculate(float start, float end)
{
    float ans=0;
    for(float i=start;i<=end;i++)
    {
        ans+=(1/(i*i));
    }
    return ans;
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    srand(time(NULL));
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    enum role_ranks { SENDER, RECEIVER }; 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    
    ifstream input;
    input.open(argv[1]);
    int n;
    string data;
    input >> data;
    n = stoi(data);
    input.close();

    float pie = 0;
    //int n;
    //cin >> n;
    int start,end;

    if(rank == 0) {
    	int part=1;
        if(n>size){
            part = n/size;
        }

        if(size==1)
        {
            for(float i=1;i<=n;i++){
                pie = pie+(1/(i*i));
            }
        }
        else
        {
            pie = 1;
            if(part==1)
            {
                for(float i=1;(int)i<size;++i){
                    if((int)i>=n){
                        start = i+1;
                        end = i;
                    }
                    else
                    {
                        start = i+1;
                        if(i==size-1)
                        {
                            end = n;
                        }
                        else
                        {
                            end = i+1;
                        }  
                    }
                    MPI_Send(&start, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                    MPI_Send(&end, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                }
            }
            else
            {
                end = 1;
                for(float i=1;(int)i<size-1;i++){
                    start = end+1;
                    end = (((int)i + 1)*part);
                    MPI_Send(&start, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                    MPI_Send(&end, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                }
                start = end+1;
                end = n;
                MPI_Send(&start, 1, MPI_FLOAT, size-1, 0, MPI_COMM_WORLD);
                MPI_Send(&end, 1, MPI_FLOAT, size-1, 0, MPI_COMM_WORLD);
            }
        }
        for(int i=1;i<size;++i){
            float ans = 0;
            MPI_Recv(&ans, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            pie += ans;
        }
        //cout << std::fixed << std::setprecision(6) << pie << endl;
        ofstream out;
        out.open(argv[2]);
        out << fixed << setprecision(6) << pie <<endl;
        out.close();
    }
    else
    {
	    MPI_Recv(&start, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&end, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        float ans = calculate(start,end);
        MPI_Send(&ans, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    MPI_Finalize(); 
    return EXIT_SUCCESS;
}