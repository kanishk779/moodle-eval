## Problem 1 : Sum of inverted squares
- We split the numbers to different processes by calculating part = n/size.
- All the remaining numbers will be sent to the last process.
- We send the start and end value of these numbers and recieve the answer.
- Final value is calculated by adding these answers.

# Execution :  
- mpic++ 20171197_1.cpp
- mpirun -np <no.of processes> --oversubscribe <input-file> <output-file> 


## Problem 2 : Parallel Quicksort
- All the processes split the items between them.
- Each process does inbuilt qsort on these items.
- Then all the data is got to zeroeth process and put into a 2D vector.
- The first smallest elements of all sorted arrays are sent to the heap as a tuple <value,procId (same as row number)>.
- The heap pops out minimum elemnents one by one, after every pop, it tries to get one input from the 2D vectors.
- By the time heap is empty, all elements are sorted which are output to the output file.

# Execution :
- mpic++ 20171197_2.cpp
- mpirun -np <no.of processes> --oversubscribe <input-file> <output-file> 
