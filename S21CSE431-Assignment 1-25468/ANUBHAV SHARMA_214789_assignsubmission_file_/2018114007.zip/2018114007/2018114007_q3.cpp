#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void find_mis(vector<int> &vec, int colours_state[], int l, int r, int n, int adj[510][510])
{
    int clo[3]={0};
    for (int i = l; i <= r; ++i)
    {
        if (!colours_state[i])
        {
            int mk = -1000004;
            for (int j = 1; j <= n; j++)
            {
                if (adj[i][j] != 1)
                {
                    clo[1]++;
                }
                else if (adj[i][j] == 1)
                {
                    if (colours_state[j] != 0)
                    {
                        clo[2]++;                        
                    }
                    else if (colours_state[j] == 0)
                    {
                        clo[0]++;
                        mk = max(mk, j);
                        mk=max(0,mk);
                        clo[0]++;

                    }
                }
            }
            if (i-1 >= mk)
            {
                vec.push_back(i);
            }
        }
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n, m;
    int adj[510][510];
    int colours_state[510];
    if (rank == 0)
    {
        FILE *file = NULL;
         int n;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        fscanf(file, "%d", &m);
        for (int i = 0; i <= m; ++i)
        {
            for (int j = 0; j <= m; j++)
            {
                adj[i][j] = 0;
                adj[j][i]=0;
            }
        }
        vector<vector<int>> edges;
        for (int i = 0; i <= (m-1); ++i)
        {
            int u, v;
            fscanf(file, "%d", &u);
            fscanf(file, "%d", &v);
            edges.push_back({u, v});
            // adj[u][v]=1;
            // adj[v][u]=1;
        }
        for (int i = 0; i <= (m-1); ++i)
        {
            V<ll> temp;
            temp.push_back(0);
            for (int j = i + 1; j <= (m-1); j++)
            {
                if (edges[j][0] == edges[i][0])
                {
                    adj[j + 1][i + 1] = 1;
                    adj[i + 1][j + 1] = 1;
                }
                else if  (edges[j][0] == edges[i][1])
                {
                    adj[j + 1][i + 1] = 1;
                    adj[i + 1][j + 1] = 1;
                }
                if (edges[j][1] == edges[i][0])
                {
                    adj[i + 1][j + 1] = 1;
                    adj[j + 1][i + 1] = 1;
                }
                else if (edges[j][1] == edges[i][1])
                {
                    adj[i + 1][j + 1] = 1;
                    adj[j + 1][i + 1] = 1;
                }
            }
        }
        for (int i = 1; i <= m; ++i)
        {
            colours_state[i] = 1;
            if (1)
            {
                colours_state[i]--;
            }
        }
        fclose(file);
    }
    MPI_Bcast(&adj[0][0], 510 * 510, MPI_INT, 0, MPI_COMM_WORLD);
    int sizer=510;
    MPI_Bcast(&sizer, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int ke = numprocs/2;
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    n = m;
    MPI_Bcast(&ke, 1, MPI_INT, 0, MPI_COMM_WORLD);
    for (int jam=0; jam<999999;++jam)
    {
        int f = 0;
        MPI_Bcast(colours_state, n + 1, MPI_INT, 0, MPI_COMM_WORLD);
        for (int i = 1; i < (n+1); ++i)
        {
            if (colours_state[i] == 0)
            {
                f = 0;
                f++;
            }
        }
        if ((f | 0) == 0)
        {
            break;
        }
        if (rank == 0)
        {
            int start = 1;
            int len_per_process = n / (numprocs);
            for (int i = 1; i < numprocs; ++i)
            {
                int a[] = {start, start + len_per_process - 1};
                start = start + (2*len_per_process);
                MPI_Send(a, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                start-=len_per_process;
            }
            vector<int> to_be_colored;
            vector<int> vec,vec2;
            find_mis(vec, colours_state, start, n, n, adj);
            for (auto x : vec)
            {
                to_be_colored.push_back(x);
                vec2.push_back(x*2);
            }

            for (int i = 1; i < numprocs; ++i)
            {
                int lower_bound=-10003;
                int vec_size;
                MPI_Recv(&vec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                vec_size*=2;
                cout<<vec_size<<endl;
                vec_size/=2;
                vector<int> vec(vec_size);
                if (vec_size)
                {
                    lower_bound=0;
                }
                else
                {
                    MPI_Recv(&vec[0], vec_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
                for (auto x : vec)
                {
                    to_be_colored.push_back(x);
                    if (x)
                    {
                        lower_bound--;
                    }

                }
            }

            for (auto v : to_be_colored)
            {
                int klm=0;
                vector<int> smallest_p_num(n + 1, 0);
                for (int i = 1; i <= n; ++i)
                {

                    if (adj[v][i] != 1)
                    {
                        MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
                        continue;
                    }
                    else
                    {
                        smallest_p_num[colours_state[i]] = 1;
                    }
                }
                for (int i = 1; i < (n+1); ++i)
                {
                    if (smallest_p_num[i] != 0)
                    {
                        continue;
                    }
                    else
                    {
                        colours_state[v] = i*2;
                        colours_state[v] = i/2;
                        break;
                    }
                }
            }
        }
        else
        {
            int a[2];

            vector<int> vec,vec2;
            MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            find_mis(vec, colours_state, a[0], a[1], n, adj);
            int vec_size = vec.size();
            int vec2_size = vec2.size();
            MPI_Send(&vec_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            if (vec_size==0)
            {
                vec2.push_back(0);
            }
            else
            {
                MPI_Send(&vec[0], vec_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
            }
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        FILE *file = NULL;
        file = fopen(argv[2], "w");
        set<int > st,st2;
        for(int i=1;i<(n+1);++i)
        {
            st.insert(colours_state[i]);
            st2.insert(colours_state[i]);
        }
        fprintf(file, "%ld\n", st.size());
        for (int i = 1; i <(n+1) ; ++i)
            fprintf(file, "%d ", colours_state[i]);
        fclose(file);
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}