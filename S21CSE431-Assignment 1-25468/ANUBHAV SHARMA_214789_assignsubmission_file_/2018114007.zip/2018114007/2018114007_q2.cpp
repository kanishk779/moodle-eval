/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int compare(const void * a, const void * b) 
{ 
    return ( *(int*)a - *(int*)b ); 
}
void swap(int* a, int* b)  
{  
    int t = *a;  
    *a = *b;  
    *b = t;  
}  
  
int partition (int arr[], int low, int high)  
{  
    int pivot = arr[high];   
    int i = low;
    i-=1  ; 
  
    for (int j = low; j <= high - 1; j++)  
    {    
        if (arr[j] < pivot)  
        {  
            i++;   
            swap(&arr[i], &arr[j]);  
        }  
    }  
    swap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}  
  

void quickSort(int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        int pi = partition(arr, low, high);   
        quickSort(arr, low, pi - 1);  
        quickSort(arr, pi + 1, high);  
    }  
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) 
    {
        printf( "Total time (s): %f\n", maxTime );
        int N;
        //cin>>N;
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> N;
        int arr_i[N+4];
        vector<queue<int>>arr_f(numprocs);
        //int arr_f[numprocs][(N/numprocs)+(N%numprocs)];
        // for (int i=0;i<numprocs;++i)
        // {
        //     for (int j=0; j< (N/numprocs)+(N%numprocs) ; ++j)
        //     {
        //         arr_f[i][j]=-1000003;
        //     }
        // }

        int arr_te[(N/numprocs)+(N%numprocs)];
        for (int i=0; i< N ; ++i)
        {
            input_file >>arr_i[i];
            if (i<(N/numprocs)+(N%numprocs))
            {
                arr_te[i]=arr_i[i];
            }
        }
        input_file.close();
        quickSort(arr_te,0,(N/numprocs)+(N%numprocs)-1);
        for (int i=0; i<(N/numprocs)+(N%numprocs) ; ++i)
        {
            cout<<"the sorted array in rank 0 is here "<<arr_te[i] <<endl;
            arr_f[0].push(arr_te[i]);
        }
        for (int i=1; i< numprocs;++i)
        {
            MPI_Send(&N, 1, MPI_INT, i,0, MPI_COMM_WORLD);
            MPI_Send( arr_i + (i*(N/numprocs)) + (N%numprocs)  ,(N/numprocs)  , MPI_INT, i,1, MPI_COMM_WORLD);
        }
        for (int i=1; i< numprocs;++i)
        {
            int arr[N/numprocs];
            MPI_Recv(arr,N/numprocs , MPI_INT, i, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (int j=0; j< N/numprocs ; ++j)
            {
                cout<<"in rank 0 , got the process from rank  "<<i << "and the value is "<<arr[j]<<endl;
                arr_f[i].push(arr[j]);
            }
        }
        // for (int i=0;i<numprocs;++i)
        // {
        //     for (int j=0; j< (N/numprocs)+(N%numprocs) ; ++j)
        //     {
        //         cout<<arr_f[i].front()<<" ";
        //     }
        //     cout<<"\n";
        // }
        int answer[N+4];
        int k = 0 ;
        priority_queue <pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>> > pq;
        for (int i=0; i< numprocs;++i)
        {
            if (arr_f[i].empty()!=true)
            {
                pq.push(make_pair(arr_f[i].front(), i));
                arr_f[i].pop();
            }
        }
        while(k<N)
        {
            answer[k]=pq.top().first;
            k+=1;
            int index = pq.top().second;
            pq.pop();
            if (arr_f[index].empty()!=true)
            {
                pq.push(make_pair(arr_f[index].front(), index));
                arr_f[index].pop();
            }
        }
        for (int i=0; i< N ; ++i)
        {
            printf("The element number %d in final sorted array is %d\n",i, answer[i]);
        }
        ofstream outfile(argv[2]);
        for(int i = 0; i < N; i++) {
            outfile << answer[i];
            outfile << " ";
        }
        outfile.close();
        
    }
    else
    {
        int N;
        MPI_Recv(&N, 1, MPI_INT, 0, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int arr[N/numprocs];
        MPI_Recv(arr,N/numprocs , MPI_INT, 0, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        for (int i=0; i< N/numprocs ; ++i)
        {
            cout<<"HERE in rank "<<rank<<" "<<arr[i]<<endl;
        }
        quickSort(arr,0,(N/numprocs)-1);
        MPI_Send( arr,(N/numprocs)  , MPI_INT, 0,2, MPI_COMM_WORLD);
        printf("%d in else , in process %d \n",N , rank);

    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}