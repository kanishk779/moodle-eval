/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) 
    {
        printf( "Total time (s): %f\n", maxTime );
        fstream input_file;
        input_file.open(argv[1], ios::in);
        int N;
        input_file >> N;
        input_file.close();
        //Initialising the double to store the final answer
        double local_sum=double(0);
        for (int i=1 ; i<=(N/numprocs);++i)
        {
            local_sum+=(double(1)/double(i*i));
        }
        //Sending the input number to each process in the communicator
        for (int i=1; i< numprocs;++i)
        {
            MPI_Send(&N, 1, MPI_INT, i,0, MPI_COMM_WORLD);
        }
        for (int i=1; i< numprocs;++i)
        {
            double proc_ans=double(0);
            MPI_Recv(&proc_ans, 1, MPI_DOUBLE, i, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            local_sum+=proc_ans;
            printf("from rank %d , updated local sum is %lf \n",i , local_sum);
            //MPI_Recv(&te, 1, MPI_INT, 0, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        ofstream outfile(argv[2]);
        outfile <<  fixed << setprecision(6) <<local_sum;
        outfile.close();
        printf("%lf in main\n ", local_sum);

    }
    else
    {
        //cout<<"heythere";
        int N;
        MPI_Recv(&N, 1, MPI_INT, 0, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("%d in else , in process %d \n",N , rank);
        if (rank!=numprocs-1)
        {
            double local_sum=double(0);
            for (int i=(rank*(N/numprocs)) +1 ; i<=(rank+1)*(N/numprocs) ;++i)
            {
                local_sum+=(double(1)/double(i*i));
            }
            MPI_Send(&local_sum, 1, MPI_DOUBLE, 0,rank, MPI_COMM_WORLD);
            printf("%lf , not in the last iteration\n" , local_sum);
        }
        else
        {
            double local_sum=double(0);
            for (int i=(rank*(N/numprocs)) +1 ; i<=((rank+1)*(N/numprocs))+(N%numprocs) ;++i)
            {
                local_sum+=(double(1)/double(i*i));
            }
            MPI_Send(&local_sum, 1, MPI_DOUBLE, 0,rank, MPI_COMM_WORLD);
            printf("%lf , not in the last iteration\n" , local_sum);
        }
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}