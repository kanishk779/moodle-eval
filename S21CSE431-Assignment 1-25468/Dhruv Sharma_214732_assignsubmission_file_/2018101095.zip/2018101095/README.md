# Distributed Systems Assignment 1
## MPI Programming

### Problem 1
- **Description**:
We have to take sum N times, so we divide N by the number of processes available (also taking care of the remainder) and then each process parallely sums only the range given to it, and then we sum the results of all the individual processes and write it to output file.
- **Analysis**:
    - For N = 2
        - if np = 1 - Total time (s): 0.000030
        - if np = 11 - Total time (s): 0.000183
    - For N = 10000:
        - if np = 1 - Total time (s): 0.000223
        - if np = 11 - Total time (s): 0.000190
    - It is obvious that time will increase almost monotically with increase in N.
    - A but surprising result is that the more the number of processes, the more time it takes which is counter-intutive. But, it can be justified as the overhead of sending and receiving from processes is more than the time it takes to compute the very simple sum. Hence the time increases.

---

### Problem 2
- **Description**:
    - We have sort the array using parallel quick sort. So we divide the array almost equally into m-1 parts, and give the remainder elements to the last part. Then each process parallely sorts their portion of the array using quicksort and sends the sorted array back to the root process. Then the root process uses k-way merge technique to merge the sorted blocks. In k-way merge, we use a min heap and initially insert the smallest elements of each block into the heap. Then we take the min out of these and remove it from the heap and add the next smallest element of the block, from which the element was removed, into the heap. We continue this untill we get a sorted list of n elements.
    - **Note** that it is assumed that all the elements of the array fit into the integer datatype. Since, no constraints on the range of the values of elements were given, it was safe to assume that.
- **Analysis**:
    - For N = 10 and array elements randomly initialized
        - if np = 1 - Total time (s):  0.000125
        - if np = 6 - Total time (s): 0.000070
        - if np = 11 - Total time (s): 0.000165
    - For N = 10000 and array elements randomly initialized
        - if np = 1 - Total time (s): 0.005347
        - if np = 6 - Total time (s): 0.003297
        - if np = 11 - Total time (s): 0.004715
    - For N = 1000000 and array elements randomly initialized
        - if np = 1 - Total time (s): 0.311143
        - if np = 6 - Total time (s): 0.209196
        - if np = 11 - Total time (s): 0.341502
    - It is obvious that time will increase almost monotically with increase in N
    - Parallelising too much can also increase the time, here till n = 6 the time was decreasing and parallelising was beneficial but after that time increased with increasing the number of parallel processes.

---

### Problem 3
- **Description**:
    - We want a valid edge coloring of the graph in no more than delta + 1 colors, where delta is the maximum of the degrees of all the vertices in the original graph or the line graph. We convert the problem into finding a valid vertex coloring of the line graph of the original graph, which is equivalent to finding the edge coloring of the original graph.
    - A line graph was obtained by considering edges as vertices in the new graph and common vertices as edges 
    - In each iteration, we find all those vertices that are the maximum (which was considered to be their index or the order in which they came) amongst their uncolored neighbors. They will form an independent set.
    - Since they form an independent set, we can color them parallely without any contradiction.
    - To color each node, we take the minimum color which has not been yet assigned to any of its colored neighbors.
    - To parallelize this even further, the root process will not find the independent set. Instead, that task is divided with each process where each process finds an independent set from the nodes in it's range.
    - Repeat this until all nodes are colored.
- **Analysis**:
    - For N = 10, M = 25 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.000142
        - if np = 6 - Total time (s): 0.001943
        - if np = 11 - Total time (s): 0.003222
    - For N = 50, M = 100 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.000092
        - if np = 6 - Total time (s): 0.001540
        - if np = 11 - Total time (s): 0.003268
    - For N = 100, M = 500 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.000079
        - if np = 6 - Total time (s): 0.001726
        - if np = 11 - Total time (s): 0.003208
    - It is obvious that time will increase almost monotically with increase in N and M.
    - When there are less number of nodes and edges in the graph, the overhead of sending the large adjacency matrix and all the other supporting arrays and values is larger and hence the time increases with the increase in the number of processes.
    - Even though time should increase as a general rule of thumb, since the test cases were generated randomly, it is not shown in the above values.
    - When the number of nodes and edges start to increase, we see that the time reduces till some number of processes and then it starts increasing again. Parallelization does improve the time taken, but it may also happen that exchange of information among processes in parallel computing increasing the time for short programs.

---

### Assignment by
- Tanish Lad (2018114005)
