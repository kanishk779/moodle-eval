/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int compvar(const void *one, const void *two)
{
    int a = *((int*)one);
    int b = *((int*)two);
    if (a<b)
       return -1;
    if (a == b)
       return 0;
    return 1;   

}
    int buffer[1000002];

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );
    // MPI_Comm comm = MPI_COMM_WORLD;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int size = numprocs;
    int n;
    // int reduction_result = 0;
    int root_rank = 0;
    int sz = 0;
        // cout<<rank;
    if(rank == 0)
    {

        fstream file;
        file.open(argv[1], ios::in);
        file>>n;
        for(int i=0;i<n;i++)
            file>>buffer[i];
        // buffer[n] = n;
        sz = n;
        file.close();
        // cout<<size<<endl;
        // for(int i=0;i<=n;i++)
            // cout<<buffer[i]<<" ";
    }
    MPI_Bcast(&sz,1,MPI_INT,root_rank,MPI_COMM_WORLD);
    MPI_Bcast(&buffer,sz,MPI_INT,root_rank,MPI_COMM_WORLD);
    int len[size];
    for(int i=0;i<size-1;i++)
    {
        len[i] = buffer[sz]/(size-1);
    }
    int xx = (size==1) ? 0 : (sz/(size-1)) * (size-1);
    len[size-1] = max(0, sz - xx);
    int ptr[size];
    if(size!=1)
    for(int i=0, j=0;j<size;i+=sz/(size-1),j++)
        ptr[j] = i;
    else
        ptr[0] = 0;
    int received[len[0]];
    if(rank!=0)
    {
        vector <int>  temp(len[rank]+1);
        for(int i = ptr[rank]; i < len[rank]+ptr[rank]; i++)
        {   
            temp[i-ptr[rank]] = buffer[i];
        }
        qsort(&temp[0], len[rank], sizeof(int), compvar);
    // printf("%d \n", len[rank]);
        MPI_Send(&temp[0], len[rank], MPI_INT, 0, 0, MPI_COMM_WORLD);
    // printf("%d \n", rank);
    }
    else
    {
        vector <int> temp(len[rank]+1);
        for(int i=ptr[0];i<ptr[0]+len[0];i++)
            temp[i-ptr[0]] = buffer[i];
        qsort(&temp[0], len[0], sizeof(int), compvar);
        for(int i=ptr[0];i<ptr[0]+len[0];i++){
            buffer[i] = temp[i-ptr[0]];
            // cout<<buffer[i]<<" ";
        }
        // cout<<endl;
    }
    // printf("%d \n", rank);
    // MPI_Barrier( MPI_COMM_WORLD );
    // printf("%d \n", rank);

    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {

        for(int i=1;i<size;i++)
        {
            MPI_Recv(&received[0], len[i], MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            // cout<<ptr[i]<<" "<<ptr[i]+len[i]<<": ";
            for(int j=ptr[i];j<ptr[i]+len[i];j++)
            {
                buffer[j] = received[j-ptr[i]];
                // cout<<buffer[j]<<" ";
            }
            // cout<<endl;
        }
        // for(int i=0;i<n;i++)
            // printf("%d ", buffer[i]);
        // cout<<endl;
        int lol = len[size-1];
        for(int i=0;i<size;i++)
            len[i] = len[i]+ptr[i];
        std::priority_queue <pair<int, int>, vector<pair<int, int>>, greater<pair<int, int> > >  pq;
        vector <int> ans(sz);
        for(int i=0;i<size;i++)
        {
            if(ptr[i]<len[i])
            {
                pq.push(make_pair(buffer[ptr[i]], i));
                ptr[i]++;
            }
        }
        while(!pq.empty())
        {
            ans.push_back(pq.top().first);
            // if(pq.top().second==size-1)
                // cout<<pq.top().first<<" ";
                int l1 = pq.top().second;
                pq.pop();
            if(ptr[l1] < len[l1])
            {
                pq.push(make_pair(buffer[ptr[l1]], l1));
                ptr[l1]++;
            }
        }
        // for(auto j: ans)
            // cout<<j<<" ";
        // printf("%d \n", sz);
        printf( "Total time (s): %f\n", maxTime );
            for(int i=0;i<lol;i++)
            {
                int t2 = ans[i];
                ans[i] = ans[sz+i-lol];
                ans[sz+i-lol] = t2;
            }

        // printf("%.6f\n", reduction_result);
        ofstream file1(argv[2]);
        // char ans[40];
        // sprintf(ans, "%.6f\n", reduction_result);
        // cout << ans << endl;
        for(auto j: ans){
        file1 << j;
        file1 << " ";
    }
        file1.close();
        // double et = MPI_Wtime() - tbeg;
        // printf( "Total time (s): %f\n", et );
        /* shut down MPI */
    }
    MPI_Finalize();
    return 0;
}