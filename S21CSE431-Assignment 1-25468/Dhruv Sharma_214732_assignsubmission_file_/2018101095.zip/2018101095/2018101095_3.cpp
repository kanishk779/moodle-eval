/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
int n, m;
map < ll, pair<ll, ll> > edges;
int mat[501][501];
int color[501];
int color1[501];
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );
    // MPI_Comm comm = MPI_COMM_WORLD;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int size = numprocs;
    int root_rank = 0;
    int sz;
    // int mark[size];
    // for(int i=0;i<size;i++)
        // mark[i] = 0;
    if(rank == 0)
    {

        fstream file;
        file.open(argv[1], ios::in);
        file>>n;
        file>>m;

        for(int i=0;i<m;i++)
        {
            int x,y;
            file>>x;
            file>>y;
            if(x<y)
            edges[i+1] = mp(x,y);
            else
            edges[i+1] = mp(y,x);
        }
        sz = m;
        for(int i=1;i<=m;i++)
        {
            for(int j=1;j<=m;j++)
            {
                if(i!=j)
                {
                    pair <ll, ll> k1 = edges[i];
                    pair <ll, ll> k2 = edges[j];
                    if(k1.ff==k2.ff||k1.ff==k2.ss||k1.ss==k2.ff||k1.ss==k2.ss){
                        mat[i][j] = 1;
                        mat[j][i] = 1;
                    }
                }
            }
        }
        file.close();
    }
    
    MPI_Bcast(&sz,1,MPI_INT,root_rank,MPI_COMM_WORLD);
    MPI_Bcast(&mat,(501)*(501),MPI_INT,root_rank,MPI_COMM_WORLD);
    vector <int> nodes;
    int sooz[size];
    for(int i = sz/size * (rank) + 1; i <= sz/size * (rank + 1); i++)
    {
        nodes.pb(i);
    }
    for(int i=0;i<size;i++)
    {
        sooz[i] = sz/size;
    }
    for(int i = 1; i <= sz%size; i++)
    {
        if(i==rank+1)
        {
            nodes.pb(i+(sz/size * size));
        }
        sooz[i-1]++;
    }
    while(1)
    {
        vector <int> left;
        vector <int> dhamaka;
        for(auto j: nodes)
        {
            if(color[j]==0)
            {
                left.pb(j);
                // cout<<rank<<" "<<j<<endl;
            }
        }
            for(auto j: left)
            {
                int fl = 0;
                for(int i=1;i<=sz;i++)
                {
                    if(i==j)
                        continue;
                    if(mat[i][j]==1&&color[i]==0&&i>j)
                    {
                        fl = 1;
                        break;
                    }   
                }
                if(fl==0)
                {
                    dhamaka.pb(j);
                    // if(rank==2)
                    // cout<<j<<endl;
                }
            }
            for(auto j: dhamaka)
            {
                // cout<<rank<<" "<<j<<endl;
                set <int> ss;
                for(int i=1;i<=sz;i++)
                {
                    if(i==j)
                        continue;
                    if(mat[i][j]==1&&color[i]!=0)
                    {
                        ss.insert(color[i]);
                    }
                }
                int pt = 1;
                int ff = 0;
                for(auto j1: ss)
                {
                    if(j1==pt)
                        pt++;
                    else{
                        color[j] = pt;
                        ff = 1;
                        break;
                    }
                }
                if(ff==0)
                    color[j] = pt;
            }
            for(int i=0;i<=sz;i++)
            {
                color1[i] = color[i];
            }
            for(int i=0;i<size;i++)
            {
                MPI_Bcast(&color1,sz+1,MPI_INT,i,MPI_COMM_WORLD);
                set <int> ss;
                for(int i=1;i<=sz;i++)
                {
                    color[i] = max(color[i], color1[i]);
                    color1[i] = color[i];
                }
            }
            int f = 0;
            for(int i=1;i<=sz;i++)
            {
                // cout<<color[i]<<" ";
                if(color[i]==0)
                    f = 1;
            }
            // cout<<endl;
            if(!f)
                break;
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {

        printf( "Total time (s): %f\n", maxTime );
        int ans = 0;
        for(int i=1;i<=m;i++){
            ans = max(ans, color[i]);
            // cout<<color[i]<<" ";
        }
        cout<<endl;
        // printf("%.6f\n", reduction_result);
        ofstream file1(argv[2]);
        file1 << ans;
        file1 <<endl;
        for(int i=1;i<=sz;i++){
            file1 << color[i];
            file1 <<" ";
        }
        file1.close();
        /* shut down MPI */
    }
    MPI_Finalize();
    return 0;
}