# Assignment 1, MPI Programming
## Reciprocal Sqaure Sum
Uses the numerical identity that the sum of the reciprocals of the squares of integers converges to ![equation](https://latex.codecogs.com/gif.latex?\frac{\pi^2}{6}) for estimating the numerical value of ![equation](https://latex.codecogs.com/gif.latex?\frac{\pi^2}{6}).
* **Input** - An integer N denoting the number of terms in the series that the program has to use.
* **Output** - A floating point number, denoting the estimated value of ![equation](https://latex.codecogs.com/gif.latex?\frac{\pi^2}{6}) rounded off to six decimal places.
* **Process** - For parallel programming, we will divide the set of n numbers among the processes and then compute the sum of reciprocal values for each set and then finally add them to get a floating point number.
* **Execution** -
- mpic++ 20171052_1.cpp
- mpirun -np <no.of processes> <input-file> <output-file>

## Quick Sort
Given an array of numbers, your task is to return the array in sorted order by implementing parallel quicksort.
* **Input** - The first line of input contains size of array N . The second line of input contains N space separated integers.
* **Output** - The output is a space separated sorted array.
* **Process** - For parallel programming, we execute it initially on a single process; then, when the algorithm performs its recursive calls we will assign one of the subproblems to another process. Now each of these processes sorts its array by using quicksort and assigns one of its subproblems to other processes. The algorithm terminates when the arrays cannot be further partitioned. Upon termination, each process holds an element of the array(in ideal case), and thus the array can be sorted in this manner. Here parallelizing the partitioning step makes the algorithm significantly faster.
* **Limitation** - Because of communication overhead in this parallel formulation, the partitioning step can takes longer time on realistic shared-address-space.
* **Execution** -
- mpic++ 20171052_2.cpp
- mpirun -np <no.of processes> <input-file> <output-file>
