#include <bits/stdc++.h>
#include <mpi.h>
using namespace std;

float calculate_sum(float start, float end){
    float temp = 0;
    while(start<=end){
        temp += (1/(start*start));
        start += 1;
    }
    return temp;
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    srand(time(NULL));
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    int each_process;
    float start,end;

    if(rank == 0) {
        int n;

        char input[200];
        strcpy(input,argv[1]);
        ifstream inFile;
    
        inFile.open(input);
        if (!inFile) {
            cout << "Unable to open file";
            exit(1); // terminate with error
        }
        
        inFile >> n;
    
        inFile.close();
        
        if(n > size) each_process = n/size;
        else each_process = 1;

        float ans = 0;
        for(float i=1; i<=each_process ; ++i) ans += (1/(i*i));

        if(size!=1){
            if(each_process==1){
                for(float i=1;(int)i<size;++i){
                    if((int)i>=n){
                        start = 1;
                        end = 0;
                    }
                    else if((int)i==(size-1)){
                        start = i+1;
                        end = n;
                    }
                    else{
                        start = i+1;
                        end = i+1;    
                    }
                    MPI_Send(&start, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                    MPI_Send(&end, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                }
            }
            else{
                for(float i=1;(int)i<size;++i){
                    if((int)i==(size-1)){
                        start = (((int)i)*each_process)+1;
                        end = n;
                    }
                    else{
                        start = (((int)i)*each_process)+1;
                        end = (((int)i + 1)*each_process);
                    }
                    MPI_Send(&start, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                    MPI_Send(&end, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
                }
            }
        }

        for(int i=1;i<size;++i){
            float temp = 0;
            MPI_Recv(&temp, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ans += temp;
        } 

        // cout << std::fixed;
        // cout << std::setprecision(6);
        // cout << ans << endl;

        char output[200];
        strcpy(output,argv[2]);
        ofstream outFile(output);
    
        if (!outFile) {
            cout << "Unable to open file";
            exit(1); // terminate with error
        }
        
        outFile << std::fixed;
        outFile << std::setprecision(6);
        outFile << ans;
        outFile << endl;
    
        outFile.close();

    }
    else{
        MPI_Recv(&start, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&end, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        float temp = calculate_sum(start,end);
        MPI_Send(&temp, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    	 
    MPI_Finalize(); 
    return EXIT_SUCCESS;
}