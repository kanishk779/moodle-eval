#include <bits/stdc++.h>
#include <mpi.h>
using namespace std;

int partition (int *arr, int low, int high)  
{  
    int pivot = arr[high];  
    int i = (low - 1); 
  
    for (int j = low; j <= high - 1; j++)  
    {  
        if (arr[j] < pivot)  
        {  
            i++; 
            int t = arr[i];
            arr[i] = arr[j];
            arr[j] = t;  
        }  
    }  
    int t = arr[i+1];
    arr[i+1] = arr[high];
    arr[high] = t;
    return (i + 1);  
} 

void quickSort(int *arr, int low, int high)  
{  
    if (low < high)  
    {  
        int pi = partition(arr, low, high);  
  
        quickSort(arr, low, pi - 1);  
        quickSort(arr, pi + 1, high);  
    }  
}  

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    srand(time(NULL));
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    int n;
    int arr[1000006];
    int pivot,l_sz,r_sz;

    if(rank == 0) {
        ifstream inFile;
    
        inFile.open(argv[1]);
        if (!inFile) {
            cout << "Unable to open file";
            exit(1); // terminate with error
        }
        
        inFile >> n;
        int ind = 0;

        for(int i=0;i<n;++i) inFile >> arr[ind++];
            
        inFile.close();

    }

    if(size==1){
        quickSort(arr,0,n-1);
    }
    else if(size==2){
        pivot = partition(arr, 0, n-1);
        if(rank) 
            quickSort(arr,0,pivot-1);
        else
            quickSort(arr,pivot+1,n-1);
    }
    else{
        if(rank == 0){
            pivot = partition(arr,0,n-1);
            l_sz = pivot;
            r_sz = n-1-l_sz;
            MPI_Send(&l_sz, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            MPI_Send(&arr[0], l_sz, MPI_INT, 1, 0, MPI_COMM_WORLD);

            MPI_Send(&r_sz, 1, MPI_INT, 2, 0, MPI_COMM_WORLD);
            MPI_Send(&arr[pivot+1], r_sz, MPI_INT, 2, 0, MPI_COMM_WORLD);

            MPI_Recv(&arr[0], l_sz, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(&arr[pivot+1], r_sz, MPI_INT, 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        else
        {
            int from = rank - 1;
            from /= 2;
            int sz;
            int temp[1003];
            MPI_Recv(&sz, 1, MPI_INT, from, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(&temp[0], sz, MPI_INT, from, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            // if(sz==1)
            // {
            //     MPI_Send(&temp[0], sz, MPI_INT, from, 0, MPI_COMM_WORLD);
            // }
            // else{
                if(sz == 0){
                    pivot = 0;
                    l_sz = 0;
                    r_sz = 0;
                }
                else
                {
                    pivot = partition(temp,0,sz-1);
                    l_sz = pivot;
                    r_sz = sz-1-l_sz;
                }
                
                int ltree = 2*rank + 1 ;
                int rtree = 2*rank + 2 ;

                if(ltree < size){
                    MPI_Send(&l_sz, 1, MPI_INT, ltree, 0, MPI_COMM_WORLD);
                    MPI_Send(&temp[0], l_sz, MPI_INT, ltree, 0, MPI_COMM_WORLD);
                    MPI_Recv(&temp[0], l_sz, MPI_INT, ltree, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
                else quickSort(&temp[0],0,l_sz-1);

                if(rtree < size){
                    MPI_Send(&r_sz, 1, MPI_INT, rtree, 0, MPI_COMM_WORLD);
                    MPI_Send(&temp[pivot+1], r_sz, MPI_INT, rtree, 0, MPI_COMM_WORLD);
                    MPI_Recv(&temp[pivot+1], r_sz, MPI_INT, rtree, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
                }
                else quickSort(&temp[pivot+1],0,r_sz-1);

                MPI_Send(&temp[0], sz, MPI_INT, from, 0, MPI_COMM_WORLD);

            // }
        }
    }

    if(rank==0){

        char output[200];
        strcpy(output,argv[2]);
        ofstream outFile(output);
    
        if (!outFile) {
            cout << "Unable to open file";
            exit(1); // terminate with error
        }
        
        for(int i=0;i<n;++i){
            outFile << arr[i];
            outFile << " ";
        }

        outFile << endl;
    
        outFile.close();

    }

    // cout << rank << endl;
    	 
    MPI_Finalize(); 
    return EXIT_SUCCESS;
}

        // else if(rank < size)
