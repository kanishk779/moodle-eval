#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char *argv[]) {
    // Unique rank is assigned to each process in a communicator
    // Total number of ranks
    int rank;
    int size;
    int n;
    double result = 0;
    // printf("value of n is %d\n",n);
    // Initializes the MPI execution environment
    MPI_Init(&argc, &argv);

    // Get this process' rank (process within a communicator)
    // MPI_COMM_WORLD is the default communicator
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    // Get the total number ranks in this communicator
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(rank==0){
        string word, filename; 
        fstream fil;
        // filename of the file 
        filename = argv[argc-2]; 
        // opening file 
        fil.open(filename.c_str()); 
        fil >> word;
        fil.close();
        stringstream str_int(word);
        str_int >> n;
        for(int i=1;i<size;i++)
            MPI_Send(&n, 1, MPI_INT, i, rank, MPI_COMM_WORLD);
    }
    else{
        MPI_Recv(&n, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
    }
    // Pack these values together into a string
    double temp_ans = 0;
    int start = (rank*n)/size;
    int end = ((rank+1)*n)/size;
    if(rank<size-1){
        for(int i=start+1;i<end+1;i++){
            // cout << rank << " " << i << "\n";
            temp_ans += (double)1/(i*i);
        }
    }
    else{
        for(int i=start+1;i<=n;i++){
            temp_ans += (double)1/(i*i);
        }
    }

    MPI_Allreduce(&temp_ans, &result, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    // Synchronize so we can remove interleaved output
    if (rank == 0) {
        ofstream myfile;
        myfile.open (argv[argc-1]);
        myfile << std::fixed << std::setprecision(6) << result;
        myfile.close();
    } 
    // else {
    //     // // If not rank zero, send your message to be printed
    //     // MPI_Send(&temp_ans, 1, MPI_DOUBLE, 0, rank, MPI_COMM_WORLD);
    // }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    // Terminate MPI execution environment
    MPI_Finalize();

}
