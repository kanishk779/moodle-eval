## Question1
Each process is assigned a consecutive range of n/p elements and perform sum operation of 1/(i*i). This sum from all processes has been added and written to the output file.
## Question2
Let A be an array of n elements that need to be sorted and p be the number of processes. Each process is assigned a consecutive block of n/p elements. Each process performs Quicksort independently on the block that it was assigned to.
Let K be the no of processes. We merge results of odd processes to even processes. Now we have k/2 arrays in even numbered processes. We repeat the above process again. The merging process has Log(K) recursion levels. We return the final array present in the root process(process with rank 0).
