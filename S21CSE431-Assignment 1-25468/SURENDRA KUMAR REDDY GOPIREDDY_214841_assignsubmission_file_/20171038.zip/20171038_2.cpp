#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<fstream>
#include <bits/stdc++.h>
#define max_rows 1123456
#define send_data_tag 1999
#define return_data_tag 2000
#define ll long long int

ll partition(ll arr[], ll l, ll r);
void quicksort(ll arr[], ll l, ll r);
void merge(ll a, ll b, ll *arr, ll *brr, ll *crr);

using namespace std;


void print_arr(ll *arr,ll a){
	for(int i=0;i<a;i++)
		cout << arr[i] << " ";
	
	cout << "\n";
}

int main(int argc, char **argv)
{
	ll sum, mysum;
	MPI_Status status;
	int my_id, n_procs;
	ll ierr, root, i, n=0;
	ll id, my_n, avg, chunksize;
	ll n_rec, l, r;
	ll* arr2;

	ierr = MPI_Init(&argc, &argv);
	root = 0;
	ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
	ierr = MPI_Comm_size(MPI_COMM_WORLD, &n_procs);

	    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

	if (my_id == root)
	{

		ifstream fin;
		fin.open(argv[1]);
		ll num;
        fin >> n;
		ll* arr = (ll*)malloc(n*sizeof(ll));
        int i = 0;
		while(fin>>num)
		{
			arr[i]=num;
			i++;
		}
		fin.close();

		avg = n/(ll)n_procs;

		// Distribute the elements 
		arr2=(ll*)malloc(avg*sizeof(ll));

		for (id=1;id<(ll)n_procs;id++)
		{
			l = id*avg;
			r = (id+1)*avg-1;

			if (id==n_procs-1) r = n-1;
			chunksize = r-l+1;

			ierr = MPI_Send(&chunksize, 1, MPI_LONG_LONG_INT, (int)id, send_data_tag, MPI_COMM_WORLD);
			ierr = MPI_Send(&arr[l], chunksize, MPI_LONG_LONG_INT, (int)id, send_data_tag, MPI_COMM_WORLD);
		}
		// Elements distributed. MPI_Recv with send_data_tag will be activated.

		for (i=0;i<avg;i++)
		{
			arr2[i] = arr[i];
		}
		my_n = avg;
		free(arr);
		// printf("this was process %d\n", my_id);
	}
	else
	{
		ierr = MPI_Recv(&my_n, 1, MPI_LONG_LONG_INT, 0, send_data_tag, MPI_COMM_WORLD, &status);
		arr2=(ll*)malloc(my_n*sizeof(ll));
		ierr = MPI_Recv(arr2, my_n, MPI_LONG_LONG_INT,0, send_data_tag, MPI_COMM_WORLD, &status);

	}

	MPI_Barrier(MPI_COMM_WORLD);

	quicksort(arr2,0,my_n-1);

	ll iter;
	for (iter=1;iter<(ll)n_procs;iter=iter<<1)
	{
		ll uskachunksize;
		if (my_id%(2*iter)!=0)
		{
			MPI_Send(&my_n, 1, MPI_LONG_LONG_INT, (ll)my_id-iter, (iter+return_data_tag), MPI_COMM_WORLD);
			MPI_Send(arr2, my_n, MPI_LONG_LONG_INT, (ll)my_id-iter, iter, MPI_COMM_WORLD);
			break;
		}
		else if (((ll)my_id + iter) < (ll)n_procs)
		{
			ierr = MPI_Recv(&uskachunksize, 1, MPI_LONG_LONG_INT, (ll)my_id + iter, (iter+return_data_tag), MPI_COMM_WORLD, &status);
			ll* brr = (ll*)malloc(uskachunksize*sizeof(ll));
			ierr = MPI_Recv(brr, uskachunksize, MPI_LONG_LONG_INT,(ll)my_id + iter, iter, MPI_COMM_WORLD, &status);
			ll* nrr = (ll*)malloc((uskachunksize+my_n)*sizeof(ll));
			merge(my_n, uskachunksize, arr2, brr, nrr);
			free(arr2);
			free(brr);
			arr2 = nrr;
			my_n+=uskachunksize;
			// continue;
		}
	}
	// printf("I, %d process, have reached Here!\n", my_id);
	MPI_Barrier(MPI_COMM_WORLD);

	    // MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if (my_id==0)
	{ 
		ofstream fout;
		fout.open(argv[2]);
		for (i=0;i<n;i++)
		{
			// printf("%lld ", arr2[i]);
			fout<<arr2[i]<< " ";
		}
		fout<<'\n';
		// printf("   <- Final Output, Exiting\n");
		fout.close();
        printf( "Total time (s): %f\n", maxTime );
		
	}

	ierr = MPI_Finalize();
	return 0;
}


void quicksort(ll arr[], ll l, ll r)
{
	if (l<r)
	{
		ll pivot = partition(arr,l,r);
		quicksort(arr, l, pivot-1);
		quicksort(arr, pivot+1,r);
	}
	return;
}

ll partition(ll arr[], ll l, ll r)
{
	ll a = arr[l];
	ll b = arr[(l+r)/2];
	ll c = arr[r];
	ll pivot;
	if ((a<=b) && (b<=c)) pivot = (l+r)/2;
	else if ((a<=c) && (c<=b)) pivot = r;
	else if ((b<=c) && (c<=a)) pivot = r;
	else if ((b<=a) && (a<=c)) pivot = l;
	else if ((c<=a) && (a<=b)) pivot = l;
	else if ((c<=b) && (b<=a)) pivot = (l+r)/2;
	ll temp = arr[pivot];
	arr[pivot] = arr[r];
	arr[r] = temp;
	ll i,small=l;
	for (i=l;i<r;i++)
	{
		if (arr[i]<arr[r])
		{
			temp = arr[small];
			arr[small] = arr[i];
			arr[i] = temp;
			small++;
		}
	}
	temp = arr[small];
	arr[small] = arr[r];
	arr[r] = temp;
	return small;
}

void merge(ll a, ll b, ll *arr, ll *brr, ll *crr)
{
	ll p,i,l=0,r=0;
	for(ll i=0;i<(a+b);i++)
	{
		if (l==a)
		{
			crr[i] = brr[r];
			r++;
			continue;
		}
		if (r==b)
		{
			crr[i] = arr[l];
			l++;
			continue;
		}
		if (arr[l]<=brr[r])
		{
			crr[i]=arr[l];
			l++;
			// i++;
		}
		else
		{
			crr[i]=brr[r];
			r++;
			// i++;
		}
	}
}