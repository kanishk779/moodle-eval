Problem 1

Use the numerical identity that the sum of the reciprocals of the squares of integers converges to
π2/6 .

Solution :

1. All the process are given some numbers to calculate part of the series.
2. Numbers which gives same remainder ( num % np ) on dividing from np are assigned to the same process.
3. Each process after calculating the partial series sum sends the result to the root process that is process with rank 0.
4. Root process then collects all the results and add them up to get the final sum and store the output file.
