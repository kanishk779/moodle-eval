/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int readInput(string filename)
{
    ifstream input;
    int n;
    input.open(filename);
    input>>n;
    input.close();
    return n;
}

void writeOutput(double result, string filename)
{
    ofstream output;
    output.open(filename);
    output << fixed << setprecision(6) <<result<<endl;
    output.close();
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/

    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */    
    int  n, j;
    double temp, result = 0, denom = 0, i;

    n = readInput(argv[1]);
    //cout<<n<<endl;
    i = rank; 
    while(i < n)
    {
        temp = (i+1)*(i+1);
        denom += 1/temp;
        i += numprocs;
    }

    if(rank == 0)
    {   
    result += denom;
    j = 1;
    while(j < numprocs)
    {
        MPI_Recv(&denom, 1,  MPI::DOUBLE, j, j%numprocs, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        result += denom;
        j++;
    }
        writeOutput(result, argv[2]);
    }
    else
        MPI_Send(&denom, 1,  MPI::DOUBLE, 0, rank, MPI_COMM_WORLD);
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
