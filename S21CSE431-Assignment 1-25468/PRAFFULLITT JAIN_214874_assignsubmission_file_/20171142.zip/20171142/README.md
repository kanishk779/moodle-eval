# Assignment-1
## MPI Programming

# How to run

On command line, type:
> mpic++ 20171142_x.cpp
> mpirun -np Y ./a.out input.txt output.txt
- x= 1, 2 or 3
- Y is the number of processes allowed
- input.txt contains the input
- output.txt will store the output

#### Problem-1

N = the number of terms in the series that your program has to use
: 2  <= N <= 10^4

p = number of processes 
: 1 <= p <= 11


- if N <= p, then we will simply each process for calculating each term.
- Otherwise, we distribute them as evenly as possible among the processes. Now, each process has to compute the summation of only N/p terms. 
- Example, if n=10 and p=4, then terms {1,2,3} are sent to process1, {4,5,6} to process2 and {7,8,9} to process3. The root process(process0) calculates term {10}. The children processes calculate their terms and send it to the root process where we add it to the global sum which will be stored in the output file.

#### Problem-2

N = size of array
: 2  <= N <= 10^6

p = number of processes 
: 1 <= p <= 11

- We distribute them as evenly as possible among the processes. Now, each process has to compute the summation of only N/p terms.
- The child processes send the sorted subarrays back to the root process.
- Then, in the root process, a p-way (p being the number of processes) merge was performed to obtain the sorted array.
- The result was stored in the output file.

#### Problem-3

N and M denoting the number vertices and edges of the graph
: 1<= N <= 100 and  1 <= M <= 500

p = number of processes 
: 1 <= p <= 11


### Analysis of time
- It was expected that as the number of processes increased the time taken to execute the tasks will decrease because of parallelization.
- It was observed that when the input size was very small, the time taken actually did not decrease which could be because of the overhead of actually creating so many processes.
- However with larger input size, parallelization will definitely benefit us because the time required for execution will decrease drastically.