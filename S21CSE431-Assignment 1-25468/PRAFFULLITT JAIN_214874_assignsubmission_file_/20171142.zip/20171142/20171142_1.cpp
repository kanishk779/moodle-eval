#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

float findInverseSquare(int input)  
{  
    return 1/pow(input,2);
}

int main( int argc, char **argv ) 
{
	int rank, p;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &p);

	if(rank == 0) 
	{
		ifstream input_file(argv[1]);
		string num; 
		input_file >> num;
		int n = stoi(num);

		int begin_num, end_num = 0;
		int div = n / p;
		int rem = n % p;

		for(int i = 1; i < p; i++) 
		{
			begin_num = end_num + 1;
			if (rem > 0)
			{ 
				end_num += div + rem;
			}
			MPI_Send(&begin_num, 1 , MPI_INT, i, 0, MPI_COMM_WORLD);
			MPI_Send(&end_num, 1 , MPI_INT, i, 0, MPI_COMM_WORLD);
			rem--;
		}

		float sum = 0;
		for(int i=end_num+1; i <= n; i++)
		{
			sum += findInverseSquare(i);
		}

		for(int i = 1; i < p; i++) 
		{
			float received_sum;
			MPI_Recv(&received_sum, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            sum += received_sum;
		}

		ofstream out_file(argv[2]);
		out_file << setprecision(7) << sum << endl;
	}
	else 
	{
		int begin_num, end_num;
		MPI_Recv( &begin_num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv( &end_num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        float child_sum = 0;

        for(int i=begin_num; i <= end_num; i++)
        {
        	child_sum += findInverseSquare(i);
        }

        MPI_Send( &child_sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Finalize();
	return 0;
}