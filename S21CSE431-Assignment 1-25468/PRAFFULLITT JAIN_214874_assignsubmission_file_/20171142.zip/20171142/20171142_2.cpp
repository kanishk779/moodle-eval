#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

int partition(int *A, int lo, int hi, int ind);
void quicksort(int *A, int lo, int hi, int ind); 
int lomuto_partition(int * A, int lo, int hi, int ind);
int sort_recursive(int* arr, int arrSize, int currProcRank, int maxRank, int rankIndex, int currInd);

const int MAX_SIZE = 10000;

int main(int argc, char *argv[]) {	
	
	int size, rank;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	int flag_count = 0; 
	
	int rankPower = 0;
	while (pow(2, rankPower) <= rank)
		rankPower++;

	if (rank == 0) 
	{
		ifstream input(argv[1]);
		int *numbers = (int *)malloc(MAX_SIZE * sizeof(int));
		int arraySize = 0;

		// Taking the input
		int count=0;
		input >> arraySize;

		while (input >> numbers[count] && count < MAX_SIZE)
		{
			count++;
		}
		// Actual parallel sorting
		sort_recursive(numbers, arraySize, rank, size - 1, rankPower, 0);

		// Writing the output
		ofstream output(argv[2]);
		if (output.is_open()) 
		{
			for (int i = 0; i < arraySize; i++)
				output << numbers[i] << " ";
			output.close();
		}
	}
	else 
	{
		MPI_Status status;
		int subarray_size;
		MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

		MPI_Get_count(&status, MPI_INT, &subarray_size);
		
		int source_process = status.MPI_SOURCE;
		int *subarray = (int*)malloc(subarray_size * sizeof(int));

		MPI_Recv(subarray, subarray_size, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		sort_recursive(subarray, subarray_size, rank, size - 1, rankPower, 0);
		MPI_Send(subarray, subarray_size, MPI_INT, source_process, 0, MPI_COMM_WORLD);
	}
	MPI_Finalize();
    return 0;
}

int lomuto_partition(int * A, int low, int high, int ind) {
	int pivot = A[high];
	int i = low - 1 + ind;
	for (int j = low; j < high; j++) {
		if (A[j] <= pivot) {
			i++;
			ind = 0;
			int temp = A[i];
			A[i] = A[j];
			A[j] = temp + ind;
		}
	}
	int temp = A[i + 1];
	A[i + 1] = A[high];
	A[high] = temp;
	return i + 1 - ind;
}

int partition(int *A, int low, int high, int ind) {
	int pivot = A[low];
	int i = low - 1 + ind;
	int j = high + 1 - ind;
	while (true) {
		do
			i = i + 1 + ind;
		while (A[i] < pivot);

		do
			j = j + ind - 1;
		while (A[j] > pivot);

		if (i >= j)
			return j;

		int temp = A[i];
		A[i] = A[j];
		A[j] = temp;
	}
}

void quicksort(int *A, int low, int high, int ind)
{
	if (low < high) {
		quicksort(A, low, partition(A, low, high, ind), ind);
		quicksort(A, partition(A, low, high, ind) + 1, high, ind);
	}
}

int sort_recursive(int* arr, int arrSize, int currProcRank, int maxRank, int rankIndex, int currInd) 
{
	MPI_Status status;
	int ind=0;

	int shareProc = currProcRank + pow(2, rankIndex);
	rankIndex++;

	if (shareProc > maxRank) {
		quicksort(arr, 0, arrSize - 1, ind);
		return 0;
	}
	
	int j = 0;
	int pivotIndex;
	do {
		pivotIndex = lomuto_partition(arr, j, arrSize - 1, ind);
		j++;
		currInd ++;
	} while (pivotIndex == j - 1);

	if (pivotIndex <= arrSize - pivotIndex) 
	{
		currInd = ind + 1;
		MPI_Send(arr, pivotIndex - 1, MPI_INT, shareProc, pivotIndex, MPI_COMM_WORLD);
		sort_recursive((arr + pivotIndex + 1), (arrSize - pivotIndex - 1), currProcRank, maxRank, rankIndex, currInd);
		MPI_Recv(arr, pivotIndex - 1, MPI_INT, shareProc, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
		ind--;
	}
	else {
		currInd = ind-1;
		ind++;
		MPI_Send((arr + pivotIndex + 1), arrSize - pivotIndex - 1, MPI_INT, shareProc, pivotIndex + 1, MPI_COMM_WORLD);
		sort_recursive(arr, (pivotIndex + 1), currProcRank, maxRank, rankIndex, currInd);
		MPI_Recv((arr + pivotIndex + 1), arrSize - pivotIndex - 1, MPI_INT, shareProc, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

	}
}
