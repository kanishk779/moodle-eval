Problem 1
The number of processes and the integer "num" denoting the number of terms in the sequence is given.
I am declaring an array of size num and populating the array with the sequence i.e 1/1^2, 1/2^2, 1/3^2 etc.
avgNumsPerProcess denotes how many numbers are sent to each process to find the partial sum. 
Parts of array are sent to all the processes evenly and each process calculates the sum of the chunk of array it gets.
After finding the partial sum, each process sends back the partial sum to the root process.
Root process collects all the partial sums and adds them up to find the final sum.

Note: If the number of processes is greater than the number of terms in the sequence, then few processes are not sent anything. 

Problem 2
The number of processes and the array to be sorted is given.
After scanning the array from the file, I am broadcasting the value of n to all the processes.
Then, chunksize is calculated which represents the size of the chunk of the array which is to be sent to all the processes.
After the chunksize is found, the array is scattered to all the processes such that each process gets a chunk. 
Each process quicksorts the chunk it gets.
After sorting, instead of gathering all those chunks and merging them, I have tried a tree based merge.
Instead of merging all chunks at once, each process sends its chunk to its neighbour.
After receiving a chunk, each process merges the received chunk with its own chunk and so on.
The final sorted arrives at the root process