#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    MPI_Status status;
    float arr[10010], arr2[10010], partialSum;
    int num;
    if (argc != 3) 
    {
        fprintf(stderr, "Usage: mpirun -np <numprocs> %s <input_file> <output_file>\n", argv[0]);
        exit(1);
    }
    FILE * file = NULL;

    if(rank == 0)
    {
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &num);
        fclose(file);

        // Populating the array with values
        for(int i = 0; i < num; i++)
            arr[i] = 1/(((float)i + 1) * ((float)i + 1));

        int avgNumsPerProcess = num / numprocs;
        // A boolean variable to check if the number
        // of processes is greater than num
        bool overflow = false;

        // If there is an overflow, avgNumsPerProcess becomes
        // zero and no data is sent to the processes. So, we 
        // need to fix that.
        if(avgNumsPerProcess == 0)
        {
            avgNumsPerProcess = 1;
            overflow = true;
        }
        
        // When there are more processes than num, not all processes
        // would receive data. So, we send the data to only "num"
        // number of processes and the others are left free.
        int temp = num;

        for(int i = 1; i < numprocs; i++)
        {
            temp--;
            if(temp == 0)
                avgNumsPerProcess = 0;
            int start = i * avgNumsPerProcess + 1;
            int end = (i + 1) * avgNumsPerProcess;
            if(num - end < avgNumsPerProcess)
                end = num - 1;
            int numsToSend = end - start + 1;
            MPI_Send(&numsToSend, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&arr[start], numsToSend, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
        }

        float sum = 0;
        for(int i = 0; i < num; i++)
            sum += arr[i];
        cout << "Actual sum found by adding sequentially is " << sum << endl;

        sum = 0;
        if(overflow)
            avgNumsPerProcess = 1;
        for(int i = 0; i < avgNumsPerProcess + 1; i++)
            sum += arr[i];
        
        cout << "Partial sum found by root process is " << sum << endl;

        for(int i = 1; i < numprocs; i++)
        {
            MPI_Recv(&partialSum, 1, MPI_FLOAT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
            int sender = status.MPI_SOURCE;
            cout << "Partial sum found by the process " << sender << " is " << partialSum << endl;
            sum += partialSum;
        }
        file = fopen(argv[2], "w");
        fprintf(file, "%.6f", sum);
        fclose(file);
        cout << "The total sum is " << std::setprecision(6) << std::fixed << sum << endl;
    }

    else
    {
        int numsToReceive;
        MPI_Recv(&numsToReceive, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Recv(&arr2, numsToReceive, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        int numsReceived = numsToReceive;
        partialSum = 0;
        for(int i = 0; i < numsReceived; i++)
            partialSum += arr2[i];
        MPI_Send(&partialSum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}