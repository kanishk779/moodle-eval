#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


void swap(int * arr, int i, int j)
{
	int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

int partition(int arr[], int left, int right)
{
    int pivot = arr[right];
    int i = left - 1;
    for(int j = left; j <= right - 1; j++)
    {
        if(arr[j] <= pivot)
        {
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i+1, right);
    return i + 1;
}

void quicksort(int arr[], int left, int right)
{
    if(left < right)
    {
        int pi = partition(arr, left, right);
        quicksort(arr, left, pi - 1);
        quicksort(arr, pi + 1, right);
    }
}

int * merge(int * arr1, int n1, int * arr2, int n2)
{
	int i = 0, j = 0, k = 0;
	int * ret = (int *)malloc((n1 + n2) * sizeof(int));
    while(k < n1 + n2)
    {
		if (i >= n1)
			ret[k++] = arr2[j++];
		else if (j >= n2)
			ret[k++] = arr1[i++];
		else if (arr1[i] < arr2[j])
			ret[k++] = arr1[i++];
		else
			ret[k++] = arr2[j++];
	}
	return ret;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (argc != 3) 
    {
        fprintf(stderr, "Usage: mpirun -np <numprocs> %s <input_file> <output_file>\n", argv[0]);
        exit(1);
    }

    FILE * file = NULL;
    // int * arr = NULL;
    int n, s, o, i, chunkSize;
    int * other, *chunk, *arr = NULL;
    // int * chunk;
    MPI_Status status;
    if(rank == 0)
    {
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        chunkSize = (n % numprocs != 0) ? n/numprocs + 1 : n/numprocs;
        arr = (int *)malloc(numprocs * chunkSize * sizeof(int));
        for (int i = 0; i < n; i++)
            fscanf(file, "%d", &(arr[i]));
        fclose(file);
        for (int i = n; i < numprocs*chunkSize; i++)
            arr[i] = 0;
    }    

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    chunkSize = (n % numprocs != 0) ? n/numprocs + 1 : n/numprocs;

    s = (n >= chunkSize * (rank + 1)) ? chunkSize : n - chunkSize * rank;

    chunk = (int *)malloc(chunkSize * sizeof(int));
    MPI_Scatter(arr, chunkSize, MPI_INT, chunk, chunkSize, MPI_INT, 0, MPI_COMM_WORLD);
	// cout << "Chunk sent to the process" << endl;
    // for(int i = 0; i < chunkSize; i++)
	// 	cout << chunk[i] << " ";
	// cout << endl;

	quicksort(chunk, 0, chunkSize - 1);

    // cout << "Chunk sorted by the process" << endl;
    // for(int i = 0; i < chunkSize; i++)
	// 	cout << chunk[i] << " ";
	// cout << endl << endl;

    
    for (i = 1; i < numprocs; i = 2*i) 
    {
        if (rank % (2*i) != 0) 
        {
            // send the chunk to process with rank rank - i
			MPI_Send(&s, 1, MPI_INT, rank - i, 0, MPI_COMM_WORLD);
            MPI_Send(chunk, s, MPI_INT, rank - i, 0, MPI_COMM_WORLD);
            break;
        }
        // merge chunks from rank + i (if it exists)
        if (rank+i < numprocs) 
        {
            // compute size of chunk to be received
            o = (n >= chunkSize * (rank + 2 * i)) ? chunkSize * i : n - chunkSize * (rank+i);
			MPI_Recv(&o, 1, MPI_INT, rank + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            other = (int *)malloc(o * sizeof(int));
            // receive other chunk
            MPI_Recv(other, o, MPI_INT, rank + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            // merge the chunks            
            arr = merge(chunk, s, other, o);
            free(chunk);
            chunk = arr;
            s += o;
        }
    }

    // Printing the sorted array from root process
    if(rank == 0)
    {
        file = fopen(argv[2], "w");
        for (int i = 0; i < s; i++)
        	fprintf(file, "%d ", chunk[i]);
        for (int i = 0; i < s; i++)
            cout << chunk[i] << " ";
        cout << endl;
        fclose(file);
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    /* shut down MPI */

    MPI_Finalize();
    return 0;
}