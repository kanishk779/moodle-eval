
/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;



int partition (int arr[], int low, int high)  
{  
    int pivot = arr[high]; 
    int i = (low - 1);   
  
    for (int j = low; j < high ; j++)  
    {  
        if (arr[j] < pivot)  
        {  
            i++; 
            int temp = arr[i];
            arr[i]= arr[j];
            arr[j]= temp;
        }  
    }  

    int temp = arr[i+1];
    arr[i+1]= arr[high];
    arr[high]= temp;
    
    return (i + 1);  
} 

void regular_quickSort(int arr[], int start, int end) 
{ 
    if (start < end) 
    { 
        int part = partition(arr, start, end); 
        regular_quickSort(arr, start, part - 1); 
        regular_quickSort(arr, part + 1, end); 
    } 
} 

int arr[1000001];

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    fstream fin;
    fin.open(argv[1], ios::in);

    fstream fout;
    fout.open(argv[2], ios::out);
    
    int size = numprocs;
    if(rank == 0) 
    {
        int n;
        fin >> n;
        for (int i = 0; i < n; ++i)
        {
            fin >> arr[i];
        }

        int batchsize=0;
        if(size==1)
        {
            batchsize = 0;
        }
        else
        {
            batchsize=n/size;
        }
        MPI_Bcast(&batchsize,1,MPI_INT,0,MPI_COMM_WORLD);


        for(int i=1;i<size;i++)
        {
            MPI_Send(arr+batchsize*(i-1), batchsize, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        
        int remaining_elements = n-batchsize*(size-1);
        int local_arr[remaining_elements];
        for (int i = batchsize*(size-1); i < n ; ++i)
        {
            local_arr[i-(batchsize*(size-1))]=arr[i];
            
        }
       
        regular_quickSort(local_arr, 0, remaining_elements-1);

        int ans[n];
        vector<int> sorted[size];
        
        for (int i = 0; i < remaining_elements ; ++i)
        {   
            sorted[rank].push_back(local_arr[i]);
        }
 
        for(int i=1;i<size;i++)
        {
            int temp[batchsize];
            MPI_Recv(temp, batchsize, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (int j = 0; j < batchsize; ++j)
            {
                sorted[i].push_back(temp[j]);
            }
        }
          
        priority_queue <pair<int, int>, vector<pair<int, int>>, greater<> > pq;
        int cnt[size];

        for (int i = 0; i < size; ++i)
        {
            if(sorted[i].size()!=0)
            pq.push({sorted[i][0], i});
            cnt[i]=1;
        }

        while(!pq.empty())
        {
            fout << pq.top().first<<" " ;
            int pnum = pq.top().second; 
            pq.pop();
            if (cnt[pnum] < sorted[pnum].size())
            {
                pq.push({sorted[pnum][cnt[pnum]++], pnum});
            }

        }
        
        
    }
    else 
    {   
        int batchsize=0;
        MPI_Bcast(&batchsize,1,MPI_INT,0,MPI_COMM_WORLD);
        
        int local_arr[batchsize];
        MPI_Recv(local_arr, batchsize, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        regular_quickSort(local_arr, 0, batchsize-1);
        MPI_Send(local_arr, batchsize, MPI_INT, 0, 0, MPI_COMM_WORLD);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}







