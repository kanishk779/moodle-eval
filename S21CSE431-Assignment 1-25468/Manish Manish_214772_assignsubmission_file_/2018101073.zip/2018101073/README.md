# Distributed Systems Assignment 1
## MPI Programming

### Problem 1
- *Description*
To each process we send a range of integers(dividing equally) to process there result and send it back. The root process then sums up all of the partial sums to get the final solution.

- *Analysis*: 
	- For N = 2
		- if np = 1 - Total time (s): 0.0002
		- if np = 11 - Total time (s): 0.0003
	- For N = 10000:
		- if np = 1 - Total time (s): 0.0004
		- if np = 11 - Total time (s): 0.0005
	
	- As N increses the consumned time increases. The increase in time as number of process increases is due to the overhead of sending and recieving the data btw different processes.
---

### Problem 2
- *Description*: 
We have sort the array using parallel quick sort. 
So we divide the array almost equally into np parts. Then each process parallely sorts their portion of the array using quicksort and sends the sorted array back to the root process. 
To merge these sorted arrays we use k way merge sort. A min heap is created initially containing only the smallest element of each sorted array. Then one by one the smallest element in the heap is removed and the next element from the corresponding array is inserted back into the heap.
The algorthm terminated when there are no more elements in the heap implying all arrays have been merged.

- *Analysis*: 
	- For N = 10 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.00005
		- if np = 11 - Total time (s): 0.0005

	- For N = 1000000 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.626278
		- if np = 11 - Total time (s): .782302
	
	- As N increses the consumned time increases. The increase in time as number of process increases is due to the overhead of sending and recieving the data btw different processes.
---

### Problem 3
- **Description**:
    - We want a valid edge coloring of the graph in no more than delta + 1 colors, where delta is the maximum of the degrees of all the vertices in the original graph or the line graph. We convert the problem into finding a valid vertex coloring of the line graph of the original graph, which is equivalent to finding the edge coloring of the original graph.
    - We start by assigning random weights to each vertex in this new graph.
    - In each iteration, we find all those vertices that are the maximum amongst their uncolored neighbors. They will form an independent set.
    - Since they form an independent set, we can color them parallely without any contradiction.
    - We color the node with the least possible color value such that none of the neighbour is colored in the same color.
    - To parallelize this even further, the root process will not find the independent set. Instead, that task is divided with each process where each process finds an independent set from the nodes in it's range.
    - Repeat this until all nodes are colored.
- **Analysis**:
    
    - For N = 5, M = 10 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.0002
        - if np = 11 - Total time (s): 0.006
    
    - For N = 100, M = 500 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.13
        - if np = 11 - Total time (s): 0.059
    
    - It is obvious that time will increase almost monotically with increase in N and M.
    - When there are less number of nodes and edges in the graph, the overhead of sending the large adjacency matrix and all the other supporting arrays and values is larger and hence the time increases with the increase in the number of processes.
    - When the number of nodes and edges start to increase, we see that the time reduces 