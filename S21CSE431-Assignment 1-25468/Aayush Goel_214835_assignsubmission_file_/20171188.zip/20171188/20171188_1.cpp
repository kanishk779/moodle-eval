/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Status mpi_status; 
    FILE *inp;
    
    if(rank==0)
    {
        if(argc < 3)
        {
            cout << "Invalid Command Line Arguments Syntax" << endl;
            cout << "Valid Syntax : mpirun ./a.out INPUTFILE OUTPUTFILE"<<endl;
            return 0;
        }
        char* input_file = argv[1];
        std::ifstream infile(input_file);
        int n;
        infile >> n;
        infile.close();


        int start_num = 0;
        int each_num = n/numprocs;

        if(numprocs >= 2)
        {
            for(int i=1;i<numprocs-1;i++)
            {
                start_num += each_num;
                MPI_Send(&start_num,1,MPI_INT,i,0,MPI_COMM_WORLD);
                MPI_Send(&each_num,1,MPI_INT,i,0,MPI_COMM_WORLD);
            }

            start_num += each_num;
            int last_num = n-start_num;
            MPI_Send(&start_num,1,MPI_INT,numprocs-1,0,MPI_COMM_WORLD);
            MPI_Send(&last_num,1,MPI_INT,numprocs-1,0,MPI_COMM_WORLD);
        }

        double ans = 0;
        for(int i=0;i<each_num;i++)
            ans += 1.0/pow(i+1,2.0);

        for(int i=1;i<numprocs;i++)
        {
	        double ret_ans ;
            MPI_Recv(&ret_ans,1, MPI_DOUBLE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &mpi_status);
            ans += ret_ans;
        }

        ofstream output(argv[2]);
        output<<setprecision(7)<<ans<<endl;        
    }
    else
    {
    	int start_recv;
        MPI_Recv(&start_recv,1,MPI_INT,0,0,MPI_COMM_WORLD,&mpi_status);
    	int num_recv;
        MPI_Recv(&num_recv,1,MPI_INT,0,0,MPI_COMM_WORLD,&mpi_status);
        double ans = 0;

        for(int i=0;i<num_recv;i++)
            ans += 1/pow(i+1+start_recv,2.0);

        MPI_Send(&ans,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}