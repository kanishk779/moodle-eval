# DS Assignment 1 Report

## Aayush Goel (20171188)

### Question 1

The i-th rank processor sums up f(j) for all j values such that j <= n and j/numprocs = i. This distribution ensures almost equal number of values to each process, as in a modulo group each value repeats cyclically.

- f(j) is defined as 1/(j^2)
- Each process (including the sender) compute the sums for their modulo value. 
- The computed sums are sent by other processes to the rank 0 process.
- The rank 0 process adds them up and reports the answer.

**Communication complexity**: Constant (only integer n is shared)  
**Time complexity**: linear O(n) (for each value <= n, f of that value is computed exactly once)

### Question 2

- Split the main vector into a number of smaller parts using mpi_scatter function of mpi.
- If length of vector is |n|, then if n%numprocs == 0 --> we give m = n/numprocs to each process else we zero-pad the array and give m = n/numprocs+1 to each process.
- We then sort each individual subpart/subvectors parrallely in each process.
- We now have m sorted vectors.We need to merge them.
- We can merge by using same in O(m) time and in log(p) steps.
- In the merge step, I have used MPI_Send and MPI_Recv to exchange vectors between processes.

**Communication complexity**: num\_procs * linear (subarrays of the original array are received - and sent back - by each process exactly once)    
**Time complexity**: nlogn (average case). Each process spends linear time partitioning the array and then uses a divded-and-conquer strategy to solve the two subparts. On average case this strategy will result in logn such steps.

### Question 3

The idea used for edge colouring is as follows:
1. We start with an initial approximate of number of colours as the number of edges and then reduce the number of colours until it's less than the limit maxDegree + 1.
2. The first processor will broadcast the list of current colors to all the processes (so that they maintain latest color)
2. Now, form groups of vertices such that each group contains delta+1 vertices, we will have 2^k groups in this manner.
3. Use first processor to merge first two groups, next processor to merge next two groups, and so on. This step is done in **parallel.**
4. the merge step is performed such that for each vertex (in the two groups) which has color greater that delta + 1, it is reduced to the lower half (below delta+1 colors)
5. Now we are left with 2^{k-1} groups. Repeat step 2 again, until k is 0.

The number of processors have been limited to 11.

**Communication complexity**: (m*m + mlog(nlog(\delta+1)), i.e., at each step of the communication (logarithmic steps), the processors exchange the color information of all the edges. Before start of the communication, the processes exchange the adjacency matrix of size m*m via a broadcast.tu

**Time complexity**: roughly Tlog(n*d)$. Here d is roughly N/numprocs and T has a theoretical lower bound of delta. However in our implementation it can go upto delta^2, because of lack of number of processors required theoretically.
