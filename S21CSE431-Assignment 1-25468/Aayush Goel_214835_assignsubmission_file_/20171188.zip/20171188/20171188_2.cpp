#include<mpi.h>
#include<bits/stdc++.h>
using namespace std;

#define FAST_IO std::ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define ll long long int
#define pb push_back
#define mp make_pair
#define ld long double
#define sz(a) (ll)(a).size()
#define endl "\n"
#define send_data_tag 2000001
#define return_data_tag 2000002

vector <ll> input;
vector <ll> my_buffer;

void quicksort(ll l, ll h)
{
    if(l > h) return;
    ll x = l + rand() % (h - l + 1), val = my_buffer[x], flag = 0;
    vector<ll>le, g, b;
    for(int i=l;i<=h;i++)
    {
        if(i == x) continue;
        if(my_buffer[i] < val) le.pb(my_buffer[i]);
        else g.pb(my_buffer[i]);
    }
    for(int i=0;i<sz(le);i++) b.pb(le[i]);
    b.pb(val);
    for(int i=0;i<sz(g);i++) b.pb(g[i]);
    for(int i=l;i<=h;i++) my_buffer[i] = b[i - l];
    for(int i=l+1;i<=h;i++)
    {
        if(my_buffer[i] < my_buffer[i - 1])
        {
            flag = 1;
            break;
        }
    }
    if(flag)
    {
        x = l + sz(le);
        quicksort(l, x - 1);
        quicksort(x + 1, h);
    }
    return;
}

vector <ll> merge(vector <ll> v1,vector <ll> v2)
{
    ll n1 = v1.size();
    ll n2 = v2.size();

	ll k;

	vector <ll> combin;

	ll i = 0;
	ll j = 0;
	while(i < n1 && j < n2)
	{
		if(v1[i] <= v2[j])
            combin.pb(v1[i++]);
		else
            combin.pb(v2[j++]);
	}

	while(i>= n1 && j < n2)
        combin.pb(v2[j++]);

	while(j >= n2 && i<n1)
        combin.pb(v1[i++]);

	return combin;
}

int main(int argc, char ** argv)
{
	int rank, numprocs;
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    MPI_Status mpi_status;

    ll n;

    if(rank == 0)
    {
        if(argc < 3)
        {
            cout << "Invalid Command Line Arguments Syntax" << endl;
            cout << "Valid Syntax : mpirun ./a.out INPUTFILE OUTPUTFILE"<<endl;
            return 0;
        }
       char* input_file = argv[1];
       std::ifstream infile(input_file);
       infile >> n;
       for(ll i=0;i<n;i++)
       {
            ll k;
            infile >> k;
            input.push_back(k);
       }       
       infile.close();
    }
    
    MPI_Bcast(&n,1,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);

    ll l = (n + numprocs - 1)/numprocs;

	my_buffer.resize(l);

    MPI_Scatter(input.data(),l,MPI_LONG_LONG_INT,my_buffer.data(),l,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);

    ll m = 0;
    m = (n >= l*(rank+1))?max(l,m):max((n-l*rank),m);

    quicksort(0,m-1);

    for(ll step = 1;step < numprocs; step *= 2)
    {
    	if(rank % (2*step) != 0)
    	{
    		MPI_Send(my_buffer.data(),my_buffer.size(),MPI_LONG_LONG_INT,rank-step,0,MPI_COMM_WORLD);
    		break;
    	}

    	else if(rank+step < numprocs)
    	{
            ll j = (n >= l*(rank+2*step))?l*step:n - l*(rank+step);

    		if(j <= 0)
    			continue;

    		vector <ll> rec(j);

    		MPI_Recv(rec.data(),rec.size(),MPI_LONG_LONG_INT,(rank+step),0,MPI_COMM_WORLD,&mpi_status);

    		my_buffer = merge(my_buffer,rec);
    		m += rec.size();
    	}
    } 


    if(rank == 0)
    {
        ofstream outfile;
        outfile.open(argv[2]);

        for(ll i=0;i<my_buffer.size();i++)
            outfile << my_buffer[i] << " ";
        outfile << endl;
        outfile.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        cout << "Total time (s): " << maxTime << '\n';
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}