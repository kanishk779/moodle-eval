#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define READ_DSC 1
#define SENDER 0
#define vi std::vector<int>
#define vv std::vector<std::vector<char>>
#define vpii std::vector<std::pair<int, int>>
#define DEBUG 0
#define mpi MPI_INT

int  n, m;
double tbeg;
bool arr[1000][1000];
vpii edges;
int colors[1000];

void send_data(int dest, int start, int count) {
    MPI_Send(&start, 1, mpi, dest, 0, MPI_COMM_WORLD);
    MPI_Send(&count, 1, mpi, dest, 0, MPI_COMM_WORLD);
}

void receive_data(int dest, int &start, int &count) {
    int temp;
    MPI_Recv(&temp, 1, mpi, dest, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    start = temp;

    MPI_Recv(&temp, 1, mpi, dest, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    count = temp;
}

vi receive_vector(int source_rank) {
    int temp;
    MPI_Recv(&temp, 1, mpi, source_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    int size = temp;

    vector<int> v;
    if (size != 0)
    {
        v.resize(size);
        MPI_Recv(&v[0], size, MPI_INT, source_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    return v;
}

vector<int> colAssign(int start, int mid, int end) {
    stack<int> s;
    set<int> colors_used;
    vector<int> cols;

    for (int j = start; j < mid; j++)
        colors_used.insert(j);

    for (int i = 0; i < m; i++) {
        if (colors[i] < start or colors[i] >= mid) {
            for (int k = 0; k < m; k++) {
                if (!arr[k][i])
                    continue;
                else if (colors_used.erase(colors[k]))
                    s.push(colors[k]);
            }

            assert(!colors_used.empty());
            int top = *colors_used.begin();
            colors[i] = top;
            cols.push_back(colors[i]);

            while (!s.empty()) {
                int temp = s.top();
                s.pop();
                colors_used.insert(temp);
            }
        }
    }
    return cols;
}

streambuf* stream_buffer_cout;
streambuf* stream_buffer_cin ;
std::fstream out_file, in_file;

int main(int argc, char *argv[]) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    tbeg = MPI_Wtime();

    if (rank == 0) {
        out_file.open(argv[2], ios::out); 
        stream_buffer_cout = cout.rdbuf(); 
        streambuf* output_buffer = out_file.rdbuf(); 
        cout.rdbuf(output_buffer);
    }

    if (rank == 0) {
        if(argc < 3)
        {
            cout << "Invalid Command Line Arguments Syntax" << endl;
            cout << "Valid Syntax : mpirun ./a.out INPUTFILE OUTPUTFILE"<<endl;
            return 0;
        }

        string inputFile = string(argv[1]);
        ifstream fin(inputFile.c_str());

        fin>>n;
        fin>>m;

        for(int i=0;i<m;i++){
            ll x,y;
            fin>>x;
            fin>>y;
            edges.push_back({ x-1, y - 1});
        }
        fin.close();

        out_file.open(argv[2], ios::out); 

        for (int i = 0; i < m; i++) {
            for (int j = i + 1; j < m && j!=i; j++) {
                if (edges[i].first == edges[j].first)
                {
                    arr[i][j] = true;
                    arr[j][i] = true;
                }
                else if(edges[i].first == edges[j].second)
                {
                    arr[i][j] = true;
                    arr[j][i] = true;
                }
                else if(edges[i].second == edges[j].first)
                {
                    arr[i][j] = true;
                    arr[j][i] = true;
                }
                else if(edges[i].second == edges[j].second)
                {
                    arr[i][j] = true;
                    arr[j][i] = true;
                }
            }
        }
    }

    MPI_Bcast(&m, 1, MPI_INT, SENDER, MPI_COMM_WORLD);
    MPI_Bcast(&arr[0][0], 1000000, MPI_BYTE, SENDER, MPI_COMM_WORLD);

    ll max_deg = 0;
    for (int i = 0; i < m; i++) {
        
        ll deg = 0;
        for (int j = 0; j < m; j++)
        {
            if(arr[i][j])
                deg++;
            // cout<<arr[i][j]<<' ';
        }
        // cout<<endl;

        max_deg = max(deg, max_deg);
    }
    // cout<<max_deg<<endl;

    for(int i=0;i<m;i++)
        colors[i] = i;

    if (rank == 0) {
        int unique;
        int bin_size = 2 * (max_deg + 1);

        for(int iters = 0;iters<10;iters++) {
            set<int> uniqueColours = set<int>(colors, colors + m);
            unique = uniqueColours.size();

            if (unique <= max_deg + 1) break;

            else if (unique <= bin_size) {
                // colAssign(0, max_deg + 1, unique);

                set<int> colors_used;
                for (int j = 0; j <= max_deg; j++)
                    colors_used.insert(j);

                stack<int> s;    
                vector<int> cols;
                for (int i = 0; i < m; i++) {
                    if (colors[i] < 0 or colors[i] > max_deg) {
                        for (auto neigh = 0; neigh < m; neigh++) {
                            if (!arr[neigh][i]) 
                                continue;
                            else  if (colors_used.erase(colors[neigh]))
                              s.push(colors[neigh]);
                        }

                        assert(!colors_used.empty());
                        int top = *colors_used.begin();
                        colors[i] = top;
                        cols.push_back(colors[i]);

                        while (!s.empty()) {
                            colors_used.insert(s.top());
                            s.pop();
                        }
                    }
                }
            } 
            else 
            {
                MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);

                int chunk = ((unique / numprocs) & 1)?(unique / numprocs)+1:(unique / numprocs);

                int low = max(bin_size, chunk);

                for (int i = 1; i < numprocs; i++) {
                    if (low + max(bin_size, chunk) - 1 >= n) send_data(i, -1, -1);
                    else send_data(i, low, max(bin_size, chunk));

                    low += max(bin_size, chunk);
                }

                colAssign(0, max(bin_size, chunk) / 2, max(bin_size, chunk));

                low = max(bin_size, chunk);

                for (int i = 1; i < numprocs; i++) {
                    if (low + max(bin_size, chunk) - 1 >= n) break;

                    int temp;
                    MPI_Recv(&temp, 1, mpi, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    int size = temp;

                    vector<int> v;
                    if (size != 0)
                    {
                        v.resize(size);
                        MPI_Recv(&v[0], size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    }
                    std::vector<int> res = v;

                    
                    int res_p = 0;
                    for (int j = 0; j < m; j++) {
                        auto &x = colors[j];
                        if (x < low or x >= low + max(bin_size, chunk) / 2)
                            x = res[res_p++];
                    }

                    low += max(bin_size, chunk);
                }
            }
        } 

        cout << unique << endl;
        for (int i = 0; i < m; i++)
            std::cout << colors[i] + 1 << " ";
        cout<<endl;

        colors[0] = -1;
        MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);
    } 
    else 
    {
        while (1) {
            MPI_Bcast(&colors, m, MPI_INT, SENDER, MPI_COMM_WORLD);

            if (colors[0] < 0)
                break;

            int temp;
            MPI_Recv(&temp, 1, mpi, SENDER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            int low = temp;

            MPI_Recv(&temp, 1, mpi, SENDER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            int bin_size = temp;
            
            if (low != -1) {
                vector<int> cols = colAssign(low, low + bin_size / 2, low + bin_size);
                int count = cols.size();
                MPI_Send(&count, 1, mpi, SENDER, 0, MPI_COMM_WORLD);    
                MPI_Send(&cols[0], count, MPI_INT, SENDER, 0, MPI_COMM_WORLD);
            }
        }
    }

    cout.rdbuf(stream_buffer_cout); 
    out_file.close();

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if (rank == 0) {
        std::cout << "Total time (s): " << maxTime << std::endl;
    }

    /* shut down MPI */
    MPI_Finalize();

    return 0;
}