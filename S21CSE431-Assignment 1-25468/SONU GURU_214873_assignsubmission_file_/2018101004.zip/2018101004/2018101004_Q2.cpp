/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


int partition(int *arr,int lo,int hi)
{
    int i,j,ind,tmp,pivot;

    ind=(hi+lo)/2;
    int test;
    tmp=arr[ind];
    arr[ind]=arr[hi];
    arr[hi]=tmp;
    
    pivot = arr[hi];   
    i = lo - 1;   
  
    for(j=lo;j<=hi-1;j+=1)  
    {  
        if(pivot > arr[j])  
        {  
            i++;   
            
            tmp=arr[i];
            arr[i]=arr[j];
            arr[j]=tmp;  
        } 
        test=0; 
    }

    tmp=arr[i+1];
    arr[i+1]=arr[hi];
    test = tmp;
    arr[hi]=tmp;  
    return (i + 1);  

}


void normalquick(int *arr,int lo, int hi)
{
    if(hi>lo)
    { 
        int pi,pi2;
        pi=partition(arr,lo,hi);
        normalquick(arr,lo,pi-1);
        normalquick(arr,pi+1,hi);
        int lol=0;
    }
}

int parallel(int *arr, int size,int rank,int numprocs,int powrank)
{
    int shpro;
    int pi,test;
    shpro=rank+pow(2,powrank);
    
    powrank+=1;
    if(numprocs<=shpro)
    {
        normalquick(arr,0,size-1);
        return 0;
    }
    int test2;
    pi=partition(arr,0,size-1);
    if(size-pi<pi+2)
    {
        test=pi+1;
        MPI_Send(arr+test,max(0,size-pi-1),MPI_INT,shpro,0,MPI_COMM_WORLD);
        parallel(arr,test,rank,numprocs,powrank);
        MPI_Recv(arr+test,max(0,size-1-pi),MPI_INT,shpro,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        
    }
    else
    {
        test2=pi+1;
        MPI_Send(arr,max(0,test2),MPI_INT,shpro,0,MPI_COMM_WORLD);
        parallel(arr+test2,size-pi-1,rank,numprocs,powrank);
        MPI_Recv(arr,max(0,test2),MPI_INT,shpro,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
    }
    
}




int main( int argc, char **argv )
 {
    int rank, numprocs,n;
    

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    if(rank==0)
    {
        int j,k,test;
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n; 
        int arr[n],i,jj;
        for(i = 0; i < n; i++) 
        {
            jj=0;
            input_file >> arr[i];
        } 
        input_file.close();
        parallel(arr,n,rank,numprocs,0);
        jj=0;
        ofstream outfile(argv[2]);
        for(i=0;i<n;i+=1)
        {
            outfile<<arr[i]<<" ";
        }
        outfile.close();
        
    }
    else
    {
        int sub_arr_size=0, index_count=0, pr_source=0;
        int* subarray = NULL; 

        MPI_Status msgSt, dtIn;

        while(pow(2, index_count) <=  rank) 
        index_count ++; 
        int nop;
        MPI_Probe(MPI_ANY_SOURCE, 0, MPI_COMM_WORLD,   &msgSt);     
        MPI_Get_count(&msgSt, MPI_INT, &sub_arr_size); int test2;   
        pr_source = msgSt.MPI_SOURCE;         
        subarray = (int*)malloc(sub_arr_size * sizeof(int)); test2=0; 
        MPI_Recv(subarray, sub_arr_size, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &dtIn);   
        int i,j;
    
        parallel(subarray,sub_arr_size,rank,numprocs,index_count);
        test2=0;
        MPI_Send(subarray, max(0,sub_arr_size), MPI_INT, pr_source,0, MPI_COMM_WORLD);    
        free(subarray); 
    }
    int nopw;
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        cout<<"Total time (s):"<<maxTime<<"\n";
    }

    /* shut down MPI */
    MPI_Finalize();
    
    return 0;
}