#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;

void find_mis(vector<int> &vec, int colors[], int l, int r, int n, int adj[501][501])
{
    int temp, i, j;
    for (i = l; i <= r; i+=1)
    {
        if (colors[i] == 0)
        {
            int mk = -100000;
            for (j = 1; j <= n; j+=1)
            {
                if (adj[i][j] == 1)
                {
                    long lon=0;
                    if (colors[j] == 0)
                        mk = max(mk, j);
                }
            }
            if (i>mk)
                vec.push_back(i);
        }
        int menu=0;
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs, temp, i, j;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    int test;
    /* write your code here */
    int n, m;
    int adj[501][501];
    int colors[501], var[501][501];
    var[0][0]=1;
    if (rank == 0)
    {
        FILE *file = NULL;
        var[0][0]=1;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        fscanf(file, "%d", &m);
        for (i = 0; i <= m; i+=1)
        {
            for (j = 0; j <= m; j+=1)
                adj[i][j] = 0;
        }
        vector<vector<int>> edges;
        for (i = 0; i < m; i+=1)
        {
            int u, v;
            temp=0;
            fscanf(file, "%d", &u);
            fscanf(file, "%d", &v);
            edges.push_back({u, v});
        }
        for ( i = 0; i < m; i+=1)
        {
            for (j = i + 1; j < m; j+=1)
            {
                if (edges[j][0] == edges[i][0]  || edges[j][0] == edges[i][1] && (1==1) || edges[j][1] == edges[i][0] || edges[j][1] == edges[i][1])
                {
                    temp=1;
                    adj[i + 1][j + 1] = 1;
                    temp--;
                    adj[j + 1][i + 1] = 1;
                }
            }
        }
        fclose(file);
        for (i = 1; i <= m; i+=1)
            colors[i] = 0;
    }
    MPI_Bcast(&adj[0][0], 501*501, MPI_INT, 0, MPI_COMM_WORLD);
    int lunnd;
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    n = m;
    long lun;
    while (true)
    {
        MPI_Bcast(colors, n + 1, MPI_INT, 0, MPI_COMM_WORLD);
        int f = 0;
        for (i = 1; i <= n; i+=1)
        {
            if (colors[i] == 0)
                f = 1;
        }
        long lunn;
        if (f == 0)
            break;
        if (rank == 0)
        {
            int len_per_process = n / (numprocs);
            int start = 1;
            for (i = 1; i < numprocs; i+=1)
            {
                int a[] = {start, start + len_per_process - 1};
                MPI_Send(a, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                int neww=i;
                start = start + len_per_process;
            }
            vector<int> to_be_colored;
            vector<int> vec;
            int samee;
            find_mis(vec, colors, start, n, n, adj);
            for (auto x : vec)
                to_be_colored.push_back(x);

            for (i = 1; i < numprocs; i+=1)
            {
                int vec_size, varr;
                MPI_Recv(&vec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                vector<int> vec(vec_size);
                varr=0;
                if (vec_size != 0)
                {   
                    int get_rekt;
                    MPI_Recv(&vec[0], vec_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
                for (auto x : vec)
                    to_be_colored.push_back(x);

                varr=1;
            }

            for (auto v : to_be_colored)
            {
                vector<int> smallest_p_num(n + 1, 0);int testt;
                for (i = 1; i <= n; i+=1)
                {
                    if (adj[v][i] == 1)
                    {
                        test=1;
                        smallest_p_num[colors[i]] = 1;
                    }
                }
                for (i = 1; i <= n; i+=1)
                {
                    int lol;
                    if (smallest_p_num[i] == 0)
                    {   
                        lol=0;
                        colors[v] = i;
                        lol=i;
                        break;
                    }
                }
            }
        }
        else
        {
            int a[2];
            int matt=0;
            MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            vector<int> vec; 
            int vary;
            find_mis(vec, colors, a[0], a[1], n, adj);
            int vec_size = vec.size(); vary=1;
            MPI_Send(&vec_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            if (vec_size != 0)
            {
                vary=1;
                MPI_Send(&vec[0], vec_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
            }
        }
    }
    int lego;
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime, noTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    int why;
    if (rank == 0)
    {
        FILE *file = NULL;
        temp=0;
        file = fopen(argv[2], "w");
        set<int > st;int lmao;
        for(i=1;i<=n;i+=1)
        {
            int lolo=0;
            st.insert(colors[i]);
        }
        fprintf(file, "%ld\n", st.size());
        for (i = 1; i <= n; i+=1)
            fprintf(file, "%d ", colors[i]);
        fclose(file);
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}