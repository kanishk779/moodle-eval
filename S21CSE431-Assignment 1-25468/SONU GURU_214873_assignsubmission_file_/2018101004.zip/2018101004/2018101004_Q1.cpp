#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
   #define max_rows 100000
   #define send_data_tag 2001
   #define return_data_tag 2002

  
   
   int main(int argc, char **argv) 
   {  int rank,numprocs;
      MPI_Status status;
      int root_process, ierr, i, num_rows,an_id, num_rows_to_receive, avg_rows_per_process, sender, num_rows_received, start_row, end_row, num_rows_to_send;
       int array[max_rows];
      int array2[max_rows];
      double sum, partial_sum;
      root_process = 0;
       MPI_Init( &argc, &argv );

      MPI_Comm_rank( MPI_COMM_WORLD, &rank );
      MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
      MPI_Barrier( MPI_COMM_WORLD );
      double tbeg = MPI_Wtime();

      if(rank == root_process)
       { 
         fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> num_rows;
        input_file.close();
         // scanf("%i", &num_rows);
      
         avg_rows_per_process = num_rows / numprocs;

         for(i = 0; i < num_rows; i++) {
            array[i] = i + 1;
         }        

            
         for(an_id = 1; an_id < numprocs; an_id++) 
         {
            start_row = (an_id-1)*avg_rows_per_process;
            end_row = an_id*avg_rows_per_process-1;

            if((num_rows - end_row) < avg_rows_per_process)
               end_row = num_rows - 1;

            num_rows_to_send = end_row - start_row + 1;

            ierr = MPI_Send( &num_rows_to_send, 1 , MPI_INT, an_id, send_data_tag, MPI_COMM_WORLD);

            ierr = MPI_Send( &array[start_row], num_rows_to_send, MPI_INT, an_id, send_data_tag, MPI_COMM_WORLD);
         }

          if(avg_rows_per_process == 0)      // root process does all the stuff
          {
             sum = 0.0;
             for(i = 0; i < num_rows; i++) {
             sum += 1.0/(array[i]*array[i]);
             //sum+=array[i];   
             } 
             //printf("sum %f calculated by root process\n", sum);
          }
          else
          {
            sum = 0.0;
            for(i = ((numprocs-1)*avg_rows_per_process); i < num_rows; i++) {
            sum += 1.0/(array[i]*array[i]);
            //sum+=array[i]; 
            //printf("%d\n",array[i]); 
            } 

         for(an_id = 1; an_id < numprocs; an_id++) 
         {
            
            ierr = MPI_Recv( &partial_sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE, return_data_tag, MPI_COMM_WORLD, &status);
  
            sender = status.MPI_SOURCE;

            //printf("Partial sum %f returned from process %i\n", partial_sum, sender);
     
            sum += partial_sum;
         }
        }
 
         ofstream outfile(argv[2]);
        // outfile<<ans;
        outfile << fixed << setprecision(6) << sum << endl;
        
        outfile.close();
        
      }

      else {      //slave process

  
         ierr = MPI_Recv( &num_rows_to_receive, 1, MPI_INT, root_process, send_data_tag, MPI_COMM_WORLD, &status);
          
         ierr = MPI_Recv( &array2, num_rows_to_receive, MPI_INT,root_process, send_data_tag, MPI_COMM_WORLD, &status);

         num_rows_received = num_rows_to_receive;


         partial_sum = 0.0;
         for(i = 0; i < num_rows_received; i++) {
            partial_sum += 1.0/(array2[i]*array2[i]);
          //partial_sum+=array2[i];
         }
          //printf("%f\n", partial_sum);

         ierr = MPI_Send( &partial_sum, 1, MPI_DOUBLE, root_process, return_data_tag, MPI_COMM_WORLD);
      }

      MPI_Barrier( MPI_COMM_WORLD );
      double elapsedTime = MPI_Wtime() - tbeg;
      double maxTime;
      MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
      if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
      }
      ierr = MPI_Finalize();

   }