#Q1 

##Statement - Finding the sum of the reciprocals of the squares of integers, which converges to pi^2/6 
##Explanation:

We have used MPI and parallel processing to find the sum of reciprocal of squares of integers from 1 to n(given). The input n is taken from a file and the numbers ranging from 1 to n are divided into almost equal groups and are assigned to different processes(including the root) which parallely compute the values and return their partial result to the root process. The root process then sums all of these together to get the answer, which is stored in a file.

- For N = 1e4 and 11 processes - Time Taken: 0.0003023 seconds



#Q2 

##Statement - Given an array of numbers, we have to return the array in sorted order by implementing parallel quicksort.
##Explanation: 

The algorithm is a parallel implementation of the quicksort algorithm. We take the array as input from a file and then divided the input array. Here we have avoided the merging step by dividing input set through regular sampling. An initial partitioning of data is performed until all the available processes were given a subset to sort sequentially. The received data set is sorted by each slave/child process in parallel. The sub-sorted arrays are then gathered, corresponding to the exact partitioned offsets without performing any merging.


- For N = 1e6 and random values of array from 0 till 1e9 and 11 processes - Time Taken: 0.8245

#Q3 

##Statement - Given an undirected graph G, find a proper edge coloring of the graph using Delta(G) + 1 colors or fewer. No 2 adjacent edges should have a same color. Delta(G) is the maximum degree of any vertex in G.

##Explanation: 
At first, we will be generating a line graph, from the given graph. Now to each process we are passing contiguous chunks of vertices. A parallel approach is followed for edge coloring of the graph such that no adjacent edges share same color and number of colors used is not more than `1 + max(Delta of the original graph, Delta of the line graph)'. Afterwards, each process is returning the uncolored vertices, which are maximum among its uncolored neighbours. 

- For 128 vertices and random 774 edges and 11 processes - Time Taken: 0.06173 seconds
