Q1 :-
	I divided the n into near equal ranges for all the process and then calculated the 1/r^2 sperately for 
	that range in all the process and then collected them from all process using reduced sum fuction.

Q2 :- 
	I divided array in number of process subparts then sorted them individually in  using merge sort sperately in every process. then collected all the sorted array in the root process. In root process merged those sorted arrays using
	priority queue.
	Complexity :- k*(n/k*logk) + n*logk = O(nlogk) here n is number of element and k is number of process  

Q3 :-
	Used Jonas plassman algorithm,  made line graph from original graph. Assigned weight to vertices in new graph, and sent that weight to every process. Then seperated new graph's vertices in near equal subparts for each process. Then found local maxima in each iteration for each seperate set of vertices of process and colored vertices with minimal avaialable color. Synced color array for each process at end of iteration. Root was checking if all colors are assigned on finding it the case it set flag variable zero stopping all process simultanously. 
	Complexity :- O(delta*(m^2)) here delta is chromaticity and m is number of edges.