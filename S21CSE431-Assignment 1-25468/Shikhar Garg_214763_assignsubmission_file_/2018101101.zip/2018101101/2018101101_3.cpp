#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    double ans;
    double ans1;
    int n;
    int m;
    int matrix[501][501];
    int max=0;
    for(int i=0; i<501; i++){
        // cout<<rank << endl;
        for(int j=0; j<501; j++){
            matrix[i][j]=0;
        }
        // cout<<endl;
    }
    if (rank == 0){
    	string inp;
    	ifstream MyReadFile(argv[1]);
    	getline (MyReadFile, inp);
        char *inp1 = strdup(inp.c_str());
        char *pch = strtok (inp1," ");
        n = atoi(pch);
        pch = strtok (NULL, " ");
        m = atoi(pch);
        vector<pair<int,int>> tempgraph[n+1];
        int count = 0;
        while(!MyReadFile.eof()){
            getline (MyReadFile, inp);
            inp1 = strdup(inp.c_str());
            int a,b;
            pch = strtok (inp1," ");
            a = atoi(pch);
            pch = strtok (NULL, " ");
            b = atoi(pch);
            // cout<<a<<" "<<b<< " " << count << endl;
            tempgraph[a].push_back({b,count});
            tempgraph[b].push_back({a,count});
            count++;
        }
        for(int i=0; i < n+1; i++){
            for(pair<int,int> j : tempgraph[i]){
                for( pair<int,int> k: tempgraph[j.first]){
                    if(j.second != k.second)
                    {
                        // cout<<j.second << " " << k.second <<endl;
                        matrix[j.second][k.second] = 1;
                        matrix[k.second][j.second] = 1;
                    }
                }
            }
        }
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&matrix, 501*501, MPI_INT, 0, MPI_COMM_WORLD);
    int blocks = m/numprocs;
    int colors[m];
    int weight[m];
    for(int i=0; i<m; i++){
        colors[i] = 0;
        if(rank==0)
            weight[i] = rand()%(m*m);
    }
    // for(int i=0; i<m; i++){
    //     cout<<rank << endl;
    //     for(int j=0; j<m; j++){
    //         cout<< matrix[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
    MPI_Bcast(&weight, m, MPI_INT, 0, MPI_COMM_WORLD);
    int flag = 1;
    while(flag){
        // cout<< "my rak is" << rank <<endl;
        flag = 0;
        if(rank != numprocs-1){
            // cout<< rank << " Old one"<<endl;
            // for(int i=0; i<m; i++)
            //     cout<<colors[i]<<" ";
            // cout<<endl;
            // cout<< "my rak is" << rank <<endl;
            for(int i=rank*blocks; i<(rank+1)*blocks; i++){
                // cout << i << " " << colors[i] << endl;
                int is = 1;
                if(colors[i] == 0){
                    // flag =1;
                    int found[m+1];
                    for(int i=0; i<m+1; i++){
                        found[i] = 0;
                    }
                    for(int j=0; j<m; j++){
                        if(matrix[i][j] == 1){
                            if(colors[j] == 0){
                                if(weight[j]>=weight[i]){
                                    // cout << i << " breaked with " << j <<endl;
                                    is =0;
                                    break;
                                }
                            }
                            else{
                                found[colors[j]] = 1;
                            }
                        }
                    }
                    // cout<< i <<" "<<is <<endl;
                    int k=1;
                    if (is){
                        while(true){
                            // cout<<found[k]<<" "<<k<<endl;

                            if(found[k] == 0){
                                // cout<< i <<" came unbreaked" <<endl;
                                colors[i] = k;
                                break;
                            }
                            k++;
                        }
                    }
                }
            }
            // cout << rank<< " new one" <<endl;
            // for(int i=0; i<m; i++)
            //         cout<<colors[i]<<" ";
            // cout<<endl;
        }
        else{
            // cout<< rank << " Old one"<<endl;
            // for(int i=0; i<m; i++)
            //     cout<<colors[i]<<" ";
            // cout<<endl;   
            for(int i=rank*blocks; i<m; i++){
                // cout<< i <<endl;
                // cout<< "my rak is" << rank <<endl;
                // cout<< rank << " Old one"<<endl;
                // for(int i=0; i<m; i++)
                //     cout<<colors[i]<<" ";
                // cout<<endl;
                int is = 1;
                if(colors[i] == 0){
                    // flag = 1;
                    int found[m+1];
                    for(int i=0; i<m+1; i++){
                        found[i] = 0;
                    }
                    for(int j=0; j<m; j++){
                        if(matrix[i][j] == 1){
                            if(colors[j] == 0){
                                if(weight[j]>=weight[i]){
                                    is = 0; 
                                    // cout << i << " breaked with " << j <<endl;
                                    break;
                                }
                            }
                            else{
                                found[colors[j]] = 1;
                            }
                        }
                    }
                    int k=1;
                    if (is){
                        while(true){
                            // cout<<k<<endl;
                            // cout<<found[k]<<" "<<k<<endl;
                            if(found[k] == 0){
                                // cout<< i <<" came unbreaked" <<endl;
                                colors[i] = k;
                                break;
                            }
                            k++;
                        }
                    }
                }
            }
            // cout << rank<< " new one" <<endl;
            // for(int i=0; i<m; i++)
            //         cout<<colors[i]<<" ";
            // cout<<endl;
        }
        // cout<<"hello"
        // cout<<rank<<endl;
        // for(int i=0; i<m; i++)
        //     cout<<colors[i]<<" ";
        // cout<<endl;
        for(int i=0; i<numprocs-1; i++)
            MPI_Bcast(&colors[i*blocks], blocks, MPI_INT,i, MPI_COMM_WORLD);
        MPI_Bcast(&colors[(numprocs-1)*blocks], n-(numprocs-1)*blocks+1, MPI_INT,numprocs-1, MPI_COMM_WORLD);

        // cout<< rank << " came for"<<endl;
        if (rank ==0){
            for(int i=0; i<m; i++)
            {
                if(colors[i] == 0){
                    flag =1;
                    break;
                }
                if(max<colors[i])
                    max=colors[i];

            }
        }
        MPI_Bcast(&flag, 1, MPI_INT,0, MPI_COMM_WORLD);

        // cout<<endl;
    }
    // cout <<rank<<" hello"<<endl;
    if ( rank == 0 ){
    	ofstream MyFile(argv[2]);
        MyFile << max << endl;
        for(int i=0; i<m; i++){
            MyFile << colors[i]<< " ";            
        }
        MyFile << endl;
    	MyFile.close();
	}
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}