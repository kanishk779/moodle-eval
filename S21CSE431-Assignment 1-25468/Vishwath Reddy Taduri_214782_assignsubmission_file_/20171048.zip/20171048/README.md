## Question1
Each process is assigned a consecutive range of (N/np) (where np is number of processes and N is input) elements and performs a sum operation of 1/(i*i). This sum from all processes is added and written to the output file.

## Question 2: Parallel Quick Sort Using MPI:

### Algorithm Used : Parallel Sorting by Regular Sampling
- Divide the array into p lists and sort them in parallel with different processes.
- Select (p-1) pivots from each of p lists and send them to the main process.
- Sort the pivots and partition the lists according to the pivots.
- Exchange the partitions among the processes by sending the partions whose elements are less than are equal to 1st pivot to first process.
- Similarly with the other partitions too.
- Finally merge all the partitions into single list.
#### Complexity: This algorithm takes O(p) space and O(nlogn) time.