/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;
    ll N;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Status status;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    ifstream inFile;
    ofstream outFile;

    inFile.open(argv[1]);
    
    outFile.open(argv[2]);

    ll MAX_LIMIT = 1000000;
    ll inp_arr[MAX_LIMIT];
    ll i=0, x;
    while (inFile >> x) {
        inp_arr[i] = x;
        i++;
    }
    N = i;
    inFile.close();

    if(numprocs == 1){
        sort(inp_arr, inp_arr+N);
        for(ll i=0; i<N; i++){
            outFile<<inp_arr[i];
            if(i != N-1)
                outFile<<" ";
        }
        outFile.close();
        MPI_Barrier( MPI_COMM_WORLD );
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
        if ( rank == 0 ) {
            printf( "Total time (s): %f\n", maxTime );
        }

        MPI_Finalize();
        return 0;
    }

    ll P = numprocs - 1;
    ll partition_size = N / P;

    if(rank == 0){
        for(ll i=0; i<P-1; i++)
        {
            MPI_Send(&inp_arr[i*partition_size], partition_size, MPI_LONG_LONG_INT, i+1, 0, MPI_COMM_WORLD);
        }
        MPI_Send(&inp_arr[(P-1)*partition_size], N-(P-1)*partition_size, MPI_LONG_LONG_INT, P, 0, MPI_COMM_WORLD);

        ll gathered_samples[P][P];
        for(ll i=0; i<P; i++){
            MPI_Recv(&gathered_samples[i], P, MPI_LONG_LONG_INT, i+1, 0, MPI_COMM_WORLD, &status);
        }

        ll sorted_samples[P*P];
        ll cnt[P] = {0};
        for(ll i=0; i<P*P; i++){
            ll val;
            ll pos;
            for(ll j=0; j<P; j++){
                if(cnt[j] < P){
                    val = gathered_samples[j][cnt[j]];
                    pos = j;
                    break;
                }
            }
            for (ll j=0; j<P; j++){
                if(cnt[j]<P){
                    if(gathered_samples[j][cnt[j]] < val){
                        val = gathered_samples[j][cnt[j]];
                        pos = j;
                    }
                }
            }
            sorted_samples[i] = val;
            cnt[pos]++;
        }

        ll pivot_interval = P;
        ll pivots[P-1];
        ll c = ceil(P/2);
        for(ll i=0; i<P-1; i++){
            pivots[i] = sorted_samples[c + (i+1)*pivot_interval];
        }

        for(ll i=0; i<P; i++){
            MPI_Send(pivots, P-1, MPI_LONG_LONG_INT, i+1, 0, MPI_COMM_WORLD);
        }

        ll final_sorted_arr[N];
        ll total_size;
        ll idx = 0;
        for(ll i=1; i<=P; i++){
            MPI_Recv(&total_size, 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            MPI_Recv(&final_sorted_arr[idx], total_size, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            idx = idx + total_size;
        }

        for(ll i=0; i<N; i++){
            outFile<<final_sorted_arr[i];
            if(i != N-1)
                outFile<<" ";
        }
        outFile.close();
    }


    else{

        if(rank == P){
            partition_size = N - (P-1) * partition_size; 
        }

        ll partition_arr[partition_size];
        
        MPI_Recv(partition_arr, partition_size, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, &status);
        sort(partition_arr, partition_arr + partition_size);

        ll local_samples[P];
        ll sample_length = partition_size / P;
        
        for(ll i=0; i<P; i++){
            local_samples[i] = partition_arr[i*sample_length];
        }
        MPI_Send(local_samples, P, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);

        ll global_samples[P-1];
        MPI_Recv(global_samples, P-1, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, &status);

        ll allotment[P][2] = {0};
        ll n = 0, i = 0;
        while(n<P && i<partition_size){
            if(n==P-1 || partition_arr[i] <= global_samples[n]){
                allotment[n][1]++;
                i++;
            }
            else{
                n++;
                allotment[n][0] = i;
            }
        }

        ll merged_partitions[P][partition_size];
        ll len[P];

        len[rank-1] = allotment[rank-1][1];
        for(ll i=0; i<len[rank-1]; i++){
            ll temp = allotment[rank-1][0];
            merged_partitions[rank-1][i] = partition_arr[temp+i];
        }

        for(ll i=1; i<rank; i++){
            ll size = allotment[i-1][1];
            MPI_Send(&size, 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            if(size > 0){
                MPI_Send(&partition_arr[allotment[i-1][0]], size, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            }
        }

        for(ll i=rank+1; i<=P; i++){
            ll size = allotment[i-1][1];
            MPI_Send(&size, 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            if(size>0){
                MPI_Send(&partition_arr[allotment[i-1][0]], size, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            }
        }

        for(ll i=1; i<rank; i++){
            MPI_Recv(&len[i-1], 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            if(len[i-1] > 0){
                MPI_Recv(&merged_partitions[i-1][0], len[i-1], MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            }
        }

        for(ll i=rank+1; i<=P; i++){
            MPI_Recv(&len[i-1], 1, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            if(len[i-1] > 0){
                MPI_Recv(&merged_partitions[i-1][0], len[i-1], MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD, &status);
            }
        }

        ll total_size = accumulate(len, len+P, 0);
        ll sorted_samples[total_size];
        ll cnt[P] = {0};
        for(ll i=0; i<total_size; i++){
            ll val;
            ll pos;
            for(ll j=0; j<P; j++){
                if(cnt[j] < len[j]){
                    val = merged_partitions[j][cnt[j]];
                    pos = j;
                    break;
                }
            }
            for(ll j=0; j<P; j++){
                if(cnt[j] < len[j]){
                    if(merged_partitions[j][cnt[j]] < val){
                        val = merged_partitions[j][cnt[j]];
                        pos = j;
                    }
                }
            }
            sorted_samples[i] = val;
            cnt[pos]++;
        }
        MPI_Send(&total_size, 1, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
        MPI_Send(sorted_samples, total_size, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}