#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if(rank == 0) {
        fstream file;   
        file.open(argv[argc - 2]);
        if (file.fail()) {
            cout<<"Error! opening file"<<endl;
            exit(1);
        }
        int N;
        file>>N;
        file.close(); 
        float sum=0;

        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        
            for(int i=1;i<size;i++)
            {
                float received; 
                MPI_Recv(&received, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                sum= sum + received;
            }  
        if(size==1 || N<size)
        {
            int lowerlimit=0;
            int upperlimit=N;
            for(int i=lowerlimit;i<upperlimit;i++)
            {
                float val1= (((i+1)*(i+1)));
                float val;
                val=1.00/val1;
                sum+=val;
            }
        }
        ofstream ofile(argv[argc - 1]);
        ofile<<fixed<<std::setprecision(6)<<sum;
        ofile.close();
        
    }
    else if(rank == size-1)
    {
        int N;
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        float local_sum=0.00;
        int lowerlimit=(rank-1)*(N/size-1);
        int upperlimit=N;
        for(int i=lowerlimit;i<upperlimit && N>=size;i++)
        {
            float val1= (((i+1)*(i+1)));
            float val;
            val=1.00/val1;
            local_sum+=val;
        }
	    MPI_Send(&local_sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    else {
        int N;
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        float local_sum=0.00;
        int lowerlimit=(rank-1)*(N/size-1);
        int upperlimit=(rank)*(N/size-1);
        for(int i=lowerlimit;i<upperlimit && N>=size;i++)
        {
            float val1= (((i+1)*(i+1)));
            float val;
            val=1.00/val1;
            local_sum+=val;
        }
	    MPI_Send(&local_sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}