#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdlib.h> 
#include <time.h>
#include <bits/stdc++.h>
using namespace std;

int getPartitionNode(vector<int> &A,int low,int high)
{
    int pivot = A[high];
	int i = low - 1;
	for (int j = low; j < high; j++) {
		if (A[j] <= pivot) {
			i++;
			swap(A[i],A[j]);
		}
	}
	int temp = A[i + 1];
	A[i + 1] = A[high];
	A[high] = temp;
	return i + 1;
}
void quicksort(vector<int> &A,int low,int high)
{
    if (low >= high)
        return;
    int partition = getPartitionNode(A, low, high);
    quicksort(A, low, partition - 1);
    quicksort(A, partition + 1, high);
}
vector<int> merge(vector<int> &a,vector<int> &b)
{
    int n=a.size();
    int m=b.size();
    vector<int> ans(n+m);
    int i=0,j=0,k=0;
    while(i<n && j<m)
    {
        if(a[i]<b[j])
        {
            ans[k]=a[i];
            i++;
            k++;
        }
        else
        {
            ans[k]=b[j];
            j++;
            k++;
        }
    }
    while(i<n)
    {
        ans[k]=a[i];
        i++;
        k++;
    }
    while(j<m)
    {
        ans[k]=b[j];
        j++;
        k++;
    }
    return ans;
}
int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv); 
    int size, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    int process=pow(2,log2(size));
    int arr_chunk_size;
    int N;
    vector<int> arr;
    if(rank == 0) {
        fstream file;   
        file.open(argv[argc - 2]);
        if (file.fail()) {
            cout<<"Error! opening file"<<endl;
            exit(1);
        }  
        file>>N; 
        for(int i=0;i<N;i++)
        {
            int x;
            file>>x;
            arr.push_back(x);
        }
        file.close();
        // MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    }
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if(N%process==0)
    arr_chunk_size=N/process;
    else
    arr_chunk_size=N/process + 1;
    vector<int> arr_chunk(arr_chunk_size);
    MPI_Scatter(static_cast<void *>(&arr[0]), arr_chunk_size, MPI_INT, static_cast<void *>(&arr_chunk[0]), arr_chunk_size, MPI_INT, 0, MPI_COMM_WORLD);   
    arr.clear();
    if(rank < process)
    {
        // MPI_Bcast(&arr_chunk_size, 1, MPI_INT, 0, MPI_COMM_WORLD);
        int new_size;
        if((N-arr_chunk_size*(rank+1)) > 0)
        new_size=arr_chunk_size;
        else
        new_size=N-arr_chunk_size*rank;
        quicksort(arr_chunk,0,new_size-1);

        for(int i=1;i<process;i=i*2)
        {
            if(rank%(2*i)==0)
            {
                if(rank+i<process)
                {
                    int csize;
                    if((N-arr_chunk_size*(rank+2*i)) > 0)
                    csize=arr_chunk_size*i;
                    else
                    csize=N-arr_chunk_size*(i+rank);
                    vector<int> proccessing_chunk(csize);
                    MPI_Recv(static_cast<void *>(&proccessing_chunk[0]), csize, MPI_INT, rank + i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    arr_chunk=merge(arr_chunk,proccessing_chunk);
                    new_size+=csize;

                }
            }
            else
            {
                MPI_Send(static_cast<void *>(&arr_chunk[0]), new_size, MPI_INT, rank - i, 0, MPI_COMM_WORLD);
                break;
            }
        }
        if(rank==0)
        {
            ofstream ofile(argv[argc - 1]);
            for(int i=0;i<arr_chunk.size();i++)
            ofile<<arr_chunk[i]<<' ';
            ofile.close();
        }
    }

    MPI_Finalize();
    return 0;
}