**COMMAND TO RUN:**
<br/>
```
For Problem 1: Sum of Series:
mpic++ 2019201028_1.cpp 
mpirun -np 4 ./a.out input.txt output.txt
```
```
For Problem 2: Quick Sort:
mpic++ 2019201028_2.cpp 
mpirun -np 4 ./a.out input.txt output.txt
```
<br/>
<br/>

**Problem 1: Sum of Series**<br/>
1. The 0th process is the root process, where the final addition of result takes place
2. All the other numof processes-1 are given a subset of range based on rank. These processes individually compute the sum of (rank-1) *(N/size) to rank *(N/size) range. And then send the local sum to the Root process 0. The root process receives the sum from each process and computes the global sum.
3. After computation it writes it in the output file.

**Problem 2: Parallel Quick Sort**<br/>
___Assumpsion:___: 
* For simplicity we use only closest 2^n process for this alogithm so that merging becomes simple. <br/>
* Number of process should be less than size of input array.

**ALGORITHM:**<br/>
1. Divide The given array into chunks and distribute to all the processes. Used MPI_Scatter for this purpose.
2. Apply quicksort to all the received chunks.
3. Now we have p(number of processes) chunks sorted locally but not globally. Apply tree based merging in parallel, this will merge the sorted chunks in O(log(p)).


