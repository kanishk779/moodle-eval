/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int pos(int x, int y, int nodes)
{
    return ((x * nodes) + y);
}

int pos2(int rank, int nodes, int totalp, int offset)
{
    int num_per_p = nodes / (totalp - 1);
    return (num_per_p * (rank - 1)) + offset;
}

int rank_of_node(int node, int total_nodes, int totalp)
{
    int per_n = (total_nodes / (totalp - 1));
    int rank = 1;

    while ((rank * per_n) <= node)
    {
        rank++;
    }

    return rank;
}

void process_coloring(int rank, int totalprocs, MPI_Comm *comm_workers, int nodes)
{
    MPI_Status status;
    MPI_Request request;
    // MPI_Recv(&nodes, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);

    int nodes_per_p = (nodes) / (totalprocs - 1);

    if (rank == totalprocs - 1)
    {
        nodes_per_p += (nodes % (totalprocs - 1));
    }

    int *adjacency_matrix = new int[nodes_per_p * nodes];

    for (int i = 0; i < (nodes_per_p * nodes); i++)
    {
        adjacency_matrix[i] = 0;
    }

    int *weights = new int[nodes];
    int *local_count = new int[nodes];
    int local_nodes_count = 0;

    MPI_Recv(weights, nodes, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);

    MPI_Recv(adjacency_matrix, nodes * nodes_per_p, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
    int actual_pos;
    map<int, vector<int>>
        sending, recieving;
    int *colors = new int[nodes];
    int coloring_done = 0;

    for (int i = 0; i < nodes_per_p; i++)
    {
        sending.insert(make_pair(i, vector<int>(nodes)));
        recieving.insert(make_pair(i, vector<int>(nodes)));
    }

    vector<int> send_count(nodes, 0), recieve_count(nodes, 0);

    // for (int i = 0; i < nodes_per_p; i++)
    // {
    //     cout << rank << endl;
    //     for (int j = 0; j < nodes; j++)
    //     {
    //         cout << adjacency_matrix[pos(i, j, nodes)] << " ";
    //     }
    //     cout << endl;
    // }
    for (int i = 0; i < nodes; i++)
    {
        colors[i] = 0;
    }
    for (int i = 0; i < nodes_per_p; i++)
    {
        for (int j = 0; j < nodes; j++)
        {
            // cout << pos2(rank, nodes, totalprocs, i) << ' ' << j << endl;
            if (pos2(rank, nodes, totalprocs, i) == j)
            {
                // cout << "here"
                //      << " " << rank << " " << j << endl;

                continue;
            }

            else if (adjacency_matrix[pos(i, j, nodes)] != 1)
            {

                continue;
            }

            else if (rank == rank_of_node((j), nodes, totalprocs))
            {
                // cout << "test" << rank << " " << pos2(rank, nodes, totalprocs, i) << endl;
                // cout << pos2(rank, nodes, totalprocs, i) << " "
                //      << "send"
                //      << " " << j << endl;
                continue;
            }

            else if (weights[pos2(rank, nodes, totalprocs, i)] < weights[j])
            {
                recieving[i].push_back(j);
                recieve_count[i]++;
            }

            else
            {
                sending[i].push_back(j);
                send_count[i]++;
            }
        }

        // cout << "////////////////Testing////////////" << endl;
        // for (int i = 0; i < nodes; i++)
        // {
        //     cout << weights[i] << " ";
        // }
        // cout << endl;
        // cout << "////////////////Testing////////////" << endl;

        int flag = 0;

        for (int j = 0; j < nodes; j++)
        {
            if (pos2(rank, nodes, totalprocs, i) != j)
            {
                if (adjacency_matrix[pos(i, j, nodes)] == 1 && rank != rank_of_node((j + 1), nodes, totalprocs))
                {
                    flag = 1;
                    break;
                }
            }
        }

        if (!flag)
        {
            local_count[i] = 1;
            local_nodes_count++;
            continue;
        }
        else
        {
            local_count[i] = 0;
        }
        // cout << rank << " " << i << endl;
        if (recieve_count[i] == 0)
        {
            vector<int> neigh_colors;
            actual_pos = pos2(rank, nodes, totalprocs, i);
            for (int j = 0; j < nodes; j++)
            {
                if (actual_pos != j && adjacency_matrix[pos(i, j, nodes)] == 1 && colors[j] != 0)
                {
                    neigh_colors.push_back(colors[j]);
                }
            }
            int color = 1;
            for (color = 1; color <= nodes; color++)
            {
                if (count(neigh_colors.begin(), neigh_colors.end(), color) == 0)
                {
                    colors[pos2(rank, nodes, totalprocs, i)] = color;
                    break;
                }
            }

            int color_done = colors[pos2(rank, nodes, totalprocs, i)];
            coloring_done++;
            int message_colors[2] = {actual_pos, color_done};

            for (int neighbors = 0; neighbors < sending[i].size(); neighbors++)
            {
                int send_node = sending[i][neighbors];
                // cout << "send"
                //      << " " << rank_of_node((send_node), nodes, totalprocs) << endl;
                MPI_Isend(&message_colors, 2, MPI_INT, rank_of_node((send_node), nodes, totalprocs), 0, MPI_COMM_WORLD, &request);
                // MPI_Isend(&actual_pos, 1, MPI_INT, rank_of_node((neighbors + 1), nodes, totalprocs), 0, MPI_COMM_WORLD, &request);
            }
        }
    }

    while (coloring_done + local_nodes_count != nodes_per_p)
    {
        // cout << "recieve"
        //      << " " << rank << endl;
        // cout << "yes" << endl;
        int color_recv, target_node;
        int message_out[2];
        MPI_Recv(message_out, 2, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        // MPI_Recv(&target_node, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        // cout << rank << endl;

        target_node = message_out[0];
        color_recv = message_out[1];
        colors[target_node] = color_recv;

        for (int j = 0; j < nodes_per_p; j++)
        {
            if (recieve_count[j] == 0)
            {
                continue;
            }
            else if (local_count[j] > 0)
            {
                continue;
            }

            auto it = find(recieving[j].begin(), recieving[j].end(), target_node);
            if (it != recieving[j].end())
            {
                recieving[j].erase(it);
                recieve_count[j]--;
            }

            if (recieve_count[j] > 0)
            {
                continue;
            }

            vector<int> neigh_colors;
            actual_pos = pos2(rank, nodes, totalprocs, j);
            for (int k = 0; k < nodes; k++)
            {
                if (actual_pos != k && adjacency_matrix[pos(j, k, nodes)] == 1 && colors[k] != 0)
                {
                    neigh_colors.push_back(colors[k]);
                }
            }
            int color = 1;
            for (color = 1; color <= nodes; color++)
            {
                if (count(neigh_colors.begin(), neigh_colors.end(), color) == 0)
                {
                    colors[pos2(rank, nodes, totalprocs, j)] = color;
                    break;
                }
            }

            int color_done = colors[pos2(rank, nodes, totalprocs, j)];
            coloring_done++;
            int message_colors[2] = {actual_pos, color_done};

            for (int neighbors = 0; neighbors < sending[j].size(); neighbors++)
            {
                int send_node = sending[j][neighbors];
                MPI_Isend(&message_colors, 2, MPI_INT, rank_of_node((send_node), nodes, totalprocs), 0, MPI_COMM_WORLD, &request);
                // MPI_Isend(&actual_pos, 1, MPI_INT, rank_of_node((neighbors + 1), nodes, totalprocs), 0, MPI_COMM_WORLD, &request);
            }
        }
    }

    for (int i = 0; i < nodes_per_p; i++)
    {
        if (local_count[i] > 0)
        {
            vector<int> neigh_colors;
            actual_pos = pos2(rank, nodes, totalprocs, i);
            for (int j = 0; j < nodes; j++)
            {
                if (actual_pos != j && adjacency_matrix[pos(i, j, nodes)] == 1 && colors[j] != 0)
                {
                    neigh_colors.push_back(colors[j]);
                }
            }
            int color = 1;
            for (color = 1; color <= nodes; color++)
            {
                if (count(neigh_colors.begin(), neigh_colors.end(), color) == 0)
                {
                    colors[pos2(rank, nodes, totalprocs, i)] = color;
                    break;
                }
            }
        }
    }

    // cout << endl;

    // for (int i = 0; i < nodes_per_p; i++)
    // {
    //     cout << send_count[i] << " " << recieve_count[i];
    // }

    // cout << endl;
    // cout << rank << endl;
    // cout << "Resuts" << endl;
    // cout << rank << endl;
    // for (int i = 0; i < nodes; i++)
    // {
    //     cout << colors[i] << " ";
    // }
    // cout << endl;
    MPI_Send(&colors[(rank - 1) * (nodes / (totalprocs - 1))], nodes_per_p, MPI_INT, 0, 0, MPI_COMM_WORLD);
}

int main(int argc, char **argv)
{
    int *matrix;
    int *weights;
    int *colors;
    // number of nodes and edges
    int nodes, edges;

    // temp variable for showing edge
    int node1, node2;

    int nodes_per_p, remain;

    int rank, numprocs;
    MPI_Request *reqs;
    MPI_Status *status;
    static int excl_ranks[1] = {0};

    MPI_Group orig_group, workers_group;
    MPI_Comm comm_workers;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    MPI_Comm_group(MPI_COMM_WORLD, &orig_group);
    MPI_Group_excl(orig_group, 1, excl_ranks, &workers_group);
    MPI_Comm_create(MPI_COMM_WORLD, workers_group, &comm_workers);
    ifstream data(argv[1]);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    if (rank == 0)
    {
        data >> nodes >> edges;
        // srand(time(NULL));
        weights = new int[nodes];
        for (int i = 0; i < nodes; i++)
        {
            weights[i] = rand();
        }

        reqs = new MPI_Request[numprocs - 1];
        status = new MPI_Status[numprocs - 1];
    }

    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Bcast(&nodes, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        matrix = new int[(nodes + 2) * (nodes + 2)];
        for (int i = 0; i < ((nodes + 2) * (nodes + 2)); i++)
            matrix[i] = 0;

        for (int i = 0; i < edges; i++)
        {
            data >> node1 >> node2;
            matrix[pos(node1 - 1, node2 - 1, nodes)] = 1;
            matrix[pos(node2 - 1, node1 - 1, nodes)] = 1;
        }

        colors = new int[nodes];
        nodes_per_p = (nodes) / (numprocs - 1);
        remain = nodes % (numprocs - 1);
        for (int i = 1; i < numprocs; i++)
        {
            MPI_Send(&weights, nodes, MPI_INT, i, 0, MPI_COMM_WORLD);

            if (i != numprocs - 1)
            {
                MPI_Send(&matrix[(i - 1) * nodes * nodes_per_p], nodes * nodes_per_p, MPI_INT, i, 0, MPI_COMM_WORLD);
            }

            else
            {
                MPI_Send(&matrix[(i - 1) * nodes * nodes_per_p], (nodes * (nodes_per_p + remain)), MPI_INT, i, 0, MPI_COMM_WORLD);
            }
        }

        for (int i = 1; i < numprocs; i++)
        {
            if (i != numprocs - 1)
            {
                MPI_Irecv(&colors[(i - 1) * nodes_per_p], nodes_per_p, MPI_INT, i, 0, MPI_COMM_WORLD, &reqs[i - 1]);
            }

            else
            {
                MPI_Irecv(&colors[(i - 1) * nodes_per_p], nodes_per_p + remain, MPI_INT, i, 0, MPI_COMM_WORLD, &reqs[i - 1]);
            }
        }
        MPI_Waitall(numprocs - 1, reqs, status);
        ofstream myfile;
        myfile.open(argv[2]);
        myfile << *max_element(colors, colors + nodes) << endl;
        for (int i = 0; i < nodes; i++)
        {
            myfile << colors[i] << " ";
        }

        myfile << endl;
    }

    else
    {
        process_coloring(rank, numprocs, &comm_workers, nodes);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}