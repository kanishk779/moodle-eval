# Question 1

## Implementation Details

Rank 0 process reads from the input file and broadcasts it to all the processes and then each process starts calculating the local sum of the elements it is assigned to calculate. In the solution, all the values from rank+1 to input value in multiples of the number of processes are assigned 

After calculating the local sum mpi_reduce is used to sum all the local sum to the global sum and rank 0 process writes in the output file.

# Question 2

## Implementation Details
Rank 0 process reads from the input file and finds the subarray size which needs to be assigned to each process and starts reading elements from the input file and after reading elements from the input file, extra vacant spaces are filled with INT_MAX to remove the ambiguities by random/redundant values.

The sub-array size is broadcasted to all the processes for them to allocate appropriate size memory. The respective sub-arrays are then scattered to the processes and QuickSort is called by each process to sort their local subarrays. The sub-arrays are gathered back to the main array creating sorted equal-sized sub arrays. To merge and sort these subarrays a heap is created whose size is equal to the number of processes. We initialize the heap with the first element of each sorted subarray and extract the minimum of it. Whenever any element is extracted from the heap, the next element of the subarray is inserted and again heap is formed and we repeat this process n times. The merging process is entirely done by the rank 0 process to remove possible error chances. 


# Question 3

## Implementation Details

The rank 0 process takes the input and constructs an adjacency matrix and decides the number of nodes to be distributed to each node. Each node starts colouring firstly we assign some random weights to nodes so that we can decide the nodes to be coloured first. The weights having weight highest than its neighbours are coloured first all the corresponsing neighbours are sent a non blocking message for the purpose that it doesn't perform deadlock. After completing the colouring of nodes that have highest weight we proceed for the nodes which are reciving colors from other nodes to decide their colors and after recieving all the messages from the neighbouring nodes we assign the colour based on the colour of the neighbours. At the end all the left out nodes which are local and haven't been assigned the colour are assigned the colour.  