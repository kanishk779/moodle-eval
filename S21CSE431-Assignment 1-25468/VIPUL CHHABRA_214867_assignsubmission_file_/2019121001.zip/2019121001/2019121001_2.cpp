/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

class node
{
public:
    int value, i, j;
};

class MinHeap
{

public:
    vector<node> *harr;
    int size;
    MinHeap(auto a, int size)
    {
        this->size = size;
        this->harr = a;
        int iter = (this->size - 1) / 2;
        while (iter >= 0)
        {
            heapify(iter);
            iter--;
        }
    }
    void heapify(int i)
    {
        int l = ((2 * i) + 1);
        int r = ((2 * i) + 2);
        int smallest = i;
        if (l < this->size && this->harr->at(l).value < this->harr->at(i).value)
        {
            smallest = l;
        }

        if (r < this->size && this->harr->at(r).value < this->harr->at(smallest).value)
        {
            smallest = r;
        }

        if (smallest != i)
        {
            swap(this->harr->at(i), this->harr->at(smallest));
            heapify(smallest);
        }
    }

    void replaceMin(node x)
    {
        this->harr->at(0) = x;
        heapify(0);
    }
};

int *mergeSubArrays(int arr[], int n, int sub_array_size, int numProcesses)
{
    int *output = new int[sub_array_size * numProcesses];

    auto *heap = new vector<node>(numProcesses);

    for (int i = 0; i < numProcesses; i++)
    {
        heap->at(i).value = arr[(i * sub_array_size)];
        heap->at(i).i = i;
        heap->at(i).j = 1;
    }

    MinHeap minHp(heap, numProcesses);

    for (int i = 0; i < (numProcesses * sub_array_size); i++)
    {
        output[i] = INT_MAX;
    }

    for (int i = 0; i < n; i++)
    {
        node root = minHp.harr->at(0);
        output[i] = root.value;
        if (root.j < sub_array_size)
        {
            root.value = arr[(root.i * sub_array_size) + root.j];
            root.j += 1;
        }

        else
        {
            root.value = INT_MAX;
        }

        minHp.replaceMin(root);
    }

    return output;
}

int partition(int arr[], int start, int end)
{
    int mid = end;
    int pivot = arr[mid];
    int smaller = start - 1;

    for (int j = start; j < end; j++)
    {
        if (arr[j] < pivot)
        {
            smaller++;
            swap(arr[smaller], arr[j]);
        }
    }

    swap(arr[smaller + 1], arr[mid]);
    return (smaller + 1);
}

void quickSort(int arr[], int start, int end)
{

    if (start < end)
    {
        int part = partition(arr, start, end);
        quickSort(arr, start, part - 1);
        quickSort(arr, part + 1, end);
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;
    int size, sub_array_size;
    int *arr, *sub_arrays;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */

    if (rank == 0)
    {
        ifstream data(argv[1]);
        data >> size;

        sub_array_size = (int)ceil(((float)size / (float)numprocs));

        MPI_Alloc_mem(sub_array_size * numprocs * sizeof(int), MPI_INFO_NULL, &arr);
        int x, i = 0;

        while (data >> x)
        {
            arr[i] = x;
            i++;
        }

        data.close();

        for (i = size; i < (sub_array_size * numprocs); i++)
        {
            arr[i] = INT_MAX;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);

    MPI_Bcast(&sub_array_size, 1, MPI_INT, 0, MPI_COMM_WORLD);

    MPI_Alloc_mem(sub_array_size * sizeof(int), MPI_INFO_NULL, &sub_arrays);

    MPI_Scatter(arr, sub_array_size, MPI_INT, sub_arrays, sub_array_size, MPI_INT, 0, MPI_COMM_WORLD);
    quickSort(sub_arrays, 0, sub_array_size - 1);

    MPI_Barrier(MPI_COMM_WORLD);

    int status = MPI_Gather(sub_arrays, sub_array_size, MPI_INT, arr, sub_array_size, MPI_INT, 0, MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;

    MPI_Free_mem(sub_arrays);

    if (rank == 0)
    {

        int *output = mergeSubArrays(arr, size, sub_array_size, numprocs);
        ofstream myfile;
        myfile.open(argv[2]);

        for (int i = 0; i < (size); i++)
        {
            myfile << output[i] << " ";
        }

        myfile << endl;

        myfile.close();
    }

    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}