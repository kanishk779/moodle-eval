Analysis 1st

let np=number of cores
N= input integer
here I have split n into number of cores
such as N/np

last core is handled sepreately to ensure that it contains only left over last few values



Example :
100/7 = 14   N/np

core 1: [1,2,...14]  computation(1/1^1 + 1/2^2 + ... 1/14^14)
core 2: [15 .... 28]
core 3..  .....
.
.
.
core 7  [....100]

the all evaluated values will be sent to core 1 that is rank=0

Analysis 2nd

Here we have made use of quicksort paralelly using muliple process
Here array size is n and processes are p

N is divided equally among all process .
that is n/p;
sort each subarray using quicksort done by process parallely.
Then merging of sorted subarray will take place.
In merging 2 subarrays are combined at a time untill 1 final sorted subarray is produced.



