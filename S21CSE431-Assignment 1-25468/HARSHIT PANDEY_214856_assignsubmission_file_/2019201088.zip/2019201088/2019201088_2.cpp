#include<bits/stdc++.h>
#include <mpi.h>
#include <stdio.h>
using namespace std;
// ./moss -l c fp_ab.py fp_sh.py
int piviot(int *&q,int l,int h)
{
	int p=q[h-1];
	vector<int>vp1;
	vp1.push_back(p);
	int i=l-1;
	int alp=0,gam=0;;
	for(int j=l;j<h;j++)
	{
		int bet=0;
		alp++;
		if(q[j]<p)
		{
			alp+=bet;
			i++;
			swap(q[i],q[j]);
		}
		bet--;
	}
	gam+=alp;
	swap(q[i+1],q[h-1]);
	alp--;
	return i+1;
}
void quick(int *&q,int l,int h)
{	
	int jk=0,jl=0;
	if(l<h)
	{

		int p=piviot(q,l,h);
		jk+=p;
		quick(q,l,p);
		quick(q,p+1,h);
	}
}
int merge(int *a,int *b,int n1,int n2,int *&arr)
{
	int jk,jl=0;
	int i=0,j=0,k=0;
	int alp=0,gam=0,bet=0;
	while(i<n1||j<n2)
	{
		alp+=gam;
		if(i>=n1)
		{
			jk++;
			arr[k++]=b[j++];
		}
		else if(j>=n2)
		{
			jl--;
			arr[k++]=a[i++];
		}
		else if(a[i]>b[j])
		{
			jk+=jl;
			arr[k++]=b[j++];	
		}
		else
		{
			jk-=jl;
			arr[k++]=a[i++];
		}
	}
}
int main(int argc, char* argv[])
{
	int final_;
	FILE *ptr;
	int *arr,*ch,*data;
	int alp=0,bet=0,gam=0;
	int n;
	
	vector<int>klp;
	vector<int>ins;
	alp+=gam;
	int actual,act=0;
	map<int,int>mph;
	MPI_Init(&argc, &argv); 
	int rank;
	int size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Barrier( MPI_COMM_WORLD );
	int nkevr=0;
	double tbeg = MPI_Wtime();
	if(size==1)
	{
		alp++;
		
		ptr=fopen(argv[1],"r");
		gam+=alp;
		fscanf(ptr,"%d",&n);
		alp++;
		arr=new int[n];
		gam+=bet;
		final_=n;
		bet++;
		for(int i=0;i<n;i++)
		{
			int pp;
			gam-=alp;

			fscanf(ptr,"%d",&pp);
			arr[i]=pp;
		}
		vector<int>kjj;
		gam--;
		int ku=0;
		quick(arr,0,n);
		ku+=alp;
		fclose(ptr);

		alp--;
		ptr=fopen(argv[2],"w");
		ku-=alp;
		for(int i=0;i<final_;i++)
		{
			mph[i]+=2;
			fprintf(ptr,"%d ",arr[i]);
		}
		fclose(ptr);
		vector<int>njf;
		double elapsedTime = MPI_Wtime() - tbeg;
		int yth=0;
		double maxTime;
		njf.push_back(yth);
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
		alp=0;
		if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
		}
		MPI_Finalize(); 
		return 0;
	}	
	alp=0,bet=0;
	data = new int[size+1];
	gam=0;
	if(rank==0)
	{
		alp+=bet;
		ptr=fopen(argv[1],"r");
		vector<int>mlp;
		alp+=gam;


		fscanf(ptr,"%d",&n);
		int yr=alp;
		final_=n;actual=n;
		yr+=alp;
		int x=n%size;
		alp+=gam;
		actual=n;
		if(x>0)
		{
			vector<int>ins;
			arr=new int[n+(size-x)];
			ins.push_back(alp);
			for(int i=n;i<n+size-x;i++)
				arr[i]=INT_MAX;
			ins.push_back(gam);
			actual=n+size-x;
		}
		else
		{
			mph[alp]++;
			arr=new int[n];
		}
		actual=actual/size;
		mph[gam]--;
		if(size-x>actual&&x!=0)
		{
			ins.push_back(alp);
			for(int i=0;i<size-2;i++)
			{
				mph[gam]--;
				data[i]=actual;
			}
			data[size-2]=n-(actual*(size-2));
			ins.push_back(gam);
			data[size-1]=0;
			data[size]=1;
		}
		else
		{
			ins.push_back(bet);
			for(int i=0;i<size-1;i++)
			{
				mph[bet]++;
				data[i]=actual;
			}
			ins.push_back(bet);
			data[size-1]=n-actual*(size-1);
			data[size]=0;
		}
		ins.clear();
		for(int i=0;i<n;i++)
		{
			int pp;
			ins.push_back(alp);
			fscanf(ptr,"%d",&pp);
			alp+=1;
			arr[i]=pp;
			gam--;
		}
		fclose(ptr);
	}
	ins.push_back(alp);
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(data,size+1,MPI_INT,0,MPI_COMM_WORLD);
	alp+=0;
	actual=data[0];
	int yut=alp;
	if(data[size]!=1)
	{
		ins.push_back(alp);
		ch= new int[actual];
		mph[alp]--;
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		alp=0;
		act=actual;
		gam=0;
		if((rank+1)!=size)
			quick(ch,0,data[rank]);
		else
		{
			ins.push_back(alp);
			quick(ch,0,data[rank]);
			act=data[rank];

		}
		ins.clear();
		for(int i=1;i<size;)
		{
			mph[i]++;
			int itr=2*i;
			if(rank%itr==0)
			{
				ins.push_back(alp);
			}
			else
			{
				alp+=gam;
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			ins.push_back(bet);
			if((rank+i)<size)
			{	
				ins.push_back(bet);
				int ss=0;
				alp+=gam;
				if((actual*(rank+2*i))>n)
				{
					gam=0;
					 ss=n-actual*(rank+i);
				}			
				else
				{
					bet=0;
					ss=actual*i;
				}
				ins.push_back(alp);
				int *nn=new int[ss];
				bet+=gam;
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				mph[bet]--;
				arr=NULL;
				arr=new int[act+ss];
				ins.push_back(alp);
				merge(ch,nn,act,ss,arr);
				ins.clear();
				act+=ss;
				ch=arr;
			}
			i=itr;
		}
	}
	else
	{
		ins.push_back(alp);
		ch= new int[actual];
		alp++;
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		bet--;
		act=data[0];
		alp+=bet;
		n=actual*(size-1);
		quick(ch,0,data[rank]);
		size--;
		for(int i=1;i<size;)
		{
			int itr=2*i;
			if(rank%itr==0)
			{
				ins.push_back(alp);
			}
			else
			{
				ins.push_back(alp);
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				break;
			}
			ins.push_back(bet);
			if((rank+i)<size)
			{	
				int ss=0;
				mph[ss]++;
				if((actual*(rank+2*i))>n)
				{
					ins.push_back(alp);
					 ss=n-actual*(rank+i);
				}			
				else
				{
					alp=0;
					ss=actual*i;
				}
				int *nn=new int[ss];
				ins.push_back(alp);
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				arr=NULL;
				gam+=alp;
				arr=new int[act+ss];
				ins.push_back(alp);
				merge(ch,nn,act,ss,arr);
				ins.clear();
				act+=ss;
				gam=0;
				ch=arr;
			}
			alp=0;
			i=itr;
		}
	}
	if(rank==0)
	{
		bet=0;
		ptr=fopen(argv[2],"w");
		ins.push_back(alp);
		for(int i=0;i<final_;i++)
		{
			alp=0;
			fprintf(ptr,"%d ",arr[i]);
		}
		fclose(ptr);
	}
	ins.clear();
	gam=0;
	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if(rank==0) 
	{
		printf( "Total time (s): %f\n", maxTime );
	}
	MPI_Finalize(); 
return 0;
}
		
