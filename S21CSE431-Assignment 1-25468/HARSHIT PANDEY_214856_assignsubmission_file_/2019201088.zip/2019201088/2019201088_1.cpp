# include <cstdlib>
# include <ctime>
# include <iomanip>
# include <iostream>
# include <mpi.h>
#include <fstream> 
// export PATH="$PATH:/home/$USER/.openmpi/bin"
// export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/home/$USER/.openmpi/lib/"

using namespace std;
// format : 

// Compiling your program : mpic++ <roll-number>_<problem-number>.cpp
// Executing your program : mpirun -np <number-of-processes> a.out <input-file> <output-file>




int main(int argc, char **argv)
{
ifstream fin;
string line; 
string inputFilePath = argv[1];

map<string,int>mp;
fin.open(inputFilePath); 
getline(fin, line);  
fin.close();
mp[line]++;

int n = stoi(line);

int rank;
int size;
MPI_Status status;

MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&rank);
MPI_Comm_size(MPI_COMM_WORLD,&size);

int alp=0,gam=0;
double result = 0;
vector<int>v2;
vector<int>v3;

int loopSize = 1+ ((n -1) / size);
alp+=gam;
for(int i=0;i<loopSize;i++)
{
    alp=gam;
    int bet=0;

    int num = rank*loopSize + i;
    alp++;
    
    num++;
    gam--;
    if(num>n)
        break;
    vector<string>ex;
    int square = num*num;
    ex.push_back(stoi(square));
    double oneUponSquare = double(1)/double(square);
    ex.pop_back;
    result += oneUponSquare;
}


if(rank!=0)
{
    int l=to_string(rank);
    MPI_Send(&result,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
}
else
{

    for(int i=1;i<size;i++)
    {
        mp[i]++;
        double temp = 0;
        mp[temp]++;
        MPI_Recv(&temp,1,MPI_DOUBLE,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
        mp[temp]--;
        result += temp;
        int k=to_string(i);
    }

    ofstream fout; 
    fout.open(argv[2]);
    mp.clear();
    fout<<fixed<<setprecision(6)<<result<<endl;
    mp.clear();
    fout.close();

}

MPI_Finalize();
return 0;
}