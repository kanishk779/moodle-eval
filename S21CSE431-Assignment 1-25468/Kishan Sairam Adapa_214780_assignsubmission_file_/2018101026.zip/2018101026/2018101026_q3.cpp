/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

char adj_mat[500][500]; // Using char to save message size overhead
int color_count = 0;
int color_map[500][500]; // colour storage - color_map[c][id] => c is to vertex id
int global_color_map[500][500]; // colour storage - color_map[c][id] => c is to vertex id
int avail_color[500][500]; // available colors - avail_color[id][c] => id can have color c
bool color_node[500]; 
int degree[500]; // degree of nodes
int avail_node[500]; // no of colors available for node

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    ifstream cin(argv[1]);
    ofstream cout(argv[2]);

    int m;
    vector< vector<int> > edge_list(500, vector<int> (2, 0));

    if(rank == 0) {
        int n;
        cin >> n >> m;
        // cin >> n >> n >> m; // Dummy loader for mtx format test cases from pyrgg
        // printf("n %d m %d\n", n, m);
        for(int i=0; i<m; i++) {
            int t1, t2;
            cin >> t1 >> t2;
            // cin >> t1 >> t2 >> n; // Dummy loader for mtx format test cases from pyrgg
            edge_list[i][0] = t1;
            edge_list[i][1] = t2;
        }
        // Edge coloring using vertex coloring of line graph
        for(int i=0; i<m; i++) {
            for(int j=0; j<i; j++) {
                if(edge_list[i][0] == edge_list[j][0] || edge_list[i][0] == edge_list[j][1] || edge_list[i][1] == edge_list[j][0] || edge_list[i][1] == edge_list[j][1]) {
                    adj_mat[i][j] = 1;
                    adj_mat[j][i] = 1;
                }
            }
        }
        // printf("m is %d\n", m);

    }

    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Node ids distributed across processes
    int start_node = (m * rank) / numprocs;
    int end_node = (m * (rank+1)) / numprocs;

    MPI_Bcast(adj_mat, 500 * 500, MPI_CHAR, 0, MPI_COMM_WORLD);

    int max_deg = 0;
    for(int i=0; i<m; i++) {
        for(int j=0; j<m; j++) {
            degree[i] += adj_mat[i][j];
            max_deg = max(max_deg, degree[i]);
        }
    }

    struct SELECTED_NODE {
        int id;
        int avail;
    };

    int min_deg; // minimum degree node selection
    int min_avail; // with minimum number of available colours
    int min_id; // track node id

    for(int round=0; round < m; round++) {
        min_deg = m; // at max degree m-1
        min_avail = m; // final num of colours <= m
        min_id = m; // id of any node < m
        
        // Check in the nodes for this process
        for(int i=start_node; i<end_node; i++) {
            // If node not yet ready to be coloured
            if(!color_node[i]) {
                // Find least degree node with lowest number of available colours
                if(degree[i] < min_deg) {
                    if(avail_node[i] <= min_avail) {
                        min_avail = avail_node[i];
                        min_deg = degree[i];
                        min_id = i;
                    }
                }
            }
        }

        SELECTED_NODE *curr = (SELECTED_NODE *) malloc(sizeof(SELECTED_NODE));
        curr->id = min_id;
        curr->avail = min_avail;

        // printf("Rank %d - SENDDD id %d, avail %d\n", rank, min_id, min_avail);


        SELECTED_NODE *global = (SELECTED_NODE *) malloc(sizeof(SELECTED_NODE));
        MPI_Allreduce(curr, global, 1, MPI_2INT, MPI_MINLOC, MPI_COMM_WORLD);

        int id = global->id;
        int avail = global->avail;

        // printf("Rank %d - GOTTT id %d, avail %d\n", rank, id, avail);

        free(curr);
        free(global);

        color_node[id] = 1;
        // Colour the node
        if(avail == 0) {
            // No available colours, create new colour
            color_map[color_count][id] = 1; // Update location
            
            // Update in possibilities for all non connected nodes
            for(int i=0; i<m; i++) {
                if((!color_node[i]) && adj_mat[id][i] == 0) {
                    avail_color[i][color_count] = 1;
                    avail_node[i]++;
                }
            }

            // Increase color count
            color_count++;

        } else {
            // Assign one of the old classes
            // printf("Rank %d -In assign\n", rank);
            int iter_proc = 0, c;

            for(c = 0; avail_color[id][c] == 0; c++) {
                if(c >= color_count)
                    printf("\t(%d, %d, %d)\n", rank, id, c);
                // printf(">>>>>> BCAST from %d value of c %d\n", rank, c);
                MPI_Bcast(&c, 1, MPI_INT, rank, MPI_COMM_WORLD);
            }

            // printf("Rank %d - After this - here c %d id %d\n", rank, c, id);
            // Assign color
            color_map[c][id] = 1;

            // Make color unavailalbe for adjacent nodes
            for(int i=0; i<m; i++) {
                // printf("i %d id %d c %d\n", i, id, c);
                if(!color_node[i] && avail_color[i][c] && adj_mat[i][id]) {
                    avail_color[i][c] = 0;
                    avail_node[i]--;
                }
            }
        }

    }

    if(rank == 0) {
        // vector< map<int, int> > checker(101);
        cout << color_count << '\n';
        if(color_count > max_deg + 1) {
            printf("Ouch! more colours used\n");
            return 1;
        }

        // Code for correctness check has been commented for performance

        // vector<int> colors;
        for(int i=0; i<m; i++) {
            for(int j=0; j<color_count; j++) {
                if(color_map[j][i] > 0) {
                    // colors.push_back(j+1);
                    cout << j+1 << ' ';
                    // cout << j+1 <<  ' ' <<  i << ' ' << "(" << edge_list[i][0] << ", " << edge_list[i][1] << ")"  << '\n'; // Debug print
                    // checker[edge_list[i][0]][j+1]++;
                    // checker[edge_list[i][1]][j+1]++;
                }
            }
        }
        cout << '\n';

        // // Check using line graph having any two adjacent vertices same colour
        // for (int i = 0; i < m; i++){
        //     for (int j = 0; j < m; j++){
        //         if (i == j)
        //             continue;
        //         bool wrong = colors[i] == colors[j] && adj_mat[i][j];
        //         if (wrong){
        //             printf("Invalid %d - (%d, %d) adjacent to %d - (%d, %d) and have same colour %d\n", i, edge_list[i][0], edge_list[i][1], j, edge_list[j][0], edge_list[j][0], colors[i]);
        //         }
        //     }
        // }

        // // Check using no vertex has more than 1 edge with same colour incident
        // for(int i=0; i<101; i++) {
        //     for(auto c: checker[i]) {
        //         // printf("Vertex %d - (Colour: %d, Count: %d)\n", i, c.first, c.second);
        //         if(c.second > 1) {
        //             printf("No way! Wrong\n");
        //             return 1;
        //         }
        //     }
        // }

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}