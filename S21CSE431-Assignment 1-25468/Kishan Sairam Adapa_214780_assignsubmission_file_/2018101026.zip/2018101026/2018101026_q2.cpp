/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;  

int partition(int *arr, int start, int end) {
    int pivot = arr[end];
    int first_gt = -1;
    for(int i=start; i<end; i++) {
        if(first_gt == -1 && arr[i] > pivot) first_gt = i;
        if(first_gt != -1 && arr[i] <= pivot) {
            int temp = arr[i];
            arr[i] = arr[first_gt];
            arr[first_gt] = temp;
            first_gt++;
        }
    }
    if(first_gt != -1) {
        int temp = arr[end];
        arr[end] = arr[first_gt];
        arr[first_gt] = temp;
    } else {
        first_gt = end;
    }
    return first_gt;
}

void quickSort(int *arr, int start, int end)  
{  
    if(end <= start) return;
    int p_id = partition(arr, start, end);
    quickSort(arr, start, p_id-1);
    quickSort(arr, p_id, end);
}

void merge(int *arr, int s1, int e1, int s2, int e2) {
    if(s1 > e1 || s2 > e2 || e1 >= s2) return;
    int p1 = s1, p2 = s2;
    int sz = (e1-s1+1) + (e2-s2+1);
    int store[sz];
    sz = 0;
    while(p1 <= e1 && p2 <= e2) {
        if(arr[p1] <= arr[p2]) {
            store[sz++] = arr[p1++];
        } else {
            store[sz++] = arr[p2++];
        }
    }
    while(p1 <= e1) {
        store[sz++] = arr[p1++];
    }
    while(p2 <= e2) {
        store[sz++] = arr[p2++];
    }
    for(int i=s1; i<=e1; i++) {
        arr[i] = store[i - s1];
    }
    for(int i=s2; i<=e2; i++) {
        arr[i] = store[i - s2 + (e1-s1+1)];
    }
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    ifstream cin(argv[1]);
    ofstream cout(argv[2]);
    
    if(rank == 0) {
        int n;
        cin >> n;
        int arr[n+1];
        for(int i=1; i<=n; i++) {
            int temp;
            cin >> temp;
            arr[i] = temp;
        }
    	if(numprocs == 1) {
            quickSort(arr, 1, n);
        } else {
            int step = n / (numprocs-1);
            if(step == 0) step = 1;
            int merge_step = step;
            int start = 1;
            for(int k=1; k<numprocs; k++) {
                // start -> start + step - 1
                // Not needed based on how step was selected
                // if(start + step > n+1) {
                    // step = n + 1 - start;
                // }
                MPI_Send(arr+start, step, MPI_INT, k, 0, MPI_COMM_WORLD);
                start += step;
                if(start > n) {
                    start = 0;
                    step = 0;
                }
            }
            int to_recv = n;
            // Handle last few left
            if(start != 0 && start <= n) {
                to_recv = start-1;
                quickSort(arr, start, n);
            }
            int done = 0;
            for(int k=1; k<numprocs; k++){
                MPI_Status status;
                MPI_Probe(k, 0, MPI_COMM_WORLD, &status);
                int num_elems;
                MPI_Get_count(&status, MPI_INT, &num_elems);
                if(done < to_recv) {
                    MPI_Recv(arr+1+done, num_elems, MPI_INT, k, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    done += num_elems;
                }
                else
                    MPI_Recv(arr, 1, MPI_INT, k, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
            // Merge arrays
            int last_part = to_recv+1;
            while(2*merge_step <= n) {
                int i;
                for(i=1; i+2*merge_step-1 <= to_recv; i+=2*merge_step) {
                    merge(arr, i, i+merge_step-1, i+merge_step, i+2*merge_step-1);
                }
                if(i <= to_recv) {
                    if(last_part != n+1) {
                        merge(arr, i, last_part-1, last_part, n);
                    }
                    last_part = i;
                }
                merge_step *= 2;
            }
            merge(arr, 1, last_part-1, last_part, n);
        }
        for(int i=1; i<=n; i++) cout << arr[i] << ' ';
            cout << '\n';
    }
    else {
        MPI_Status status;
	    MPI_Probe(0, 0, MPI_COMM_WORLD, &status);
        int num_elems;
        MPI_Get_count(&status, MPI_INT, &num_elems);
        int arr[num_elems];
        MPI_Recv(arr, num_elems, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        quickSort(arr, 0, num_elems-1);
        MPI_Send(arr, num_elems, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}