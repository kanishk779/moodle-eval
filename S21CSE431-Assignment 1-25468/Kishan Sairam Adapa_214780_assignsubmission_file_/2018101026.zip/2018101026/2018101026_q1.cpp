/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    ifstream cin(argv[1]);
    ofstream cout(argv[2]);
    
    if(rank == 0) {
        int N;
        cin >> N;
        if(numprocs == 1) {
            double ans = 0;
            for(int i=1; i<=N; i++) {
                ans += (1 / (double)(i*i));
            }
            cout << fixed << setprecision(6) << ans << '\n';
        } else {
            int step = N / (numprocs-1);
            if(step == 0) step = 1;
            int start = 1;
            int msg[2] = {start, step};
            for(int k=1; k<numprocs; k++) {
                // start -> start + step - 1
                msg[0] = start;
                // Not needed based on how step was selected
                // if(start + step > N+1) {
                //     step = N + 1 - start;
                // }
                msg[1] = step;
                start += step;
                if(start > N) {
                    start = -1;
                    step = 0;
                }
                MPI_Send(msg, 2, MPI_INT, k, 0, MPI_COMM_WORLD);
            }
            double ans = 0;
            // Handle last few left
            if(start != -1 && start <= N) {
                for(int k=start; k<N+1; k++) {
                    ans += (1 / (double)(k*k));
                }
            }
            for(int k=1; k<numprocs; k++) {
                double res;
                MPI_Recv(&res, 1, MPI_DOUBLE, k, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                ans += res;
            }
            cout << fixed << setprecision(6) << ans << '\n';
        }
    } else {
        int msg[2];
        MPI_Recv(msg, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double ans = 0;
        if(msg[0] > 0) {
            for(int i=msg[0]; i<msg[0]+msg[1]; i++) {
                ans += (1 / (double)(i*i));
            }
        }
	    MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}