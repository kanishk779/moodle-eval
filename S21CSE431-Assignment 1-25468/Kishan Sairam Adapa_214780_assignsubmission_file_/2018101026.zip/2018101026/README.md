# MPI Programming
## Disributed Systems Assignment 1

### Problem 1

#### Description

> If number of processes is 1
- Compute required summation directly

> Number of processes = k (> 1)
- Divide as equally as possible betweeen all non-root processes
- Each non root process recieves (start, end) and returns inverse square summation from start till end-1
- `step` = N / (k-1) - used for division of values between processes
- (1, step) (step+1, 2step) (2step+1, 3step) ... are provided to all the process equally
- Let `rem` be remaining ones that were not fit in multiple of step, rem to n are handled by root process
- Corner cases and handling of more no of processes than `n` is done as required

#### Analysis

- Message complexity
    - Number of messages O(numprocs)
    - Size of each message (2 * size of int)
- Time complexity
    - Each process processes at max step number of iterations in for loop = O(step)
    - Collection and send of messages O(numprocs)
    - Effective time complexity O(numprocs + step)

### Problem 2

#### Description

> If number of processes is 1
- Do quicksort locally

> Number of processes = k (> 1)
- Divide as equally as possible betweeen all non-root processes
- Each non root process recieves arr(start, end) and returns array in sorted order using local quicksort
- `step` = N / (k-1) - used for division of values between processes
- (1, step) (step+1, 2\*step) (2\*step+1, 3\*step) ... are provided to all the process equally
- Let `rem` be remaining ones that were not fit in multiple of step, rem to n are handled by root process
- Corner cases and handling of more no of processes than `n` is done as required
- Merging results
    - Pairwise merging is performed, each sorted subarray of size in multiples of `step`
    - First subarrays of size step (as recieved from non root processes) are merged
    - Step size is doubled to account for current state of sorted subarrays after 1 iteration of merge
    - We repeat this process and keep doubling step size at each stage to achieve least amount of merge calls possible
    - When doing this, we encounter cases where remaining part of subarray may either be left out in pairing or isn't a multiple of step size. Such cases are handled in code using `last_part` variable to ensure appropriate mergings take place at each level

#### Analysis

- Message Complexity
    - Number of messages O(numprocs)
    - Size of each mesage O(step * size of int)
- Time complexity
    - Each process performs quick sort of at max step number of elements = Amortized O(step * log_2(step))
    - Root process peforms O(n) operations at each level for merging and in total we have log_step levels = O(n * log_step(n))
    - Effective time complexity = O(step * log_2(step) + n * log_step(n))

### Problem 3

#### Description

> Approach is to use vertex colouring on line graph to obtain edge colouring on original graph.

- By node we refer to vertex in line graph (which actually is a edge in original graph)
- `m` number of nodes (`n`, `m` are inputs for original graph)
- For every node we store number of available colours for that node and initially intitialzed to 0
- We use greedy approach of choosing node with least degree and least number of available number of colours
- To take advantage of parallelization we partition the graph using vertex numbers and using MPI_Allreduce we find global greedy selection using local selections from each process
- At each step the number of available colours is checked
    - If none are available for that node then a new colour is created and assigned to it. This new colour generation logic is same for all the processes hence we don't need to broadcast colour selection from one process to other since all of them choose same colour for the global greedy choice. We assign this colour and update availablity for all other nodes
    - If one or more colours are available then we need to use message passing to figure out if asssigning this colour to this node creates any conflict in any other process
        - We broadcast non available colours (in for loop incrementing) from this process to all others, by this way at the end of for loop all processes have maximum (integer value) colour that is not possible for atleast one of processes
        - Since for has c++ at end, we increment that and this ensures all processes choose least integer value colour that is acceptable for all the processes. We assign this colour and update availablity for all other nodes
- At each iteration of outer most for loop exactly one vertex is coloured everytime thus we run it for number of vertices and acheive vertex colouring.
- Using this vertex colouring of line graph, we have effectively obtained edge colouring of original graph

#### Analysis

- Message Complexity
    - For each greedy choice, using all_reduce though we get better speed, message complexity is still O(numprocs). Greedy choices = O(m * numprocs)
    - For colour selection. We have at max 1, 2, 3 .... max_colours number of iterations in the for loop. Generally lesser, but considering maximum case, we have total O(max_colours ^ 2) broadcast messages. Thus total mesages in turn comes out to me O(numprocs * max_colours^2)
    - Effective message complexity = O(numprocs * (m + max_colours^2)), where max_colours <= degree of line graph + 1
    - Messages of broadcast are of size 1 but grredy choice are larger in size of 2 struct, assuming worst of size 2 for all messages. Size of each message = O(2 * size of int)
- Time complexity
    - Analyzing outer for loop on nodes, we have inside it
        - Initial degree finder O(number of local nodes) which still in bigO is O(m)
        - In case of colour availalbe O(m) for assign loop
        - In case of colour not availalbe two for loops, one O(max_colours) for mpi and another O(m) assign loop. Since max_colours < m we can consider it as O(m)
    - Effective time complexity = O(m^2) (in big O)