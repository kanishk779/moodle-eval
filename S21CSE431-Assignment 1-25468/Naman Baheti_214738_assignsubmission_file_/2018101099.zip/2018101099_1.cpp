/* MPI Program Template */
#include "mpi.h"
#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
#include <string.h>

using namespace std;
typedef long long int ll;

int main(int argc, char **argv) {
  int rank, numprocs;

  /* start up MPI */
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  MPI_Barrier(MPI_COMM_WORLD);
  double tbeg = MPI_Wtime();
  string input_filename(argv[1]);
  string output_filename(argv[2]);
  ios::openmode mode = ios::in | ios::out | ios::app;
  std::fstream fio(input_filename.c_str(), mode);
  string line;
  int n = -1;
  if (fio.is_open()) {
    while (getline(fio, line)) {
      if (n == -1) {
        n = stoi(line);
      }
    }
    fio.close();
  }
  double res;
  std::cout.precision(6);
  
  if (numprocs != 1) {
    if (rank != 0) {
      int interval = n / (numprocs - 1);
      int x, y;
      x = interval * (rank - 1);
      y = (interval * rank) - 1;
      res = 0;
      for (int i = x; i <= y; i++) {
        double num = (i+1);
        res += 1/(num*num);
      }
      MPI_Send(&res, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    else {
      double sum = 0;

      for (int source = 1; source < numprocs; source++) {
        MPI_Recv(&res, sizeof(res), MPI_DOUBLE, source, 0, MPI_COMM_WORLD,
                 MPI_STATUS_IGNORE);
        sum += res;
      }
      int mod = n%(numprocs - 1);
      while(mod) {
          double num = (double)(n - mod + 1);
          sum += 1/(num*num);
          mod--;
      }
      mode = ios::in | ios::out | ios::trunc;
      std::fstream fio1(output_filename.c_str(), mode);
      if(fio1.is_open()) {
          fio1 << std::fixed << std::setprecision(6) << sum << endl;
          fio1.close();
      }
    }
  }
  else {
      double sum = 0;
      for(int i = 0;i<n;i++) {
          double num = (i+1);
          sum += 1/(num*num);
      }
      mode = ios::in | ios::out | ios::trunc;
      std::fstream fio1(output_filename.c_str(), mode);
      if(fio1.is_open()) {
          fio1 << std::fixed << std::setprecision(6) << sum << endl;
          fio1.close();
      }
  }
  MPI_Barrier(MPI_COMM_WORLD);
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (rank == 0) {
    printf("Total time (s): %f\n", maxTime);
  }

  /* shut down MPI */
  MPI_Finalize();
  return 0;
}