/* MPI Program Template */

#include "mpi.h"
#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
using namespace std;
typedef int ll;
#define f(i, a, b) for (ll i = a; i < b; i++)
vector<ll> try_error(ll *curr, set<ll> g[], ll m1, ll size, ll *colorVertex) {
  vector<ll> ret(size, 0);
  map<ll, bool> m;
  f(i, 0, size) {
    m.clear();
    ll cv = curr[i];
    for (auto j : g[cv]) {
      ll num = colorVertex[j];
      m[num] = 1;
    }
    f(j, 0, m.size() + 1) {
      if (m.find(j) == m.end()) {
        ret[i] = j;
        break;
      }
    }
  }
  return ret;
}
ll *convertStr(string str) {
  ll n = str.length();
  ll *arr = new ll[n];
  for (ll i = 0; i < n; i++) {
    arr[i] = 0;
  }
  ll j = 0, i, sum = 0;
  for (ll i = 0; str[i] != '\0'; i++) {
    if (str[i] == ' ') {
      j++;
    } else {
      arr[j] = arr[j] * 10 + (str[i] - '0');
    }
  }
  return arr;
}

int main(int argc, char **argv) {
  int rank, numprocs;
  int ans = 0;
  /* start up MPI */
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  // / synchronize all processes /
  MPI_Barrier(MPI_COMM_WORLD);
  double tbeg = MPI_Wtime();

  /* write your code here */

  //----------------------------------------------------------------------------------------------------------------------------------------------------
  string line;
  string input_filename(argv[1]);

  ll n, m;
  map<ll, pair<ll, ll>> ind;

  ll cnt = 0;
  ios::openmode mode = ios::in | ios::out | ios::app;
  std::fstream fio(input_filename.c_str(), mode);
  if (fio.is_open()) {
    while (getline(fio, line)) {
      ll *arr = convertStr(line);
      if (cnt == 0) {
        n = arr[0];
        m = arr[1];
      } else {
        ind[cnt - 1] = {arr[0], arr[1]};
      }
      cnt++;
    }
    fio.close();
  }
  set<ll> g[m];
  f(i, 0, m) {
    f(j, i + 1, m) {
      ll x1 = ind[i].first;
      ll y1 = ind[i].second;
      ll x2 = ind[j].first;
      ll y2 = ind[j].second;
      if (x1 == x2) {
        g[j].insert(i);
        g[i].insert(j);
      } else if (y1 == y2) {
        g[j].insert(i);
        g[i].insert(j);
      } else if (x1 == y2) {
        g[j].insert(i);
        g[i].insert(j);
      } else if (y1 == x2) {
        g[j].insert(i);
        g[i].insert(j);
      }
    }
  }

  if (rank == 0) {
    ll are_others_exited = 0;
    ll colorVertex[m];
    ll is_done[m];
    f(i, 0, m) {
      is_done[i] = 0;
      colorVertex[i] = -1;
    }
    ll rem;
    rem = 1000000;
    while (rem != 0) {
      rem = 0;
      f(i, 0, m) { rem += !is_done[i]; }
      if (rem == 0)
        break;
      ll curr[rem];
      ll flag[rem];
      ll j = 0;
      f(i, 0, m) {
        if (is_done[i] == 0) {
          flag[j] = 0;
          curr[j] = i;
          j++;
        }
      }
      ll color_middle[m];
      f(i, 0, m) { color_middle[i] = 0; }
      f(i, 0, m) { color_middle[i] = colorVertex[i]; }

      ll perproc = rem / numprocs;
      ll l = 0;
      if (perproc != 0) {
        f(i, 1, numprocs) {
          MPI_Send(&perproc, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
          l += perproc;
        }
        l = 0;
        f(i, 1, numprocs) {
          MPI_Send(curr + l, perproc, MPI_INT, i, 0, MPI_COMM_WORLD);
          l += perproc;
        }
        f(i, 1, numprocs) {
          MPI_Send(colorVertex, m, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        l = 0;
        f(i, 1, numprocs) {
          int color_temp[perproc];
          MPI_Recv(&color_temp, perproc, MPI_INT, i, 0, MPI_COMM_WORLD,
                   MPI_STATUS_IGNORE);

          f(j, 0, perproc) {
            int ind = curr[j + l];
            color_middle[ind] = color_temp[j];
          }
          l += perproc;
        }
      } else {
        ll zero = 0;
        are_others_exited = 1;
        f(i, 1, numprocs) { MPI_Send(&zero, 1, MPI_INT, i, 0, MPI_COMM_WORLD); }
      }
      ll cs = perproc;
      cs += rem % numprocs;
      ll color_temp[cs];
      vector<int> ret = try_error(curr + l, g, m, cs, colorVertex);
      f(i, 0, cs) { color_temp[i] = ret[i]; }
      f(i, 0, cs) {
        int ind = curr[i + l];
        color_middle[ind] = color_temp[i];
      }
      f(i, 0, m) {
        for (auto j : g[i]) {
          if (color_middle[i] == color_middle[j]) {
            if (color_middle[i] != -1) {
              color_middle[j] = -1;
            }
          }
        }
      }
      f(i, 0, m) {
        colorVertex[i] = color_middle[i];
        if (colorVertex[i] == -1) {
          continue;
        } else {
          is_done[i] = 1;
        }
      }
    }
    if (are_others_exited == 0) {
      ll zero;
      zero = 0;
      are_others_exited = 1;
      f(i, 1, numprocs) { MPI_Send(&zero, 1, MPI_INT, i, 0, MPI_COMM_WORLD); }
    }
    int max1 = 0;
    map<ll, bool> x;
    map<ll, bool> chk[n + 1];
    f(i, 0, m) {
      x[colorVertex[i]] = 1;
      max1 = max(max1, colorVertex[i]);
    }
    f(i, 0, m) {
      ll x = ind[i].first;
      ll y = ind[i].second;
      ll c = colorVertex[i];
      if (chk[x].find(c) != chk[x].end())
        cout << "Error 404\n";
      if (chk[y].find(c) != chk[y].end())
        cout << "Error 404\n";
      chk[x][c] = 1;
      chk[y][c] = 1;
    }
    string output_filename(argv[2]);
    ios::openmode mode = ios::in | ios::out | ios::trunc;
    std::fstream fio1(output_filename.c_str(), mode);
    if (fio1.is_open()) {
      fio1 << x.size() << endl;
      for (ll i = 0; i < m; i++) {
        fio1 << colorVertex[i] + 1 << " ";
      }
      fio1 << endl;
      fio1.close();
    }
    fio1.close();
  } else {
    while (1) {
      ll perproc;
      MPI_Recv(&perproc, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      if (perproc == 0)
        break;
      ll curr[perproc];
      MPI_Recv(&curr, perproc, MPI_INT, 0, 0, MPI_COMM_WORLD,
               MPI_STATUS_IGNORE);
      ll colorVertex[m];
      MPI_Recv(&colorVertex, m, MPI_INT, 0, 0, MPI_COMM_WORLD,
               MPI_STATUS_IGNORE);
      ll flag_temp[perproc];
      vector<ll> ret = try_error(curr, g, m, perproc, colorVertex);
      f(i, 0, perproc) { flag_temp[i] = ret[i]; }
      MPI_Send(&flag_temp, perproc, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }
  }

  //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  MPI_Barrier(MPI_COMM_WORLD);
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (rank == 0) {
    printf("Total time (s): %f\n", maxTime);
  }

  /* shut down MPI */
  MPI_Finalize();
  return 0;
}