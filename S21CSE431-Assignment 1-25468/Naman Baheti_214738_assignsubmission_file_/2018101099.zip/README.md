<b><centre> Distributed Systems </centre></b>

# Assignment - 1
### Name - Naman Baheti
### Roll Number - 2018101099
## Question 1:

```
For the first question, the 0th process divided the range [1,n] in "numprocs" parts, and sent each of the processess the range  for which they have to do the computation, and the corresponding processes sent the result to root process,root added them to get the overall answer. 
```


## Question 2:
```
For this question, the 0th process divided the range [1,N] in NUMPROCS subarrays, and sent each of the processess the subarray which they had to sort, then merged processes in a way that every process get atmost log2(numprocs) merges. 
```

## Question 3:

```
For this question, firsly I converted the given edge coloring problem to a vertex coloring problem by creating a line graph of the given graph. Now for solving this vertex coloring problem I used an Iterative Greedy strategy, using the algorithm which is attached below. Firstly I distributed the vertices in the line graph(i.e. edges of the original graph) to each processes, which will assign for each vertex the minmum color which is not yet assigned to its neighbours, than each process sends this assignments to the 0th process. Now if two newly colored vertices have same colors than it will uncolor one of them, and hence in each iteration atleast one new vertex will be colored, hence worst case complexity of this algorithm is O(M*(Edges of the line graph)) and the number of colors will be bounded by Delta(Linegraph)+1.
```
## Algorithm used
![Algorithm](./algo.jpeg)
