/* MPI Program Template */

#include "mpi.h"
#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
#include <string.h>
using namespace std;
typedef int ll;
#define f(i, a, b) for (ll i = a; i < b; i++)
// ll *convertStr(string str) {
//   ll n = str.length();
//   // cout << n << endl;
//   ll *arr = new ll[n];
//   for (ll i = 0; i < n; i++) {
//     arr[i] = 0;
//   }
//   ll j = 0, i, sum = 0;
//   bool flag = false;
//   for (ll i = 0; str[i] != '\0'; i++) {
//     if (str[i] == ' ') {
//       j++;
//       flag = false;
//     }
//     else if(str[i] == '-') {
//       flag = true;
//     } else {
//       arr[j] = arr[j] * 10 + (str[i] - '0');
//       if(flag == true && arr[j] > 0) {
//         arr[j] *= (-1);
//         flag = false;
//       }
//     }
//   }
//   return arr;
// }
ll partition(ll *arr, ll start, ll end) {
  ll j = start + 1;
  ll piv = start;
  // for (ll i = start + 1; i <= end; i++) {
  f(i, start + 1, end + 1) {
    if (arr[i] < arr[piv]) {
      swap(arr[i], arr[j]);
      j++;
    }
  }
  swap(arr[start], arr[j - 1]);
  return j - 1;
}
ll compare(const void* a, const void *b) {
  ll x = *(ll *)a;
  ll y = *(ll *)b;
  return (x - y);
}
ll *merge(ll *arr, ll size, ll *brr, ll size2) {
  ll *crr;
  ll sizefinal = size + size2;
  crr = (ll *)malloc(sizefinal * sizeof(ll));
  ll i = 0, j = 0, k = 0;
  while (i < size && j < size2) {
    if (arr[i] <= brr[j]) {
      crr[k++] = arr[i++];
    } else {
      crr[k++] = brr[j++];
    }
  }
  while (i < size) {
    crr[k++] = arr[i++];
  }
  while (j < size2) {
    crr[k++] = brr[j++];
  }
  return crr;
}

void quicksort(ll *arr, ll start, ll end) {
  if (start < end) {
    ll pi = partition(arr, start, end);
    quicksort(arr, start, pi - 1);
    quicksort(arr, pi + 1, end);
  }
}
int main(int argc, char **argv) {
  int rank, numprocs;
  /* start up MPI */
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

  /*synchronize all processes*/
  MPI_Barrier(MPI_COMM_WORLD);
  double tbeg = MPI_Wtime();

  /* write your code here */

  string input_filename(argv[1]);
  string output_filename(argv[2]);
  ios::openmode mode = ios::in | ios::out | ios::app;
  std::fstream fio(input_filename.c_str(), mode);
  string line;
  ll n = -1;
  ll *arr;
  ll *local;
  ll *brr;
  if(fio.is_open()) {
    fio >> n;
    arr = (ll *)malloc(n*sizeof(ll));
    f(i,0,n) {
      fio >> arr[i];
    }
  }

  ll interval;
  if (n % numprocs != 0) {
    interval = n / numprocs + 1;
  } else {
    interval = n / numprocs;
  }
  if (rank == 0) {
    f(i, n, interval * numprocs) { arr[i] = 0; }
  }
  // cout << interval << endl;
  if (numprocs < n) {
    local = (ll *)malloc(interval * sizeof(ll));
    MPI_Scatter(arr, interval, MPI_INT, local, interval, MPI_INT, 0,
                MPI_COMM_WORLD);
    free(arr);
    arr = NULL;
    ll size;
    if (n >= interval * (rank + 1)) {
      size = interval;
    } else {
      size = n - interval * rank;
    }
    quicksort(local, 0, size - 1);
    // merge p sorted chunk of array with one process having maximum log_2(p)
    // merge
    for (ll level = 1; level < numprocs; level *= 2) {
      if (rank % (2 * level) != 0) {
        MPI_Send(local, size, MPI_INT, rank - level, 0, MPI_COMM_WORLD);
        break;
      }
      if (rank + level < numprocs) {
        ll recievesize;
        if (n >= interval * (2 * level + rank)) {
          recievesize = interval * level;
        } else {
          recievesize = n - interval * (level + rank);
        }
        brr = (ll *)malloc(recievesize * sizeof(ll));
        MPI_Recv(brr, recievesize, MPI_INT, rank + level, 0, MPI_COMM_WORLD,
                 MPI_STATUS_IGNORE);
        arr = merge(local, size, brr, recievesize);
        free(local);
        free(brr);
        local = arr;
        size += recievesize;
      }
    }
  }

  else {
    if (rank == 0) {
      // quicksort(arr, 0, n - 1);
      qsort(arr, n, sizeof(ll), compare);
      local = (ll *)malloc(n*sizeof(ll));
      f(i, 0, n) {
        local[i] = arr[i];
      }
    }
  }
  if (rank == 0) {
    mode = ios::in | ios::out | ios::trunc;
    std::fstream fio1(output_filename.c_str(), mode);
    if (fio1.is_open()) {
      f(i, 0, n) { fio1 << local[i] << " "; }
      fio1 << endl;
      fio1.close();
    }
  }
  MPI_Barrier(MPI_COMM_WORLD);
  double elapsedTime = MPI_Wtime() - tbeg;
  double maxTime;
  MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (rank == 0) {
    printf("Total time (s): %f\n", maxTime);
  }

  /* shut down MPI */
  MPI_Finalize();
  return 0;
}