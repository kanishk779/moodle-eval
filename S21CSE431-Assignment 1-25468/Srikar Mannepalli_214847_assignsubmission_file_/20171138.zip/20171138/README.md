# Distributed Systems Assignment 1
### Name : Srikar Mannepalli
 ### Roll number : 20171138
## Problem 1
Given an input n, we are supposed to find the sum of reciprocals of squares of integers from 1 till n i.e 1/(1^2) + 1/(2^2) + ... + 1/(n^2).
Let us say there are n processes, then we send the processes the starting point which is evenly divided depending on n and also the number of numbers it has to add. Based on that, each process finds the partial sum and returns its partial sum to the root process. The root process then adds all these partial sums to the partial sum it calculated to find the final total sum.
Complexity can be said to be O(p+n/p) as each process will have to find the sum of atmost n/p elements and the root along with thus also has to sum up all the n partial sums returned. 

## Problem 2
Given an array of n integers, we need to sort the array using parallel quick sort.  
Let A be an array of n elements that is to be sorted and p be the number of processes. Each process is assigned a consecutive block of n/p elements, and the labels of the processes define the global order of the sorted sequence. Let Ai be the block of elements assigned to process Pi .
The root process now selects a pivot element and broadcasts it to all the processes. Each process Pi, upon receiving the pivot, partitions its elements into two sub-blocks, with elements smaller than the pivot in one block, say Si,  elements larger than the pivot in the other, say Li. 
 Using these, the original array A is rearranged so that all the elements that are smaller than the pivot are stored at the beginning of the array(say S = union of(Si) for all i), and all the elements that are larger than the pivot are stored at the end of the array.(say L = union of(Li) for all i)
 Once this  is done, we partition the processes into two groups, and assign to the first group the task of sorting the smaller elements S, and to the second group the task of sorting the larger elements L . The number of processes assigned to each group will be proportional to sizes of the sub-blocks. Each of these steps is performed by recursively calling the  algorithm. Note that by simultaneously partitioning both the processes and the original array each group of processes can proceed independently. The termination condition for the recursion is when a particular sub-block of elements are assigned to only a single process, in which case the process sorts the elements using serial quicksort.
 The complexity Tp is Theta((n/p)log(n/p)) + Theta((n/p)logp) + Theta(logp*logp).
 
## Problem 3
Given an undirected graph G, we need to find a proper edge coloring of the graph using max(Delta(G), Delta(Linegraph(G))) + 1 colors or fewer i.e no 2 adjacent edges should have a same color. Delta(G) is the maximum degree of any vertex in G and Linegraph(G) is the linegraph of G.

The problem converts to finding the vertex coloring of Line graph. This is because vertex coloring of line graph of a graph is equivalent to the edge coloring of the original graph.
We first find the line graph of the given graph. We now find the vertex coloring of the same using the below algorithm.
Let the number of processes be p
Let U be the set of vertices to be colored and R be the set of vertices to be recolored. 
while U is not empty:
    Divide U into p parts and distributed to each process.
    Each process parallelly colors the subgraph that it has received as follows. It assigns the node, smallest possible color that has not been used by any of its neighbours.
    Now, each process shares its coloring with the root process. The root process then shares the consolidated current coloring of all the vertices.
    Each process parallelly finds if any of the vertices that it has been allocated has a coflict with respect to the vertex coloring condition. If yes, the higher numbered vertex is added to a set Ri.
    Each process Pi, share their conflict set that needs to be recoloured Ri.
    The root process obtains R as the union as Ri for all i.
    U = R
Let the number of vertices in the line graph be V and edges in E. The complexity will be of the order O((V/p)^2 + (E/p)).

