/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int exit_tag = 100;
int send_vert_tag = 101;


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Status status;
    int root_proc=0;
    int n,m,v1,v2;
    int vert_name1,vert_name2;
    vector<vector<int> > adj;
    vector<vector<int> > adj_line;
    vector<int>add;
    int* colors_allot;
    map<pair<int,int>, int> mp; //maps edge to vertex in line graph
    map<int, vector<pair<int,int> > > mp_rev; //reverse of above map

    //create linegraph
    if(rank==root_proc) {
        //take input, build graph and then line graph. Split vertices into sets for each process. Color and obtain those from each process. Get conflicts.
        // cin>>n>>m;

        // n = -1;
        // n=0;
        ifstream file(argv[1]);
        file >> n >> m;
        for(int i=0;i<n;i++) adj.push_back(add);
        for(int i=0;i<m;i++) adj_line.push_back(add);
        for(int i=0;i<m;i++) {
            // cin>>v1>>v2;
            file>>v1>>v2;
            v1--;
            v2--;
            adj[v1].push_back(v2);
            adj[v2].push_back(v1);
            mp[make_pair(v1,v2)] = i;
            mp[make_pair(v2,v1)] = i;
            mp_rev[i].push_back(make_pair(v1,v2));
            mp_rev[i].push_back(make_pair(v2,v1));
        }
        file.close();
        for(int i=0;i<n;i++) {
            for(int j=0;j<adj[i].size();j++) {
                for(int k=j+1;k<adj[i].size();k++) {
                    vert_name1 = mp[make_pair(i, adj[i][j])];
                    vert_name2 = mp[make_pair(i, adj[i][k])];
                    adj_line[vert_name1].push_back(vert_name2);
                    adj_line[vert_name2].push_back(vert_name1);
                }
            }
        }
        colors_allot = (int*)malloc(m*sizeof(int));
        for(int i=0;i<m;i++)colors_allot[i]=-1;
        // for(int i=0;i<m;i++) {
        //     cout<<"vert "<<i<<endl;
        //     for(int j=0;j<adj_line[i].size();j++) cout<<adj_line[i][j]<<" ";
        //     cout<<endl; 
        // }
    }



    // set<int>st;
    set<int>uncolored;
    int send_exit=0,ierr;
    int cnt=0,tot=0,num=0,cnt1=0,ids=0;
    while(1) {
        // break;
        //exit condns and broadcasting
        if(rank==root_proc) {
            // cout<<"iter"<<endl;
            // for(int i=0;i<m;i++) cout<<colors_allot[i]<<" ";
            // cout<<endl;
            int conflict=0;
            for(int i=0;i<m;i++) {
                for(int j=0;j<adj_line[i].size();j++){
                    if(colors_allot[adj_line[i][j]] == colors_allot[i]) {
                        conflict++;
                    }
                }
            }
            // cout<<"conflict "<<conflict<<endl;

            if(cnt==0) {
                for(int i=0;i<m;i++) uncolored.insert(i);
            }
            // else break;
            cnt=1;
            if(uncolored.size()==0) send_exit=0;
            else send_exit=1;
            // cout<<"unc sz "<<uncolored.size()<<endl;
            MPI_Bcast(&send_exit, 1, MPI_INT,root_proc, MPI_COMM_WORLD);
            // for(auto it=uncolored.begin();it!=uncolored.end();it++) {
                // cout<<*it<<" ";
            // }
            // cout<<endl;
            // for(int id=0;id<numprocs;id++) MPI_Send(&send_exit, 1, MPI_INT,id, exit_tag, MPI_COMM_WORLD);
            if(send_exit==0) {
                // cout<<"master terminated"<<endl;
                break;
            }
            MPI_Bcast(&m, 1, MPI_INT,root_proc, MPI_COMM_WORLD);
            MPI_Bcast(colors_allot, m, MPI_INT, root_proc, MPI_COMM_WORLD);
        }

        if(rank==root_proc) {
            int num_per_proc = ceil(uncolored.size()/(float)numprocs);
            int* sendarr = (int*) malloc(num_per_proc*sizeof(int));
            int* mine = (int*) malloc(num_per_proc*sizeof(int));
            int minenum; 
            tot=0;
            num = uncolored.size();
            ids=0;
            cnt1=0;

            //send the individual processes their vertices along with corresponding adjacency information 
            for(auto it=uncolored.begin();it!=uncolored.end();it++) {
                sendarr[tot] = *it;
                tot++;
                if(tot%num_per_proc==0) {
                    if(cnt1==0) {
                        // mine=sendarr;
                        for(int i=0;i<num_per_proc;i++) mine[i]=sendarr[i];
                        minenum = num_per_proc;
                        tot=0;
                        ids++;
                        cnt1++;
                        continue;
                    } 
                    cnt1++;
                    MPI_Send(&tot,1, MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);
                    MPI_Send(sendarr, tot, MPI_INT, ids, send_vert_tag, MPI_COMM_WORLD);
                    
                    for(int i=0;i<tot;i++) {
                        int* sender = (int*)malloc(adj_line[sendarr[i]].size()*sizeof(int));
                        int sz = adj_line[sendarr[i]].size();
                        // cout<<"sz rank "<<sz<<" "<<rank<<endl; 
                        MPI_Send(&sz,1,MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);
                        for(int j=0;j<adj_line[sendarr[i]].size();j++) sender[j] = adj_line[sendarr[i]][j];
                        MPI_Send(sender,sz,MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);

                    }
                   tot=0; 
                   ids++;
                }
            }
            if(tot!=0) {
                if(cnt1==0) {
                    mine=sendarr;
                    minenum = tot;
                }
                else {
                    MPI_Send(&tot,1, MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);
                    MPI_Send(sendarr, tot, MPI_INT, ids, send_vert_tag, MPI_COMM_WORLD);
                    for(int i=0;i<tot;i++) {
                        int* sender = (int*)malloc(adj_line[sendarr[i]].size()*sizeof(int));
                        int sz = adj_line[sendarr[i]].size();
                        MPI_Send(&sz,1,MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);
                        for(int j=0;j<adj_line[sendarr[i]].size();j++) sender[j] = adj_line[sendarr[i]][j];
                        MPI_Send(sender,sz,MPI_INT,ids, send_vert_tag, MPI_COMM_WORLD);
                    }
                    ids++;
                }
            }
            for(int id=ids;id<numprocs;id++) {
                tot = 0;
                MPI_Send(&tot,1, MPI_INT,id, send_vert_tag, MPI_COMM_WORLD);
                int* dummy = (int*)malloc(sizeof(int));
                MPI_Send(dummy, tot, MPI_INT, id, send_vert_tag, MPI_COMM_WORLD);
            }

            // cout<<"near coloring"<<endl;
            //coloring. Now need to color, detect conflicts and then create the uncolored set again
            vector<int>neigh;
            int least_col;
            // cout<<"mine num "<<minenum<<endl;
            for(int i=0;i<minenum;i++) {
                neigh.clear();
                // cout<<"current node "<<mine[i]<<endl;
                // cout<<"adj size "<<adj_line[mine[i]].size()<<endl;
                set<int>visited;
                for(int j=0;j<adj_line[mine[i]].size();j++){
                    // cout<<adj_line[mine[i]][j]<<" col "<<colors_allot[adj_line[mine[i]][j]]<<endl;
                    if(colors_allot[adj_line[mine[i]][j]] != -1 && visited.count(colors_allot[adj_line[mine[i]][j]])==0) {
                        neigh.push_back(colors_allot[adj_line[mine[i]][j]]);
                        visited.insert(colors_allot[adj_line[mine[i]][j]]);
                    }
                }
                visited.clear();
                sort(neigh.begin(), neigh.end());
                least_col=0;
                // cout<<"neigh size "<<neigh.size()<<endl;
                for(int j=0;j<neigh.size();j++) {
                    // cout<<"j "<<neigh[j]<<" ";
                    if(neigh[j]!=j) {
                        least_col = j;
                        break;
                    }
                    // cout<<endl;
                    if(j==neigh.size()-1) least_col = j+1;
                }
                // cout<<"vert "<<mine[i]<<" leastcol "<<least_col<<endl;
                colors_allot[mine[i]] = least_col;
            }
            // cout<<"colors middle"<<endl;
            // for(int i=0;i<m;i++) cout<<colors_allot[i]<<" ";
            // cout<<endl;

            //collect color
            for(int id=rank+1;id<numprocs;id++) {
                int rectot;
                MPI_Recv(&rectot,1, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                int* received_cols = (int*) malloc(rectot*sizeof(int));
                MPI_Recv(received_cols,rectot, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                int rec_ele_tot;
                MPI_Recv(&rec_ele_tot,1, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                int* my_vert = (int*)malloc(rec_ele_tot*sizeof(int));
                MPI_Recv(my_vert,rec_ele_tot, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                for(int i=0;i<rec_ele_tot;i++) {
                    colors_allot[my_vert[i]] = received_cols[my_vert[i]];
                }
            }

            //find conflicts
            for(int id=rank+1;id<numprocs;id++) {
                MPI_Send(colors_allot,m, MPI_INT,id,send_vert_tag,MPI_COMM_WORLD);
            }

            set<int>new_uncol_set;
            for(int i=0;i<minenum;i++) {
                for(int j=0;j<adj_line[mine[i]].size();j++){
                    if(colors_allot[adj_line[mine[i]][j]] == colors_allot[mine[i]]) new_uncol_set.insert(max(mine[i], adj_line[mine[i]][j]));
                }
            }

            for(int id=rank+1;id<numprocs;id++) {
                int conf_tot;
                MPI_Recv(&conf_tot,1, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                int* received_confl = (int*) malloc(conf_tot*sizeof(int));
                MPI_Recv(received_confl,conf_tot, MPI_INT, id,send_vert_tag,MPI_COMM_WORLD, &status);
                for(int i=0;i<conf_tot;i++) {
                    new_uncol_set.insert(received_confl[i]);
                }
            }

            // cout<<"colors "<<endl;
            // for(int i=0;i<m;i++) cout<<colors_allot[i]<<" ";
            // cout<<endl;
            uncolored = new_uncol_set;

            // break;

        }
        else {
            int check_exit;
            int rectot;
            map<int,int*>my_adj;
            // cout<<"rank waiting "<<rank<<endl; 
            // cout<<"hahah1 rank "<<rank<<endl;
            MPI_Bcast(&check_exit, 1, MPI_INT,root_proc, MPI_COMM_WORLD);
            // ierr = MPI_Recv(&check_exit, 1,MPI_INT, root_proc, exit_tag, MPI_COMM_WORLD, &status);
            if(check_exit==0) {
                // cout<<"Rank "<<rank<<" terminated"<<endl;
                break;
            }
            // cout<<"hahah2 rank "<<rank<<endl;
            MPI_Bcast(&rectot, 1, MPI_INT,root_proc, MPI_COMM_WORLD);
            int* cols =(int*) malloc(rectot*sizeof(int));
            // cout<<"hahah3 rank "<<rank<<endl;
            MPI_Bcast(cols, rectot, MPI_INT,root_proc, MPI_COMM_WORLD);
            int tot_ele = 0;
            // cout<<"hahah4 rank "<<rank<<endl;
            ierr = MPI_Recv(&tot_ele, 1,MPI_INT, root_proc, send_vert_tag, MPI_COMM_WORLD, &status);
            int* my_vert = (int*)malloc(tot_ele*sizeof(int));
            // cout<<"hahah5 rank "<<rank<<endl;
            ierr = MPI_Recv(my_vert, tot_ele,MPI_INT, root_proc, send_vert_tag, MPI_COMM_WORLD, &status);
            int adj_num;
            // cout<<"hahah6 rank "<<rank<<endl;
            // cout<<"rank "<<rank<<" "<<my_vert[0]<<endl;
            vector<int>adj_sizes;
            for(int i=0;i<tot_ele;i++) {
                ierr = MPI_Recv(&adj_num, 1,MPI_INT, root_proc, send_vert_tag, MPI_COMM_WORLD, &status);
                my_adj[my_vert[i]] = (int*)malloc(adj_num*sizeof(int));
                adj_sizes.push_back(adj_num);
                ierr = MPI_Recv(my_adj[my_vert[i]], adj_num,MPI_INT, root_proc, send_vert_tag, MPI_COMM_WORLD, &status);
            }
            // cout<<"hahah7 rank "<<rank<<endl;
            // MPI_Bcast(&rectot, 1, MPI_INT,root_proc, MPI_COMM_WORLD);
           



            //color 
            vector<int>neigh;
            int least_col;
            for(int i=0;i<tot_ele;i++) {
                neigh.clear();
                set<int>visited;
                for(int j=0;j<adj_sizes[i];j++){
                // for(int j=0;j<my_adj[my_vert[i]].size();j++){
                    if(cols[my_adj[my_vert[i]][j]] != -1 && visited.count(cols[my_adj[my_vert[i]][j]])==0) {
                        neigh.push_back(cols[my_adj[my_vert[i]][j]]);
                        visited.insert(cols[my_adj[my_vert[i]][j]]);
                    }
                }
                visited.clear();
                sort(neigh.begin(), neigh.end());
                least_col=0;
                for(int j=0;j<neigh.size();j++) {
                    if(neigh[j]!=j) {
                        least_col = j;
                        break;
                    }
                    if(j==neigh.size()-1) least_col = j+1;
                }
                cols[my_vert[i]] = least_col;
            }

            MPI_Send(&rectot,1, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);
            MPI_Send(cols,rectot, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);
            MPI_Send(&tot_ele,1, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);
            MPI_Send(my_vert,tot_ele, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);


            int* new_cols =(int*) malloc(rectot*sizeof(int));
            // int* new_cols =(int*) malloc(rectot*sizeof(int));
            MPI_Recv(new_cols, rectot, MPI_INT,root_proc,send_vert_tag,  MPI_COMM_WORLD, &status);
            // int* send_conflicts=(int*)malloc(tot_ele*sizeof(int));
            set<int>checkset;
            int maxi;
            int confl = 0;
            vector<int>confvec;
            for(int i=0;i<tot_ele;i++) {
                for(int j=0;j<adj_sizes[i];j++){
                    if(new_cols[my_adj[my_vert[i]][j]] == new_cols[my_vert[i]]) {
                        maxi = max(my_vert[i], my_adj[my_vert[i]][j]);
                        if(checkset.count(maxi)==0){
                            // send_conflicts[confl] = maxi;
                            confvec.push_back(maxi);
                            confl++;
                            checkset.insert(maxi);
                        }
                    }
                }
            }
            int* send_conflicts=(int*)malloc(((int)confvec.size())*sizeof(int));

            for(int i=0;i<confvec.size();i++) send_conflicts[i]=confvec[i];
            // cout<<"conf rank " <<rank<<" "<<confl<<endl;
            MPI_Send(&confl,1, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);
            MPI_Send(send_conflicts,confl, MPI_INT, root_proc,send_vert_tag,MPI_COMM_WORLD);
            // break;


        }
    }
    if(rank==root_proc) {
        int tot_col_used=0 ;
        for(int i=0;i<m;i++) tot_col_used = max(tot_col_used, colors_allot[i]);
        // cout<<tot_col_used+1<<endl;
        // for(int i=0;i<m;i++) cout<<1+colors_allot[i]<<" ";
        // cout<<endl;
        // int conflict=0;

        // int max_degree = 0;
        // for(int i=0;i<n;i++) {
        //     max_degree = max(max_degree, (int)adj[i].size());
        // }
        // for(int i=0;i<m;i++) {
        //     max_degree = max(max_degree, (int)adj_line[i].size());
        // }
        // for(int i=0;i<m;i++) {
        //     for(int j=0;j<adj_line[i].size();j++){
        //         if(colors_allot[adj_line[i][j]] == colors_allot[i]) {
        //             conflict++;
        //         }
        //     }
        // }
        // cout<<"Max degree: "<<1+max_degree<<endl;
        // cout<<"Conflicts: "<<conflict<<endl;

        ofstream outFile;
        outFile.open(argv[2]);
        outFile<<tot_col_used+1;
        outFile<<"\n";
        for(int i=0;i<m;i++){
            outFile<<1+colors_allot[i];
            if(i!=m-1) outFile<<" ";
        }
        // outFile<<"\n";
        outFile.close();
    }



    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

//in other codes also, check if it works if first process gets lesser than num_procs