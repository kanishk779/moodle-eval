/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n, num_per_proc,root_proc = 0,ierr,tot,start_num;
    MPI_Status status;
    long double sum, partial_sum;
    int sendtag = 100;
    int rectag = 101;

    if(rank==root_proc) {
        //master process
        // cout<<"arg "<<argv[4]<<endl;
        n = 0;
        ifstream file(argv[1]);
        file>>n;
        file.close();
        // cin>>n;
       
        num_per_proc = ceil(n/(float)numprocs);
        for(int id=1;id<numprocs;id++) {
            start_num = id*num_per_proc+1;
            if(start_num+num_per_proc>n) {
                tot = n-start_num+1;
            }
            else {
                tot = num_per_proc;
            }
            ierr = MPI_Send(&start_num, 1, MPI_INT, id, sendtag, MPI_COMM_WORLD);
            ierr = MPI_Send(&tot, 1, MPI_INT,id, sendtag, MPI_COMM_WORLD);
        }

        sum=0;
        for(float i=1;i<=num_per_proc;i++) {
            sum += (1/(i*i));
        }

        for(int id=1;id<numprocs;id++) {
            ierr = MPI_Recv(&partial_sum, 1, MPI_LONG_DOUBLE, id, rectag, MPI_COMM_WORLD, &status);
            sum+= partial_sum;
        }

        // cout<<fixed<<setprecision(6)<<sum<<endl;
        ofstream outFile;
        outFile.open(argv[2]);
        outFile<<fixed<<setprecision(6)<<sum;
        // outFile<<"\n";
        outFile.close();

    }
    else {
        //slave process
        ierr = MPI_Recv( &start_num, 1, MPI_INT, root_proc, sendtag, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv( &tot, 1, MPI_INT, root_proc, sendtag, MPI_COMM_WORLD, &status);
        partial_sum = 0;
        for(float i=start_num;i<tot+start_num;i++) {
            partial_sum += (1/(i*i));
        }
        ierr = MPI_Send(&partial_sum,1 ,MPI_LONG_DOUBLE, root_proc, rectag, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_LONG_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}