/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


int sendtag = 100;
int rectag = 101;
int lowtag  = 102;
int hightag = 103;
int pivottag = 104;
int sendarrtag=105;
int recursiontag = 106;
int sztag = 107;
int finaltag=108;

int partition(int a[], int l, int r, int pivot) {
    // int l=0, r = n-1;
  
    while(l<r) {
        while(a[l]<=pivot && l<r) l++;
        while(a[r]>pivot && l<r) r--;
        if(l<r) {
            swap(a[l],a[r]);
            l++;
            r--;
        }
    }
    int piv=l;
    for(int i=r;i>=l;i--) {
        if(a[i]<=pivot) {
            piv = i+1;
            break;
        }
    }
   
    return piv;
}

int partition_qsort(int a[], int l, int r) {
    int pivot = a[r]; 
	int small=l-1;
	for(int i=l;i<=r-1;i++) 
	{ 
        if(a[i]>=pivot) continue;
		small++;
		swap(a[small], a[i]); 
	} 
    small++;
	swap(a[small], a[r]); 
	return small; 
} 

void quickSort(int a[], int l, int r) {
    if(l>=r) return;
    int parti = partition_qsort(a, l,r);
    quickSort(a,l,parti-1);
    quickSort(a,parti+1,r);
}

int* recfn1(int a[], int n, int rank,int numprocs) {
    int ierr;
    if(numprocs==1) {
        quickSort(a, 0, n-1);
        if(rank!=0) {
            ierr = MPI_Send(&n,1, MPI_INT,0,finaltag, MPI_COMM_WORLD);
            ierr = MPI_Send(a, n,MPI_INT, 0, finaltag, MPI_COMM_WORLD);
        }
        return a;
    }
    if(n==0) return a;
    int num_per_proc = ceil(n/(float)numprocs),start_num=0;
    int pivot = (a[rand()%n]+a[rand()%n])/2; 
    int tot = num_per_proc;
    int* smaller_part;
    int* larger_part;
    MPI_Status status;
    for(int id=rank+1;id<rank+numprocs;id++) {
        start_num = (id-rank)*num_per_proc;
        if(start_num+num_per_proc>=n) {
            tot = max(0,n-start_num);
        }
        else {
            tot=num_per_proc;
        }
        ierr = MPI_Send(&pivot, 1, MPI_INT, id, pivottag, MPI_COMM_WORLD);
        ierr = MPI_Send(&tot, 1, MPI_INT, id, sendtag, MPI_COMM_WORLD);
        ierr = MPI_Send(&a[start_num], tot, MPI_INT, id, sendarrtag, MPI_COMM_WORLD);
    }
    if(num_per_proc>=n) tot = n-num_per_proc;
    else tot = num_per_proc;
    int parti = partition(a,0,tot-1,pivot);
    // int parti = partition(a,0,tot-1,tot,pivot);
    smaller_part = (int*) malloc(n*sizeof(int));
    larger_part = (int*) malloc(n*sizeof(int));
    for(int i=0;i<parti;i++) smaller_part[i]=a[i];
    for(int i=0;i<tot-parti;i++) larger_part[i] = a[i+parti];
    int num_ele;
    int smaller_part_sz = parti;
    int larger_part_sz = tot-parti;
    for(int id=rank+1;id<rank+numprocs;id++) {
        ierr = MPI_Recv(&num_ele, 1, MPI_INT, id, lowtag, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv(&smaller_part[smaller_part_sz], num_ele, MPI_INT,id, lowtag, MPI_COMM_WORLD, &status);
        smaller_part_sz += num_ele;
    }

    for(int id=rank+1;id<rank+numprocs;id++) {
        ierr = MPI_Recv(&num_ele, 1, MPI_INT, id, hightag, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv(&larger_part[larger_part_sz], num_ele, MPI_INT,id, hightag, MPI_COMM_WORLD, &status);
        larger_part_sz += num_ele;
    }
    // cout<<"smaller arr pivot "<<pivot<<" rank "<<rank<<endl;
    // for(int i=0;i<smaller_part_sz;i++) cout<<smaller_part[i]<<" ";
    // cout<<endl;
    // cout<<"larger arr pivot "<<pivot <<" rank "<<rank<<endl;
    // for(int i=0;i<larger_part_sz;i++) cout<<larger_part[i]<<" ";
    // cout<<endl;
    // for(int i=0;i<smaller_part_sz;i++) a[i]=smaller_part[i];
    // for(int i=0;i<larger_part_sz;i++) a[i+smaller_part_sz]=larger_part[i];
    // for(int i=0;i<smaller_part_sz;i++) cout<<a[i]<<" ";
    // for(int i=0;i<larger_part_sz;i++) cout<<a[i+smaller_part_sz]<<" ";
    // cout<<endl;
    int lower_procs = ceil((smaller_part_sz*numprocs)/(float)n);
    int higher_procs = numprocs-lower_procs;
    int whichrec= 1;
    int its_root;
    if(higher_procs==0) {
        higher_procs+=1;
        lower_procs-=1;
    }
    for(int id=rank+1;id<rank+numprocs;id++) {
        if(id==rank+lower_procs) whichrec=0;
        else whichrec=1;
        MPI_Send(&whichrec, 1, MPI_INT, id, recursiontag, MPI_COMM_WORLD);
        if(id>rank+lower_procs) its_root = rank+lower_procs;
        else its_root = rank;
        MPI_Send(&its_root, 1, MPI_INT, id, recursiontag, MPI_COMM_WORLD);
        if(whichrec==0) {
            MPI_Send(&larger_part_sz, 1, MPI_INT, id, sztag, MPI_COMM_WORLD);
            // MPI_Send(&a[smaller_part_sz], larger_part_sz, MPI_INT,id, sztag, MPI_COMM_WORLD);
            MPI_Send(larger_part, larger_part_sz, MPI_INT,id, sztag, MPI_COMM_WORLD);
            MPI_Send(&higher_procs, 1, MPI_INT, id, sztag, MPI_COMM_WORLD);
        }
    }

    // recfn1(a,smaller_part_sz, rank, lower_procs);
    return recfn1(smaller_part,smaller_part_sz, rank, lower_procs);
}

int* recfn2(int root, int rank) {
    MPI_Status status;
    int pivot,ierr,num_ele;
    int* arr;
    ierr = MPI_Recv(&pivot, 1, MPI_INT, root, pivottag, MPI_COMM_WORLD, &status);
    ierr = MPI_Recv(&num_ele, 1, MPI_INT, root, sendtag, MPI_COMM_WORLD, &status);
    arr = (int*)malloc(num_ele*sizeof(int));
    ierr = MPI_Recv(arr, num_ele, MPI_INT,root, sendarrtag, MPI_COMM_WORLD, &status);
    int parti = partition(arr, 0, num_ele-1, pivot);
    // int parti = partition(arr, 0, num_ele-1,num_ele, pivot);
    ierr = MPI_Send(&parti,1, MPI_INT, root, lowtag, MPI_COMM_WORLD); 
    ierr = MPI_Send(arr,parti, MPI_INT, root, lowtag, MPI_COMM_WORLD);
    int sendele = num_ele-parti;
    ierr = MPI_Send(&sendele,1, MPI_INT, root, hightag, MPI_COMM_WORLD); 
    ierr = MPI_Send(&arr[parti],num_ele-parti, MPI_INT, root, hightag, MPI_COMM_WORLD);

    int recursion_check;
    ierr = MPI_Recv(&recursion_check, 1, MPI_INT, root, recursiontag, MPI_COMM_WORLD, &status);
    int its_root;
    ierr = MPI_Recv(&its_root, 1, MPI_INT, root, recursiontag, MPI_COMM_WORLD, &status);

    // cout<<"rec check "<<recursion_check<<endl;
    int n, numprocs;
    int* newarr;
    if(recursion_check==1) {
        return recfn2(its_root, rank);
    }
    else {
        
        ierr = MPI_Recv(&n, 1, MPI_INT, root, sztag, MPI_COMM_WORLD, &status);
        newarr = (int*) malloc(n*sizeof(int));
        ierr = MPI_Recv(newarr, n, MPI_INT, root, sztag, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv(&numprocs, 1, MPI_INT, root, sztag, MPI_COMM_WORLD, &status);
        
    }
    return recfn1(newarr, n,rank ,numprocs);
}


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_proc=0,n=0,ierr;
    MPI_Status status;

    int* arr;
    int temp,num;
    if(rank == root_proc) {
        // cin>>n;
        // arr = (int*) malloc(n*sizeof(int));
        // for(int i=0;i<n;i++) cin>>arr[i];
        n = -1;
        // n=0;
        ifstream file(argv[1]);
        while(file >> temp) n++;
        file.close();
        arr = (int*)malloc(n*sizeof(int));
        ifstream file2(argv[1]);
        num=0;
        file2>>temp;
        while(file2 >> temp){
            arr[num]=temp;
            num++;
        }
        file2.close();
    }
    int* ans;
   
    if(rank==root_proc) {
        for(int id=root_proc+1;id<numprocs;id++) {
            ierr  = MPI_Send(&n,1, MPI_INT, id, sztag, MPI_COMM_WORLD);
        }
        ans = recfn1(arr,n,rank,min(n,numprocs));
        arr=ans;
    }
    else{
        int tot_ele;
        ierr = MPI_Recv(&tot_ele, 1,MPI_INT, root_proc, sztag, MPI_COMM_WORLD, &status);
        if(rank<tot_ele) int* temp =  recfn2(root_proc, rank);
    }
    int sz,tot=0;

    if(rank==root_proc) {
        int* newarr = (int*) malloc(n*sizeof(int));
        for(int id=1;id<min(n,numprocs);id++) {
            ierr = MPI_Recv(&sz, 1, MPI_INT, id, finaltag, MPI_COMM_WORLD, &status);
            ierr = MPI_Recv(&newarr[tot], sz, MPI_INT, id, finaltag, MPI_COMM_WORLD, &status);
            tot+=sz;
        }
        int orig = n-tot;
        for(int i=n-1;i>=orig;i--) {
            newarr[i]=newarr[i-orig];
        }
        for(int i=0;i<orig;i++) newarr[i]=arr[i];
        // int checker=1;
        // for(int i=1;i<n;i++) {
        //     if(newarr[i]<newarr[i-1]) {
        //         checker=0;
        //         break;
        //     }
        // }
        // if(checker==0) cout<<"WRONG!!!!"<<endl;
        // for(int i=0;i<n;i++) cout<<newarr[i]<<" ";
        // cout<<endl;
        ofstream outFile;
        outFile.open(argv[2]);
        for(int i=0;i<n;i++){
            outFile<<newarr[i];
            if(i!=n-1) outFile<<" ";
        }
        // outFile<<"\n";
        outFile.close();
    }
    

    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}