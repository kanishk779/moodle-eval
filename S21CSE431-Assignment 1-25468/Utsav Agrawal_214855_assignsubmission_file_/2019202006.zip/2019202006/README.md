# Distribted Systems Assignment 1 (MPI) 
## Utsav Agrawal 2019202006
## Question 1 Approach:
* Make the process of rank 0 leader process and the remaining processes worker processes.
* Leader's job is to distribute the different values of i (for computing Sigma(1/i^2), 1 <= i <= n ) to different workers and then add the results returned by each worker.
* The leader distributes values of i in round-robin fashion (i.e goes back to rank 1 after last process).
* Each worker just computes the sum of 1/i^2 and on all the values of i it receives. Since n and number of processes are fixed, each worker process knows how many values it will receive. Each worker returns its sum of i/i^2 to the leader.
* The leader uses MPI_Reduce function to sum the values obtained from each worker and writes it in the file.
* In case only 1 process is available, everything is done sequentially.
### Analysis:
### Number of messages passed:
* Leader passes 'n' messages to workers (if n is the input given)
* Each worker passes 1 message back to the leader (sum of the values of i it received)
* So, total number of messages: O(n + k) (k = number of workers i.e number of processes - 1)
### Time Complexity:
* Clearly, each worker does constant amount of work on each value of i, so, the solution runs in linear time i.e O(n).
### Space Complexity:
* Each worker needs a constant amount of space for computing its part of the solution and since the number of workers are independent of n, the space complexity is O(k), where k = number of workers.

## Question 2 Approach:
* Make the process of rank 0 leader process and the remaining processes worker processes.
* Leader's job is to distribute chunks of equal size to different workers and then merge the results returned by each worker.
* If there are n integers to be sorted and k workers, then each worker gets a chunk of size n / k. If n % k = x, then first x workers get 1 additional element in their chunks.
* The leader sends chunks of appropriate sizes to each worker, and each worker sorts its chunk using quick sort and returns the sorted chunk to the leader.
* The leader receives each sorted chunk and performs k-way merge on the chunks. This is done by keeping track of indices within each chunk, comparing the elements at those indices and placing the smallest elements in an additional merged array (uses extra space).
* Finally, the leader writes the merged array into the file.
* In case only 1 process is available, everything is done sequentially.

### Analysis:
### Number of messages passed:
* Leader passes 'k' messages to workers (if k is the number of workers), each containing the chunk to be sorted by that worker.
* Each worker passes 1 message back to the leader (sorted chunk)
* So, total number of messages: O(k + k) = O(k) (k = number of workers i.e number of processes - 1)
### Time Complexity:
* Each worker performs quick sort on its chunk. I have implemented the simple version of quick sort where pivot is always the last element of the array. So, the worst case time complexity is O(n^2).
* The k-way merge takes linear time (as each chunk is iterated over once).
* So, the solution has O(n^2) worst-case time complexity.
### Space Complexity:
* Each worker needs space equal to the size of its chunk, and so total extra space required by workers is O(n). This space is allocated dynamically and de-allocated after the worker sends its sorted chunk.
* The merge procedure executed by the leader also takes additional space equal to the size of the array.
* So, the total space complexity is O(n).
