/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(argc != 3){
        cerr << "Exactly 2 arguments are expected.\n";
        exit(0);
    }
    string ip_file(argv[1]), op_file(argv[2]);
    long double val = 0.0, final_result = 0.0;
    int n, num_workers = numprocs - 1;
    ifstream f_in(ip_file);
    f_in >> n;
    f_in.close();
    if(numprocs == 1){
        //Single process => MPI not required
        for(int i = 1; i <= n; ++i){
            final_result += (long double) 1 / (i * i);
        }
        ofstream f_out(op_file);
        f_out << setprecision(7) << final_result << endl;
        f_out.close();
    }else{
        if(!rank){
            for(int i = 1; i <= n; ++i){
                int worker_proc = 1 + (i - 1) % num_workers;
                MPI_Send(&i, 1, MPI_INT, worker_proc, 0, MPI_COMM_WORLD);
            }
        }else if(rank <= n){
            int n_i, div = n / num_workers, rem = n % num_workers;
            bool flag = rank <= rem;
            for(int i = 0; i < div or flag; ++i){
                if(i == div){
                    flag = false;
                }
                MPI_Recv(&n_i, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                val += (long double) 1 / (n_i * n_i);
            }
        }
        MPI_Reduce(&val, &final_result, 1, MPI_LONG_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        if(!rank){
            ofstream f_out(op_file);
            f_out << setprecision(7) << final_result << endl;
            f_out.close();
        }
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}