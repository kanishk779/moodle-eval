/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(long arr[], int lo, int hi){
    int k = lo - 1, pivot = hi;
    for(int i = lo; i < hi; ++i){
        if(arr[i] <= arr[pivot]){
            swap(arr[++k], arr[i]);
        }
    }
    swap(arr[pivot], arr[k + 1]);
    return k + 1;
}

void quick_sort(long arr[], int lo, int hi){
    if(lo >= hi){
        return;
    }
    int pos = partition(arr, lo, hi);
    quick_sort(arr, lo, pos - 1);
    quick_sort(arr, pos + 1, hi);
}

vector<long> k_way_merge(long arr[], int size, vector<int> &start_idxs, int partition_size, int remainder){
    vector<long> merged_arr(size);
    int curr = -1, k = start_idxs.size();
    while(curr < size - 1){
        long min_val = LONG_MAX;
        for(int i = 0; i < k; ++i){
            int partition_start = min(i, remainder) * (partition_size + 1) + max(0, i - remainder) * partition_size;
            if(start_idxs[i] == partition_start + partition_size + (i < remainder)){
                continue;
            }
            min_val = min(min_val, arr[start_idxs[i]]);
        }
        for(int i = 0; i < k; ++i){
            if(arr[start_idxs[i]] == min_val){
                merged_arr[++curr] = min_val;
                ++start_idxs[i];
            }
        }
    }
    return merged_arr;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(argc != 3){
        cerr << "Exactly 2 arguments are expected.\n";
        exit(0);
    }
    string ip_file(argv[1]), op_file(argv[2]);
    int num_elements, num_workers = numprocs - 1;
    ifstream f_in(ip_file);
    f_in >> num_elements;
    long *arr;
    arr = new long[num_elements];
    for(int i = 0; i < num_elements; ++i){
        f_in >> arr[i];
    }
    f_in.close();
    if(numprocs == 1){
        //Single process => MPI not required
        quick_sort(arr, 0 , num_elements - 1);
        ofstream f_out(op_file);
        for(int i = 0; i < num_elements; ++i){
            f_out << *(arr + i) << " ";
        }
        f_out << endl;
        f_out.close();
    }else{
        int div = num_elements / num_workers, rem = num_elements % num_workers;
        if(!div){
            num_workers = rem;
        }
        if(!rank){
            vector<int> start_idxs(num_workers);
            int start_ind = 0;
            for(int i = 1; i <= num_workers; ++i){
                start_idxs[i - 1] = start_ind;
                int qty = div;
                if(i <= rem){
                    ++qty;
                }
                MPI_Send(arr + start_ind, qty, MPI_LONG, i, 0, MPI_COMM_WORLD);
                start_ind += qty;
            }
            start_ind = 0;
            for(int i = 1; i <= num_workers; ++i){
                int qty = div;
                if(i <= rem){
                    ++qty;
                }
                MPI_Recv(arr + start_ind, qty, MPI_LONG, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                start_ind += qty;
            }
            ofstream f_out(op_file);
            vector<long> sorted_list = k_way_merge(arr, num_elements, start_idxs, div, rem);
            for(long val : sorted_list){
                f_out << val << " ";
            }
            f_out << endl;
            f_out.close();
            delete[] arr;
        }else if(rank <= num_elements){
            int size = div;
            if(rank <= rem){
                ++size;
            }
            long *received;
            received = new long [size];
            MPI_Recv(received, size, MPI_LONG, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quick_sort(received, 0, size - 1);
            MPI_Send(received, size, MPI_LONG, 0, 0, MPI_COMM_WORLD);
            delete[] received;
        }
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}