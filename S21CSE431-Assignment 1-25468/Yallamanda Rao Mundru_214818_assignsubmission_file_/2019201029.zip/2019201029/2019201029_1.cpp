/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <math.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {

    int rank, numprocs;
    int start,end;
    double result,partial_sum;
    MPI_Status status;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();
    
    /* write your code here */
    if(rank == 0){
        int N;
        string inpFileName,outpFileName;
        stringstream stream1(argv[argc-2]);
        stream1 >> inpFileName;
        
        
        ifstream inFile;
        inFile.open(inpFileName);
        
        if (inFile.is_open())
        {
            string line;
            while ( getline (inFile,line) )
            {
                stringstream ss(line);
                ss >> N;
                break;
            }
            inFile.close();
        }

        int avg_terms_per_process = N / numprocs;

        for(int id = 1; id < numprocs; id++) {
            start = id * avg_terms_per_process + 1;
            end   = (id + 1)*avg_terms_per_process;
            end = end > N ? N:end;

            MPI_Send( &start, 1 , MPI_INT,id, 0, MPI_COMM_WORLD);

            MPI_Send( &end, 1, MPI_INT,id, 0, MPI_COMM_WORLD);
        }
        result = 0.0;
        for(int i = 1;i <= avg_terms_per_process;i++){
            result += 1 / pow(i,2);
        }               

        std::cout << std::setprecision(7) << std::fixed;
        //cout<<"partial_sum calculated by root process: "<<result<<endl;


        for(int id = 1; id < numprocs; id++) {
                        
            MPI_Recv( &partial_sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE,
                  0, MPI_COMM_WORLD, &status);
  
            int sender = status.MPI_SOURCE;

            
            //cout<<"partial_sum returned from process"<<sender<<" is: "<<partial_sum<<endl;
     
            result += partial_sum;
         }
         //cout<<"Final result: "<<result<<endl;
        stringstream stream2(argv[argc-1]);
        stream2 >> outpFileName;

        ofstream outFile;
        outFile.open(outpFileName);
        outFile<<setprecision(7)<<result;
    }
    else{
        MPI_Recv( &start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
          
        MPI_Recv( &end,1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        
        partial_sum = 0.0;
        for(int i = start; i <= end; i++) {
            partial_sum += 1 / pow(i,2);            
        }
        
        MPI_Send( &partial_sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}