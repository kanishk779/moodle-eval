/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#define max_size 1000000

using namespace std;
typedef long long int ll;

void merge(int *arr,int size,int numprocs)
{
    int count = size / numprocs;
    priority_queue<pair<int,pair<int,int>>,vector<pair<int,pair<int,int>>>,greater<pair<int,pair<int,int>>>> min_heap;
    
    for(int i = 0;i < numprocs;i++)
    {
        min_heap.push(make_pair(arr[i*count],make_pair(0,i)));
    }
    int *arr2 = new int[size];
    memcpy(arr2, arr, size * sizeof(int));
    
    int p = 0;
    while(!min_heap.empty())
    {
        int pos = min_heap.top().second.first;
        int process = min_heap.top().second.second;
        int value = min_heap.top().first;
        arr[p] = value;
        p++;
        min_heap.pop();
        if(pos < count-1)
        {
            pos++;
            min_heap.push(make_pair(arr2[process*count + pos],make_pair(pos,process)));        
        }
    }
    return;
}

void swap(int* x, int* y)  
{  
    int temp = *x;  
    *x = *y;  
    *y = temp;  
}

int partition (int arr[], int start, int end)  
{
    int random = rand() % (end - start + 1);
    swap(&arr[random], &arr[end]);
    int pivot = arr[end];
    int i = (start - 1);
    for (int j = start; j < end; j++)  
    {    
        if (arr[j] < pivot)  
        {  
            i++;
            swap(&arr[i], &arr[j]);  
        }  
    }
    i++;
    swap(&arr[i], &arr[end]);  
    return i;  
}
void quick_sort(int *arr,int start,int end){
    if (start < end)  
    {
        int p = partition(arr, start, end);
        quick_sort(arr, start, p - 1);  
        quick_sort(arr, p + 1, end);  
    } 
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv);

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    if(rank == 0){
        int n = 0;
        int *temp_arr = new int[max_size];
        string inpFileName,outpFileName;
        stringstream stream1(argv[argc-2]);
        stream1 >> inpFileName;
        
        
        ifstream inFile;
        inFile.open(inpFileName);

        if (inFile.is_open())
        {
            int ele;
            while (inFile>>ele)
            {
                temp_arr[n] = ele;
                n++;
            }
            inFile.close();
        }

        int ceil_n = ceil(n/double(numprocs)) * numprocs;
        
        
        for(int i = n; i < ceil_n;i++){
            temp_arr[i] = 0;
        }

        int num_per_process = ceil_n / numprocs;
        
        for(int i = 1;i < numprocs;i++){
            int start_idx = num_per_process * i;

            MPI_Send( &num_per_process, 1 , MPI_INT,
                  i, 0, MPI_COMM_WORLD);

            MPI_Send( &temp_arr[start_idx], num_per_process, MPI_INT,
                  i, 0, MPI_COMM_WORLD);
        }
        int *arr2 = new int[num_per_process];
        memcpy(arr2, temp_arr, num_per_process * sizeof(int));
        quick_sort(arr2,0,num_per_process-1);
        
        memcpy(temp_arr,arr2,num_per_process);

        
        for(int i = 1; i < numprocs; i++) {

            MPI_Recv(temp_arr+num_per_process*(i), num_per_process, MPI_INT, 
                    MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        
        merge(temp_arr,ceil_n,numprocs);

        stringstream stream2(argv[argc-1]);
        stream2 >> outpFileName;

        ofstream outFile;
        outFile.open(outpFileName);

        for(int i = ceil_n - n;i < ceil_n;i++){
            outFile<<temp_arr[i]<<" ";
        }
        

        delete[] temp_arr;
        delete[] arr2;
        
    }
    else{
        int num_per_process;
        MPI_Recv( &num_per_process, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        int *arr2 = new int[num_per_process];
        MPI_Recv(arr2, num_per_process, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        quick_sort(arr2,0,num_per_process-1);

        MPI_Send( arr2, num_per_process, MPI_INT,0, 0, MPI_COMM_WORLD);
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}