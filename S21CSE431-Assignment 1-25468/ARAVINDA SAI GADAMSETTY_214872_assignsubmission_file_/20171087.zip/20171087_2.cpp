#include <mpi.h>
#include <bits/stdc++.h>
using namespace std;


int partition(int a[], int n, int piv_index){
    int smaller = 0;
    for(int i=0;i<n;i++){
        if(a[i]<=a[piv_index]){
            swap(a[i],a[smaller++]);
        }
    }
    return smaller;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    // cout << " hsbhsbhb ";
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    
    int n = 1000007;
    int idx = 0;
    int* arr;
    int total_proc = -1;
    if(rank==0){
        
        // int* a;
        // a = (int *)malloc(sizeof(int)*n);
        int a[1000007];
        ifstream f;
        f.open(argv[1]);
        int x;
        n=0;
        int count1 = 0;
        int arrsize = 0;
        while(f >> x){
            if(count1==0)arrsize = x;
            else 
            a[n++] = x;
            count1++;
        }
        // cout << endl;
        arr=a;
        total_proc = numprocs;
        idx = partition(arr,n,2);
        int rem_idx = n - idx;
        int rem_proc = total_proc - total_proc/2;
        total_proc /= 2;
        // swap(total_proc,rem_proc);
        // cout << total_proc;
        MPI_Send(&rem_idx,1,MPI_INT, rank+total_proc, 6, MPI_COMM_WORLD);
        MPI_Send(&rem_proc,1,MPI_INT, rank+total_proc, 5, MPI_COMM_WORLD);
        MPI_Send(&arr[idx],rem_idx,MPI_INT, rank+total_proc, 7, MPI_COMM_WORLD );
    }
    while(1){
        // cout << 1 ;
        if(total_proc == -1){
            // int size = 0;
            // cout << rank<< "  0" <<endl;
            MPI_Recv(&idx,1,MPI_INT,MPI_ANY_SOURCE,6,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                        // cout << rank<<"  1" <<endl;

            MPI_Recv(&total_proc,1,MPI_INT,MPI_ANY_SOURCE,5,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                        // cout << rank <<"  2"<<endl;

            arr = (int *)malloc(sizeof(int)*idx);
            MPI_Recv(arr,idx,MPI_INT,MPI_ANY_SOURCE,7,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        }
        else if(total_proc != -1)
        {
            if(total_proc == 1){
                sort(arr,arr+idx);
                if(rank!=0)
                {
                    // cout << rank << endl;
                    MPI_Send(&idx,1,MPI_INT,0,127,MPI_COMM_WORLD);
                    MPI_Send(arr,idx,MPI_INT,0,128,MPI_COMM_WORLD);
                }
                break;
            }
            int val = partition(arr,idx,idx/2);
            // cout << total_proc << endl;
            int rem_val = idx  - val;
            int rem_proc = total_proc - total_proc/2;
            total_proc /= 2;
            swap(total_proc,rem_proc);
            MPI_Send(&rem_val,1,MPI_INT, rank+total_proc, 6, MPI_COMM_WORLD);
            MPI_Send(&rem_proc,1,MPI_INT, rank+total_proc, 5, MPI_COMM_WORLD);
            MPI_Send(&arr[val],idx-val,MPI_INT, rank+total_proc, 7, MPI_COMM_WORLD );
            idx=val;
        }
        
    }
    int size = idx;
    if(rank==0){
        for(int i=1;i<numprocs;i++){
            MPI_Recv(&idx,1,MPI_INT,i,127,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            // cout << idx << " : " << i << endl;
            MPI_Recv(&arr[size],idx,MPI_INT,i,128,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            for(int i=0;i<idx;i++){
                // cout << arr[size+i] << " ";
            }
            size += idx;
        }
        // for(int i=0;i<size;i++){
        //    cout << arr[i] << " "; 
        // }
        // cout<<endl;
        int temp[size];
        for(int i=0;i<size;i++){
            temp[i] = arr[i];
        }
        ofstream mfile;
        // int x= -3;
        mfile.open(argv[2]);
        for(int i=0;i<size;i++){
           mfile << temp[i] << " "; 
        }
        // o << int(arr[0]);
        // o << endl;
        mfile.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}