# Distributed Systems | Assignment 1

```
Srinath Nair
2018111001
```
## Problem 1: Estimating pi/6

- The range of values which is input is divided 'almost' equally to all the processes.
- Each process then calculates the values assigned to it, sums them over and returns them to the master program.
- The master then sums up all the sub results and displays the final value
  - It is likely that the range of each process is not the same and that is adjusted by giving the final process a little more than the rest which happens to be the reminder of n/numprocs.

## Problem 3: Graph coloring

- We generate a line graphs from the given input graph.
- The sub processes each return uncolored vertices which would be the max among its own neighbours.


---


