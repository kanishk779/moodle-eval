#include <stdio.h>
#include <string.h>
#include "mpi.h"
// #include <fstream>
// #include <bits/stdc++.h>
// using namespace std;
typedef long long int ll;

float calculate(int l, int r){
    float res_send=0;
    int i=l;
    while(i<=r){
        res_send+=1/(((float) i)*((float) i));
        i++;
    }
    return res_send;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    float tbeg = MPI_Wtime();

    /* write your code here */
    if(rank == 0) {
        int n;
        FILE *file = NULL;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
	    int span = n/numprocs;
        int start = 1;
        int i=1;
        float result=0;
        
        while(i<numprocs)
        {
		    int a[] = {start,start+span-1};
            MPI_Send(a,2,MPI_INT,i,0,MPI_COMM_WORLD);
            start = start+span;
            i++;
        }

        result += calculate(start,n);
        
        i=1;
        while(i<numprocs)
        {
            float ans_rec;
            MPI_Recv(&ans_rec, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            result+=ans_rec;
            i++;
        }
        file = fopen(argv[2], "w");
        fprintf(file, "%f ", result);
	    
    }
    else {
	    int a[2];
        float result = 0;
        MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	    result = calculate(a[0],a[1]);
        
        MPI_Send(&result, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    float elapsedTime = MPI_Wtime() - tbeg;
    float maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}