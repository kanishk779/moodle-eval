#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void find_mis(vector<int> &vec, int colors[], int l, int r, int n, int adj[1001][1001])
{
    int i = l;
    while( i <= r)
    {
        if (!colors[i])
        {
            int mk = -100000;
            int j=1;
            while (j <= n)
            {
                if (adj[i][j] == 1)
                {
                    if (!colors[j])
                        mk = max(mk, j);
                }
                j++;
            }
            if (mk < i)
            {
                vec.push_back(i);
            }
        }
        i++;
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n, m, rr, adj[1001][1001], colors[1001];
    if (!rank)
    {
        FILE *file = NULL;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        fscanf(file, "%d", &m);
        int rr = 0;
        int i=0;
        while (i <= m)
        {
            for (int j = 0; j <= m; j++)
                adj[i][j] = 0;
            
            i++;
        }
        
        vector<vector<int>> edges;
        i=0;
        while (i < m)
        {
            int u, v;
            fscanf(file, "%d", &u);
            fscanf(file, "%d", &v);
            edges.push_back({u, v});
            i++;
        }

        i=0;
        while (i < m)
        {
            int j = i + 1; 
            while (j < m)
            {
                if ( edges[j][0] == edges[i][1] || edges[j][0] == edges[i][0] )
                {
                    if (edges[j][1] == edges[i][0]){ 
                        if (edges[j][1] == edges[i][1]){
                            
                            bool value = true;
                            adj[i + 1][j + 1] = 1;
                            value = false;
                            adj[j + 1][i + 1] = 1;
                        }
                    }
                }
                j++;
            }
            i++;
        }
        fclose(file);

        i = 1;
        while (i <= m)
        {
            colors[i] = 0;
            i++;
        }
    }
    
    MPI_Bcast(&adj[0][0], 1001*1001, MPI_INT, 0, MPI_COMM_WORLD);
    rr = n;
    MPI_Bcast(&rr, 1, MPI_INT, 0, MPI_COMM_WORLD);
    rr = m;
    MPI_Bcast(&rr, 1, MPI_INT, 0, MPI_COMM_WORLD);

    n = m;
    while (1)
    {
        MPI_Bcast(colors, n + 1, MPI_INT, 0, MPI_COMM_WORLD);
        
        int i=1, f=0;
        while(i <= n)
        {
            if (!colors[i])
                f = 1;

            i++;
        }
        if (!f)
            break;
        if (!rank)
        {
            int len_per_process = n / (numprocs);
            int start = 1;
            int i=1;
            while (i < numprocs)
            {
                int a[] = {start, start + len_per_process - 1};
                int sz = 2;
                MPI_Send(a, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                start = start + len_per_process;
                i++;
            }

            vector<int> to_be_colored, vec;
            find_mis(vec, colors, start, n, n, adj);

            for (auto x : vec)
                to_be_colored.push_back(x);

            i=1;
            while (i < numprocs)
            {
                int vec_size;
                MPI_Recv(&vec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                vector<int> vec(vec_size);
                
                if (vec_size)
                    MPI_Recv(&vec[0], vec_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
                for (auto x : vec)
                    to_be_colored.push_back(x);

                i++;
            }

            for (auto v : to_be_colored)
            {
                vector<int> smallest_p_num(n + 1, 0);
                int o=1
                while(o <= n)
                {
                    if (adj[v][o] == 1)
                    {
                        smallest_p_num[colors[o]] = 1;
                    }
                    o++;
                }

                o=1;
                while(o <= n)
                {
                    if (!smallest_p_num[o])
                    {
                        colors[v] = o;
                        break;
                    }
                    o++;
                }
            }
        }
        else
        {
            int a[2];
            MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            vector<long> vec;
            find_mis(vec, colors, a[0], a[1], n, adj);

            long vec_size = vec.size();
            MPI_Send(&vec_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            
            if (vec_size)
                MPI_Send(&vec[0], vec_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    
    if (!rank)
    {
        FILE *file = NULL;
        file = fopen(argv[2], "w");
        set<int > st;

        int i=1;
        while(i<=n){
            st.insert(colors[i]);
            i++;
        }

        fprintf(file, "%ld\n", st.size());
        i=1;
        while( i <= n ){
            fprintf(file, "%d ", colors[i]);
            i++;
        }
        fclose(file);
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}