#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iomanip>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int str_to_int(string s_num) {
	int n = 0;
	for(int i = 0; i < s_num.size(); i++) {
		n = n*10 + (s_num[i]-'0');
	}
	return n;
}

int main( int argc, char **argv ) {
	int rank, numprocs;

	/* start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	
	/* synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

	/* write your code here */

	/* MPI variables */
	MPI_Status status;
	int sender;

	/* My variables */
	int n;
	int div, rem;
	int start_n, end_n = 0;
	long double sum, child_sum;

	/* Root process */
	if(rank == 0) {

		/* Take input from file given in command line */
		ifstream inp_file(argv[1]);
		string num; 
		inp_file >> num;
		n = str_to_int(num);

		div = n / numprocs;
		rem = n % numprocs;

		/* Distribute to child processes */
		for(int an_id = 1; an_id < numprocs; an_id++) {
			start_n = end_n + 1;
			end_n += div + (rem > 0);
			rem--;
			MPI_Send(&start_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&end_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
		}

		/* Compute partial sum assigned to root process */
		sum = 0.00;
		for(int i=end_n+1; i <= n; i++) sum += 1.00/(i*i);


		/* Take partial sums from child processes */
		for(int an_id = 1; an_id < numprocs; an_id++) {
			MPI_Recv(&child_sum, 1, MPI_LONG_DOUBLE, MPI_ANY_SOURCE, 2002, MPI_COMM_WORLD, &status);
			sender = status.MPI_SOURCE;
            sum += child_sum;
		}

		/* Write output to file taken from command line */
		ofstream out_file(argv[2]);
		out_file << setprecision(7) << sum << endl;
	}

	/* Child process */
	else {
		/* Receive data from parent */
		MPI_Recv( &start_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);
        MPI_Recv( &end_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);

        /* Compute sum for child */
        child_sum = 0.00;
        for(int i=start_n; i <= end_n; i++) child_sum += 1.00/(i*i);

        /* Send partial sum to parent */
        MPI_Send( &child_sum, 1, MPI_LONG_DOUBLE, 0, 2002, MPI_COMM_WORLD);
	}


	/* taken from given template */

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}