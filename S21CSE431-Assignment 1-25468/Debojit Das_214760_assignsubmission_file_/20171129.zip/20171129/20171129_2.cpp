#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;
typedef pair<int, int> pi;

int arr[1000000];
int partly_sorted[1000000];

int str_to_int(string s_num) {
	int n = 0, i = 0, sign = 1;
	if(s_num[0] == '-') {
		i = 1;
		sign = -1;
	}
	while(i < s_num.size()) {
		n = n*10 + (s_num[i++]-'0');
	}
	return sign*n;
}

int pivoting(int from, int to, int pivot) {
	int i = from-1;
	for(int j=from; j < to; j++) {
		if(arr[j] <= pivot) {
			i++;
			swap(arr[i], arr[j]);
		}
	}
	swap(arr[i+1], arr[to]);
	return i+1;
}

void quicksort(int from, int to) {
	if(from >= to) return;
	int pivot = from + rand() % (to - from + 1);
	swap(arr[pivot], arr[to]);
	int pos = pivoting(from, to, arr[to]);
	quicksort(from, pos-1);
	quicksort(pos+1, to);
}

vector <int> merge(vector <vector <int> > sorted_arrays) {
	int k = sorted_arrays.size();
	vector <int> sizes(k);
	vector <int> reached(k);
	for(int i=0; i < k; i++) {
		sizes[i] = sorted_arrays[i].size();
		reached[i] = 1;
	}

	priority_queue<pi, vector<pi>, greater<pi> > minheap; 
	for(int i=0; i < k; i++) {
		minheap.push(make_pair(sorted_arrays[i][0], i));
	}

	pi selected_elem;
	vector <int> sorted;

	while(!minheap.empty()) {
		selected_elem = minheap.top();
		minheap.pop();
		sorted.push_back(selected_elem.first);
		if(reached[selected_elem.second] < sizes[selected_elem.second]) {
			minheap.push(make_pair(sorted_arrays[selected_elem.second][reached[selected_elem.second]], selected_elem.second));
			reached[selected_elem.second]++;
		}
	}
	return sorted;
}

int main( int argc, char **argv ) {
	int rank, numprocs;

	/* start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	
	/* synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();

	/* write your code here */

	/* MPI variables */
	MPI_Status status;
	int sender;

	/* My variables */
	int n;
	int div, rem;
	int start_n, end_n = -1;
	int K;

	vector <int> partial_sorted_arr;
	vector < vector <int> > sorted_arrays;
	vector <int> ans;

	/* Root process */
	if(rank == 0) {

		int size_n[numprocs];

		/* Take input from file given in command line */
		ifstream inp_file(argv[1]);
		string s; 
		inp_file >> s;
		n = str_to_int(s);

		for(int i=0; i < n; i++) {
			inp_file >> s;
			arr[i] = str_to_int(s);
		}

		div = n / numprocs;
		rem = n % numprocs;

		K = min(numprocs, n);

		/* Distribute to child processes */
		for(int an_id = 1; an_id < K; an_id++) {
			start_n = end_n + 1;
			end_n += div + (rem > 0);
			rem--;
			size_n[an_id] = end_n - start_n + 1;
			MPI_Send(&start_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&end_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&arr, n, MPI_INT, an_id, 2001, MPI_COMM_WORLD);
		}
		for(int an_id = K; an_id < numprocs; an_id++) {
			MPI_Send(&start_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&end_n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&n, 1 , MPI_INT, an_id, 2001, MPI_COMM_WORLD);
			MPI_Send(&arr, n, MPI_INT, an_id, 2001, MPI_COMM_WORLD);
		}

		/* Do quicksort on array-subsegment assigned to root process */
		quicksort(end_n+1, n-1);
		partial_sorted_arr.clear();
		for(int i = end_n+1; i < n; i++) partial_sorted_arr.push_back(arr[i]);
		sorted_arrays.push_back(partial_sorted_arr);


		/* Take sorted array-subsegments from child processes */
		for(int an_id = 1; an_id < K; an_id++) {

			MPI_Recv(&partly_sorted, size_n[an_id], MPI_INT, MPI_ANY_SOURCE, 2002, MPI_COMM_WORLD, &status);
			
			partial_sorted_arr.clear();
			for(int i=0; i < size_n[an_id]; i++){
				partial_sorted_arr.push_back(partly_sorted[i]);
			}
            sorted_arrays.push_back(partial_sorted_arr);
		}
		for(int an_id = K; an_id < numprocs; an_id++) {
			MPI_Recv(&partly_sorted, size_n[an_id], MPI_INT, MPI_ANY_SOURCE, 2002, MPI_COMM_WORLD, &status);
		}

		/* K-way merge them */
		ans = merge(sorted_arrays);

		/* Write output to file taken from command line */
		ofstream out_file(argv[2]);
		for(int i=0; i < n; i++) {
			out_file << ans[i] << " ";
		}
		out_file << endl;
	}

	/* Child process */
	else {
		/* Receive data from parent */
		MPI_Recv(&start_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);
        MPI_Recv(&end_n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);
        MPI_Recv(&n, 1, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);
        MPI_Recv(&arr, n, MPI_INT, 0, 2001, MPI_COMM_WORLD, &status);

        /* Do quicksort on array-subsegment assigned to child process */
        quicksort(start_n, end_n);
		for(int i = start_n; i <= end_n; i++) partly_sorted[i-start_n] = arr[i];

        /* Send partial sum to parent */
        MPI_Send(&partly_sorted, end_n-start_n+1, MPI_INT, 0, 2002, MPI_COMM_WORLD);
	}


	/* taken from given template */

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}

	/* shut down MPI */
	MPI_Finalize();
	return 0;
}