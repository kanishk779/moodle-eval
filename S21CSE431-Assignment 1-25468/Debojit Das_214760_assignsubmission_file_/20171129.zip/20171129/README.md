This project is submitted as part of my first assignment in the course Distributed Systems.

# How to run

On command line, type:
mpiCC 20171129_x.cpp; mpirun -np Y ./a.out input.txt output.txt
- Here x can be 1, 2 or 3 depending on the code you want to run
- Here Y is the number of processes allowed
- input.txt contains the input and output.txt will store the output

# Problem 1

- The problem required us to compute the sum of (1/N^2) to estimate the value of (pi^2)/6
- Integer N (int n) was taken as input (from the given file in command line) in the root process
- The task was equally divided (or as close as possible, given that remainder may not be 0) among the given processes
- E.g if n = 5 and numprocs = 3, we compute for the (1 and 2) in proc 1, (3 and 4) in proc 2 and (5) in proc 3
- Finally the child processes send the partially computed sum back to the root process and the final sum was computed
- The result was stored in the file specified in the command line

# Problem 2

- The problem required us to perform parallel quicksort on an array of given size N
- Integer N (int n) and the array were taken as input (from the given file in command line) in the root process
- The task was equally divided (or as close as possible, given that remainder may not be 0) among the given processes
- E.g if n = 5 and numprocs = 3, we perform quicksort (pivot chosen randomly) for the subarray (1:2) in proc 1, (3:4) in proc 2 and (5) in proc 3
- Finally the child processes send the sorted subarrays back to the root process
- Then, in the root process, a K-way (K being the number of processes) merge was performed to obtain the sorted array
- The result was stored in the file specified in the command line

# Problem 3


# Time taken

- It is expected that as the number of processes increase (while still remaining << n), the execution of the code will take less time. This is because code segments will be executed parallely, hence saving time.

- However, it was observed that on increasing the number of processes, code actually took longer to execute. This is probably because the size of input is small and the time saved there is much less than the overheads of creating processes.

- Code will run faster on parallelization on inputs that are much larger in size, say a few GBs