/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void swap(int* a, int* b)  
{  
    int t = *a;  
    *a = *b;  
    *b = t;  
}  

int divide_into_two(int array[], int low, int high) {
    int pivot = array[high];
    int i = low - 1;
    int j = low;

    for(; j <= high-1; j++) {
        if(array[j] < pivot) {
            swap(&array[++i], &array[j]);
        }
    }
    swap(&array[i+1], &array[high]);
    return i+1;
}

void quicksort(int array[], int low, int high) {
    if(low < high) {
        int partition_index = divide_into_two(array, low, high);
        quicksort(array, low, partition_index-1);
        quicksort(array, partition_index+1, high);
    }
}

void display_sorted_array(int array[], int N) {
    int i;
    for(i = 0; i < N; i++) {
        cout << array[i] << " ";
    }
    cout << "\n";
}

int main( int argc, char **argv ) {
    int array[1000001];
    int rank, numprocs, N, i, temp_single_element, left_child, right_child, parent, pivot, right_elements;

    ofstream ofs;
    ofs.open (argv[2], std::ofstream::out | std::ofstream::trunc);
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    left_child = 2 * rank + 1;
    right_child = 2 * rank + 2;
    parent = (rank - 1) / 2;
    if(rank == 0) {
        ifstream file(argv[1]);
        int inp,cnt=0, it=0;
        while (file >> inp)
        {
            if(cnt == 0){
                N = inp;
                cnt++;
            }
            else{
                array[it] = inp;
                it++;
            }
        }
    }
    else {
        if (N < rank)
        {
            MPI_Recv(&N, 1, MPI_INT, parent, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            if (N > 0) {
                MPI_Recv(array, N, MPI_INT, parent, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    }
    int t = 0;
    if(N == 0)  {
        if(left_child < numprocs) {
            MPI_Send(&t, 1, MPI_INT, left_child, 1, MPI_COMM_WORLD);
        }
        if(right_child < numprocs)  {
            MPI_Send(&t, 1, MPI_INT, right_child, 1, MPI_COMM_WORLD);
        }
    }
    else 
    {
        pivot = divide_into_two(array, 0, N - 1);

        if (left_child < numprocs)
        {
            MPI_Send(&pivot, 1, MPI_INT, left_child, 1, MPI_COMM_WORLD);
            if (pivot != 0)
            {
                MPI_Send(array, pivot, MPI_INT, left_child, 2, MPI_COMM_WORLD);
                MPI_Recv(array, pivot, MPI_INT, left_child, 3, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
        else
            quicksort(array, 0, N - 1);

        if (right_child < numprocs)
        {
            right_elements = N - pivot - 1;
            MPI_Send(&right_elements, 1, MPI_INT, right_child, 1, MPI_COMM_WORLD);
            if (right_elements != 0)
            {
                MPI_Send(&array[pivot + 1], right_elements, MPI_INT, right_child, 2, MPI_COMM_WORLD);
                MPI_Recv(&array[pivot + 1], right_elements, MPI_INT, right_child, 3, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
        else if (left_child < numprocs)
            quicksort(array, pivot + 1, N - 1);

    }
    if (rank != 0) {
        if(N > 0) {
            MPI_Send(array, N, MPI_INT, parent, 3, MPI_COMM_WORLD);
        }
    }
    else 
    {
        // display_sorted_array(array, N);
        for (i = 0; i < N; i++)
        {
            ofs << array[i] << " ";
        }
        ofs << "\n";
    }


    ofs.close();
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}