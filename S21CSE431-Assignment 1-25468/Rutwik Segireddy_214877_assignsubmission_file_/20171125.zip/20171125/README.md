# How to Run it?

mpic++ 20171125_1.cpp
mpirun -np 11 ./a.out <input file> <output file>

mpic++ 20171125_2.cpp
mpirun -np 11 ./a.out <input file> <output file>

mpic++ 20171125_3.cpp
mpirun -np 11 ./a.out <input file> <output file>

#Problem 1
This problem is very similar to sum of first N integers. But instead we take the reciprocal of the integer and square it.

#Problem 2
We will get two partitions using the pivot and the two partitions are sent to different processes to implement parallelization.

#Problem 3
We create a coloured array that tells us the remaining colours can be used for a particular edge. 