/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include<iostream>
#include<mpi.h>
#include<fstream>
#include<set>
#include<vector>
using namespace std;
typedef long long int ll;

int PartQsort(int A[], int l, int r, int n);
void doQsort(int A[], int l, int r, int n);

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank);
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    ifstream myfile;
    myfile.open(argv[1]);

    int node_max = 1e6+10;
    int n = 0;
    int root_rank = 0;
    int cur_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &cur_rank);
    int pool_size;
    MPI_Comm_size(MPI_COMM_WORLD, &pool_size);    
    int inp;
    if(cur_rank == root_rank){
        myfile>>inp;
        n = inp;
    }

    MPI_Group world_group;
    MPI_Comm_group(MPI_COMM_WORLD, &world_group);
    MPI_Bcast(&n, 1, MPI_INT, root_rank, MPI_COMM_WORLD);//share the n value
    
    int reqd_processes = min(n, pool_size);
    int ranks[20];
    for(int i=0;i<reqd_processes;++i)   ranks[i] = i;
    MPI_Group new_group;
    MPI_Group_incl(world_group, reqd_processes, ranks, &new_group); 
    MPI_Comm my_comm_world;
    // cout<<"trying to create new coom\n";
    MPI_Comm_create(MPI_COMM_WORLD, new_group, &my_comm_world);//create communicator for working
    // cout<<"For process: "<<cur_rank<<" reached till new comm declaration.\n";
    if(cur_rank < reqd_processes){
        MPI_Comm_size(my_comm_world, &pool_size);    
        int chunk_size = n/pool_size;
        int work_A[chunk_size+2];
        int co[pool_size];
        for(int i=0;i<pool_size;++i)   co[i] = chunk_size;
        for(int i=0;i<n%pool_size;++i)   co[i]++;
        int disp[pool_size];
        disp[0] = 0;
        for(int i=1;i<pool_size;++i)   disp[i] = disp[i-1] + co[i-1];
        if(cur_rank == root_rank){
            int A[node_max];
            for(int i=0;i<n;++i){
                myfile>>inp;
                A[i] = inp;
            }
            //scatter the input array into chunks to split among procesess
            MPI_Scatterv(A, co, disp, MPI_INT, &work_A, co[cur_rank], MPI_INT, root_rank, my_comm_world);
        }
        else{
            MPI_Scatterv(NULL, NULL, NULL, NULL, &work_A, co[cur_rank], MPI_INT, root_rank, my_comm_world);
        }
        myfile.close();
        doQsort(work_A, 0, co[cur_rank]-1, co[cur_rank]);
        int ret_num = work_A[co[cur_rank]/2];
        int ret_vals[co[cur_rank]];
        int ret_len = 0;
        if(n < pool_size*pool_size) ret_vals[ret_len++]  = ret_num;//if n too small for multiple candidates
        else{
            int npp = n/(pool_size*pool_size);
            int iter_for_here = 0;
            //collect multiple candiates for choosing medians for partition beofre quicksort
            while(iter_for_here*npp < co[cur_rank]){
                ret_vals[ret_len++] = work_A[iter_for_here*npp];
                iter_for_here++;
            }
        }
        int all_rets[pool_size+1];
        MPI_Gather(&ret_len, 1, MPI_INT, all_rets, 1, MPI_INT, root_rank, my_comm_world);//gather number of candidates form each process
        int final_candidates[pool_size];
        int chosen_candidates_co = pool_size-1;
        if(cur_rank == root_rank){
            int disp[pool_size];
            for(int i=0;i<pool_size;++i)     disp[i] = 0;
            for(int i=1;i<pool_size;++i)    disp[i] = disp[i-1] + all_rets[i-1]; 
            int total_candidates = 0;
            for(int i=0;i<pool_size;++i)    total_candidates += all_rets[i];
            int candidates[total_candidates];
            // cout<<"Total candidates: "<<total_candidates<<"\n";
            MPI_Gatherv(ret_vals, ret_len, MPI_INT, candidates, all_rets, disp, MPI_INT, root_rank, my_comm_world);//gather all candidaes
            doQsort(candidates, 0, total_candidates-1, total_candidates);//to ensure non-decreasing order, for effecient sorting and concatenation later
            for(int i=0;i<pool_size;++i) final_candidates[i] = 0;
            if(n < pool_size*pool_size){
                for(int i=0;i<chosen_candidates_co;++i) final_candidates[i] = candidates[i];
            }
            else{
                //choosing as such, so the final candidate arent from the edge, and have good seperation inbetween them
                //for better load balancing among processes
                int diff = 1;
                while(total_candidates/((diff+1)*pool_size))    diff++;
                if(diff > 1)    diff--;
                int rem = total_candidates - (diff*pool_size);
                for(int i=0;i<chosen_candidates_co;++i){
                    final_candidates[i] = candidates[i*diff+rem/2];
                }
            }
            // cout<<"Got the candidates\n";
        }
        else{
            MPI_Gatherv(ret_vals, ret_len, MPI_INT, NULL, NULL, NULL, MPI_INT, root_rank, my_comm_world);
        }
        MPI_Bcast(final_candidates, chosen_candidates_co, MPI_INT, root_rank, my_comm_world);//share the candidates
        int split_co[pool_size];
        for(int i=0;i<pool_size;++i) split_co[i] = 0;
        int split_disp[pool_size];
        for(int i=0;i<pool_size;++i) split_disp[i] = 0;
        int iter_1 = 0;
        int iter_cand = 0;
        while(iter_1 < co[cur_rank] and iter_cand < chosen_candidates_co){
            while(work_A[iter_1] > final_candidates[iter_cand]){
                split_disp[iter_cand+1] = iter_1;
                iter_cand++;
            }
            iter_1++;
        }
        while(iter_cand < chosen_candidates_co){
            split_disp[iter_cand+1] = co[cur_rank];
            iter_cand++;
        }
        for(int i=0;i<pool_size-1;++i){
            split_co[i] = split_disp[i+1]-split_disp[i];
        }
        split_co[pool_size-1] = co[cur_rank] - split_disp[pool_size-1];
        int expected_el_co[pool_size];
        for(int i=0;i<pool_size;++i) expected_el_co[i] = 0;
        MPI_Request request_1, myrequest_1;
        MPI_Request requests__[pool_size];
        for(int i=0;i<pool_size;++i){
            if(i == cur_rank){
                //gather the expected number of elements from each process
                MPI_Igather(&split_co[i], 1, MPI_INT, expected_el_co, 1, MPI_INT, i, my_comm_world, &requests__[i]);
            }
            else{
                MPI_Igather(&split_co[i], 1, MPI_INT, NULL, 0, MPI_INT, i, my_comm_world, &requests__[i]);
            }
        }
        
        // MPI_Wait(&myrequest_1, MPI_STATUS_IGNORE);
        for(int i=0;i<pool_size;++i)    MPI_Wait(&requests__[i], MPI_STATUS_IGNORE);//wait for all processes to get in otder
        int ma_exp_el_co = 0;
        for(int i=0;i<pool_size;++i)    ma_exp_el_co = max(ma_exp_el_co, expected_el_co[i]);
        int final_work_A[pool_size][ma_exp_el_co];//accumulator from all processes
        MPI_Request requests[pool_size];
        for(int i=0;i<pool_size;++i){
            if(i == cur_rank){
                //scatter the partitions to all processes
                MPI_Scatterv(work_A, split_co, split_disp, MPI_INT, final_work_A[i], expected_el_co[i], MPI_INT, i, my_comm_world);//, &requests[i]);
            }
            else{
                MPI_Scatterv(NULL, NULL, NULL, NULL, final_work_A[i], expected_el_co[i], MPI_INT, i, my_comm_world);//, &requests[i]);
            }
        }
        // for(int i=0;i<pool_size;++i)    MPI_Wait(&requests[cur_rank], MPI_STATUS_IGNORE);
        int total_co = 0;
        for(int i=0;i<pool_size;++i)    total_co += expected_el_co[i];
        // cout<<"For process : "<<cur_rank<<" final work array of size = "<<total_co<<"\n";
        int cur_final_work_A[total_co];
        int iter_co = 0;
        for(int j=0;j<pool_size;++j){
            // cout<<"For process: "<<cur_rank<<" first value maybe from process: "<<j<<" is :"<<final_work_A[j][0]<<"\n";
            for(int i=0;i<expected_el_co[j];++i){
                // cout<<"For process: "<<cur_rank<<" taking from process: "<<j<<" the value: "<<final_work_A[j][i]<<"\n";
                cur_final_work_A[iter_co++] = final_work_A[j][i];//make accumulator into 1D array
            }
        }
        doQsort(cur_final_work_A, 0, total_co-1, total_co);
        // sort(cur_final_work_A, cur_final_work_A+total_co);
        bool pro_validity = true;
        for(int i=0;i<total_co-1;++i){
            if(cur_final_work_A[i] > cur_final_work_A[i+1]) pro_validity = false;
        }
        // cout<<"For process: "<<cur_rank<<" validity: "<<pro_validity<<" and in "<<MPI_Wtime() - tbeg<<"s\n";
        int retrv_co[pool_size];
        MPI_Gather(&total_co, 1, MPI_INT, retrv_co, 1, MPI_INT, root_rank, my_comm_world);

        if(cur_rank == root_rank){
            // cout<<"Here to gather all the partitions finally\n";
            int final_sorted_arr[n];
            int retrv_disp[pool_size];
            for(int i=0;i<pool_size;++i)    retrv_disp[i] = 0;
            for(int i=1;i<pool_size;++i)    retrv_disp[i] = retrv_disp[i-1] + retrv_co[i-1];
            MPI_Gatherv(cur_final_work_A, total_co, MPI_INT, final_sorted_arr, retrv_co, retrv_disp, MPI_INT, root_rank, my_comm_world);
            int found_final_co = 0;
            for(int i=0;i<pool_size;++i)    found_final_co += retrv_co[i];
            bool validity = true;
            for(int i=0;i<n-1;++i){
                if(final_sorted_arr[i] > final_sorted_arr[i+1]){
                    validity = false;
                }
            }
            // cout<<"Verdict: "<<validity<<"\n";
            ofstream outfile;
            outfile.open(argv[2]);
            for(int i=0;i<n;++i){
                outfile<<final_sorted_arr[i]<<" ";
            }
            outfile<<"\n";
            outfile.close();
        }
        else{
            MPI_Gatherv(cur_final_work_A, total_co, MPI_INT, NULL, NULL, NULL, MPI_INT, root_rank, my_comm_world);
        }
    }
    else{
        ;// cout<<"Dropped "<<cur_rank<<"\n";
    }



    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}


int PartQsort(int A[], int l, int r, int n){
    int pos = rand()%(r-l) + l;
    if(pos < l) pos = l;
    else if(pos >= r)   pos = r;
    swap(A[pos], A[r]);
    int i = l - 1;

    for (int j = l; j < r; j++) {
        if (A[j] <= A[r]) {
            i++;
            swap(A[i], A[j]);
        }
    }
    swap(A[i + 1], A[r]);
    return i + 1;
}

void doQsort(int A[], int l, int r, int n){
    if(l>=r) return;    //one or zero element subsection
    if(r-l <= 5)    sort(A+l, A+r+1);//hybrid sort
    int pivotind = PartQsort(A, l, r, n);

    doQsort(A, l, pivotind-1, n);
    doQsort(A, pivotind+1, r, n);
}