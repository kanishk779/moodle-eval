/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <random>
#include <vector>
#include <map>
#include <set>
#include <unistd.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_rank = 0;
    int cur_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &cur_rank);
    int pool_size;
    MPI_Comm_size(MPI_COMM_WORLD, &pool_size);
    int n, m;
    vector<int> A[101];
    int lim_delt_plus_1 = 0;
    int repn[111001+10]; //(110 + 1)*1000   //a <-> b edge => index
    int repn_inv[501+100];                  //inverse of above
    int r = 501, c = 501;                   // m<=500 edges
    //int new_adj[501][501];
    bool *new_adj = (bool *)malloc(r * c * sizeof(bool));  
    set<int> rec;
    int tot_edg = 0;
    vector<pair<int, int> > order_input;    //for final edge color submission based on input order
    if(cur_rank == root_rank){
        ifstream inpfile;
        inpfile.open(argv[1]);
        inpfile>>n>>m;
        int indeg[n+1];
        for(int i=1;i<=n;++i)    indeg[i] = 0;
        int u, v;
        for(int i=0;i<m;++i){
            inpfile>>u>>v;
            order_input.push_back(make_pair(u,v));
            A[u].push_back(v);
            A[v].push_back(u);
            indeg[u]++;
            indeg[v]++;
        }
        for(int i=1;i<=n;++i){
            lim_delt_plus_1 = max(lim_delt_plus_1, indeg[i]);
        }
        lim_delt_plus_1 += 1;           //delta + 1, the limit/aim of the number of distinct colors assignment
                                        //considered to be always possible by vizig's

        int temp;
        for(int i=1;i<=n;++i){
            for(auto j:A[i]){
                if(j < i)   temp = j*1000 + i;      // to ensure no duplication of edges while able ot identify
                else        temp = i*1000 + j;
                if(rec.find(temp) != rec.end());
                else{
                    rec.insert(temp);
                    repn_inv[tot_edg] = temp;
                    repn[temp] = tot_edg;
                    tot_edg++;
                }
            }
        }

        for(int i=1;i<=n;++i){
            vector<int> all_here;
            for(auto j:A[i]){
                if(j < i)   temp = j*1000 + i;
                else        temp = i*1000 + j;
                all_here.push_back(temp);       
            }
            for(int f=0;f<all_here.size();++f){
                for(int g=f+1;g<all_here.size();++g){
                    *(new_adj + repn[all_here[f]]*c + repn[all_here[g]]) = true;
                    *(new_adj + repn[all_here[g]]*c + repn[all_here[f]]) = true;//populate the adjaceny matrix of the line graph
                }
            }
        }
        
        int newindeg[501];
        for(int i=0;i<501;++i)  newindeg[i] = 0;
        for(int i=0;i<501;++i){
            for(int j=0;j<501;++j){
                if(*(new_adj + i*c + j)) newindeg[i]++;
            }
        }
        int temp_delta = 0;
        for(int i=0;i<501;++i)  temp_delta = max(temp_delta, newindeg[i]);
        temp_delta += 1;//delta+1 of the line graph
        lim_delt_plus_1 = max(lim_delt_plus_1, temp_delta);
        inpfile.close();
    }
    MPI_Bcast(&n, 1, MPI_INT, root_rank, MPI_COMM_WORLD);//share the n value
    MPI_Bcast(&m, 1, MPI_INT, root_rank, MPI_COMM_WORLD);//share the m value
    MPI_Bcast(&lim_delt_plus_1, 1, MPI_INT, root_rank, MPI_COMM_WORLD);//share the delta value
    MPI_Bcast(&tot_edg, 1, MPI_INT, root_rank, MPI_COMM_WORLD);//share the totedg value
    MPI_Bcast(new_adj, r*c, MPI_C_BOOL, root_rank, MPI_COMM_WORLD);//share the adj mat
    MPI_Bcast(repn, 111001+10, MPI_INT, root_rank, MPI_COMM_WORLD);//share the repn map
    MPI_Bcast(repn_inv, 501+100, MPI_INT, root_rank, MPI_COMM_WORLD);//share the repn map inv
    int here_color_status[501];
    for(int i=0;i<501;++i)  here_color_status[i] = -1;//color assignemnt status
    //[start_ind, end_ind) !!!!!reminder to use as such
    double part = double(tot_edg)/pool_size;
    int start_ind = int(cur_rank*part);
    int end_ind = int((cur_rank+1)*part);
    int len_part = end_ind - start_ind;
    int split_co[pool_size+1];
    for(int i=0;i<pool_size;++i){
        split_co[i] = int((i+1)*part) - int(i*part);
    }
    int split_disp[pool_size+1];
    split_disp[0] = 0;
    for(int i=1;i<pool_size;++i){
        split_disp[i] = split_disp[i-1] + split_co[i-1];
    }
    int temp_for_sending[len_part];
    vector<vector<int> > adj_vector(501);//for faster neighbor retreival
    for(int i=start_ind;i<end_ind;++i){
        for(int j=0;j<501;++j){
            if(*(new_adj + i*c + j)){
                adj_vector[i].push_back(j);
            }
        }
    }

    set<int> uncolored_vertices;//todo list for processor
    for(int i=start_ind;i<end_ind;++i)  uncolored_vertices.insert(i);
    map<int, set<int> > pallete;//color pallete for each vertice
    for(int i=start_ind;i<end_ind;++i){
        for(int j=0;j<lim_delt_plus_1;++j)  pallete[i].insert(j);
    }
    //for actual uniform randomization; rand() is not uniform
    random_device rd; 
    mt19937 gen(rd());
            
    bool flag = true;
    while(flag){
        for(auto current_vertice:uncolored_vertices){
            for(auto neigh:adj_vector[current_vertice]){
                if(here_color_status[neigh] != -1){
                    pallete[current_vertice].erase(here_color_status[neigh]);//erase color from pallete if neighbour has it permenantly
                }
            }
        }
        for(auto current_vertice:uncolored_vertices){
            uniform_int_distribution<> distrib(0, pallete[current_vertice].size()-1);
            int color_choice = distrib(gen);//randomly choose a color to apply
            for(auto kll:pallete[current_vertice]){
                if(color_choice == 0){
                    here_color_status[current_vertice] = kll;
                    break;
                }
                color_choice--;
            }
        }
        for(int i=start_ind;i<end_ind;++i){
            temp_for_sending[i-start_ind] = here_color_status[i];//buffer for being gathered by root process
        }
        if(cur_rank == root_rank){
            MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, here_color_status, split_co, split_disp, MPI_INT, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status
            MPI_Bcast(here_color_status, 501, MPI_INT, root_rank, MPI_COMM_WORLD);//here_color_status refresh
        }
        else{
            MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, NULL, NULL, NULL, NULL, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status
            MPI_Bcast(here_color_status, 501, MPI_INT, root_rank, MPI_COMM_WORLD);//here_color_status refresh
        }
        set<int> done_vert;
        for(auto current_vertice:uncolored_vertices){
            for(auto neighbor:adj_vector[current_vertice]){
                //check if any other neighbour also applied for it, or already has it
                if(here_color_status[current_vertice] == here_color_status[neighbor]){
                    here_color_status[current_vertice] = -1;//if so cancel the application;
                    //the neighbours will get either cancelled when it is checking, or if only it is left, it will end up selecting it.
                    //it doesnt matter if current_vertice loses this color. There are delta+1 options, 
                    //even if current_vertice had indegree = delta, one colour is still left out, which it will get in the next round.
                    //The above is the worst case scenario. Therefore if this gets, other scenarios should get intuitively.
                    break;
                }
            }
            //but if there are no conflicts, permentatly assign the color by removing the vertice form uncoloured set.
            if(here_color_status[current_vertice] != -1)    done_vert.insert(current_vertice);
        }
        for(int i=start_ind;i<end_ind;++i){
            temp_for_sending[i-start_ind] = here_color_status[i];//resend the buffer for refreshing the statuses
        }
        for(auto vert:done_vert)    uncolored_vertices.erase(vert);//erase permenantly coloured vertices from uncoloured set
        done_vert.clear();
        if(uncolored_vertices.size() == 0)      flag = false;//if no vertices left to colour, finished processing
        bool reduction_result=true;
        MPI_Reduce(&flag, &reduction_result, 1, MPI_C_BOOL, MPI_LOR, root_rank, MPI_COMM_WORLD);//flags from all
        if(cur_rank == root_rank)   flag = reduction_result;//flag to see if all processes finished processing. (used Logical OR)
        MPI_Bcast(&flag, 1, MPI_C_BOOL, root_rank, MPI_COMM_WORLD);//flag if to continue running
        if(cur_rank == root_rank){
            MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, here_color_status, split_co, split_disp, MPI_INT, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status
            MPI_Bcast(here_color_status, 501, MPI_INT, root_rank, MPI_COMM_WORLD);//here_color_status
        }
        else{
            MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, NULL, NULL, NULL, NULL, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status
            MPI_Bcast(here_color_status, 501, MPI_INT, root_rank, MPI_COMM_WORLD);//here_color_status
        }
    }

    for(int i=start_ind;i<end_ind;++i){
        temp_for_sending[i-start_ind] = here_color_status[i];
    }

    if(cur_rank == root_rank){
        MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, here_color_status, split_co, split_disp, MPI_INT, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status



        ofstream outfile;
        outfile.open(argv[2]);
        outfile<<lim_delt_plus_1<<"\n";
        int temp;
        for(auto i:order_input){
            if(i.first<i.second)    temp = i.first*1000 + i.second;
            else                    temp = i.second*1000 + i.first;
            outfile<<here_color_status[repn[temp]]+1<<" ";
        }
        outfile<<"\n";
        outfile.close();
    }
    else{
        MPI_Gatherv(temp_for_sending, split_co[cur_rank], MPI_INT, NULL, NULL, NULL, NULL, root_rank, MPI_COMM_WORLD); //temp_for_sending into here_color_status
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}