Question 1:
    The calc() is an helper function that calculates the sum of reciprocals for integers for the range of [l,r].
    The whole range of [1, n] is then split up over the processes to independently calculate for the value of the function for their respective subranges.
    Used Broadcast() to broadcast the value of n (input) to all the other processes for calculating their respective ranges (used this rather than giving their respective ranges itself as faster, cleaner and unnecessary to complicate).
    The values from each process are returned back to the root process using Reduce().


Question 2:
    PartQsort() and doQsort() are the helper functions for carrying out Hybrid Quicksort. Also the pivot is selected at random each time for quicker run.

    A new group and communicator are created (mainly to handle when n is less than the number of processes). 
    
    The input array is first broken up into chunks and split up into the processes where they are further sorted using the Quicksort function implemented. Then candidates are selected from each process's sorted chunks which are used for partitioning these chunks for sending to respective indiced process. 

    Then after each process scatters all the partitions to the respective processes, and after completely reciving all the assigned partitions, it proceeds to apply quicksort on their paritition and finally sends it to the root process where they are concatenated based on the process ranks.

    This final array is the final sorted array.

    An example is below.

    4   2   1   6   4   5   7   2   5   9   3   8

    [Step 1]
    <--0-->         <--1-->         <--2-->
    4 2 1 6         4 5 7 2         5 9 3 6         Partitioned into chunks. (used scatterv)

    [Step 2]
    1 2 4 6         2 4 5 7         3 5 6 9         QSorted

    [Step 3]
    Choose candidates:  1 4     2 5        3 6      [Choose candidates from each process and send back to root process] (usde gather to get lengths of chosen candidates from each process and then gatherv to get them)

    [Step 4]
    1 2 3 4 5 6                                     Qsorted()

    [Step 5]
    3 5                                             Choose two (num_processes-1; num-processes = 3) candidates and send to each process(used broadcast)

    [Step 6]
    <0>  <1> <2>       <0> <-1-> <2>   <0> <1> <-2->    <-To be sent to process-id->
    1 2 | 4 | 6         2 | 4 5 | 7     3 | 5 | 6 9    Partition based on candidates and send to respective indiced process. Each partition is such that they are not greater than that candidate. (Hence each partition will be greater than the previous partition's candidate but not greater than the current candidate. The edge cases are trivially handled.)

    
    [Step 7]
    1 2 2 3         4 4 5 5         6 7 6 9           The recieved partitions are collected. (used Igather to gather all the expected number of elements for each process from other processes. Then the partitions are scattered using scatterv to respective processes.)

    [Step 8]
    1 2 2 3         4 4 5 5         6 6 7 9           And Qsorted()

    [Step 9]
    <--0--> <--1--> <--2-->                             <-process-id recieved from>
    1 2 2 3 4 4 5 5 6 6 7 8                            And finally sent to the root process where they are collected and submitted.(used gather to find number of elements in each process, and gatherv to get them.)


    The array can be directly concatenated as each process is being assigned numbers (step 7) that are lesser than a candidate but not greater than the next candidate, which are themselves sorted, and hence all elements in j^(th) partition are lesser than the i^(th) partition where i>j (due to step 4).

    Also this follows the standard Quicksort() process of dividing the array(step 1 and 7), and then finally constructing them(step 9). 
    The candidate selection (step 3,4,5) is such as the load on each process will be more balanced than random selection which can end up selecting edge values (in below selecting 1, or 6) or close values(2, 3, 4) which will lead to weak partitioning. 
    [1, 2, 3, 4, 5, 6]

    The worst case improves as it is O(n^2) and in this n=n/num_processes and we do it net 2*num_processes times, therefore O(2*P*(n/P)^2) => O(n^2/P). There are overheads though due to the message passing.




Question 3:

    First the given graph is converted into a line graph, as the algorithm used is a vertex coloring one whereas the task is edge coloring one. (reference: https://en.wikipedia.org/wiki/Line_graph) 
    As the constraints are small (N = 100, M = 500), for indexing these "new vertices" the conversion done is:
    If an edge exists between a and b (where a<b), the index of it in the line graph is: a*1000 + b      (max value of b can be 100, therefore the representation is one to one.)
    The mapping is stored in repn[], and the inverse can be found from repn_inv[].
    The adjacency matrix of the line graph is in new_adj[][].
    The number of colors we can use is the max of the delta of the original graph and the line graph (according to clarification).
    These values that have been inputted and calculated are Broadcasted to all the processes. 
    The processes focus on a range of vertices that are mutually exclusive and exhaustive.
    The here_color_status[] records the status of the coloring of the vertice of the line graph. Once confirmed a color, it will not be affected and will be permenanet. But temporary assignments are also kept, which are only permenanet after confirmation.
    A set of uncoloured vertices keeps track of the vertices to be still worked on.
    The pallete[] is a list of colors that can be applied to that vertice. It is updated based on the colors applied to the neighbours of that vertice. (initially is all delta + 1 values)

    While all vertices are not permenantly assigned their color:
        For each uncolored vertice, remove colors from their palletes which have been permenantly assigned to their neigbour.
        Randomly choose a color from their pallete, and apply for it in the here_color_status[]
        The root process then gathers all the statuses from the processes and broadcasts the whole updated here_color_status[] to each of them.
        Then the process checks for each of the uncolored vertice, if the color they applied for has been applied for by any of the vertice's uncolored neighbours. If such is the case, then both these vertices lose their application and are not assigned any color and remain uncolored. But if none of it's neighbour has the apllied color, then it is made permenant, and the vertice is also removed from the process's set of uncolored vertice.

    The above while loop finishes when all processes finish colouring the vertices assigned to them. (done by reduce() of all flags, with the operation of Logical OR, so even if one process has not completed, the while() continues. This blank runs of processes is preferred as, the expected number of "extra" rounds are very less, and this setup is cleaner, convienient and efficient.)

    The refresh of the colour status of the vertices is done by Gatherv() the status of the vertices from each process, and then concatenating into one "global" status record, which is then broadcasted to all processes, so they can check for each vertice if the adjacent vertice has the same color or not.

    The root process finally gathers the color status of the vertices from the processes, and submits it.

    The algorithm will definitely succeed as by vizig's theorem, any graph can be colored in delta + 1 colors.
    The randomization is ensured to be uniformly distributed.


    Expects that no duplicate edges (which is a given).




