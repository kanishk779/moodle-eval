# Distributed Systems | Assignment 1

```
Bhuvanesh Sridharan
2018113002
```
## Problem 1

- Broadcast the value of $N$ to all the subprocesses so that they calculate individually on what part of the $N$ do they have to calculate and return. 
- Each processor must get roughly equal amount of load to square and return.
  - Therefore, it shouldn't be the case that 1 proc gets all the small numbers and one gets all the big numebers.
  - Hence using modular arithmetic to calculate which numbers a processor has to calculate.

- Therefore $P_i$ calculates $\frac{1}{x^2}\forall  \{ x : x \equiv i  (\text{ mod } n)\}$ and returns to the parent process.

## Problem 2

- Partition the array into $n$ parts where $n$ is the number of processes.
- Send each of these parts to their respective slave process.
- The slave processes sorts the array using quick sort and returns the sorted subarray.
- The master process does a $k$-way merge of the sorted arrays received from the slave processes.

## Problem 3 

- Jones Plassman Algorithm is used to colour the graph parallely.
    -   Number the nodes with unique numbers,
    -   Pick set of nodes $X$ such that : $X = \{v_i : i \gt j \forall v_j \in N(v_i)\}$
    -  Colour all nodes in $X$ with lowest available colour. i.e Lowest colour such that None of the neighbors are coloured with the colour.
    -  Repeat until all the nodes are coloured. 

- How to parallelize the code?
  - Notice that each set $X$ is independent and none of them depend on each other at each stage to be coloured. 
  - They can be broken down into many sets and sent to various slave processes to process them after broadcasting the current colour state of the graph.
  - Then the slave sends back the nodes that it has coloured and the master combines the new colour state and shares it back with all the slaves again.

---


