/* mpic++ 2019201068_2.cpp -o 2019201068_2
 mpirun -np 2 2019201068_2 in.txt out.txt */


#include"mpi.h"
#include<bits/stdc++.h>
// #include<iostream>

using namespace std;
void swap(vector<long long int> &Arr,long long int a,long long int b)
{
    long long int temp=Arr[a];
    Arr[a]=Arr[b];
    Arr[b]=temp;
}
long long int Partition(vector<long long int> &arr, long long int l, long long int r)
{
    
    long long int pivot;
    pivot=arr[l];
   long long int k;
   k=l;
   for(int i=l+1;i<=r;i++)
   {
       if(arr[i]<pivot)
       {
           int temp=arr[k+1];
           arr[k+1]=arr[i];
           arr[i]=temp;
           k++;
       }
   }
   long long int temp=arr[k];
           arr[k]=arr[l];
           arr[l]=temp;
           return k;
}

void QuickSort(vector<long long int> &Arr, long long int Left, long long int Right)
{
    if(Left>=Right)
    return;
    else
    {
        long long int Partition_Index ;
         Partition_Index=Partition(Arr, Left, Right);
        
        QuickSort(Arr, Left, Partition_Index - 1);
        QuickSort(Arr, Partition_Index + 1, Right);
    }
}

vector<long long int> Merge(vector<long long int> &Array1, long long int Size1, vector<long long int> &Array2, long long int Size2)
{
    vector<long long int> Result;
    long long int i ;
    long long int j;
    i=0; 
     j = 0;
    // long long int Size1 = Array1.size();
    // long long int Size2 = Array2.size();

    while(i < Size1 && j < Size2)
    {
        if(Array1[i] < Array2[j])
        {
            long long int temp=Array1[i];
            Result.push_back(temp);
            i=i+1;
        }
        else
        {
             long long int temp=Array2[j];
            Result.push_back(temp);
            j=j+1;
        }
    }
    while(i < Size1)
    {
         long long int temp=Array1[i];
        Result.push_back(temp);
        i=i+1;
    }
    while(j < Size2)
    {
       long long int temp=Array2[j];
            Result.push_back(temp);
            j=j+1;
    }
    return Result;
}

int main( int argc, char **argv ) 
{
    int rank;
    int numprocs;
int k=0;
    MPI_Status status;
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg ;
    tbeg= MPI_Wtime();

    /* write your code here */
    if(numprocs < 1)
    {
        cout << "you have to use at least 1 processors to run this program\n";
        MPI_Finalize();
        exit(0);
    }
    

    
    long long int Total_Elements;
    vector<long long int> Array1;
    vector<long long int> Array2;
    if(rank == 0) 
    {
        

        ifstream file(argv[argc - 2]);
        string Line;

        getline(file,Line);
        stringstream  lineStream(Line);

        long long int value;
        while(lineStream >> value)
            {
                long long int temp;
                temp=value;
                Array1.push_back(temp);
            }
        
        Total_Elements = Array1.size();
    }

    MPI_Bcast(&Total_Elements, 1, MPI_LONG_LONG, k, MPI_COMM_WORLD);

    long long int Elements_Per_Process;
    if(rank == 0)
    {
        Elements_Per_Process = Total_Elements / numprocs;
        
        for(long long int P_Id = 1; P_Id < numprocs; P_Id=1+P_Id) 
        {
            long long int Start_Ele;
            long long int End_Ele;
            long long int temp2=Total_Elements % numprocs;
            if(P_Id <=temp2 )
                {
                    int a=P_Id;
                    int b=Elements_Per_Process + 1;
                    Start_Ele = a * b;
                }
            else
                {
                    long long int a=(Total_Elements % numprocs) * (Elements_Per_Process + 1);
                    long long int  b=(P_Id - (Total_Elements % numprocs));
                    Start_Ele = a+ (b * (Elements_Per_Process));
                }
            if(P_Id < Total_Elements % numprocs)
                {
                    int a=Start_Ele;
                    int b=Elements_Per_Process ;
                    End_Ele = (a+b);
                }
            else
                {
                     int a=Start_Ele;
                    int b=Elements_Per_Process ;
                    End_Ele = (a+b-1);
                }

            if(End_Ele >= Total_Elements)
                End_Ele = Total_Elements - 1;

            long long int Elements_To_Send ;
            Elements_To_Send=End_Ele - Start_Ele + 1;

            MPI_Send(&Elements_To_Send, 1, MPI_LONG_LONG, P_Id, 42, MPI_COMM_WORLD);

            MPI_Send(static_cast<void*>(&Array1[Start_Ele]), Elements_To_Send, MPI_LONG_LONG, P_Id, 42, MPI_COMM_WORLD);
            // MPI_Recv(&Array[Start_Ele], Elements_To_Send, MPI_LONG_LONG, P_Id, 44, MPI_COMM_WORLD, &status);
        }
        int t=Total_Elements % numprocs;
        if( t != 0)
            Elements_Per_Process=1+Elements_Per_Process;
        QuickSort(Array1,0,Elements_Per_Process - 1);
    }
        

    else
    {
        MPI_Recv(&Elements_Per_Process, 1, MPI_LONG_LONG, k, 42, MPI_COMM_WORLD, &status);
        
        
        Array1.resize(Elements_Per_Process);
        MPI_Recv(static_cast<void*>(&Array1[0]), Elements_Per_Process, MPI_LONG_LONG, 0, 42, MPI_COMM_WORLD, &status);

        QuickSort(Array1,0,Elements_Per_Process - 1);
    }

    long long int Merge_Itr ;
    Merge_Itr=1;
    while(Merge_Itr < numprocs)
    {
        int t=rank % (2 * Merge_Itr);
        if( t == 0)
        {
            int temp1=rank + Merge_Itr;
            if(temp1 < numprocs)
            {
                long long int Received_Size;
                MPI_Recv(&Received_Size,1,MPI_LONG_LONG,rank + Merge_Itr,0,MPI_COMM_WORLD,&status);
                Array2.resize(Received_Size);
                MPI_Recv(static_cast<void*>(&Array2[0]),Received_Size,MPI_LONG_LONG,rank + Merge_Itr,0,MPI_COMM_WORLD,&status);
                Array1 = Merge(Array1,Elements_Per_Process,Array2,Received_Size);
                Elements_Per_Process = (Elements_Per_Process+ Received_Size);
            }
        }
        else
        {
            // cout << "rank: " << Rank << ", Itr: " << Merge_Itr << "\n";
            long long int Rank_To_Send ;
             Rank_To_Send =rank - Merge_Itr;
            MPI_Send(&Elements_Per_Process,1,MPI_LONG_LONG,Rank_To_Send,0,MPI_COMM_WORLD);
            MPI_Send(static_cast<void*>(&Array1[0]),Elements_Per_Process,MPI_LONG_LONG,Rank_To_Send,0,MPI_COMM_WORLD);
            break; 
        }
        Merge_Itr = Merge_Itr* 2;
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime ;
    elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
       
        ofstream fout;
        fout.open(argv[argc - 1]);
        for(long long int i = 0; i < Array1.size(); i++) 
        {
            fout << Array1[i] << " ";   
        }
        fout.close();
    }

   
    MPI_Finalize();
    return 0;
}