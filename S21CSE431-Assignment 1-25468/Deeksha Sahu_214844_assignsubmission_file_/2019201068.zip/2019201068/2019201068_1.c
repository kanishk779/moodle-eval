/*compile: mpicc 2019201068_1.c -o hello
run: mpirun -np 11 hello in.txt out.txt*/
#include <mpi.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 


 
   
int main(int argc, char* argv[]) 
{ 
  int k=0;
    int pid;
    int np;
    int elements_per_process; 
        int n_elements_recieved;
        int n; 
 MPI_Status status; 
  MPI_Init(&argc, &argv); 
  MPI_Comm_rank(MPI_COMM_WORLD, &pid); 
    MPI_Comm_size(MPI_COMM_WORLD, &np); 
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
      MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
  
    float a2[1000];
    if (pid == 0) 
    { 
                
        FILE *fp;
       if ((fp = fopen(argv[argc - 2],"r")) == NULL)
        {
            printf("Error! opening file");
            exit(1);
        }

        fscanf(fp,"%d", &n);

        
        fclose(fp); 
       float a[n];
       for (int i=1;i<=n;i++)
        {
            float b=i*i;
            
            a[i-1]=(float)(1.0/b);
        
        }
        int index, i; 
        elements_per_process = n / np; 
         if (np >1)
          { 
           
            for (i = 1; i < np - 1; i++) 
            { 
                index = i * elements_per_process; 
                index=index*1;
  
                MPI_Send(&elements_per_process, 
                         1, MPI_INT, i, k, 
                         MPI_COMM_WORLD); 
                MPI_Send(&a[index], 
                         elements_per_process, 
                         MPI_INT, i, k, 
                         MPI_COMM_WORLD); 
            } 
            index = i * elements_per_process; 
            int elements_left = n - index; 
            elements_left=elements_left-0;
  
            MPI_Send(&elements_left, 
                     1, MPI_INT, 
                     i, k, 
                     MPI_COMM_WORLD); 
            MPI_Send(&a[index], 
                     elements_left, 
                     MPI_INT, i, k, 
                     MPI_COMM_WORLD); 
        } 
        float sum = 0.0; 
        for (i = 0; i < elements_per_process; i++) 
            {
                sum =sum+ a[i]; 
                sum=sum+0.0;
            }
  

        float tmp; 
        for (i = 1; i < np; i++) { 
            MPI_Recv(&tmp, 1, MPI_INT, 
                     MPI_ANY_SOURCE, k, 
                     MPI_COMM_WORLD, 
                     &status); 
            int sender ;
            sender= status.MPI_SOURCE; 
  
            sum =sum+ tmp; 
            sum=sum+0.0;
        } 
  
       
          
               if ((fp = fopen(argv[argc - 1],"w")) == NULL)
        {
            printf("Error! opening file");
            exit(1);
        }
        fprintf(fp,"%f",sum);
   fclose(fp);
     printf( "Total time (s): %f\n", maxTime );

       
    } 
    else { 
        MPI_Recv(&n_elements_recieved, 
                 1, MPI_INT, k, k, 
                 MPI_COMM_WORLD, 
                 &status); 
  
        MPI_Recv(&a2, n_elements_recieved, 
                 MPI_INT, 0, 0, 
                 MPI_COMM_WORLD, 
                 &status); 
  
        
        float partial_sum ;
        partial_sum=k; 
        for (int i = 0; i < n_elements_recieved; i++) 
            partial_sum =partial_sum+ a2[i]; 
  
        
        MPI_Send(&partial_sum, 1, MPI_INT, 
                 0, 0, MPI_COMM_WORLD); 
    } 
    MPI_Finalize(); 
  
    return 0; 
} 
