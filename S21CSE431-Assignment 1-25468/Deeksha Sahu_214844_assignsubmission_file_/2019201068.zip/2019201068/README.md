1. sum of the reciprocals of the squares of integers converges to
π 2
6 .
	I used sum of the reciprocals of the squares of integers in parellal with time comelexity o(n).
2. Parallel Quick Sort
	Each process is given a section of the sequence of data to be sorted. This is done generally by performing a scatter operaertion by master process but I made my own logic for scattering the data.
	This reduces the time complexity to O((n/p)(log(n/p)))
	Each process works on its subsequence individually using the quicksort algorithm and sends it's sorted subsequence for merge.
	The major advantage of this technique is that communication time is kept low by sending only a subsequence to each process. But this is not an optimized solution.
	Load balancing is not achieved since a particular process may finish its sorting process and wait for merge operation while other processes are still sorting their subsequences. This leads to idle process time and is not efficient.
	With the tree based merge, each process sends its sorted subsequence to its neighbor and a merge operation is performed at each step. This reduces the time complexity to O((log p)(n1+n2)) = O((log p)(n))
	So, Total time complexity will be O((n/p)(log(n/p))) + O((log p)(n))


