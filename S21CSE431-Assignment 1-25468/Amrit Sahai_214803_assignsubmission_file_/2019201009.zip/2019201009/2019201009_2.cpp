#include <time.h>
#include <bits/stdc++.h>
#include <mpi.h>
#define ld long double
using namespace std;



int merge(int *a,int *b,int n1,int n2,int *&arr)
{
	int i=0,j=0,k=0;
	int f=0;
	int x=0,y=0;
	while(f==0)
	{
		if(i<n1 || j <n2)
		{	
			if(i>=n1)
			{
				arr[k]=b[j];
				k=k+1;
				j=j+1;
			}
			else if(j>=n2)
			{
				arr[k]=a[i];
				k=k+1;
				i=i+1;
			}
			else if(a[i]>b[j])
			{
				arr[k]=b[j];
				k=k+1;
				j=j+1;	
			}
			else
			{
				arr[k]=a[i];
				k=k+1;
				i=i+1;
			}
		}
		else
			break;
	}
}
int piviot(int *&q,int l,int h)
{
	int p=q[h-1];
	int temp=0;
	ld h_1=p;
	int i=l-1;
	
	int j=l;
	while(j<h)
	{
		if(q[j]<p)
		{
			i++;
			swap(q[i],q[j]);
		}
		j++;
	}
	//swap(q[i+1],q[h-1]);
	//int temp;
	temp=q[i+1];
	q[i+1]=q[h-1];
	q[h-1]=temp;

	return i+1;
}
void quick(int *&q,int l,int h)
{	
	if(l<h)
	{
		int p=piviot(q,l,h);
		quick(q,l,p);
		quick(q,p+1,h);
	}
}
int create_val(int n,int size,int &current_val)
{
	int x=n%size;
	 current_val=n;

	 return x;
}
int main(int argc, char* argv[])
{
	#ifndef ONLINE_JUDGE
	freopen(argv[1],"r",stdin);
	//freopen(argv[2],"w",stdout);
	fstream obj;
	obj.open(argv[2],ios::out);
	#endif
	int n;
	cin>>n;
	//cout<<n<<endl;
	int *arr,*ch_val,*curr_cont;
	MPI_Init(&argc, &argv);
	int fin_val=n;
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	double tbeg = MPI_Wtime();
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);	
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	int current_val=n,act=0;
	curr_cont = new int[size+1];

	if(rank==0)
	{
		int x=create_val(n,size,current_val);
		if(x<=0)
		{
			arr=new int[n];
		}
		else if(x>0)
		{
			arr=new int[n+(size-x)];
			int i=n;
			while(i<n+size-x)
			{
				arr[i]=INT_MAX;
				i++;
			}
			current_val=n+size-x;
		}

		current_val=current_val/size;
		int temp_f=size-x;
		if(temp_f>current_val && x!=0)
		{
			int i=0;
			while(i<size-2)
			{
				curr_cont[i]=current_val;
				i++;
			}
			int temp_t=current_val*(size-2);
			int te=n-temp_t;
			curr_cont[size-2]=te;
			curr_cont[size]=1;
			curr_cont[size-1]=0;
		}
		else
		{
			int i=0;
			while(i<size-1)
			{
				curr_cont[i]=current_val;
				i++;
			}
			int temp_t=current_val*(size-1);
			int te=n-temp_t;
			curr_cont[size-1]=te;
			curr_cont[size]=0;

		}
		
		int i=0;
		while(i<n)
		{

			cin>>arr[i];
			//cout<<arr[i]<<" ";
			i++;
		}
		
		//cout<<endl;

	}
	MPI_Bcast(curr_cont,size+1,MPI_INT,0,MPI_COMM_WORLD);
	int temp_fi=0;
	temp_fi=curr_cont[0];
	current_val=curr_cont[0];
	if(curr_cont[size]!=1)
	{
		ch_val= new int[current_val];
		int actual_temp=current_val;
		MPI_Barrier(MPI_COMM_WORLD);
		actual_temp*=2;
		MPI_Scatter(arr,current_val, MPI_INT,ch_val,current_val, MPI_INT, 0, MPI_COMM_WORLD);
		int temp=current_val;
		act=current_val;
		temp+=1;
		int quiz=rank+1;
		if((quiz)!=size)
			quick(ch_val,0,curr_cont[rank]);
		else
		{
			quick(ch_val,0,curr_cont[rank]);
			act=curr_cont[rank];

		}
		int i=1;

		while(i<size)
		{
			int itr=2*i;
			int flag=1;
			if(rank % itr ==0)
			{
				int itr_t=i;
			}
			else
			{
				MPI_Send(ch_val,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				flag=0;
			}
			if(flag==0)
				break;

			int temp_fin=rank+i;
			int sub_script=0;
			if(temp_fin <size)
			{
				if((current_val*(rank+2*i)) <=n)
				{
					 sub_script=current_val * i;
				}
				else
					sub_script=n-current_val*(rank+i);

				int *nn= new int[sub_script];
				int *nn_t=new int[sub_script];
				arr=NULL;
				MPI_Recv(nn,sub_script,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				nn_t=nn;
				//arr=NULL;
				int num=act+sub_script;
				arr=new int[num];
				
				merge(ch_val,nn,act,sub_script,arr);
				act=act+sub_script;
				ch_val=arr;

				

			}
			i=itr;

		}


	}
	else
	{
		ch_val= new int[current_val];
		act=curr_cont[0];
		int temp_actual=0;
		temp_actual+=current_val;
		MPI_Scatter(arr,current_val, MPI_INT,ch_val,current_val, MPI_INT, 0, MPI_COMM_WORLD);
		n=current_val*(size-1);
		quick(ch_val,0,curr_cont[rank]);
		temp_actual-=1;
		size=size-1;
		int i=1;

		while(i<size)
		{
			int itr=2*i;
			int flag=1;
			if(rank % itr ==0)
			{
				int itr_t=i;
			}
			else
			{
				MPI_Send(ch_val,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				flag=0;
			}
			if(flag==0)
				break;

			int temp_fin=rank+i;
			int sub_script=0;
			if(temp_fin <size)
			{
				if((current_val*(rank+2*i)) <=n)
				{
					 sub_script=current_val * i;
				}
				else
					sub_script=n-current_val*(rank+i);

				int *nn= new int[sub_script];
				int *nn_t=new int[sub_script];
				arr=NULL;
				MPI_Recv(nn,sub_script,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				nn_t=nn;
				//arr=NULL;
				int num=act+sub_script;
				arr=new int[num];
				nn_t=NULL;
				merge(ch_val,nn,act,sub_script,arr);
				act=act+sub_script;
				ch_val=arr;

				

			}
			i=itr;

		}
	}
	double maxTime;
	MPI_Barrier(MPI_COMM_WORLD);
	double elapsedTime = MPI_Wtime() - tbeg;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if(rank==0)
	{
		int i=0;
		while(i<fin_val)
		{
			obj<<arr[i]<<" ";
			i++;
		}

		
		obj<<endl;

		 cout<<"TOTAL time"<<" "<<maxTime<<endl;	
	}
	MPI_Finalize(); 
	return 0;


	

}
