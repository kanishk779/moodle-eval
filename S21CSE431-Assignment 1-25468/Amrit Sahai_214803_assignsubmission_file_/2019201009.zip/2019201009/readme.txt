Q1) By increasing number of process execution time decreases.


Q2) By increasing number of process execution time decreases.
