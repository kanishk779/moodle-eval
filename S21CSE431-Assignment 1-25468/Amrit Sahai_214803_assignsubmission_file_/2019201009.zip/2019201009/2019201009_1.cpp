#include <time.h>
#include <bits/stdc++.h>
#include <mpi.h>
#define ld long double
using namespace std;


void fun(ld &d,ld &s,int n)
{
	for(int i=1;i<=n;i++)
	{
		d=i*i;
		s=s+1/d;
	}
}

void calc_limit(int x,int n,int &l)
{
	if(l + (x-1) >n)
		l=n;

	else
		l=l+(x-1);

}
ld calc_resout(int li,int a)
{
	ld d=0,s=0;
	for(int i=a;i<=li;i++)
	{
		d=i*i;
		s=s+(1.0/d);
	}
	return s;
}
int main( int argc, char **argv ) 
{
	freopen(argv[1],"r",stdin);
	//freopen(argv[2],"w",stdout);
	fstream obj;
	obj.open(argv[2],ios::out);
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Barrier( MPI_COMM_WORLD );
    double curr_time = MPI_Wtime();
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    
   if(rank==0)
   {
   		ld s=0;
   		int a,b,c,n,i,j,p,x;

   		cin>>n;
   		p=numprocs-1;
   		ld d=0;
   		if(p==0)
   		{
   			fun(d,s,n);
   		}
   		else
   		{
   			j=1;
   			d=n+p-1;
   			x=(n+p-1)/p;
   			i=1;
   			while(i<=n || j<=p)
   			{
   				int flag=0;
   				int temp_a=0;
   				if(n<i && j<=p)
   				{
   					a=0;
   					temp_a+=a;
   					MPI_Send(&a,1,MPI_INT,j,0,MPI_COMM_WORLD);
                	MPI_Send(&a,1,MPI_INT,j,0,MPI_COMM_WORLD);
                	flag=1;
   				}
   				if(flag==1)
   				{
   					j=j+1;
   					continue;
   				}
   				int l=i;
   				calc_limit(x,n,l);
   				MPI_Send(&i,1,MPI_INT,j,0,MPI_COMM_WORLD);
                MPI_Send(&l,1,MPI_INT,j,0,MPI_COMM_WORLD);
				j=j+1;

				i=i+x;   			
   			}

   			j=1;
   			i=1;
   			while(i<=n && j<=p)
   			{
   				MPI_Recv(&d, 1, MPI_LONG_DOUBLE, j, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
   				j=j+1;
   				s=s+d;
   				i=i+x;

   			}

   		}
   		obj<< fixed << setprecision( 6 )<<s;
   }

   else
   {
   		ld s=0;
   		int a,b,c,n,i,j,p,z,li;
   		ld x=s;
   		ld y=x+s;
   	    x=x/y;
   		MPI_Recv(&a, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
   		x=x/y;
        MPI_Recv(&li, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
   		z=a;
   		ld d=0;
        if(z!=0)
        {
            
            s=calc_resout(li,a);
        	MPI_Send(&s, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
        }
        else
        {
        	s=0;
            MPI_Send(&s, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
        	
        }


   }
    double Total_Time;
    MPI_Barrier( MPI_COMM_WORLD );
    double elap_time = MPI_Wtime() - curr_time;
    //double Total_Time;
    MPI_Reduce( &elap_time, &Total_Time, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    
    if ( rank == 0 ) 
    {
        
        cout<<"TOTAL time"<<" "<<Total_Time<<endl;
    }

    
    MPI_Finalize();
    return 0;
}