/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;




void qs(int * val2, int start,int n)
{
  if(n<=1)
    return;
  int d1=val2[start+ n/2];
  // swap(val2,start,start+ n/2);
  swap(val2[start],val2[start+ n/2]);
  int s1=start;
  
  for(int i=start+1; i<start+n; i++)
    if(val2[i] < d1)
      swap(val2[i],val2[++s1]);
  // swap(val2,start,s1);
  swap(val2[start],val2[s1]);  
  qs(val2,start,s1-start);
  qs(val2,s1+1,start+n-s1-1);
}
typedef long long int ll;


int * join(int * v1, int x, int * v2, int y)
{
  
  int t=x+y;
  int i,j;
  int * r = (int *)malloc((t) * sizeof(int));
  i=j=0;
  for (int k = 0; k <t; k++) 
  {
    if (i >= x) 
      r[k] = v2[j++];
    else if (j >= y) 
      r[k] = v1[i++];  
    else if (v1[i] < v2[j]) 
      r[k] = v1[i++];
    else 
      r[k] = v2[j++];
  }
  return r;
}






int main( int argc, char **argv ) {
    int rank, p,w, w1;
    MPI_Status status;
    fstream file,f; 
    string ip=argv[1];
    string op=argv[2];

    file.open(ip.c_str()); 
    string word;
    file >> word;
    stringstream geek(word); 
    int n = 0;
    geek >> n; 

    // int n=0; 
    // f.open(ip.c_str()); 
    // fscanf(f, "%d", &n);
   	int * val;
   	int * val1;
   	int * val3;
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &p );
    
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int chunk = ceil(float(n)/float(p));
    MPI_Bcast(&chunk, 1, MPI_INT, 0, MPI_COMM_WORLD);
    // cout<<"::"<<chunk<<endl;
    int v_size=p*chunk;

    // vector<int>val(v_size,0);
    val = (int *)malloc(v_size * sizeof(int));
    for(int i=0;i<n;i++)
    {
    	string word;
    	file >> word;
    	stringstream geek(word); 
    // fclose(file.c_str());
    	int n23 = 0;
    	geek >> n23; 
    	val[i]=n23;

    }
    // fclose(f.c_str());

    // if(rank==0){
    // for(int i=0;i<v_size;i++)
    // 	cout<<val[i]<<" ";}
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    w= chunk;
    if(n< chunk*(rank+1))
    	w= n- (chunk* rank);
    // w = (n >= chunk * (rank+1)) ? chunk : n - chunk * rank;
    // std::vector<int> val1(chunk,0);
    val1 = (int *)malloc(chunk * sizeof(int));
    int chech=0;
    bool f1=0;
    MPI_Scatter(val, chunk, MPI_INT, val1, chunk, MPI_INT, 0, MPI_COMM_WORLD);

    // cout<<rank<<endl;
    // for(int i=0;i<chunk;i++)
    // 	cout<<val1[i]<<" ";
    // cout<<endl;
    f1=true;
    free(val); val=NULL;
   	qs(val1,0,w);

    // cout<<"JJJJ";
    // cout<<"d;"<<w<<endl;
    // cout<<"c:"<<chunk<<"   r:"<<rank<<endl;
    // cout<<"Ss"<<w<<endl;
    for(int i=1;i<p;i=2*i)
    {
    	int copy=i;
    	if(rank %(2*i) !=0)
    		MPI_Send(val1, w, MPI_INT, rank-i, 0, MPI_COMM_WORLD);
    	copy+=1;
    	if(rank %(2*i) !=0){
    	break;}

    	if(rank + i < p)
    	{
    		int w11=0;
    		w11= n -chunk * (rank+i);
    		if(n>= chunk*(rank+2*i));
    			w11=chunk*i;
    		w1= (n >= chunk * (rank+2*i)) ? chunk * i : n - chunk * (rank+i);
    		// cout<<"o:"<<w1<<" "<<w<<endl;
    		f1=false;
    		val3 = (int *)malloc(w1 * sizeof(int));
    		int w2=0;
    		MPI_Recv(val3, w1, MPI_INT, rank+i, 0, MPI_COMM_WORLD, &status);
    		w2=w1;
    		val=join(val1,w,val3,w1);
    		free(val1);
    		f1=true;
    		free(val3);
    		val1=val;
    		// cout<<"val:"<<w<<"<><>"<<w1<<endl;
    		w+=w1;
    	}
    	// cout<<w<<endl;/
    }
    // cout<<"kkk"<<w<<endl;
    // cout<<"fgfg"<<endl;

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
//     float s1=0;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
//     MPI_Reduce( &s, &s1, 1, MPI_FLOAT, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {

    	// cout<<"fgggf"<<w<<endl;
    	// for (int i = 0; i < n; ++i)
    	// {
    	// 	cout<<i<<" ";
    	// }
    	// cout<<endl;
    	FILE * wr = fopen(op.c_str(), "w");
    	for (int i = 0; i < n; ++i)
    	{
    		fprintf(wr, "%d ", val1[i]);
    		// cout<<val1[i]<<" ";
    	}
    	// cout<<endl;
    	printf( "Total time (s): %f\n", maxTime);
    }


    /* shut down MPI */
    MPI_Finalize();
    return 0;

}