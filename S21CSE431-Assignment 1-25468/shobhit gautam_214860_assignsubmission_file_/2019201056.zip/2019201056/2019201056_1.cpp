/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, p;
    // int n;
    fstream file; 
    string ip=argv[1];
    string op=argv[2];
    // cout<<ip<<" "<<op<<endl;
    file.open(ip.c_str()); 
    string word;
    file >> word;
    stringstream geek(word); 
    int n = 0; 
    geek >> n; 
  
    // cout<<"f";
    // cout<<word;
    // cin>>n;
//     int a[n+2];
//     for(int i=1;i<=n;i++)
//         a[i]=i*i;
    double s=0,s1=0;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &p );
    
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&s, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
//     cout<<n<<" "<<rank<<endl;
    int x=n/p;
    /* write your code here */
//     cout<<numprocs;
//     int x=n/p;
//     float s1=0;
//     cout<<p<<endl;
//     cout<<rank<<","<<x<<endl;
    int y=rank*x+1;
    int z=(rank*x)+x;
    if(rank==p-1)
        z=n;
    for(int i=y;i<=z;i++)
    {
        s+=(1/float(i*i)); 
//         cout<<i*i<<"______ "<<float(1)/float(i*i)<<endl;
    }
//     MPI_Bcast(&s, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
//         sum1+=(1/(i*i));
//     cout<<s<<endl;
    
    MPI_Reduce( &s, &s1, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD );
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
//     float s1=0;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
//     MPI_Reduce( &s, &s1, 1, MPI_FLOAT, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
//         cout<<s1<<endl;
         // printf( "%0.6f\n", s1);
         fstream my_file;
        my_file.open(argv[2], ios::out);
        my_file << to_string(s1);
        my_file.close();
        printf( "Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
} 
