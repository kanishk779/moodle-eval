/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

double give(int l, int r){
    double ans = 0.0;
    for(int i=l;i <= r;i++){
        double mul = i*i;
        ans += 1.0/mul;
    }
    return ans;
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    if(argc != 3){
        cout<<"Wrong usage of this program\n";
        
        MPI_Barrier(MPI_COMM_WORLD);
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        if(rank == 0){
            printf("Total time (s): %f\n", maxTime);
        }
        /* shut down MPI */
        MPI_Finalize();
        return 0;
    }
        
    char * input_file = argv[1];
    char * output_file = argv[2];
    fstream new_out, new_in;
    new_in.open(input_file, ios::in);
    new_out.open(output_file, ios::out);
    
    streambuf * stream_cout = cout.rdbuf();
    streambuf * stream_cin = cin.rdbuf();

    streambuf * new_out_buf = new_out.rdbuf();
    streambuf * new_in_buf = new_in.rdbuf();

    cout.rdbuf(new_out_buf);
    cin.rdbuf(new_in_buf);
    /* write your code here */
    if(rank == 0){
        // root process
        int n;
        cin>>n;
        // divide equally among all the processes
        int div = n / numprocs;
        int rem = n % numprocs;
        // root will compute for [1 .... div ... div + rem]
        double ans = give(1, div+rem);
        // we can send information to the remaining process to calculate the value
        int start = div + rem + 1;
        for(int i=1; i<numprocs; i++){
            int arg[2];
            arg[0] = start;
            arg[1] = start + div - 1;
            MPI_Send(&arg, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
            start += div;
        }
        // Receive the calculated values from other processes
        for(int i=1; i<numprocs; i++){
            double temp;
            MPI_Recv(&temp, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ans += temp;
        }
        // Output the value
        cout<< fixed << setprecision(6) << ans <<"\n";
    }
    else{
        int receive[2];
        // receive the range for which we need to compute the function 
        MPI_Recv(receive, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double ans = give(receive[0], receive[1]);
        // Send the received answer back to the root
        MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }

    cout.rdbuf(stream_cout);
    cin.rdbuf(stream_cin);
    new_out.close();
    new_in.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}