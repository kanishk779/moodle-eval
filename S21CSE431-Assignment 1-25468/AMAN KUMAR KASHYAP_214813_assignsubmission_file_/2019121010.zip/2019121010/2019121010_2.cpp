/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int LL;
// random number generator
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const int M = 1e6;
int arr[M];
void swap(int *xp, int *yp)  
{  
    int temp = *xp;  
    *xp = *yp;  
    *yp = temp;  
}  
int partition(int * arr, int l, int r){
	int pivot = arr[r];
	int j = l;
	for(int i=l;i<r;i++){
		if(arr[i] <= pivot){
			swap(arr+i, arr+j);
			j++;
		}
	}
	swap(arr+r, arr+j);
	return j;
}
int random_partition(int *arr, int l, int r){
	int diff = r - l  + 1;
	int rand_num = rng() % diff;
	rand_num += l;
	swap(arr+rand_num, arr+r);
	return partition(arr, l, r);
}
void qsort(int *arr, int l, int r){
	if(l < r){
		int p = random_partition(arr, l, r);
		qsort(arr, l, p-1);
		qsort(arr, p+1, r);
	}
}

map<int, pair<int,int> > ranges;
void recurse(int start_process, int end_process, int l, int r){
    if(l > r || start_process > end_process)
        return ;
    if(start_process == end_process){
        ranges[start_process] = make_pair(l, r);
        return ;
    }
    int mid = start_process + (end_process - start_process)/2;
    int p = random_partition(arr, l, r);
    recurse(start_process, mid, l, p);
    recurse(mid+1,end_process, p+1,r);
}
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    
    if(argc != 3){
        cout<<"Wrong usage of this program\n";
        
        MPI_Barrier(MPI_COMM_WORLD);
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        if(rank == 0){
            printf("Total time (s): %f\n", maxTime);
        }
        /* shut down MPI */
        MPI_Finalize();
        return 0;
    }
        
    char * input_file = argv[1];
    char * output_file = argv[2];
    fstream new_out, new_in;
    new_in.open(input_file, ios::in);
    new_out.open(output_file, ios::out);
    
    streambuf * stream_cout = cout.rdbuf();
    streambuf * stream_cin = cin.rdbuf();

    streambuf * new_out_buf = new_out.rdbuf();
    streambuf * new_in_buf = new_in.rdbuf();

    cout.rdbuf(new_out_buf);
    cin.rdbuf(new_in_buf);

    /* write your code here */
    if(rank == 0){
        int n;
        cin>>n;
        for(int i=0; i<n; i++){
            cin >> arr[i];
        }
        // divide equally among all the processes
        recurse(0, numprocs-1, 0, n-1);
        // stores the final sorted array
        vector<int> res;
        // sort the data which is supposed to be sorted by root
        if(ranges.find(0) != ranges.end()){
            qsort(arr, ranges[0].first, ranges[0].second);
            for(int i=ranges[0].first; i <= ranges[0].second; i++)
            res.push_back(arr[i]);
        }
        // send data to other processes
        for(int i=1; i<numprocs; i++){
            if(ranges.find(i) != ranges.end()){
                int elements = ranges[i].second - ranges[i].first + 1;
                MPI_Send(arr + ranges[i].first, elements, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
            else{
                MPI_Send(arr, 0, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
        }
        // receive relevant portions from each of the processes
        
        int size;
        MPI_Status info;
        for(int i=1; i<numprocs; i++){
            MPI_Probe(i, 0, MPI_COMM_WORLD, &info);
            MPI_Get_count(&info, MPI_INT, &size);
            if(size > 0){
                int *ptr = new int[size];
                MPI_Recv(ptr, size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                for(int j=0; j<size; j++)
                    res.push_back(ptr[j]);
                delete[] ptr;
            }
            else{
                int *ptr;
                MPI_Recv(ptr, 0, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
        int prev = 0;
        for(auto it : res){
            cout<<it<<" ";
            assert(prev <= it);
            prev = it;
        }
        cout<<"\n";
    }
    else{
        MPI_Status info;
        MPI_Probe(0, 0, MPI_COMM_WORLD, &info);
        int size;
        MPI_Get_count(&info, MPI_INT, &size);
        if(size > 0){
            int *ptr = new int[size];
            MPI_Recv(ptr, size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            qsort(ptr, 0, size-1);
            MPI_Send(ptr, size, MPI_INT, 0, 0, MPI_COMM_WORLD);
            delete[] ptr;
        }
        else{
            int *ptr;
            MPI_Recv(ptr, 0, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Send(ptr, 0, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }
    cout.rdbuf(stream_cout);
    cin.rdbuf(stream_cin);
    new_out.close();
    new_in.close();
    
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
