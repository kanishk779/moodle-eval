# MPI_examples
College Assignment

## TASK 1
The program takes a single integer N as input. The sequential program would
simply try to calculate the $1/i^2$ series sum. But in this parallel program
ranges are fixed by the root process and root informs the other processes regarding their respective ranges including itself.
Each process calculates the sum of the assigned range and passes the value to
the root process. The root process uses MPI_Recv() function which is a blocking
function to receive result from each of the process of the computation. Finally
it adds up all the values and prints the final answer.

## TASK 2
The task is to implement parallel quick-sort. There are two ways to do it. One is
to just divide the input array into chunks and send each of the chunk to some
process and receive the sorted version of the array. Finally the root process
merges the individually sorted lists.
Another way which is kind of tougher is to recursively assign processes to
chunks of the input array. We start with all the processes being assigned the
whole array. Than half of the process handle the first half of the array and
rest handles the second half of the array. This goes on until there is just one
process left for a range. In which case that whole range is assigned to that
process. After receiving a chunk of array, the process can used the sequential
sort to sort the chunk of array and send this data back to the root using the
Blocking MPI_Send(). The root on the other hand uses MPI_Recv() to receive data
from each of the other processes. Finally root can print the sorted array.

## TASK 3
The task is to implement edge coloring of a graph using at most 1 + delta color.
Here delta is max(degree in original graph, degree in line graph). We convert
the original graph to the corresponding line graph now the task remains to just
color the **vertices** of the line graph with at most 1 + max(degree) of the
graph. This can be achieved pretty easily as opposed to the previous problem as
that requires use of Misra and Gries algorithm.
Once we obtain the line graph the root process assigns random weights to each
of the vertices. The weights array is broadcast by root, so that every other
process gets the same random weights information. Now the vertices are divided
equally between all the processes. Each process now finds a set of vertices
which are **locally maximal** according to the weights assigned. If two vertices
have the same weight, we can use the vertex number to break the tie. All the
processor now parallelly can find the set of vertices which are locally maximal.
Each process other than root than colors these vertices according to the minimum
color which is not present at the neighbours. Than it sends the newly colored
vertices and their colors to the root process. Root process than updates it
colors array by taking information from all the other processes and also it own
set of vertices. Finally the array of colors is broadcast to all the other
process so that they know which other vertices are colored which are assigned to
different processes. This continues till all the vertices are colored.
In each iteration at least one vertex will get colored hence the upper bound of
number of iterations is the number of vertices in the graph. Finally the root
process prints the assigned color to the **vertices** of the line graph i.e the
edges of the original graph.
