/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int n,m;
vector<vector<int>> g;
vector<vector<int>> new_g;
int *colors;
int *weights;
int MAX_C = 0;
const int range = 1e6;
vector<pair<int,int>> edges;
map<pair<int,int>, int> edge_num;
int MAX_LOOP = 0;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
void send_start(int to){
    char *buffer = new char[5];
    strcpy(buffer, "start");
    MPI_Send(buffer, 5, MPI_CHAR, to, 0, MPI_COMM_WORLD);
    delete[] buffer;
}
void send_stop(int to){
    char *buffer = new char[4];
    strcpy(buffer, "stop");
    MPI_Send(buffer, 4, MPI_CHAR, to, 0, MPI_COMM_WORLD);
    delete[] buffer;
}
void show_output(){
    int color_used = 0;
    for(int i=0; i<m; i++)
    color_used = max(color_used, colors[i]);
    cout<<color_used<<"\n";
    for(int i=0; i<m; i++){
        cout<<colors[i]<<" ";
    }
}
int main(int argc, char ** argv){
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    /* write your code here */

    if(argc != 3){
        cout<<"Wrong usage of this program\n";
        
        MPI_Barrier(MPI_COMM_WORLD);
        double elapsedTime = MPI_Wtime() - tbeg;
        double maxTime;
        MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        if(rank == 0){
            printf("Total time (s): %f\n", maxTime);
        }
        /* shut down MPI */
        MPI_Finalize();
        return 0;
    }
        
    char * input_file = argv[1];
    char * output_file = argv[2];
    fstream new_out, new_in;
    new_in.open(input_file, ios::in);
    new_out.open(output_file, ios::out);
    
    streambuf * stream_cout = cout.rdbuf();
    streambuf * stream_cin = cin.rdbuf();

    streambuf * new_out_buf = new_out.rdbuf();
    streambuf * new_in_buf = new_in.rdbuf();

    cout.rdbuf(new_out_buf);
    cin.rdbuf(new_in_buf);

    cin>>n>>m; // we assume that number of edges > 0
    int u,v;
    g.resize(n);
    for(int i=0;i<m;i++){
        cin>>u>>v;
        u--;v--;
        g[u].push_back(v);
        g[v].push_back(u);
        if(u < v){
            edges.push_back(make_pair(u, v));
            edge_num[{u, v}] = i;
        }
        else{
            edges.push_back(make_pair(v, u));
            edge_num[{v, u}] = i;
        }
    }
    
    new_g.resize(m); // new graph may be disconnected, but that does'nt affect the algo
    for(int i=0;i<m;i++){
        int u = edges[i].first;
        int v = edges[i].second;
        set<int> adj;
        for(auto it : g[u]){
            int vert;
            if(it < u)
            vert = edge_num[{it, u}];
            else
            vert = edge_num[{u, it}];
            if(vert != i){
                adj.insert(vert);
            }
        }
        for(auto it : g[v]){
            int vert;
            if(it < v)
            vert = edge_num[{it, v}];
            else
            vert = edge_num[{v, it}];
            if(vert != i){
                adj.insert(vert);
            }
        }
        for(auto it : adj){
            new_g[i].push_back(it);
        }
    }
    // used for assertion
    for(int i=0;i<m;i++){
        MAX_C = max(MAX_C,(int) new_g[i].size());
    }
    MAX_C++;
    MAX_LOOP = m;
    // do not assign random weights on each processor as it will lead to 
    // different weights in each processor's local view
    weights = new int[m];
    colors = new int[m];
    for(int i=0; i<m; i++){
        colors[i] = 0;
    }
    // colors given will be in the range [1, MAX_C]
    if(rank == 0){
        // root process
        for(int i=0;i<m;i++){
            int w = rng() % range;
            weights[i] = w;
        }
        // Broadcast the weights array to all the process
        MPI_Bcast(weights, m, MPI_INT, 0, MPI_COMM_WORLD);
        int div = m / numprocs;
        int rem = m % numprocs;
        vector<int> offsets(numprocs);
        int curr = 0;
        for(int i=0;i<numprocs;i++){
            if(rem){
                curr += div+1;
                offsets[i] = curr - 1;
                rem--;
            }
            else{
                curr += div;
                offsets[i] = curr - 1;
            }
        }
        vector<pair<int,int>> ranges; // keep the ranges of vertices for each process;
        // send ranges of vertices to other processes
        int st = offsets[0]+1;
        
        for(int i=1; i<numprocs; i++){
            int * ptr = new int[2];
            ptr[0] = st; // start
            ptr[1] = offsets[i]; // end
            int elements = ptr[1] - ptr[0] + 1;
            if(elements > 0)
                MPI_Send(ptr, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
            else
                MPI_Send(ptr, 0, MPI_INT, i, 0, MPI_COMM_WORLD);
            st = offsets[i] + 1;
            delete[] ptr;
        }
        int vertices_colored = 0;
        set<int> remaining;
        for(int i=0;i<=offsets[0];i++){
            remaining.insert(i);
        }
        for(int k=0;k<MAX_LOOP;k++){
            int new_vertices_colored = 0;
            // root process will do some processing and parallely others will also do
            set<int> colored;
            for(auto it : remaining){
                bool is_max = true;
                set<int> neigh_color;
                for(auto v : new_g[it]){
                    if(!colors[v]){
                        if(weights[it] == weights[v]){
                            if(v > it)
                            is_max = false;
                        }
                        else{
                            if(weights[v] > weights[it])
                            is_max = false;
                        }
                    }
                    else{
                        neigh_color.insert(colors[v]);
                    }
                }
                if(is_max){
                    colored.insert(it);
                    for(int c=1; c <= MAX_C; c++){
                        if(neigh_color.find(c) == neigh_color.end()){
                            colors[it] = c;
                            break;
                        }
                    }
                }
            }
            for(auto it : colored){
                remaining.erase(it); // remove the remaining colors
                new_vertices_colored++;
            }
            // collect results from every other process
            // update the colors array (which holds color for each vertex)
            int size;
            MPI_Status info;
            for(int i=1; i<numprocs; i++){
                MPI_Probe(i, 0, MPI_COMM_WORLD, &info);
                MPI_Get_count(&info, MPI_INT, &size);
                new_vertices_colored += (size/2);
                if(size > 0){
                    int * arr = new int[size];
                    MPI_Recv(arr, size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    for(int i=0;i < size; i+= 2){
                        colors[arr[i]] = arr[i+1];
                    }
                    delete[] arr;
                }
                else{
                    int * faltu = new int[1];
                    MPI_Recv(faltu, 0, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    delete[] faltu;
                }
            }
            vertices_colored += new_vertices_colored; // update number of colored vertices
            // broadcast the updated array to every process
            MPI_Bcast(colors, m, MPI_INT, 0, MPI_COMM_WORLD);    
        }
        for(int i=0; i<m; i++){
            assert(colors[i] <= MAX_C);
            for (auto it : new_g[i]){
                assert(colors[i] != colors[it]);
            }
        }
        // now each vertex has a color, convert to corresponding original graph and mention edge colors
        show_output();
    }
    else{
        MPI_Bcast(weights, m, MPI_INT, 0, MPI_COMM_WORLD); // weights received;
        // get the size of the chunk of vertices that this process receives from root
        MPI_Status info;
        MPI_Probe(0, 0, MPI_COMM_WORLD, &info);
        int size;
        MPI_Get_count(&info, MPI_INT, &size);
        set<int> remaining;
        
        int *ptr;
        if(size)
            ptr = new int[size];
        // chunk of vertices allocated to this process received
        MPI_Recv(ptr, size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if(size){
            for(int i=ptr[0]; i<= ptr[1]; i++)
            remaining.insert(i);
            delete[] ptr;
        }
        for(int k=0;k<MAX_LOOP;k++){
            // Do some processing
            set<int> colored;
            for(auto it : remaining){
                bool is_max = true;
                set<int> neigh_color;
                for(auto v : new_g[it]){
                    if(!colors[v]){
                        if(weights[it] == weights[v]){
                            if(v > it)
                            is_max = false;
                        }
                        else{
                            if(weights[v] > weights[it])
                            is_max = false;
                        }
                    }
                    else{
                        neigh_color.insert(colors[v]);
                    }
                }
                if(is_max){
                    colored.insert(it);
                    for(int c=1; c <= MAX_C; c++){
                        if(neigh_color.find(c) == neigh_color.end()){
                            colors[it] = c;
                            break;
                        }
                    }
                }
            }
            // send the newly colored vertices in the fashion (vertex, color, vertex, color, ..... so on)
            int num_colored = colored.size();
            if(num_colored){
                int * color_info = new int[2*num_colored];
                int i=0;
                for(auto it : colored){
                    remaining.erase(it);// erase the vertices which are colored
                    color_info[i] = it;
                    color_info[i+1] = colors[it];
                    i += 2;
                }
                MPI_Send(color_info, 2*num_colored, MPI_INT, 0, 0, MPI_COMM_WORLD);
                delete[] color_info;
            }
            else{
                // nothing was colored
                int * faltu = new int[1];
                MPI_Send(faltu, 0, MPI_INT, 0, 0, MPI_COMM_WORLD);
                delete[] faltu;
            }
            // receive the new color information from root
            MPI_Bcast(colors, m, MPI_INT, 0, MPI_COMM_WORLD); // this receives the broadcast msg from root
        }
    }
    // free the memory
    delete[] weights;
    delete[] colors;
    
    cout.rdbuf(stream_cout);
    cin.rdbuf(stream_cin);
    new_out.close();
    new_in.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}