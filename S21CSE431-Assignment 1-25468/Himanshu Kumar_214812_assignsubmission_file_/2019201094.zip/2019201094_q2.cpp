

#include <stdio.h>

#include <time.h>
#include <stdlib.h>
#include <mpi.h>
#include <bits/stdc++.h>

using namespace std;

double startTime;


void sp(int * arr, int l, int h)
{
  int temp = arr[l];
  arr[l] = arr[h];
  arr[h] = temp;
}


int * merge(int * arr1, int sz1, int * arr2, int sz2)
{

  int sz=sz1+sz2;
  int i,j,k;

  int *r;

  r = (int *)malloc((sz) * sizeof(int));
  j=i = 0;


  for (int z = 0; z < sz; z++) {

     if (j >= sz2) 
    {
      r[z] = arr1[i++];

    }
    else if (i >= sz1) 
    {
      r[z] = arr2[j++];

    }

    else if (arr1[i] > arr2[j]) 
    { 
      r[z] = arr1[j++];

    }
    else 
    { 

      r[z] = arr2[i++];
    }
  }
  return r;
}

void qsort(int * arr, int st, int n)
{
  int x, pt, i;


  int hf=n/2;

  if(n>1)
  {

    x = arr[st + hf];
    sp(arr, st, st + hf);

    pt = st;

    i=st+1;

    while(i<st+n)
    {
        if (arr[i] < x) {
        pt++;
        sp(arr, i, pt);
      }

      i++;

    }

    sp(arr, st, pt);


    qsort(arr, st, pt-st);


    qsort(arr, pt+1, st+n-pt-1);



  }




}





int main(int argc, char ** argv)
{


  int n,c,s,o,st,p,id;


  int * data = NULL;
  int * ch;

  int * ot;

  MPI_Status status;
  double elapsed_time;

  int i;
  



  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &p);
  MPI_Comm_rank(MPI_COMM_WORLD, &id);



  if (id == 0) {  
    cin>>n;



    c = (n%p!=0) ? n/p+1 : n/p;



    data = (int *)malloc(p*c * sizeof(int));
    for (i = 0; i < n; i++)
      cin>>data[i];

    cout<<"hello"<<endl;

    int total=p*c;

    for (i = n; i < total; i++)
      data[i] = 0;
  }


  MPI_Barrier(MPI_COMM_WORLD);

  elapsed_time = - MPI_Wtime();


  MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);


  if(n%p!=0)
    c=n/p+1;
  else
    c=n/p;  

 



  ch = (int *)malloc(c * sizeof(int));

  MPI_Scatter(data, c, MPI_INT, ch, c, MPI_INT, 0, MPI_COMM_WORLD);

  free(data);

  data = NULL;



  if(n >= c * (id+1))
    s=c;
  else
    s=n - c * id;
  qsort(ch, 0, s);


  for (st = 1; st < p; st = 2*st) {
    if (id % (2*st) != 0) 
    {


      MPI_Send(ch, s, MPI_INT, id-st, 0, MPI_COMM_WORLD);
      break;
    }

    if(id+st >= p)
      continue;



      if(n >= c * (id+2*st))
        o=c * st;
      else
        o=n - c * (id+st);



      ot = (int *)malloc(o * sizeof(int));
      MPI_Recv(ot, o, MPI_INT, id+st, 0, MPI_COMM_WORLD, &status);

      data = merge(ch, s, ot, o);
      free(ch);
      free(ot);
      ch = data;
      s = s + o;

  }


  elapsed_time += MPI_Wtime();


  if (id == 0) {

    for (i = 0; i < s; i++)
    {
      cout<<ch[i]<<" " ;
    }
    cout<<endl;

  }

  MPI_Finalize();
  return 0;
}











