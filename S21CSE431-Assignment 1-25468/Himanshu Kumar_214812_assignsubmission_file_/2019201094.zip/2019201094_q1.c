// #include <mpi.h>
// #include <stdio.h>

// int main(int argc, char** argv) {
//     // Initialize the MPI environment
//     MPI_Init(NULL, NULL);

//     // Get the number of processes
//     int world_size;
//     MPI_Comm_size(MPI_COMM_WORLD, &world_size);

//     // Get the rank of the process
//     int world_rank;
//     MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

//     // Get the name of the processor
//     char processor_name[MPI_MAX_PROCESSOR_NAME];
//     int name_len;
//     MPI_Get_processor_name(processor_name, &name_len);

//     // Print off a hello world message
//     printf("Hello world from processor %s, rank %d out of %d processors\n",
//            processor_name, world_rank, world_size);

//     // Finalize the MPI environment.
//     MPI_Finalize();
// }

# include <cstdlib>
# include <ctime>
# include <iomanip>
# include <iostream>
# include <mpi.h>
#include <fstream> 
#include <bits/stdc++.h>

using namespace std;
// format : 

// Compiling your program : mpic++ <roll-number>_<problem-number>.cpp
// Executing your program : mpirun -np <number-of-processes> a.out <input-file> <output-file>




// int main(int argc, char **argv)
// {

//     string inputFilePath = argv[1];
//     ifstream fin;
//     string line; 
//     fin.open(inputFilePath); 
//     getline(fin, line);  
//     fin.close();
//     int n = stoi(line);

//     int rank,size;
//     MPI_Status status;




//     MPI_Init(&argc,&argv);
//     MPI_Comm_rank(MPI_COMM_WORLD,&rank);
//     MPI_Comm_size(MPI_COMM_WORLD,&size);
//     double result = 0;
//     int loopSize = 1 + ((n - 1) / size);
//     for(int i=0;i<loopSize;i++)
//     {
//         int num = rank*loopSize + i;
//         num++;
//         if(num>n)
//             break;
//         int square = num*num;
//         double oneUponSquare = double(1)/double(square);
//         result += oneUponSquare;
//     }


//     if(rank!=0)
//     {
//         MPI_Send(&result,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
//     }
//     else
//     {

//         for(int i=1;i<size;i++)
//         {
//             double temp = 0;
//             MPI_Recv(&temp,1,MPI_DOUBLE,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
//             result += temp;
//         }

//         ofstream fout; 
//         fout.open(argv[2]);
//         fout<<setprecision(7)<<result<<endl;
//         fout.close();

//     }

//     MPI_Finalize();
//     return 0;
// }   



int main(int argc, char **argv)
{





    MPI_Status status;




    MPI_Init(&argc,&argv);

    int n = stoi(argv[1]);

    int rk,sz;

    double res  =  0;

    MPI_Comm_rank(MPI_COMM_WORLD,&rk);

    MPI_Comm_size(MPI_COMM_WORLD,&sz);

    int lsz = 1 + ((n - 1) / sz);


    int j=0;


    while(j<lsz)
    {

        int nm = rk*lsz + j;
        nm=nm+1;
        if(nm>n)
            break;
        int sq = nm*nm;
        double revsq = double(1)/double(sq);
        res =res+revsq;

        j++;
    }




    if(rk!=0)
        MPI_Send(&res,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
    else
    {

        j=1;

        while(j<sz)
        {
            double tp = 0;
            MPI_Recv(&tp,1,MPI_DOUBLE,j,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
            res += tp;
            j++;
        }


    }

    if(rk==0)
    cout << fixed << setprecision(6)<<res<<endl;

    MPI_Finalize();
    return 0;
}   