### 2018101065
### Raghav Saboo

### Version Used (MPI 4.1.0)

# Parallel Sum

## Description:

Integers from 1 to N are divided equally to each process in their respectibe code. Each process finds sum of reciprocal of sqaures of integers from this starting to ending point and pass this sum back to root process which is zero. Finally in root process we sum each of the received value and the value computed by it and output it in a file.

## Analysis
**TIME MAY CHANGE ON DIFFERNET MACHINES!**
- For N = 2
    - if np = 1 - Total time (s): 0.000158
    - if np = 11 - Total time (s): 0.000328
- For N = 10000:
    - if np = 1 - Total time (s): 0.000202
    - if np = 11 - Total time (s): 0.000389
- It is obvious that time will increase almost monotically with increase in N as number of operations would increase.
- But the overhead of sending and receiving from processes is more than the time it takes to compute the very simple sum. Hence the time increases on increasing the number of processes.

# Parallel Quick Sort

## Description:

Initially input array is divided into equal continous subarrays with size of each subarray depending upon total number of processes. Subarrays are passed to each process where each process sorts their recieved subarrays parallely using iterative quick sort algorithm. Now after each process sorts its subarray they send back the sorted subarray to root process which is zero. Root process also sorts its own part of the subarray.
After recieving all sorted subarray, root process places them in their respective slots in the original array and after that all of them are merged using `C++ STL Priority Queue`.

## Analysis
**TIME MAY CHANGE ON DIFFERNET MACHINES!**
	- For N = 10 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.000207
		- if np = 11 - Total time (s): 0.001345
	- For N = 1000000 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.520452
		- if np = 11 - Total time (s): 0.694521
	- It is obvious that time will increase almost monotically with increase in N
	- But overhead of sending and receiving a large part of array is more than the very simple quick sort that it has to do.Hence the time increases on increasing the number of processes.

# Parallel Edge Coloring

## Description:

Initially given graph is transformed to its line graph. The line graph of an undirected graph G is another graph L(G) that represents the adjacencies between edges of G. L(G) is constructed in the following way: for each edge in G, make a vertex in L(G); for every two edges in G that have a vertex in common, make an edge between their corresponding vertices in L(G). Now for this line graph our problem is transformed to graph coloring (vertex-coloring). For this a parallel approach has been followed using **Jones-Plassmann** algorithm as explained [here](https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/).

## Analysis
**TIME MAY CHANGE ON DIFFERNET MACHINES!**
    - For N = 1, M = 5 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.000268
        - if np = 11 - Total time (s): 0.008456
    - For N = 100, M = 500 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.005452
        - if np = 11 - Total time (s): 0.014542
    - It is obvious that time will increase almost monotically with increase in N and M.
    - When there are less number of nodes and edges in the graph, the overhead of sending the large adjacency matrix and all the other supporting arrays and values is larger and hence the time increases with the increase in the number of processes.

