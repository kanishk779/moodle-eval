/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef pair<int, int>  ppi; 

#define send_data_tag 2001
#define return_data_tag 2002

vector<int> arr,carr;
vector<int>  output;


int partition(vector<int> &arr, int l, int h) 
{ 
    swap(arr[h],arr[l+((h-l)/2)]);
    int x = arr[h]; 
    int i = (l - 1); 
  
    for (int j = l; j < h; ++j) { 
        if (arr[j] <= x) { 
            swap(arr[++i], arr[j]); 
        } 
    } 
    swap(arr[i + 1], arr[h]); 
    return (i + 1); 
} 
void quickSortIterative(vector<int> &arr, int l, int h) 
{ 
    // int stack[h - l + 1];
    stack<int>s; 
    // int top = -1;
    s.push(l);
    s.push(h);
    while (!s.empty()) { 
        h = s.top();
        s.pop(); 
        l = s.top();
        s.pop();
        int p = partition(arr, l, h); 
        if (p  > l+1) { 
            s.push(l);
            s.push(p-1);
        } 
        if (p  < h -1 ) { 
            s.push(p+1);
            s.push(h);
        } 
    } 
} 
void mergeKArrays() 
{ 
    priority_queue<ppi, vector<ppi>, greater<ppi> > pq; 
    int j=0;
    map<int,int>mp;
    // cout<<arr.size()<<endl;
    for (int i = 1; i < arr.size(); i++){ 
        // cout<<arr[i]<<endl;
        if(arr[i]>=arr[i-1])
        continue;
        else{
        // cout<<"inhere"<<arr[j]<<" "<<j<<endl;
        pq.push({ arr[j], j  });
        mp[j]++;
        j=i;

        }
    }
    // cout<<"sese";
    // cout<<arr[j]<<" "<<j<<endl;

    pq.push({ arr[j], j  });
    mp[j]++;

    while (!pq.empty()) { 
        ppi curr = pq.top(); 
        pq.pop(); 
        int i = curr.second; 
        // int j = curr.second.second; 
        output.push_back(curr.first);
         
        if (mp.find( i + 1) == mp.end() && ((i+1)<arr.size())) 
            pq.push({arr[i+1], i+1}); 
    } 
    // return output; 
} 
int main( int argc, char **argv ) {
    int rank, numprocs;
    int n,sr,er,rows,nrows,sz,rem;
    // ll *arr
    MPI_Status status;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    if(!rank)
    {
        // cout<<argv[1]<<endl;
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n; 
        arr.resize(n);
        for(int i = 0; i < n; i++) {
            input_file >> arr[i];
        } 
        input_file.close();
        // arr = (int*)malloc(n * sizeof(int)); 
        // arr.clear();


    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if(!rank){
        sz=n/numprocs;
        rem=n%numprocs;
        if(rem)
        sz++;
        for(int i=1;i<numprocs;i++){
            sr=(sz*i);
            er=(sr+sz-1);
            if(er>=n)
            er=n-1;
            rows=er-sr+1;
            // MPI_Send(&rows,1,MPI_INT,i,send_data_tag,MPI_COMM_WORLD);
            if(sr<=er)
            MPI_Send(&arr[sr],rows,MPI_INT,i,send_data_tag,MPI_COMM_WORLD);

        }
        quickSortIterative(arr, 0,sz-1);

    if(numprocs>1){
        carr.resize(sz);
        // for(int i=0;i<sz;i++){
        // carr[i]=arr[i];
        // // cout<<carr[i]<<" ";
        // }
        // cout<<endl;
        // ans.push_back(carr);
        for(int i=1;i<numprocs;i++){
            sr=(sz*i);
            er=(sr+sz-1);
            if(er>=n)
            er=n-1;
            rows=er-sr+1;
            if(sr<=er){
            // carr.clear();
            // carr.resize(rows);
            MPI_Recv(&carr[0],rows,MPI_INT,i,return_data_tag,MPI_COMM_WORLD,&status);
            for(int j=0;j<rows;++j)
            {
                arr[j+sr]=carr[j];
                // cout<<arr[j+sr]<<" ";
            }
            // cout<<endl;
            // ans.push_back(carr);
            // for(int i=0;i<n)
            }
        }
        // for(int i=0;i<n;i++)
        // cout<<arr[i]<<" ";
        // cout<<endl;
        // cout<<ans.size()<<endl;
        // for(int i=0;i<ans.size();i++)
        // {
        //     for(int j=0;j<ans[i].size();j++)
        //     cout<<ans[i][j]<<" ";
        //     cout<<endl;
        // }
        mergeKArrays();
    }

    }
    else{
            sz=n/numprocs;
            if(n%numprocs)
            sz++;

            sr=(sz*rank);
            er=(sr+sz-1);
            if(er>=n)
            er=n-1;
            nrows=er-sr+1;


            // MPI_Recv(&nrows,1,MPI_INT,0,send_data_tag,MPI_COMM_WORLD,&status);
            if(nrows>0){
            // cout<<rank<<endl;
            // cout<<nrows<<endl;
            carr.resize(nrows);
            MPI_Recv(&carr[0],nrows,MPI_INT,0,send_data_tag,MPI_COMM_WORLD,&status);
            // for(int i=0;i<nrows;i++)
            // cout<<carr[i]<<" ";
            // cout<<endl;

            quickSortIterative(carr, 0,nrows-1);
            // for(int i=0;i<nrows;i++)
            // cout<<carr[i]<<" ";
            // cout<<endl;
            MPI_Send(&carr[0],nrows,MPI_INT,0,return_data_tag,MPI_COMM_WORLD);
            }
    }
    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        // cout<<output.size()<<endl;

        ofstream outfile(argv[2]);
        // for(i=0;i<sortedBuffer.size();i++)
        // {
        //     outfile<<sortedBuffer[i]<<" ";
        // }
        if(numprocs>1){
        for(int i=0;i<n;i++){
        outfile<<output[i]<<" ";
        }
        }
        else
        {
        for(int i=0;i<n;i++){
        outfile<<arr[i]<<" ";
        }

        }
        // outfile<<"\n";
        // outfile <<"Total time "<<maxTime<<"\n";
        outfile.close();
        printf( "Total time (s): %f\n", maxTime );

        // cout <<"Total time "<<maxTime<<"\n";


    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}