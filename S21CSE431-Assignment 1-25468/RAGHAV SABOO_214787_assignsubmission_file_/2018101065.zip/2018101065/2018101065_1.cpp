/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include <mpi.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define send_data_tag 2001
#define return_data_tag 2002

int main( int argc, char **argv ) {
    int rank, numprocs;
    int  n,avg,sr,er;
     double sum=0,psum=0,k;
    /* start up MPI */
    MPI_Status status;

    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    // cout<<"saddsa  "<<rank<<" "<<numprocs<<endl;
    if(rank==0){
    fstream input_file;
    input_file.open(argv[1], ios::in);
    input_file >> n; 
    input_file.close();
    // cout<<n<<endl;

    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    if(rank==0){
        // cout<<n<<endl;
        avg=(n/(numprocs));
        if(n%(numprocs))
        avg++;
        // cout<<avg<<endl;
        // cout<<1<<" "<<avg<<endl;
        // int l=((rank*avg)+1);
        // int r=((l+avg)-1);

        for(long long i=1;i<=avg;++i )
        {
            k= (i*i);
            // cout<<k<<endl;
            sum+=((double)1/(double)k);
            
        }
        // cout<<rank<<sum<<endl;
        for(int aid=1;aid<numprocs;++aid){
            sr=((aid*avg)+1);
            er=(sr+avg-1);
            if(er>n)
            er=n;
            if(er>=sr && sr<=n){
            MPI_Recv(&psum,1,MPI_DOUBLE,aid,return_data_tag,MPI_COMM_WORLD,&status);
            sum+=psum;
            }
        }
    }
    else{
            avg=(n/(numprocs));
            if(n%(numprocs))
            avg++;
            sr=((rank*avg)+1);
            er=(sr+avg-1);
            if(er>n)
            er=n;
            // cout<<sr<<" "<<er<<endl;

            if(er>=sr && sr<=n)
            {
            psum=0;
            for(ll i=sr;i<=er;++i )
            {
                 k= (i*i);
                psum+=((double)1/(double)k);
            }
            MPI_Send(&psum,1,MPI_DOUBLE,0,return_data_tag,MPI_COMM_WORLD);
            // cout<<rank<<psum<<endl;
            }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        ofstream outfile(argv[2]);
        // for(i=0;i<sortedBuffer.size();i++)
        // {
        //     outfile<<sortedBuffer[i]<<" ";
        // }
        outfile << fixed << setprecision(6) << sum << endl;
        // <<sum<<" ";

        // for(int i=1;i<=m;i++){
        // outfile<<col[i]<<" ";
        // }
        // outfile<<"\n";
        // outfile <<"Total time "<<maxTime<<"\n";
        outfile.close();
        // cout<<sum<<endl;
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}