/* MPI Program Template */

#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
using namespace std;


typedef long long int ll;
// typedef push_back pb;

    int adj[501][501]={0};
    int col[501]={0};
    int indd[501];
    int arr[1002];

int main( int argc, char **argv ) {
    int rank, numprocs;
    int n,m,sz;
    vector<pair<int,int>>mat;

    // memset(adj,0,sizeof(adj));
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
        if(!rank){
        // for(int i=0;i<501;i++)
        // {
        //     col[i]=0;
        //     for(int j=0;j<501;j++)
        //     adj[i][j]=0;
        // }
        int x,y; 
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n>>m; 
        // arr.resize(n);
        // for(int i = 0; i < n; i++) {
        //     input_file >> arr[i];
        // } 
        // cout<<m<<endl;
        for(int i=0;i<m;i++){
            input_file>>x>>y;
            indd[i+1]=0;
            mat.push_back({min(x,y),max(y,x)});
            // adj[x][y]=1;
            // adj[y][x]=1;
        }
        int xx,yy;
        for(int i=0;i<mat.size();i++){
            // val[i+1]=i+1;
            x=mat[i].first;
            y=mat[i].second;
            for(int j=i+1;j<mat.size();j++){
                    xx=mat[j].first;
                    yy=mat[j].second;
                        if(x==xx || x==yy || y==xx || y==yy){
                        adj[j+1][indd[j+1]]=i+1;
                        indd[j+1]++;
                        adj[i+1][indd[i+1]]=j+1;
                        indd[i+1]++;
                        // adj[j+1][i+1]=1;
                        }

            }
        }
        // n=m;

        // for(int i=1;i<=m;i++)
        // cout<<indd[i]<<" ";
        // cout<<endl;
        input_file.close();
        // cin>>n>>m;

        // for(int i=1;i<=n;i++){   
        // val[i]=i;
        // // cout<<val[i]<<" ";
        // }
        // cout<<endl;

    }


    /* write your code here */
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(indd, 501  , MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(adj, ((501)*(501))  , MPI_INT, 0, MPI_COMM_WORLD);
    // cout<<"rank "<<rank<<endl;
    sz=(m/numprocs);
    if(m%numprocs)
    sz++;
    int l=(rank*sz)+1;
    int r=l+sz-1;
    if(r>m){
    r=m;
    }
    // cout<<l<<" r"<<r<<" sz"<<sz<<" rank"<<rank<<endl;

    while(true){
        vector<int>ind;
        for(int i=l;i<=r;++i)
        {
            if(!col[i]){
            int  flag=0;
            // cout<<"ind  of i  ==>"<<indd[i]<<" "<<i<<endl;
            for(int j=0;j<indd[i];++j){
                // if(adj[i][j])
                // {
                    // cout<<adj[i][j]<<" "<<i<<endl;
                    if(!col[adj[i][j]] && adj[i][j]>i)
                    {
                        flag=1;
                        break;
                    }
                // }
            }
            if(!flag)
            {
                set<int>v;
                for(int j=0;j<indd[i];++j){
                    // cout<<adj[i][j]<<" "<<i<<endl;

                    if( col[adj[i][j]])
                            v.insert(col[adj[i][j]]);
                }
                // sort(v.begin(),v.end());
                int k=1;
                for(auto u: v){
                    if(u==k)
                    k++;
                    else
                    break;
                }
                col[i]=k;
                ind.push_back(i);
                ind.push_back(k);
            }
            }
            // copy[i]=col[i];
        }
        // int ro=sz;
        int ro=ind.size();
        // cout<<indd[0][0];
        for(int j=0;j<ro;++j)
        arr[j]=ind[j];

        for(int i=0;i<numprocs;++i){
            // cout<<" ro"<<ro<<" rank"<<rank<<endl;
            MPI_Bcast(&ro,1 , MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(arr,ro , MPI_INT, i, MPI_COMM_WORLD);
            // cout<<" ro"<<ro<<" rank"<<rank<<endl;

            if(i!=rank)
            {
                for(int j=0;j<ro;j+=2)
                col[arr[j]]=arr[j+1];

                // cout<<" rank"<<rank<<" i"<<i<<" k"<<k<<endl;
            }
            ro=ind.size();
            for(int j=0;j<ro;++j)
            arr[j]=ind[j];

            // ind=indd;

        }
        int cntt=0;
        for(int i=1;i<=m;i++){
            if(col[i])
            cntt++;
        }
        if(cntt==m)
            break;

        // f=1;
        // }
        // MPI_Bcast(&f,1 , MPI_INT, 0, MPI_COMM_WORLD);

        // int f=0;

        // if(f){
        // }
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        // cout<<n<<endl;
        int mx=0;
        for(int i=1;i<=m;i++)
        mx=max(mx,col[i]);
        ofstream outfile(argv[2]);
        // for(i=0;i<sortedBuffer.size();i++)
        // {
        //     outfile<<sortedBuffer[i]<<" ";
        // }
        outfile<<mx<<" ";

        for(int i=1;i<=m;i++){
        outfile<<col[i]<<" ";
        }
        // outfile<<"\n";
        // outfile <<"Total time "<<maxTime<<"\n";
        outfile.close();

        // for(int i=1;i<=n;i++){
        // cout<<col[i]<<" ";
        // }
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}