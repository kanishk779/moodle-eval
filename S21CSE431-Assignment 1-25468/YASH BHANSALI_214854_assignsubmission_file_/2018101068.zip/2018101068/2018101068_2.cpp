#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(vector<int> &arr, int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return (i + 1);
}

void quickSort(vector<int> &arr, int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n;
    vector<int> ans;
    if (rank == 0)
    {
        // read size of data
        FILE *file = NULL;
        // int n;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);

        vector<int> data(n);
        for (int i = 0; i < n; i++)
            fscanf(file, "%d", &(data[i]));
        fclose(file);
        // cout << n << endl;
        // for (int i = 0; i < n; i++)
        //     cout << data[i] << " ";
        // cout << endl;
        int len_per_process = n / numprocs;
        int start = 0;
        for (int i = 1; i < numprocs; i++)
        {
            MPI_Send(&len_per_process, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            if (len_per_process)
                MPI_Send(&data[start], len_per_process, MPI_INT, i, 0, MPI_COMM_WORLD);
            start = start + len_per_process;
        }
        vector<int> qwe(data.begin() + start, data.end());
        quickSort(qwe, 0, n - len_per_process * (numprocs - 1));
        vector<vector<int>> a;
        a.push_back(qwe);
        priority_queue<pair<int, pair<int, int>>> pq;
        pq.push({-qwe[0], {0, 0}});
        if (len_per_process)
            for (int i = 1; i < numprocs; i++)
            {
                vector<int> dum(len_per_process);
                MPI_Recv(&dum[0], len_per_process, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                pq.push({-dum[0], {i, 0}});
                a.push_back(dum);
            }
        // vector<int > ans;
        while (!pq.empty())
        {
            auto ptr = pq.top();
            pq.pop();
            int val = ptr.first;
            int i = ptr.second.first;
            int j = ptr.second.second;
            // cout << -val << " ";
            ans.push_back(-val);
            if (j + 1 < a[i].size())
            {
                pq.push({-a[i][j + 1], {i, j + 1}});
            }
        }
        file = fopen(argv[2], "w");
        for (int i = 0; i < n; i++)
        fprintf(file, "%d ", ans[i]);
        fclose(file);
    }
    else
    {

        int n;
        MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if (n)
        {
            vector<int> a(n);
            MPI_Recv(&a[0], n, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quickSort(a, 0, n - 1);
            MPI_Send(&a[0], n, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}