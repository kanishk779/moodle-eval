#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void find_mis(vector<int> &vec, int colors[], int l, int r, int n, int adj[501][501])
{
    for (int i = l; i <= r; i++)
    {
        if (colors[i] == 0)
        {
            int mk = -100000;
            for (int j = 1; j <= n; j++)
            {
                if (adj[i][j] == 1)
                {
                    if (colors[j] == 0)
                    {
                        mk = max(mk, j);
                    }
                }
            }
            if (mk < i)
            {
                vec.push_back(i);
            }
        }
    }
}

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int n, m;
    int adj[501][501];
    int colors[501];
    if (rank == 0)
    {
        FILE *file = NULL;
        // int n;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        fscanf(file, "%d", &m);
        for (int i = 0; i <= m; i++)
        {
            for (int j = 0; j <= m; j++)
                adj[i][j] = 0;
        }
        vector<vector<int>> edges;
        for (int i = 0; i < m; i++)
        {
            int u, v;
            fscanf(file, "%d", &u);
            fscanf(file, "%d", &v);
            edges.push_back({u, v});
            // adj[u][v]=1;
            // adj[v][u]=1;
        }
        for (int i = 0; i < m; i++)
        {
            for (int j = i + 1; j < m; j++)
            {
                if (edges[j][0] == edges[i][0] || edges[j][0] == edges[i][1] || edges[j][1] == edges[i][0] || edges[j][1] == edges[i][1])
                {
                    adj[i + 1][j + 1] = 1;
                    adj[j + 1][i + 1] = 1;
                }
            }
        }
        fclose(file);
        for (int i = 1; i <= m; i++)
            colors[i] = 0;
    }
    MPI_Bcast(&adj[0][0], 501 * 501, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    n = m;
    while (true)
    {
        MPI_Bcast(colors, n + 1, MPI_INT, 0, MPI_COMM_WORLD);
        int f = 0;
        for (int i = 1; i <= n; i++)
        {
            if (colors[i] == 0)
                f = 1;
        }
        if (f == 0)
            break;
        if (rank == 0)
        {
            int len_per_process = n / (numprocs);
            int start = 1;
            for (int i = 1; i < numprocs; i++)
            {
                int a[] = {start, start + len_per_process - 1};
                MPI_Send(a, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                start = start + len_per_process;
            }
            vector<int> to_be_colored;
            vector<int> vec;
            find_mis(vec, colors, start, n, n, adj);
            for (auto x : vec)
                to_be_colored.push_back(x);

            for (int i = 1; i < numprocs; i++)
            {
                int vec_size;
                MPI_Recv(&vec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                vector<int> vec(vec_size);
                if (vec_size != 0)
                {
                    MPI_Recv(&vec[0], vec_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
                for (auto x : vec)
                    to_be_colored.push_back(x);
            }

            for (auto v : to_be_colored)
            {
                vector<int> smallest_p_num(n + 1, 0);
                for (int i = 1; i <= n; i++)
                {
                    if (adj[v][i] == 1)
                    {
                        smallest_p_num[colors[i]] = 1;
                    }
                }
                for (int i = 1; i <= n; i++)
                {
                    if (smallest_p_num[i] == 0)
                    {
                        colors[v] = i;
                        break;
                    }
                }
            }
        }
        else
        {
            int a[2];

            MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            vector<int> vec;
            find_mis(vec, colors, a[0], a[1], n, adj);
            int vec_size = vec.size();
            MPI_Send(&vec_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            if (vec_size != 0)
            {
                MPI_Send(&vec[0], vec_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
            }
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        FILE *file = NULL;
        file = fopen(argv[2], "w");
        set<int > st;
        for(int i=1;i<=n;i++){
            st.insert(colors[i]);
        }
        fprintf(file, "%ld\n", st.size());
        for (int i = 1; i <= n; i++)
            fprintf(file, "%d ", colors[i]);
        fclose(file);
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}