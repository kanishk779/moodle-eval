#include <stdio.h>
#include <mpi.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <stdarg.h> 
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main(int argc, char **argv){
    double sum, partial_sum;
    MPI_Status status;
    int my_id, root_process, ierr, i, num_rows, num_procs, 
        an_id, num_rows_to_receive, avg_rows_per_process, 
        sender, num_rows_received, start_row, end_row, num_rows_to_send;
    ierr = MPI_Init(&argc, &argv);
    // cout << "Hello world\n";
    int root = 0;
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);
    int size = 60;
    double bufferUnsorted[size];
    double tmp[size];
    double tmp_sorted[size];
    double bufferSorted[size];
    int to_recieve;
    vector<vector<int> > vect;
    if(my_id == root) {
    	// cout << input_file << output_file;
    	char *input_file = argv[1];
    	char *output_file = argv[2];
    	string myText;
    	ifstream MyReadFile(input_file);
    	getline (MyReadFile, myText);
    	char *char_array = &myText[0];
    	// cout << myText;
    	sscanf(char_array, "%d", &size);
    	MyReadFile.close(); 
    	for(int i=0;i<size;i++)
            bufferUnsorted[i] = (double)(i+1);
        int per_proc = size / num_procs;
        // for(int i=0;i<size;i++)
        //     cout << bufferUnsorted[i] << " ";
        int start = 0,end = -1;
        for(int i=1;i<num_procs;i++){
            start = (i-1)*per_proc;
            end = i*per_proc - 1;
            int to_send = end - start + 1;
            ierr = MPI_Send( &to_send, 1 , MPI_INT, i, 0, MPI_COMM_WORLD);
            // ierr = MPI_Send( &array[start], to_send, MPI_INT, i, 0, MPI_COMM_WORLD);
            ierr = MPI_Send(bufferUnsorted+start, to_send,MPI_DOUBLE,i,0,MPI_COMM_WORLD);
        }
        partial_sum = 0;
        sum = 0;
        for (int i = end + 1; i < size; i++)
        	// partial_sum +=  (double)((double)1/((bufferUnsorted[i]*bufferUnsorted[i])));
            partial_sum += pow(pow(bufferUnsorted[i], 2), -1);
     	sum += partial_sum;
     	// partial_sum = 0;
        // for(i = 0; i < to_recieve; i++) {
        //     partial_sum += (double)((double)1/((double)((double)tmp[i]*(double)tmp[i])));
    	// }
    	for(int i=1;i<num_procs;i++){
    		double rec_partial_sum; 
    		ierr = MPI_Recv( &rec_partial_sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &status);
    		sum += rec_partial_sum;
    	}
    	ofstream MyFile(output_file);
    	char buffer[50];
    	sprintf(buffer, "%.6lf\n", sum);
    	MyFile << buffer;
    	printf("%.6lf\n", sum);
    	MyFile.close();
    }
    else{
    	ierr = MPI_Recv( &to_recieve, 1, MPI_INT, root, 0, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv( &tmp, to_recieve, MPI_DOUBLE, root, 0, MPI_COMM_WORLD, &status);
        partial_sum = 0;
        for(i = 0; i < to_recieve; i++) {
            // partial_sum += (double)((double)1/((tmp[i]*tmp[i])));
            partial_sum += pow(pow(tmp[i], 2), -1);
            // cout << tmp[i] << ' ';
        }
        // cout << to_recieve << '\n';
        // cout << partial_sum << ' ' << my_id << '\n';
        ierr = MPI_Send( &partial_sum, 1 , MPI_DOUBLE, root, 0, MPI_COMM_WORLD);
    }
    ierr = MPI_Finalize();
}