#include <stdio.h>
#include <mpi.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <stdarg.h> 
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

void swap(int *x, int *y)  
{  
    int tmp = *x;  
    *x = *y;  
    *y = tmp;  
}  
  
// A function to implement bubble sort  
void bubbleSort(int arr[], int n)  
{  
    int i, j;  
    for (i = 0; i < n-1; i++)
      
    // Last i elements are already in place  
    for (j = 0; j < n-i-1; j++)  
        if (arr[j] > arr[j+1])  
            swap(&arr[j], &arr[j+1]);  
}
int divide (int arr[], int l, int h) 
{ 
    int pin = arr[h];
    int i = (l - 1);
    int j = l;
    while (j <= h- 1) 
    { 
        if (arr[j] <= pin) 
        { 
            i++;
            swap(&arr[i], &arr[j]); 
        } 
        j++;
    } 
    swap(&arr[i + 1], &arr[h]); 
    return (i + 1); 
} 
  

void quickSort(int arr[], int l, int h) 
{ 
    if (l < h) 
    { 
        
        int pi = divide(arr, l, h); 
        quickSort(arr, l, pi - 1); 
        quickSort(arr, pi + 1, h); 
    } 
} 
vector<int> mergeKArrays(vector<vector<int> > arr) 
{ 
    vector<int> res; 
    priority_queue<pair<int, pair<int, int> > , vector<pair<int, pair<int, int> > >, greater<pair<int, pair<int, int> > > > heap; 
    for (int i = 0; i < arr.size() && arr[0].size() > 0; i++)
        heap.push({ arr[i][0], { i, 0 } });
    // for (int i = 0; i < arr.size(); i++) 
    //     heap.push({ arr[i][0], { i, 0 } }); 
  
    while (heap.empty() == false) { 
        pair<int, pair<int, int> >  curr = heap.top(); 
        heap.pop(); 
        int i = curr.second.first; 
        int j = curr.second.second; 
  
        res.push_back(curr.first); 
        if (j + 1 < arr[i].size()) 
            heap.push({ arr[i][j + 1], { i, j + 1 } }); 
    } 
  
    return res; 
} 
int main(int argc, char **argv){
    double sum, partial_sum;
    MPI_Status status;
    int my_id, root_process, ierr, i, num_rows, num_procs, 
        an_id, num_rows_to_receive, avg_rows_per_process, 
        sender, num_rows_received, start_row, end_row, num_rows_to_send;
    int size = 60;
    int bufferUnsorted[size];
    int tmp[size];
    int tmp_sorted[size];
    int bufferSorted[size];
    int to_recieve;
    vector<vector<int> > vect;
    char *input_file = argv[1];
    char *output_file = argv[2];
    string myText;
    ifstream MyReadFile(input_file);
    getline (MyReadFile, myText);
    char *char_array = &myText[0];
    // // cout << myText;
    sscanf(char_array, "%d", &size);
    // ifstream MyReadFile(input_file);
    string myText2;
    getline (MyReadFile, myText2);
    char *char_array2 = &myText2[0];
    for(int i=0;i<size;i++){
        // bufferUnsorted[i] = int(rand()%101) + 1;
        int n,offset;
        sscanf(char_array2, "%d%n", &n, &offset);
        bufferUnsorted[i] = n;
        char_array2 += offset;
    }
    ierr = MPI_Init(&argc, &argv);
    // // cout << "Hello world\n";
    int root = 0;

    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);
    if (num_procs > size)
        num_procs = size;
    if(my_id == root) {
        // char *input_file = argv[1];
        // char *output_file = argv[2];
        // string myText;
        // ifstream MyReadFile(input_file);
        // getline (MyReadFile, myText);
        // char *char_array = &myText[0];
        // // // cout << myText;
        // sscanf(char_array, "%d", &size);
        // if (num_procs > size)
        //     num_procs = size;
        // // ifstream MyReadFile(input_file);
        // string myText2;
        // getline (MyReadFile, myText2);
        // char *char_array2 = &myText2[0];
        // for(int i=0;i<size;i++){
        //     // bufferUnsorted[i] = int(rand()%101) + 1;
        //     int n,offset;
        //     sscanf(char_array2, "%d%n", &n, &offset);
        //     bufferUnsorted[i] = n;
        //     char_array2 += offset;
        // }
        int per_proc = size / num_procs;
        int start = 0,end = -1;
        for(int i=0;i<size;i++)
            // cout << bufferUnsorted[i] << " ";
        // cout << "\n^ Un Sorted \n";
        for(int i=1;i<num_procs;i++){
            start = (i-1)*per_proc;
            end = i*per_proc - 1;
            if((size - end) < per_proc)
               end = size - 1;
            int to_send = end - start + 1;
            ierr = MPI_Send( &to_send, 1 , MPI_INT, i, 0, MPI_COMM_WORLD);
            // ierr = MPI_Send( &array[start], to_send, MPI_INT, i, 0, MPI_COMM_WORLD);
            ierr = MPI_Send(bufferUnsorted+start, to_send,MPI_INT,i,0,MPI_COMM_WORLD);
        }
        int idx = 0;
        // // cout << size;
        for (int j = end + 1; j < size; j++){
            tmp[idx] =  bufferUnsorted[j];
            // // cout << idx << j << size;
            idx++;
        }
        // for(int i=0;i< idx;i++)
        //     // cout << tmp[i] << " ";
        quickSort(tmp, 0, idx - 1);

        // for(int i=0;i< idx;i++)
            // cout << tmp[i] << " ";
        vector<int> tmp_vec(tmp, tmp + idx);
        vect.push_back(tmp_vec);
        // cout << "\n^ Sorted array for root process \n";
        for(int i=1;i<num_procs;i++){
            int to_send;
            ierr = MPI_Recv( &to_send, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            // // cout << to_recieve << '\n';
            ierr = MPI_Recv( &tmp_sorted, to_send, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            // for(int j=0;j<to_send;j++)
                // cout << tmp_sorted[j] << " ";
            vector<int> tmp_vec2(tmp_sorted, tmp_sorted + to_send);
            vect.push_back(tmp_vec2);
            // cout << "\n^ Sorted array for process " << i << "\n";
        }
        vector<int> final = mergeKArrays(vect); 
        // cout << "Merged array is " << endl; 
        ofstream MyFile(output_file);
        char buffer[10000];
        sprintf(buffer, "%.6lf\n", sum);
        for (auto x : final) {
            int offset;
            sprintf(buffer, "%d ", x);
            MyFile << buffer;
            // buffer += offset
            // cout << x << " "; 
        }
        
        MyFile.close();
        // cout << '\n';
    }
    else{
        // // cout << "hoola\n";
        if (my_id < num_procs){ 
            ierr = MPI_Recv( &to_recieve, 1, MPI_INT, root, 0, MPI_COMM_WORLD, &status);
            // // cout << to_recieve << '\n';
            ierr = MPI_Recv( &tmp, to_recieve, MPI_INT, root, 0, MPI_COMM_WORLD, &status);
            quickSort(tmp, 0, to_recieve - 1);
      //       for(int i=1;i<to_recieve + 1;i++)
            //  // cout << tmp[i] << " ";
            // // cout << "\n^ Sorted array for process " << my_id << "\n";
            ierr = MPI_Send( &to_recieve, 1 , MPI_INT, root, 0, MPI_COMM_WORLD);
            // ierr = MPI_Send( &array[start], to_send, MPI_INT, i, 0, MPI_COMM_WORLD);
            ierr = MPI_Send(tmp, to_recieve , MPI_INT, root, 0, MPI_COMM_WORLD);
        }
    }
    ierr = MPI_Finalize();
}