/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {

    ifstream in(argv[1]);
    streambuf *cinbuf = cin.rdbuf();
    cin.rdbuf(in.rdbuf());

    ofstream out(argv[2]);
    streambuf *coutbuf = cout.rdbuf();
    cout.rdbuf(out.rdbuf());

    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    int n,m;
    int graph[110][110]={-1};
    int edge[510][2];
    int color[510];
    if(rank==0)
    {
        cin >>n>>m;
        for(int i=0;i<m;i++)
        {
            int a,b;
            cin >>a>>b;
            a-=1;
            b-=1;
            graph[a][b]=i;
            graph[b][a]=i;
            edge[i][0]=a;
            edge[i][1]=b;
            color[i]=-1;
        }
    }
    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&m,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(graph,110*110,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(edge,510*2,MPI_INT,0,MPI_COMM_WORLD);

    if(rank==0)
    {

        int num=0;
        // int iter=0;
        while(num<m)
        {

            int cnt=0;
            int toDo[510];
            for(int i=0;i<m;i++)
            {
                if(color[i]!=-1) continue;
                int u=edge[i][0];
                int v=edge[i][1];

                int flag=1;
                for(int k=0;k<n;k++)
                {
                    if(k==v) continue;

                    if(color[graph[u][k]]==-1&&graph[u][k]>graph[u][v])
                    {
                        flag=0;
                        break;
                    }
                }
                for(int k=0;k<n;k++)
                {
                    if(k==u) continue;

                    if(color[graph[k][v]]==-1&&graph[k][v]>graph[u][v])
                    {
                        flag=0;
                        break;
                    }
                }
                if(flag==1)
                    toDo[cnt++]=i;
            }
            // cout <<iter<<"\n";

            // for(int i=0;i<cnt;i++)
            // {
            //     color[toDo[i]]=1;
            //     cout <<toDo[i]<<" ";
            // }
            // cout <<"\n";
            // iter++;

            num+=cnt;
            int useprocs=numprocs-1;
            if(useprocs>0)
            {
                while(cnt>useprocs)
                {
                    for(int i=1;i<=useprocs;i++)
                    {
                        MPI_Send(&toDo[cnt-i],1,MPI_INT,i,0,MPI_COMM_WORLD);
                        MPI_Send(color,510,MPI_INT,i,0,MPI_COMM_WORLD);

                    }
                    for(int i=1;i<=useprocs;i++)
                    {
                        MPI_Recv(&color[toDo[cnt-i]],1,MPI_INT,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                    }
                    cnt-=useprocs;
                }
                if(cnt>0)
                {
                    for(int i=1;i<=cnt;i++)
                    {
                        MPI_Send(&toDo[cnt-i],1,MPI_INT,i,0,MPI_COMM_WORLD);
                        MPI_Send(color,510,MPI_INT,i,0,MPI_COMM_WORLD);
                    }
                    for(int i=1;i<=cnt;i++)
                    {
                        MPI_Recv(&color[toDo[cnt-i]],1,MPI_INT,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                    }
                    cnt=0;
                }
            }
            else
            {
                for(int i=0;i<cnt;i++)
                {
                    int toColor=toDo[i];
                    int colorlist[510]={0};
                    int u=edge[toColor][0];
                    int v=edge[toColor][1];
                    for(int k=0;k<n;k++)
                    {
                        if(k==v) continue;

                        if(graph[u][k]>=0&&color[graph[u][k]]!=-1)
                        {
                            colorlist[color[graph[u][k]]]=1;
                        }
                    }
                    for(int k=0;k<n;k++)
                    {
                        if(k==u) continue;

                        if(graph[k][v]>=0&&color[graph[k][v]]!=-1)
                        {
                            colorlist[color[graph[k][v]]]=1;
                        }
                    }
                    
                    int chosen=0;
                    while(colorlist[++chosen]==1);
                    color[toColor]=chosen;
                }
            }


        }

        for(int i=1;i<numprocs;i++)
        {
            int temp=-1;
            MPI_Send(&temp,1,MPI_INT,i,0,MPI_COMM_WORLD);
        }

        int top=0;
        for(int i=0;i<m;i++)
        {
            top=max(top,color[i]);
        }
        cout <<top<<"\n";
        for(int i=0;i<m;i++)
        {
            cout << color[i]<<" ";
        }
        cout <<"\n";
    }
    else
    {
        while(true)
        {
            int toColor;
            int colorlist[510]={0};
            int coloredge[510]={0};
            
            MPI_Recv(&toColor, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            if(toColor<0) break;
            
            MPI_Recv(coloredge, 510, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            // cout << rank<<" "<<edge[toColor][0]<<" "<<edge[toColor][1]<<"\n";

            int u=edge[toColor][0];
            int v=edge[toColor][1];
            for(int k=0;k<n;k++)
            {
                if(k==v) continue;

                if(graph[u][k]>=0&&coloredge[graph[u][k]]!=-1)
                {
                    colorlist[coloredge[graph[u][k]]]=1;
                }
            }
            for(int k=0;k<n;k++)
            {
                if(k==u) continue;

                if(graph[k][v]>=0&&coloredge[graph[k][v]]!=-1)
                {
                    colorlist[coloredge[graph[k][v]]]=1;
                }
            }
            
            int chosen=0;
            while(colorlist[++chosen]==1);

            MPI_Send(&chosen, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);

        }
    }



    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}



// 6 7
// 1 3
// 3 4
// 1 2
// 2 3
// 5 6
// 4 6
// 4 5

// 4 3 2 1 3 2 1


// 7 12
// 1 2
// 1 3
// 2 3
// 1 5
// 1 4
// 5 4
// 5 7
// 5 6
// 6 7
// 2 7
// 1 7
// 3 4

// 4 2 3 5 3 2 4 1 3 2 1 1 
