# Assignment 1

## Q1
```
To calculate the sum of all the n elements they are divided equally among all the processes.

> 1 num+1 2*num+1 ... => handled by rank 0
> 2 num+2 2*num+2 ... => handled by rank 1
> 3 num+3 2*num+3 ... => handled by rank 2
and so on.

Using mpi reduce I accumulate all the partial sum and print the result
```

## Q2

```
> After taking the input of n elements they are divided equally among all the processes and they are sorted using quick sort by the indivisual process.

> Each process then return back the sorted chunk and then the root process merges these thunk to create the final sorted array
```

## q3
```
> After taking the input of the graph we assign a weight to all the edges ( I am taking their index as the weight itself)

> Then using these weights I determine the edges which are greater than all of its neighbour edges

> these edges are then sent to indivisual process where the job of the indivisual process is to check all of its neighbours and assign it the least available color

> The color is then retured and the process is repeated until all the edges are exhausted
```
