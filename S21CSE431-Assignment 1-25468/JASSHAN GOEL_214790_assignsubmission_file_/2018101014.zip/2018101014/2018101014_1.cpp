/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {

    ifstream in(argv[1]);
    streambuf *cinbuf = cin.rdbuf();
    cin.rdbuf(in.rdbuf());

    ofstream out(argv[2]);
    streambuf *coutbuf = cout.rdbuf();
    cout.rdbuf(out.rdbuf());

    int rank, size,n;
    double sum=0;
    cin >>n;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
  
  
  
    /* write your code here */


    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    double temp_sum=0,i=rank+1;
    while(i<=n)
    {
        temp_sum+=1/(i*i);
        i+=size;
    }    
    MPI_Reduce(&temp_sum,&sum,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);




    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {

        cout << sum <<"\n";

        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}