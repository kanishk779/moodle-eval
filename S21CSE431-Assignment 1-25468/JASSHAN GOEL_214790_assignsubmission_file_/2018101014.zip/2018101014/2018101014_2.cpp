/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 
int partition (int arr[], int low, int high) 
{ 
    int pivot = arr[high];   
    int i = (low - 1); 

    for (int j = low; j <= high- 1; j++) 
    { 
        if (arr[j] < pivot) 
        { 
            i++;
            swap(&arr[i], &arr[j]); 
        } 
    } 
    swap(&arr[i + 1], &arr[high]); 
    return (i + 1); 
} 
void normal_quickSort(int arr[], int low, int high) 
{ 
    if(high<low)
    {
        return ;
    }
    if(high-low < 5)
    {
        for(int i=low;i<high;i++)
        {
            for(int j=i+1;j<=high;j++)
            {
                if(arr[j]<arr[i] && j<=high) 
                {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        return;
    }
    if (low < high) 
    { 
        int pi = partition(arr, low, high); 

        normal_quickSort(arr, low, pi - 1); 
        normal_quickSort(arr, pi + 1, high); 
    } 
    return ;
} 

int main( int argc, char **argv ) {

    ifstream in(argv[1]);
    streambuf *cinbuf = cin.rdbuf();
    cin.rdbuf(in.rdbuf());

    ofstream out(argv[2]);
    streambuf *coutbuf = cout.rdbuf();
    cout.rdbuf(out.rdbuf());

    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */


    int n;
    if(rank==0)
    {
        cin >>n;
    }
    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    if(rank==0)
    {
        int bufferUnsorted[1000010];
        int bufferSorted[1000010];
        
        for(int i=0;i<n;i++)
        {
            cin >> bufferUnsorted[i];
            bufferSorted[i]=bufferUnsorted[i];
        }
        if(numprocs>1)
        {
            int num=numprocs-1;
            int partialn=n/num;
            int shift=0;
            int store[num][2];
            for(int i=1;i<=num;i++)
            {
                if(i==num)
                {
                    MPI_Send(bufferUnsorted+shift,partialn+n%num,MPI_INT,i,0,MPI_COMM_WORLD);
                }
                else
                {
                    MPI_Send(bufferUnsorted+shift,partialn,MPI_INT,i,0,MPI_COMM_WORLD);
                }
                shift+=partialn;
            }
            shift=0;
            for(int i=1;i<=num;i++)
            {
                if(i==num)
                {
                    MPI_Recv(bufferSorted+shift,partialn+n%num,MPI_INT,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                    store[i-1][0]=shift;
                    store[i-1][1]=shift+partialn+n%num;
                }
                else
                {
                    MPI_Recv(bufferSorted+shift,partialn,MPI_INT,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                    store[i-1][0]=shift;
                    store[i-1][1]=shift+partialn;
                }
                shift+=partialn;
            }

            int total=0;
            while(total<n)
            {
                int minIndex=-1;

                for(int i=0;i<num;i++)
                {
                    if(store[i][0]<store[i][1])
                    {
                        if(minIndex==-1) minIndex=i;
                        else
                        {
                            if(bufferSorted[store[minIndex][0]]>bufferSorted[store[i][0]])
                            {
                                minIndex=i;
                            }
                        }
                    }
                }
                cout <<bufferSorted[store[minIndex][0]]<<" ";
                store[minIndex][0]++;
                total++;
            }
            cout <<"\n";

        }
        else
        {
            normal_quickSort(bufferUnsorted,0,n-1);
            for(int i=0;i<n;i++) cout << bufferUnsorted[i]<<" ";
            cout <<"\n";
        }
    
    }
    else 
    {

	    int received[1000010];
        int num=numprocs-1;
        if(rank==num)
        {
            MPI_Recv(received, n/num+n%num, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            normal_quickSort(received,0,n/num+n%num-1);
            MPI_Send(received, n/num+n%num, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
        else
        {
            MPI_Recv(received, n/num, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            normal_quickSort(received,0,n/num-1);
            MPI_Send(received, n/num, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }







    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}