Problem 1:
Input file format: 
File containing a single value n

Analysis of solution:
1) Each process will calculate the sum of reciprocals of squares of n/no_procs values.
2) These values will be stored in a buffer and finally we will add all these values using MPI_Reduce and MPI_Sum function.

For example: If n=10 and no_procs=2, then:
Process with rank 0 will calculate the sum of reciprocals of squares of 1,3,5,7,9 number values
Process with rank 1 will calculate the sum of reciprocals of squares of 2,4,6,8,10 number values
Both of these values will be stored in a buffer and finally we will add all these values using MPI_Reduction and MPI_Sum function.




Problem 2:
Input file format: 
First line of file contains number of values
Second line contains all the values separated by space

Analysis of solution:
1) First we calculate piece length as no. of values divided by no. of processes(If no of values is not divisible by no of processes, then leftover values after even distribution are handled in first part)
2) Then each process is responsible for sorting of no_of_values/no_procs values
3) Process with rank 0 sends these parts to other processes with non zero rank; who then sort these parts individually; and send these sorted parts back.
4) Process with rank 0 receive sorted parts back and merges them, one part at a time.
5) Write the finally merged sorted file into output file.

