/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition(int *arr, int lo, int hi) {
    int i = lo-1;
    int pivot = arr[hi];
    
    for (int j = lo; j < hi; j++) {
        if (arr[j] <= pivot) { 
            int temp = arr[i+1];
            arr[i+1] = arr[j];
            arr[j] = temp;
            i++;
        }
    }
    int temp = arr[hi];
    arr[hi] = arr[i + 1];;
    arr[i + 1] = temp;
    return i + 1;
}

void quicksort(int *arr, int lo, int hi) {
    if (lo < hi) {
        int pivot = partition(arr, lo, hi);
        quicksort(arr, lo, pivot-1);
        quicksort(arr, pivot + 1, hi);
    }
}


int* merge(int *out,int n,int *arr,int m) {
    int i=0;
    int j=0;
    int k=0;
    int total_len = n+m;
    int *ans = (int*)malloc(total_len * sizeof(int));

    while(i<n && j<m) {
        if(out[i]<arr[j]){
            ans[k] = out[i];
            i++;
            k++;
        }
        else{
            ans[k] = arr[j];
            j++;
            k++;
        } 
            
    }
    while(i<n) {
        ans[k] = out[i];
        i++;
        k++;
    }
    while(j<m) {
        ans[k] = arr[j];
        j++;
        k++;
    }
    return ans;
}


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    
    if(rank==0) {
        int size , *arr, *out;

        char* input_file = argv[1];
        ifstream infile(input_file);
        infile>>size;

        ofstream outfile;
        char* output_file = argv[2];
        outfile.open (argv[2],ios::out);
        
        arr = (int*)malloc(size * sizeof(int));
        int i=0;
        int num; 
        while (infile >> num){
            arr[i] = num;
            i++;
        }
        infile.close();

        int piece_len = size/numprocs;
        int leftover = size%numprocs;
        int n = piece_len+leftover;
        int first_piece_len = piece_len+leftover-1; 
        quicksort(arr,0,first_piece_len);

        
        out = (int*)malloc(n * sizeof(int));
        int start = piece_len+leftover;
        for(int i=0;i<n;++i) out[i]=arr[i];

        
        for(int i=1;i<numprocs;i++&&(start += piece_len)) {
            MPI_Send(&piece_len, 1, MPI_INT, i, i, MPI_COMM_WORLD);
            int* startaddr = arr+start;
            MPI_Send(startaddr, piece_len, MPI_INT, i, i, MPI_COMM_WORLD);
            
        }
        for(int i=1;i<numprocs;i++ &&(n += piece_len)) {
            int *newarr = (int*)malloc(piece_len * sizeof(int));
            MPI_Recv(newarr, piece_len, MPI_INT, i, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            out = merge(out,n,newarr,piece_len);
            
        }
        for(int i=0;i<n;++i) {
            outfile<<out[i]<<" ";
        }
        outfile.close();
    } else {
        int arrsize ,*newarr;
        MPI_Recv(&arrsize, 1, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        newarr = (int*)malloc(arrsize * sizeof(int));
        MPI_Recv(newarr, arrsize, MPI_INT, 0, rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        quicksort(newarr,0,arrsize-1);
        MPI_Send(newarr, arrsize, MPI_INT, 0, rank, MPI_COMM_WORLD);
    }


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}