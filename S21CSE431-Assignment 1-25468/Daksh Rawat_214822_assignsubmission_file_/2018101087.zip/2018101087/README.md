# Distributed Systems Assignment-1

**Disclaimer**: The runtime of the programs are machine-dependent. The reported results maybe different when tested on a different machine.

## Problem 1 - Parallel Sum
### Approach

A parallel appproach using MPI is followed to find the sum of the reciprocals of the squares of integers from 1 to N (both inclusive). integers from 1 to N are divided among each process using the following logic:
```
for(i=rank+1;i<=N;i+=numprocs)
```
Each process then finds sum of the reciprocals of the squares of integers which it is alloted. Finally, MPI_Reduce is used to send each process' individual value to a root process using the operation MPI_SUM to get the final result.

### Analysis
* For N = 10
    - np = 2 - Total time(s): 0.000062
    - np = 11 - Total time(s): 0.000829
* For N = 1e4
    - np = 2 - Total time(s): 0.000144
    - np = 11 - Total time(s): 0.000235

## Problem 2 - Parallel Quick Sort
### Approach

A parallel approach using MPI is followed to sort the given array using quick sort algorithm. Initially, the input array is divided into equal continuous subarrays with size of each subarray depending on the number of processes. Subarrays are then passed to their corresponding process. Each process sorts its own subarray using serial quick sort algorithm.

Next, each process then sends back its sorted subarray to a root process. The root process uses K-way merge algorithm using a min heap (used ```C++ STL priority_queue``` for this) to create a sorted array from its own subarray and all the other subarrays which it recieves.

**Merging sorted subarrays**: The smallest element of each sorted subarray is first pushed into the min heap. Then the smallest element is popped from the heap and put into the final array. The next element of the subarray from which the element was popped is now pushed into the heap. This process is repeated until all the subarrays are covered.

### Analysis
* For N = 10 with random values in the array from 0 to 1e9
    - np = 2 - Total time(s): 0.000178
    - np = 11 - Total time(s): 0.002926
* For N = 1e6 with random values in the array from 0 to 1e9
    - np = 2 - Total time(s): 0.559274
    - np = 11 - Total time(s): 1.699354

## Problem 3 - Parallel Edge Coloring
### Approach
A parallel approach is to be followed to color the edges of given graph in such a way that no two adjacent edges have same color and maximum number of colors used is not more than `1 + max(Delta of the original graph, Delta of the line graph)`. Initially given graph is transformed to its line graph. The line graph of an undirected graph G is another graph L(G) that represents the adjacencies between edges of G. L(G) is constructed in the following way: for each edge in G, make a vertex in L(G); for every two edges in G that have a vertex in common, make an edge between their corresponding vertices in L(G). Now for this line graph our problem is transformed to graph coloring (vertex-coloring). For this a parallel approach has been followed using **Jones-Plassmann** algorithm as explained [here](https://ireneli.eu/2015/10/26/parallel-graph-coloring-algorithms/).

### Analysis
* For N = 7, M = 21
    - np = 2 - Total time(s): 0.000829
    - np = 11 - Total time(s): 0.006362
* For N = 50, M = 244
    - np = 2 - Total time(s): 0.001840
    - np = 11 - Total time(s): 0.030815