/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int graph[501][501];
int edges[501][2];
int sizes[501] = {0};
int colors[501] = {0};
int new_colors[501] = {0};
int final_colors[501] = {0};

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_rank = 0;
    int n, m, i, j;
    if(rank == root_rank)
    {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file>>n;
        input_file>>m;
        int u, v;
        for(i=0;i<m;i++)
        {
            input_file>>u;
            input_file>>v;
            edges[i][0] = u;
            edges[i][1] = v;
        }
        for(i=0;i<m;i++)
        {
            for(j=i+1;j<m;j++)
            {
                if(j != i)
                {
                    if(edges[i][0] == edges[j][0] || edges[i][0] == edges[j][1] || edges[i][1] == edges[j][0] || edges[i][1] == edges[j][1])
                    {
                        graph[i+1][sizes[i+1]] = j+1;
                        graph[j+1][sizes[j+1]] = i+1;
                        sizes[i+1]++;
                        sizes[j+1]++;
                    }
                }
            }
        }
        input_file.close();
    }
    MPI_Bcast( &m , 1 , MPI_INT , root_rank , MPI_COMM_WORLD);
    MPI_Bcast( sizes , 501 , MPI_INT , root_rank , MPI_COMM_WORLD);
    MPI_Bcast( graph , 501*501 , MPI_INT , root_rank , MPI_COMM_WORLD);
    vector<int> vertices;
    for(i=rank+1;i<=m;i+=numprocs)
        vertices.push_back(i);
    
    int colored = 0;
    int my_colored = 0;
    while(colored < m)
    {   
        int new_colored = 0;
        for(i=0;i<vertices.size();i++)
        {
            int v = vertices[i];
            if(colors[v] == 0)
            {
                int color = 1;
                int mm = v;
                set<int> used_colors;
                for(j=0;j<sizes[v];j++)
                {
                    if(colors[graph[v][j]] != 0)
                        used_colors.insert(colors[graph[v][j]]);
                    if(colors[graph[v][j]] == 0)
                    {
                        mm = max(v, graph[v][j]);
                        if(mm != v)
                            break;
                    }
                }
                if(mm == v)
                {
                    for(auto itr = used_colors.begin(); itr != used_colors.end(); itr++)
                    {
                        if(*itr != color)
                            break;
                        else
                            color++;
                    }
                    colors[v] = color;
                    new_colored++;
                }
            }
        }
        int more_colored=0;
        for(i=0;i<501;i++)
            final_colors[i] = colors[i];
        for(i=0;i<numprocs;i++)
        {
            if(i == rank)
            {
                MPI_Bcast( &new_colored , 1 , MPI_INT , i , MPI_COMM_WORLD);
                if(new_colored != 0)
                    MPI_Bcast( final_colors , 501 , MPI_INT , i , MPI_COMM_WORLD);
            }
            else
            {
                int add_colored=0;
                MPI_Bcast( &add_colored , 1 , MPI_INT , i , MPI_COMM_WORLD);
                if(add_colored > 0)
                {
                    more_colored += add_colored;
                    MPI_Bcast( new_colors , 501 , MPI_INT , i , MPI_COMM_WORLD);
                    for(j=1;j<=m;j++)
                    {
                        if(colors[j] < new_colors[j])
                            colors[j] = new_colors[j];
                    }
                }
            }            
        }
        colored += more_colored+new_colored;
        my_colored += new_colored;
    }

    if(rank == root_rank)
    {
        int* colors_used = max_element(colors, colors+m);
        fstream out_file;
        out_file.open(argv[2], ios::out);
        out_file<<*colors_used<<"\n";
        for(i=1;i<=m;i++)
            out_file<<colors[i]<<" ";
        out_file<<endl;
        out_file.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}