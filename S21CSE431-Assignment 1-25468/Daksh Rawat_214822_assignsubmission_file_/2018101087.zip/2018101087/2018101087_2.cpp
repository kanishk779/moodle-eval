/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<int, pair<int, int>> ppi;
// vector<int> output;
int output[1000000];

void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
}

int partition(int low, int high, int arr[])
{
    int i = low-1;
    int temp;
    int pivot = arr[high];
    for(int j=low;j<high;j++)
    {
        if(arr[j] <= pivot)
        {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i+1], &arr[high]);
    return i+1;
}

void quicksort(int low, int high, int arr[])
{
    if(low>=high)
        return;
    int pi = partition(low, high, arr);
    quicksort(low, pi-1, arr);
    quicksort(pi, high, arr);
    return;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    int root_rank = 0;
    int i, n;
    /* write your code here */
    if(rank == root_rank)
    {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n; 
        int arr[n];
        int value;
        for(i = 0; i < n; i++) {
            input_file >> value;
            arr[i] = value;
        } 
        input_file.close();
        MPI_Bcast( &n , 1 , MPI_INT , root_rank , MPI_COMM_WORLD);
        int eq = n/numprocs;
        int rem = n%numprocs;

        int offset = eq + (rem>0?1:0);
        int root_eq = offset;

        for(i=1;i<numprocs;i++)
        {
            int cur = eq + (rem>i?1:0);
            MPI_Send( arr+offset , cur , MPI_INT , i , 0 , MPI_COMM_WORLD);
            offset += cur;
        }

        assert(offset == n);

        quicksort(0, root_eq-1, arr);
        int portions[numprocs][root_eq];
        for(i=0;i<root_eq;i++)
            portions[0][i] = arr[i];
        vector<int> sizes;
        sizes.push_back(root_eq);
        for(i=1;i<numprocs;i++)
        {
            int size = eq + (rem>i?1:0);
            MPI_Recv( portions[i] , size , MPI_INT , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
            int j;
            sizes.push_back(size);
        }
        priority_queue<ppi, vector<ppi>, greater<ppi>> pq;
        for(i=0;i<numprocs;i++)
            pq.push({portions[i][0], {i, 0}});
        
        int o = 0;
        while(!pq.empty())
        {
            ppi curr = pq.top();
            pq.pop();
            output[o] = curr.first;
            o++;
            i = curr.second.first;
            int j = curr.second.second;

            if(j+1 < sizes[i])
                pq.push({portions[i][j+1], {i, j+1}});
        }

        ofstream outfile(argv[2]);
        for(i=0;i<o;i++)
        {
            outfile<<output[i]<<" ";
        }
        outfile.close();
    }
    else
    {
        MPI_Bcast( &n , 1 , MPI_INT , root_rank , MPI_COMM_WORLD);
        int rem = n%numprocs;
        int size = n/numprocs + (rem>rank?1:0);;
        int recv[size];
        MPI_Recv( recv , size , MPI_INT , root_rank , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
        quicksort(0, size-1, recv);
        MPI_Send( recv , size , MPI_INT , root_rank , 0 , MPI_COMM_WORLD);
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}