/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
// #include<iostream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

bool is_valid_colouring(vector<vector<int>> g, vector<pair<int,int>> e, map<pair<int,int>,int> colours) {
    int m = e.size();
    int n = g.size();
    vector<int> cols;
    for(int i = 0;i < n;i++) {
        cols.clear();
        for(int j = 0;j < g[i].size();j++) {
            int c;
            auto res = colours.find(make_pair(i,g[i][j]));
            c = res->second;
            if(res == colours.end()) {
                res = colours.find(make_pair(g[i][j],i));
                c = res->second;
            }
            // cout << "Colour value = " << c << endl;
            cols.push_back(c);
        }
        // for(int j = 0;j < cols.size();j++) {
        //     cout << cols[i] << " ";
        // }
        // cout << endl;
        sort(cols.begin(),cols.end());
        auto it = unique(cols.begin(),cols.end());
        bool wasUnique = (it == cols.end());
        if(!wasUnique) {/*cout << "Wasn't unique" << endl;*/ return false;}
    }
    return true;
}

vector<int> colourReduction(vector<vector<int>> V, int D) {
    //Returns a D+1 colouring of the graph V
    int n = V.size();
    vector<int> c(n);
    bool found[10000];
    for(int i = 0;i < n;i++) c[i] = i;
    for(int i = D+1; i < n;i++) {
        for(int j = 0;j < D+1;j++) {
            found[j] = true;
        }
        for(int j = 0;j < V[i].size();j++) {
            int u = V[i][j];
            if(c[u] < D+1) found[c[u]] = false;
        }
        for(int j = 0;j < D+1;j++) {
            if(found[j]) {
                c[i] = j;
                break;
            }
        }
    }
    return c;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    float tbeg = MPI_Wtime();

    /* write your code here */
    /*Get N and broadcast to all processes*/
    int send_data_tag = 2001;
    if(argc < 3) {
        cout << "Insufficient number of arguments" << endl;
        exit(1);
    }
    MPI_Status status;
    int n,m,i,j,D;
    m = 0;
    vector<vector<int>> g;
    vector<pair<int,int>> e;
    // map<pair<int,int>,int> colours;
    if(rank == 0) {
        ifstream input;
        input.open(argv[1]);
        input >> n;
        input >> m;
        for(int t = 0;t < n;t++) {
            vector<int> a;
            g.push_back(a);
        }
        for(int t = 0;t < m;t++) {
            input >> i;
            input >> j;
            e.push_back(make_pair(i,j));
            g[i].push_back(j);
            g[j].push_back(i);
        }
        input.close();
    }

    /*Do computations by each process*/
    vector<vector<int>> v(m); //Vertex set for the line graph
    int u1,v1,u2,v2;
    if(rank == 0) {
        //Generate line graph
        for(i = 0;i < m;i++) {
            u1 = e[i].first;
            v1 = e[i].second;
            for(j = i+1;j < m;j++) {
                u2 = e[j].first;
                v2 = e[j].second;
                if(u1 == u2 || u1 == v2 || v1 == u2 || v1 == v2) {
                    v[i].push_back(j);
                    v[j].push_back(i);
                }
            }
        }
        D = v[0].size(); //Degree of the graph
        for(i = 0;i < m;i++) {
            j = v[i].size();
            if(j > D) D = j;
        }
    }
    vector<int> cols;
    // cout << "Rank: " << rank << endl;

    if(rank == 0) {
        cols = colourReduction(v,D);
    }

    if(rank == 0) {
        // cout << "Rank: " << rank << " Iters: " << t << endl;
        ofstream output;
        output.open(argv[2]);
        // output << "Rank: " << rank << endl;
        output << D+1 << endl;
        for(i = 0;i < m;i++) {
            output << 1+cols[i] << " ";
        }
        output << endl;
        // cout << value << endl;
        output.close();
    }


    /* My code finishes here*/


    MPI_Barrier( MPI_COMM_WORLD );
    float elapsedTime = MPI_Wtime() - tbeg;
    float maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}