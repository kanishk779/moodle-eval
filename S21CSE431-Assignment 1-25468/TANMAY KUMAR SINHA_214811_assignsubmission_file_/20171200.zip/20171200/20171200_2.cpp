/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
// #include<iostream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int A[2000006];

void quicksort(int *A, int n) {
    /*Sorts A, assuming it has n elements*/
    if(n <= 1) return;
    int pivot = n/2;
    int val = A[pivot];
    int less_than = -1;
    for(int i = 0;i < n;i++) {
        if(A[i] <= val) less_than++;
    }
    int temp = A[less_than];
    A[less_than] = val;
    A[pivot] =  temp;
    int arr1[less_than];
    int arr2[n - less_than - 1];
    int a,b;
    a = 0;
    b = 0;
    for(int i = 0;i < n;i++) {
        if(A[i] <= val) {
            if(i != less_than) {arr1[a] = A[i];a++;}
        } else {
            arr2[b] = A[i];
            b++;
        }
    }
    quicksort(arr1,a);
    quicksort(arr2,b);
    for(int i = 0;i < a;i++) {
        A[i] = arr1[i];
    }
    for(int i = 0;i < b;i++) {
        A[a+1+i] = arr2[i]; 
    }
}

void merge(int *a, int *b, int n1,int n2) {
    /*Merge the sorted As a and b, of sizes n1 and n2 respectively. Puts the merged A into A a*/
    int i = 0;
    int j = 0;
    int c[n1+n2];
    while(i < n1 && j < n2) {
        if(a[i] < b[j]) {
            c[i+j] = a[i];
            i++;
        } else {
            c[i+j] = b[j];
            j++;
        }
    }
    if(i == n1) {
        while(j < n2) {
            c[i+j] = b[j];
            j++;
        }
    }
    if(j == n2) {
        while(i < n1) {
            c[i+j] = a[i];
            i++;
        }
    }
    for(i = 0;i<n1+n2;i++) a[i] = c[i];
}

int main( int argc, char **argv ) {
    int rank, numprocs;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronsize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    float tbeg = MPI_Wtime();

    /* write your code here */
    /*Get input and broadcast the pieces to all processes*/
    int send_data_tag = 2001;
    if(argc < 3) {
        cout << "Insufficient number of arguments" << endl;
        exit(1);
    }
    int N,a,b;
    // int temp[1000006];
    MPI_Status status;
    if(rank == 0) {
        ifstream input;
        input.open(argv[1]);
        input >> N;
        for(int i = 0;i < N;i++) input >> A[i];
        input.close();
        a = N/numprocs;
        b = N%numprocs;
        MPI_Bcast(&a, 1, MPI_INT, 0, MPI_COMM_WORLD);
        for(int i = 0;i < numprocs - 1;i++) {
            MPI_Send(&A[i*a],a,MPI_INT,i+1,send_data_tag,MPI_COMM_WORLD);
        }
        quicksort(&A[(numprocs-1)*a],a+b);
        // cout << "AAAAAAAAAAAAA" << endl;
    } else {
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Recv(&A,N,MPI_INT,0,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
        quicksort(A,N);
        MPI_Send(A, N,MPI_INT,0,send_data_tag,MPI_COMM_WORLD);
    }
        /*int MPI_Send(void *data_to_send, int send_count, MPI_Datatype send_type, 
      int destination_ID, int tag, MPI_Comm comm); */
        /*int MPI_Recv(void *received_data, int receive_count, MPI_Datatype receive_type, 
      int sender_ID, int tag, MPI_Comm comm, MPI_Status *status);*/

    /*Merge answers to get the final sorted A, and write to file.*/
    if(rank == 0) {
        // int sorted[N];
        for(int i = 0;i < a+b;i++) A[i] = A[(numprocs-1)*a+i];
        for(int i = 1;i < numprocs;i++) {
            MPI_Recv(&A[N+1],a,MPI_INT,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
            merge(A,&A[N+1],a*i+b,a);
        }
        ofstream output;
        output.open(argv[2]);
        for(int i = 0;i < N;i++) output << A[i] << " ";
        output << endl;
        // cout << value << endl;
        output.close();
    }

    /* My code finishes here*/


    MPI_Barrier( MPI_COMM_WORLD );
    float elapsedTime = MPI_Wtime() - tbeg;
    float maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}