/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
// #include<iostream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    float tbeg = MPI_Wtime();

    /* write your code here */
    /*Get N and broadcast to all processes*/
    int send_data_tag = 2001;
    if(argc < 3) {
        cout << "Insufficient number of arguments" << endl;
        exit(1);
    }
    int N;
    MPI_Status status;
    if(rank == 0) {
        ifstream input;
        input.open(argv[1]);
        input >> N;
        input.close();
        // cout << N+1 << endl;
    }
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    /*Do computations by each process*/
    float value = 0.0;
    if(N <= 11 || numprocs > N) {
        if(rank == 0) {
            float j = 0;
            for(int i = 1; i <= N;i++) {
                j += 1.0;
                value += 1/(j*j);
            }
        }
    } else {
        int a = N/numprocs;
        int b = N%numprocs;
        float j = a*rank;
        for(int i = 1;i <= a;i++) {
            j += 1.0;
            value += (1/(j*j));
        }
        if(b != 0 && rank == 0) {
            j = a*numprocs;
            for(int i = 1;i <= b;i++) {
                j += 1.0;
                value += 1/(j*j);
            }
        } 
    }

    
    /* Send/receive all the data, compute final answer.*/
    if(rank!=0) {
        /*int MPI_Send(void *data_to_send, int send_count, MPI_Datatype send_type, 
      int destination_ID, int tag, MPI_Comm comm); */
        MPI_Send(&value, 1, MPI_FLOAT, 0, send_data_tag, MPI_COMM_WORLD);
    } else {
        float recv_value;
        /*int MPI_Recv(void *received_data, int receive_count, MPI_Datatype receive_type, 
      int sender_ID, int tag, MPI_Comm comm, MPI_Status *status);*/
      for(int i = 1;i < numprocs;i++) {
          MPI_Recv(&recv_value, 1, MPI_FLOAT, i, MPI_ANY_TAG, MPI_COMM_WORLD,&status);
          value += recv_value;
      }
    }

    /*Write to file*/
    if(rank == 0) {
        ofstream output;
        output.open(argv[2]);
        output.precision(6);
        output << fixed;
        output << value << endl;
        // cout << value << endl;
        output.close();
    }

    /* My code finishes here*/


    MPI_Barrier( MPI_COMM_WORLD );
    float elapsedTime = MPI_Wtime() - tbeg;
    float maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}