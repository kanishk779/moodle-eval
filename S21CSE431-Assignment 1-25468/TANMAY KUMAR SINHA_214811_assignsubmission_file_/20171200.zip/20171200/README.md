# Distributed Systems Assignment 1
Tanmay Sinha
Roll no 20171200

Throughout the report, it is assumed that $m$ is the number of processes.
## Problem 1
The task was a simple one. The main process(rank 0) reads the input N from the command line and broadcasts it to all other processes, using `MPI_Bcast`. They calculate the region along which they want to sum and send the sum back to the process 0. 

Each process has to iterate over roughly N/m numbers, instead of N, in the case of no parallelism. As such, this offers good speed up.

## Problem 2
The algorithm followed was as follows:-

* Divide  up  the  array  into m sections,  each  with N/m elements,  adjusting  the  remaining elements into any remaining process.
* Sort each of the individual processes using `quicksort`
* Merge the individual solutions in a tree-like manner - first, merge in pairs of two, then merge the remaining ones in pairs, and so on till we are left with only one.

n total, we will have to do O(logm) merges, but each of them will be done in parallel so in theory there should be a speed up. In the average case, quicksort takes O(nlogn) comparisons, and as such,we can bring this factor down significantly, by doing parallel computation.

## Problem 3
For this problem, I have used the Kuhn-Wattenhofer Colour Reduction technique. This technique parallelizes the vertex colouring for the graph. Since we have to do edge colouring, we can convert our problem to an equivalent vertex colouring problem by constructing the line graph of the original graph, then doing vertex colouring on that. This conversion can be done in O(|E|^2). The complexity analysis and explanation for the Kuhn-Wattenhofer technique can be found [here](https://stanford.edu/~rezab/classes/cme323/S16/projects_reports/bae.pdf) and a more advanced analysis can be found [here](https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.68.2988&rep=rep1&type=pdf). Note that the line graph might have a larger degree than the original graph, so using this technique the colouring might be larger than if we had used an algorithm for edge colouring on the original graph. Note that, since we are always dealing with small sized graphs in our case, the parallel algorithm might actually run inefficiently as compared to the simple algorithm due to the overhead involved in managing the distributed system. The advantage would only be visible in the asymptotic cases.