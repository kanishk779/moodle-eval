/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
    
    /*synchronize aint processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ifstream MyReadFile(argv[1]);
    ofstream MyWriteFile(argv[2]);
    
    int N,M,adj[102][102],adj_lg[502][502],wt[502],color[502],i,j;
    map < int,pair<int,int> > v2e;
    map < pair<int,int>,int > e2v;
    
    if(rank == 0)
    {
//      Reading the value of N and M
        string myText;
        getline (MyReadFile, myText);
        char t[100];
        strcpy(t, myText.c_str());
        char *token = strtok(t, " ");
        N = atoi(token);
        token = strtok(NULL, " ");
        M = atoi(token);
//         cout << N << " " << M << endl;
        
        for(i=0;i<N+1;i++)
            for(j=0;j<M+1;j++)
            {
                adj[i][j] = 0;
                adj[j][i] = 0;
            }
        

//      Reading the edges
        int cnt = 1;
        for(i=0;i<M;i++)
        {
            getline (MyReadFile, myText);
            strcpy(t, myText.c_str());
            char *token = strtok(t, " ");
            int a = atoi(token);
            token = strtok(NULL, " ");
            int b = atoi(token);
//             cout << a << " " << b << endl;
            adj[a][b] = cnt;
            adj[b][a] = cnt;
            e2v.insert(make_pair(make_pair(a,b),cnt));
            v2e.insert(make_pair(cnt,make_pair(a,b)));
            cnt+=1;     
        }
        
        memset(color,0,sizeof(color));
        
        for(i=0;i<M+1;i++)
            wt[i] = i;
        
        unsigned seed = 0;
        random_shuffle(wt + 1, wt + M + 1);
        
        map<pair<int,int>,int>::iterator itr;
        
        for(itr = e2v.begin(); itr != e2v.end(); itr++)
        {
            int a = itr->first.first;
            int b = itr->first.second;
            
            int v = itr->second;
            
            for(i=1;i<N+1;i++)
            {
                if(adj[a][i] != 0 && adj[a][i] != v)
                {
                    adj_lg[adj[a][i]][v] = 1;
                    adj_lg[v][adj[a][i]] = 1;
                }
                
                if(adj[b][i] != 0 && adj[b][i] != v)
                {
                    adj_lg[adj[b][i]][v] = 1;
                    adj_lg[v][adj[b][i]] = 1;
                }
            }
        }
        
//         for(i=1;i<N+1;i++)
//         {
//             for(j=1;j<N+1;j++)
//                 cout << adj[i][j] << " ";
//             cout << endl;
//         }   
        
//         cout << endl;
        
//          for(i=1;i<M+1;i++)
//          {
//             for(j=1;j<M+1;j++)
//                 cout << adj_lg[i][j] << " ";
//             cout << endl;
//          }    
    }
    
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&M, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(wt, M+1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(color, M+1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(adj_lg, 502*502, MPI_INT, 0, MPI_COMM_WORLD);
//     MPI_Bcast(&adj, 502*502, MPI_INT, 0, MPI_COMM_WORLD);
    
    
    int flag = 1;
    
    while(flag == 1)
    {
        
//         for(i=1;i<M+1;i++)
//             cout << wt[i] << " ";
//         cout << endl;
        
        int l,r;
        l = rank*(M/numprocs) + 1;
        if(rank != numprocs -1)
        {
            r = rank*(M/numprocs) + M/numprocs;
        }
        else
            r = M;
        
        vector <int> ind;
        
        
        for(i=l;i<=r;i++)
        {
            int flag1 = 0;
            for(j=1;j<M+1;j++)
            {
                if(adj_lg[i][j] == 1 && wt[i] <= wt[j])
                {
                    flag1 =1;
                    break;
                }
            }
            
            if(flag1 == 0)
                ind.push_back(i);
        }
        
        
        
        int changes[2][502];
        int cnt_changes = 0;
        
        for(i=0;i<ind.size();i++)
        {
            set <int> st;
            for(j=1;j<M+1;j++)
                st.insert(j);
            
            for(j=1;j<M+1;j++)
            {
                if(adj_lg[ind[i]][j] == 1)
                    st.erase(color[j]);
            }
            
            color[ind[i]] = *st.begin();
            changes[0][cnt_changes] = ind[i];
            changes[1][cnt_changes] = color[ind[i]];
            cnt_changes++;
            
            wt[ind[i]] = -1;
        }
        
        
        
        for(i=0;i<numprocs;i++)
        {
            if(rank == i)
            {
                int cnt_changes2;
                int changes2[502];        
                int changes3[502];        
                
                cnt_changes2 = cnt_changes;
                for(j=0;j<cnt_changes;j++)
                {
                    changes2[j] = changes[0][j];
                    changes3[j] = changes[1][j];
                }
                
//                 cout << "before " << "rank =" << rank << " cnt_changes2 = " << cnt_changes << endl;
                
//                 for(j=0;j<cnt_changes2;j++)
//                 {
//                     cout << changes2[j] << " " << changes3[j];
//                 }
                
//                 cout << endl;
                
                MPI_Bcast(&cnt_changes2, 1, MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(changes2, cnt_changes, MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(changes3, cnt_changes, MPI_INT, i, MPI_COMM_WORLD);
            }
            else
            {
                int c;
                int d[502];   
                int e[502];   
                
                MPI_Bcast(&c, 1, MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(d, c, MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(e, c, MPI_INT, i, MPI_COMM_WORLD);

//                 cout << "after " << "i = " << i << " rank =" << rank << " cnt_changes2 = " << c << endl;

//                 for(j=0;j<c;j++)
//                 {
//                     cout << d[j] << " " << e[j];
//                 }

//                 cout << endl;

                for(j=0;j<c;j++)
                {
                    color[d[j]] = e[j];
                    wt[d[j]] = -1;
                }   
            }
               
        }
        
//         cout << "color_rank = " <<  rank <<  endl;
        
//         for(i=1;i<M+1;i++)
//             cout << color[i] << " ";
//         cout << endl;
//         break;
        
        flag = 0;
        for(i=1;i<M+1;i++)
        {
            if(color[i] == 0)
            {
                flag = 1;
                break;
            }
        }   
    }
    
    if(rank == 0)
    {
        set <int> st;
        for(i=1;i<M+1;i++)
            st.insert(color[i]);

        MyWriteFile << st.size() << endl;

        for(i=1;i<M+1;i++)
            MyWriteFile << color[i] << " ";
        MyWriteFile <<  endl;
    }
        
    
    MyWriteFile.close();
    MyReadFile.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}