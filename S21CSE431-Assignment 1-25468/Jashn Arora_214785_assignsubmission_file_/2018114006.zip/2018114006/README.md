# Distributed Systems Assignment 1

### Problem 1
- *Description*
To take the sum of N values, these are divided almost equally among all the processes and the root process ercieves the sum of chunks from every process and these values of chunk to give the final output.

- *Analysis*: 
	- For N = 2
		- if np = 1 - Total time (s): 0.000098
		- if np = 11 - Total time (s): 0.000256
	- For N = 10000:
		- if np = 1 - Total time (s): 0.000149
		- if np = 11 - Total time (s): 0.000494
	- Obviously time increases with the increase in value of N
	- Also time increases with increase in the no. of process. It may be the reason that sending and recieving of messages takes time. So more the no. of processes , more the send and recieve events 

---

### Problem 2
- *Description*: 
To sort the array, The main array is divided into chunks and each shunk is sent to one process. Every process sorts the recieved chunk and send it back to the root process. The Root process on recieving all the sorted chunks , merge them to form the sorted main array.
- *Analysis*: 
	- For N = 10 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.000189
		- if np = 5 - Total time (s): 0.000287
		- if np = 11 - Total time (s): 0.008832
	- For N = 10000 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.004325
		- if np = 5 - Total time (s): 0.006534
		- if np = 11 - Total time (s): 0.007786
	- For N = 1000000 and array elements randomly initialized
		- if np = 1 - Total time (s): 0.478232
		- if np = 5 - Total time (s): 0.567823
		- if np = 11 - Total time (s): 0.687657
	- Obviously time increases with the increase in value of N
	- Also time increases with increase in the no. of process. It may be the reason that sending and recieving of messages takes time. So more the no. of processes , more the send and recieve events 
---

### Problem 3
- **Description**:
    - First we draw a line graph of given graph.
    - After getting the line graph, we then random initialize unique weightsto all the vertices.
    - Independent set of vertices are formed by the vertices that are the maximum amongst their uncolored neighbors. 
    - Since they form an independent set, we can color them parallely without any contradiction.
    - To color each node, we take the minimum color which has not been yet assigned to any of its colored neighbors.
    - To parallelize this even further, each process find the independent set of vertices from the set of vertices alooted to it. The color it and inform all the other process about which vertices it colored.
    - Repeat this until all nodes are colored.
- **Analysis**:
    - For N = 5, M = 10 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.000287
        - if np = 3 - Total time (s): 0.003075
        - if np = 11 - Total time (s): 0.008742
    - For N = 80, M = 400 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.004285
        - if np = 3 - Total time (s): 0.003853
        - if np = 11 - Total time (s): 0.009865
    - For N = 100, M = 500 and the graph randomly intialized according to N and M
        - if np = 1 - Total time (s): 0.005864
        - if np = 3 - Total time (s): 0.005264
        - if np = 11 - Total time (s): 0.009754
    - Obviously time increases with the increase in value of N
    - When there are less number of nodes and edges in the graph, time increases with increase in the no. of process. It may be the reason that sending and recieving of messages takes time. So more the no. of processes , more the send and recieve events 
    - When the number of nodes and edges start to increase, we see that the time reduces till some number of processes and then it starts increasing again. It can exploit the benefits of parallelization, but after that the message passing becomes a bottleneck and the time starts to increase again.

---

### Assignment by
- Jashn Arora (2018114006)
	
