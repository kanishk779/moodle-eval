/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
    
    ifstream MyReadFile(argv[1]);
    ofstream MyWriteFile(argv[2]);
    
    int N,i,j;
    
    if(rank == 0)
    {
        string myText;
        getline (MyReadFile, myText);
        
        char t[10];
        strcpy(t, myText.c_str());
        
        N = atoi(t);
        
        for(i=1;i<numprocs;i++)
            MPI_Send(&N,1,MPI_INT,i,i,MPI_COMM_WORLD);
    }
    
//     MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        
    double ans = 0.0;
        
    if(numprocs == 1)
    {
        for(i=1;i<=N;i++)
        {
            ans += 1.0/double(i*i);
        }
        
        MyWriteFile << fixed << setprecision(6) << ans << endl;
    }
    else
    {
        if(rank == 0)
        {
            int send[N];
            double rec = 0.0;
            
            for(i=0;i<N;i++)
            {
                send[i] = i+1;
            }
            
            if(N >= numprocs-1)
            {
                ll x = N/(numprocs-1);

                for(i=1;i<numprocs-1;i++)
                {
                    MPI_Send(send+x*(i-1),x,MPI_INT,i,0,MPI_COMM_WORLD);
                }
               
                ll x_prev = x;
                if(N%(numprocs-1))
                    x = x + (N - (numprocs-1)*x);
                
                i = numprocs-1;
                MPI_Send(send+x_prev*(i-1),x,MPI_INT,i,0,MPI_COMM_WORLD);
                
                for(i=1;i<numprocs;i++)
                {
                    MPI_Recv(&rec, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    ans += rec;
                }
                
                MyWriteFile << fixed << setprecision(6) << ans << endl;
            }
            else 
            {
                ll x = 1;
                for(i=1;i<numprocs;i++)
                {
                    if(i< N+1)
                    {
                        MPI_Send(send+x*(i-1),x,MPI_INT,i,0,MPI_COMM_WORLD);
                    }
                    else
                    {
                        int d = -1;
                        MPI_Send(&d,1,MPI_INT,i,0,MPI_COMM_WORLD);
                    }
                }                
                
                for(i=1;i<numprocs;i++)
                {
                    MPI_Recv(&rec, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    ans += rec;
                }
                
                MyWriteFile << fixed << setprecision(6) << ans << endl;
            }
            
        }
        else
        {
            MPI_Recv(&N,1,MPI_INT,0,rank,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            
            int recieved[N];
            
            if(N >= numprocs-1)
            {
                ll x = N/(numprocs-1);

                if(N%(numprocs-1) && rank == numprocs-1)
                    x = x + (N - (numprocs-1)*x);

                MPI_Recv(recieved,x,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
                double temp = 0.0;

                for(j = 0;j<x;j++)
                {
                    temp += 1.0/double(recieved[j]*recieved[j]);
                }

                MPI_Send(&temp, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

            }
            else
            {
                int a;
                MPI_Recv(&a,1,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                
                double temp = 0.0;
                
                if(rank < N+1)
                {
                    temp += 1.0/double(a*a);
                }

                MPI_Send(&temp, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
            }
            
        }
    }
    
    MyWriteFile.close();
    MyReadFile.close();


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}