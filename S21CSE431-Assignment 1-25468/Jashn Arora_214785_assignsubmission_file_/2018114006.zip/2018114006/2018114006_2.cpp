/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void swap(int *b , int *c)
{
    int temp = *b;
    *b = *c;
    *c = temp;
}

int partition(int *a , int start , int end)
{
    int i,pivtindx = start,pivot = a[end];

    for(i=start;i<end;i++)
    {
        if(a[i] <= pivot)
        {
            swap(&a[i] , &a[pivtindx]);
            pivtindx++;
        }
    }

    swap(&a[pivtindx],&a[end]);

    return(pivtindx);
}

void quicksrt(int *a , int start , int end)
{
    if(start < end)
    {
        int pivotindx = partition(a ,start ,end);
        quicksrt(a,start,pivotindx-1);
        quicksrt(a,pivotindx+1,end);
    }
    
//     return a;
}

void print(vector <int> a , int n)
{
    for(int i=0;i<n;i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}

vector <int> arr2vec(int * a, int lent)
{
    vector <int> v;
    
    for(int i=0;i<lent;i++)
        v.push_back(a[i]);
    
    return v;
}


vector <int> merge(vector< vector <int> > sorted_parts)
{
    vector <int> sorted;
    priority_queue <pair <int, int>, vector < pair <int, int> >, greater <pair <int, int> > > q;
    int lent = sorted_parts.size();
    
    for(int i = 0; i< lent;i++)
    {
        q.push(make_pair(sorted_parts[i].front(),i));
        sorted_parts[i].erase(sorted_parts[i].begin());
    }
    
    while(!q.empty())
    {
        sorted.push_back(q.top().first);
        int sec  = q.top().second;
        q.pop();
        if(sorted_parts[sec].size() > 0)
        {
            q.push(make_pair(sorted_parts[sec].front(),sec));
            sorted_parts[sec].erase(sorted_parts[sec].begin());
        }
        
    }
    
    return sorted;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs);
    
    /*synchronize aint processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ifstream MyReadFile(argv[1]);
    ofstream MyWriteFile(argv[2]);
    
    int N,i,j,arr_send[1000008];
    
    if(rank == 0)
    {
//      Reading the value of N
        string myText;
        getline (MyReadFile, myText);
        char t[10];
        strcpy(t, myText.c_str());
        N = atoi(t);
        
//      Reading the array elements
        getline (MyReadFile, myText);
        char t1[30000000];
        strcpy(t1, myText.c_str());
        
        char *token = strtok(t1, " ");
        
        i = 0;
        
        while (token != NULL)
        {
            arr_send[i] = atoi(token);
            i++;
            token = strtok(NULL, " ");
        }
        
//         print(arr2vec(arr_send,N),N);
        
        for(i=1;i<numprocs;i++)
            MPI_Send(&N,1,MPI_INT,i,i,MPI_COMM_WORLD);
    }
    
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        
    double ans = 0.0;
        
    if(numprocs == 1)
    {
       quicksrt(arr_send,0,N-1);
        for(int i=0;i<N;i++)
        {
            MyWriteFile << arr_send[i] << " ";
        }
        MyWriteFile << endl;
//        print(arr2vec(arr_send,N),N);
    }
    else
    {
        if(rank == 0)
        {
            
            vector < vector <int> > sorted_parts;
            
            if(N > numprocs-1)
            {
//                 sending
                int x = N/(numprocs-1);

                for(i=1;i<numprocs-1;i++)
                {
                    MPI_Send(arr_send+x*(i-1),x,MPI_INT,i,0,MPI_COMM_WORLD);
                }
               
                int x_prev = x;
                if(N%(numprocs-1))
                    x = x + (N - (numprocs-1)*x);
                
                i = numprocs-1;
                MPI_Send(arr_send+x_prev*(i-1),x,MPI_INT,i,0,MPI_COMM_WORLD);
                
//                 recieving
                
                x = N/(numprocs-1);

                for(i=1;i<numprocs-1;i++)
                {
                    int rec[x];
                    MPI_Recv(&rec, x, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    sorted_parts.push_back(arr2vec(rec,x));
                }
               
                x_prev = x;
                if(N%(numprocs-1))
                    x = x + (N - (numprocs-1)*x);
                
                i = numprocs-1;
                int rec[x];
                MPI_Recv(&rec, x, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                sorted_parts.push_back(arr2vec(rec,x));

//                 merging
                
                vector <int> sorted = merge(sorted_parts); 
                for(int i=0;i<N;i++)
                {
                    MyWriteFile << sorted[i] << " ";
                }
                MyWriteFile << endl;
                
//                 print(merge(sorted_parts),N);
                
            }
            else
            {
                quicksrt(arr_send,0,N-1);
                for(int i=0;i<N;i++)
                {
                    MyWriteFile << arr_send[i] << " ";
                }
                MyWriteFile << endl;
//                 print(arr2vec(arr_send,N),N);
            }
        }
        else
        {
            MPI_Recv(&N,1,MPI_INT,0,rank,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
//             cout << "rank = " << rank << " " << "N = " << N << endl;
            
            
            
            if(N > numprocs-1)
            {
                int x = N/(numprocs-1);

                if(N%(numprocs-1) && rank == numprocs-1)
                    x = x + (N - (numprocs-1)*x);
                
//                 recieving
                int recieved[x];
                MPI_Recv(recieved,x,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
//                 cout << "rank = " << rank << " " << "x = " << x << " " << "recieved = ";
//                 print(recieved,x);
                
//                 sorting
                quicksrt(recieved,0,x-1);
                
//                 sending
//                 cout << "rank = " << rank << " " << "sent = ";
//                 print(recieved,x);
                MPI_Send(recieved, x, MPI_INT, 0, 0, MPI_COMM_WORLD);

            }
        }
    }

    MyWriteFile.close();
    MyReadFile.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}