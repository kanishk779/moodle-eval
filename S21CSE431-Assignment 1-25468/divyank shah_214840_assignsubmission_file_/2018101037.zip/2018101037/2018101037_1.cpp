/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{

    int rank, numprocs;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    // / synchronize all processes /
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int N = -1, ind = 0;

    string myText, inp, out;

    inp = argv[1];
    ifstream MyReadFile(inp);
    getline(MyReadFile, myText);
    N = stoi(myText);


    // double ans = 1; //for 0th process

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    int l = 1, perproc = N / numprocs;

    if (rank == 0)
    {

        for (int i = 1; i < numprocs; i++)
        {
            int buffer_sent[2];
            buffer_sent[0] = l;
            buffer_sent[1] = l + perproc - 1;
            l += perproc;
            MPI_Send(buffer_sent, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
    }
    else
    {
        int received[2];
        MPI_Recv(received, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        double ans = 0;

        for (int i = received[0]; i <= received[1]; i++)
            ans = ans + (1 / ((double)(i * i)));

        MPI_Send(&ans, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }
    double ans = 0;
    if (rank == 0)
    {

        for (int i = l; i <= N; i++)
            ans = ans + 1 / ((double)(i * i));

        for (int i = 1; i < numprocs; i++)
        {
            double temp;
            MPI_Recv(&temp, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            ans += temp;
        }
    }
    if (rank == 0)
    {

        ofstream MyFile(argv[2]);

        // Write to the file
        MyFile << fixed << setprecision(6) << ans << endl;

        // Close the file
        MyFile.close();
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}