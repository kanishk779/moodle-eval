# Question 1:

```
For the first question, the 0th process divided the range [1,N] in NUMPROCS parts, and sent each of the processess the range [l,r] for which they have to do the computation, and received the result, added them to get the overall answer. 
```


# Question 2:
```
For this question, the 0th process divided the range [1,N] in NUMPROCS subarrays, and sent each of the processess the subarray which they had to sort, then the processess send the sorted subarrays to the 0th process, and the 0th process merges these NUMPROCS subarrays using the heap method for merging k subarrays, whose complexity is O(N*ln(NUMPROCS)) .
```


# Question 3:

```
For this question, firsly I converted the given edge coloring problem to a vertex coloring problem by creating a line graph of the input graph, in which each vertex will be the edges of origional graph,which will be connected only if the edges shared a vertex in the origional graph. Now for solving this vertex coloring problem I used an Iterative Greedy strategy, using the algorithm which is attached below. Firstly I distributed the vertices in the line graph to each processes, which will assign for each vertex the minmum color which is not yet assigned to its neighbours, than each process sends this assignments to the 0th process, which if two newly colored vertices have same colors than it will uncolor one of them, and hence in each iteration atleast one new vertex will be colored, hence worst case complexity of this algorithm is O(M*(Edges of the line graph)) and the number of colors will be bounded by Delta(Linegraph)+1.
```
## Algorithm used
![Algorithm](./algo.png)
