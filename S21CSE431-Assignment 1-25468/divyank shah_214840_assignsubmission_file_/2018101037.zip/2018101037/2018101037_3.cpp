/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;
typedef long long int ll;

//colors will start from zero
vector<int> try_error(int curr[], set<int> g[], int m1, int size, int colorVertex[]) // color = -1 signifies that the edge is not yet coloured;
{
    vector<int> ret(size, 0);
    map<int, bool> m;
    for (int i = 0; i < size; i++)
    {
        m.clear();
        int cv = curr[i];
        // cout << "cv " << cv << endl;
        for (auto j : g[cv])
        {
            m[colorVertex[j]] = 1; // this vertex cannot take same colors
            // cout << "found " << j << " " << colorVertex[j] << endl;
        }
        for (int j = 0; j < m.size() + 1; j++)
        {
            if (m.find(j) == m.end())
            {
                ret[i] = j;
                break;
            }
        }
    }
    return ret;
}

int main(int argc, char **argv)
{
    int rank, numprocs;
    int ans = 0;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    // / synchronize all processes /
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */

    //----------------------------------------------------------------------------------------------------------------------------------------------------
    ifstream MyReadFile(argv[1]);

    int n, m;
    MyReadFile >> n >> m;
    map<int, pair<int, int>> ind; // ind of each edge
    for (int i = 0; i < m; i++)
    {
        int x, y;
        MyReadFile >> x >> y;
        ind[i] = make_pair(x, y);
    }
    set<int> g[m]; // g is the line graph of the given graph
    for (int i = 0; i < m; i++)
    {
        for (int j = i + 1; j < m; j++)
        {
            if (i == j)
                continue;
            int x1 = ind[i].first, y1 = ind[i].second, x2 = ind[j].first, y2 = ind[j].second;
            if (x1 == x2 || y1 == x2 || x1 == y2 || y1 == y2)
            {
                g[i].insert(j);
                g[j].insert(i);
            }
        }
    }
    // if (rank == 0)
    // {
    //     cout << "the line graph is " << endl;
    //     for (int i = 0; i < m; i++)
    //     {
    //         for (auto j : g[i])
    //             cout << j << " ";
    //         cout << endl;
    //     }
    // }
    if (rank == 0)
    {
        // int color = 0;
        int are_others_exited = 0;
        int colorVertex[m], is_done[m]; //color of each vertex
        for (int i = 0; i < m; i++)
        {
            colorVertex[i] = -1;
            is_done[i] = 0;
        }

        int rem = 1000000;
        while (rem)
        {
            rem = 0;
            for (int i = 0; i < m; i++)
                rem += !is_done[i];
            if (!rem)
                break;
            // if(!rem)
            int curr[rem], flag[rem];
            for (int i = 0, j = 0; i < m; i++)
            {
                if (!is_done[i])
                {
                    curr[j] = i;
                    flag[j] = 0;
                    j++;
                }
            }
            // cout << "remaining " << rem << endl;
            // for (int i = 0; i < rem; i++)
            //     cout << curr[i] << " ";
            // cout << endl;
            vector<int> color_middle(m, 0);
            for (int i = 0; i < m; i++)
                color_middle[i] = colorVertex[i];
            int perproc = rem / numprocs, l = 0;
            if (perproc != 0)
            {
                for (int i = 1; i < numprocs; i++, l += perproc)
                {
                    MPI_Send(&perproc, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
                }

                for (int i = 1, l = 0; i < numprocs; i++, l += perproc)
                {
                    MPI_Send(curr + l, perproc, MPI_INT, i, 0, MPI_COMM_WORLD);
                }
                for (int i = 1; i < numprocs; i++)
                    MPI_Send(colorVertex, m, MPI_INT, i, 0, MPI_COMM_WORLD);

                for (int i = 1, l = 0; i < numprocs; i++, l += perproc)
                {
                    int color_temp[perproc];
                    MPI_Recv(&color_temp, perproc, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    // cout << "from process " << i << endl;
                    for (int j = 0; j < perproc; j++)
                    {

                        int ind = curr[j + l];
                        // cout << ind << " " << flag_temp[i] << endl;
                        color_middle[ind] = color_temp[j];
                        // if (flag_temp[i])
                        // colorVertex[ind] = color;
                    }
                }
            }
            else // if a process receives perproc == 0 than it will stop communicating
            {
                are_others_exited = 1;
                int zero = 0;
                for (int i = 1; i < numprocs; i++)
                {
                    MPI_Send(&zero, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
                }
            }
            // cout << "l is " << l << endl;
            int cs = perproc + rem % numprocs;
            int color_temp[cs];
            vector<int> ret = try_error(curr + l, g, m, cs, colorVertex);
            for (int i = 0; i < cs; i++)
                color_temp[i] = ret[i];
            // cout << "from process " << 0 << endl;

            for (int i = 0; i < cs; i++)
            {
                int ind = curr[i + l];
                color_middle[ind] = color_temp[i];
                // is_done[ind] = flag_temp[i];
                // cout << ind << " " << flag_temp[i] << endl;

                // if (flag_temp[i])
                // colorVertex[ind] = color;
            }
            // cout << "before" << endl;
            // for (int i = 0; i < m; i++)
            //     cout << color_middle[i] << " ";
            // cout << endl;
            // for (int i = 0; i < m; i++)
            //     cout << is_done[i] << " ";
            // cout << endl;
            for (int i = 0; i < m; i++)
            {
                for (auto j : g[i])
                {
                    if ((color_middle[i] == color_middle[j]) && color_middle[i] != -1)
                    {
                        // if (is_done[i] || is_done[j])
                        //     cout << "Major error" << endl;
                        color_middle[j] = -1;
                    }
                }
            }
            for (int i = 0; i < m; i++)
            {
                colorVertex[i] = color_middle[i];
                if (colorVertex[i] != -1)
                    is_done[i] = 1;
            }
            // cout << "after" << endl;
            // for (int i = 0; i < m; i++)
            //     cout << colorVertex[i] << " ";
            // cout << endl;
            // for (int i = 0; i < m; i++)
            //     cout << is_done[i] << " ";
            // cout << endl;

            // color++;
        }
        if (are_others_exited == 0)
        {
            are_others_exited = 1;

            are_others_exited = 1;
            int zero = 0;
            for (int i = 1; i < numprocs; i++)
            {
                MPI_Send(&zero, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            }
        }

        map<int, bool> x;
        int max1 = 0;
        map<int, bool> chk[n + 1];
        for (int i = 0; i < m; i++)
        {
            // max1 = max(max1, colorVertex[i]);
            x[colorVertex[i]] = 1;
        }
        // for (int i = 0; i < m; i++)
        // {
        //     int x = ind[i].first, y = ind[i].second, c = colorVertex[i];
        //     if (chk[x].find(c) != chk[x].end() || chk[y].find(c) != chk[y].end())
        //         cout << "Major error" << endl;
        //     chk[x][c] = 1;
        //     chk[y][c] = 1;
        // }
        ofstream MyFile(argv[2]);

        // Write to the file
        // cout << max1 << " " << x.size() << endl;
        MyFile << x.size() << endl;
        for (int i = 0; i < m; i++)
            MyFile << colorVertex[i] + 1 << " ";
        MyFile << endl;
        // Close the file
        MyFile.close();

        // for (int i = 0; i < m; i++)
        // cout << colorVertex[i] << endl;
    }
    else
    {
        while (1)
        {
            int perproc;
            int colorVertex[m];
            MPI_Recv(&perproc, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (!perproc)
                break;
            int curr[perproc];
            MPI_Recv(&curr, perproc, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            MPI_Recv(&colorVertex, m, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            int flag_temp[perproc];
            vector<int> ret = try_error(curr, g, m, perproc, colorVertex);
            for (int i = 0; i < perproc; i++)
                flag_temp[i] = ret[i];
            MPI_Send(&flag_temp, perproc, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}