/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
vector<int> merge_sorted(int N, int numprocs, int a[], char **argv)
{
    vector<int> ret;
    vector<pair<int, int>> ind;
    int l = 0;
    int perproc = N / numprocs;
    if (perproc == 0)
    {
        for (int i = 0; i < N; i++)
            ret.push_back(a[i]);

        ofstream MyFile(argv[2]);

        // Write to the file
        for (int i = 0; i < N; i++)
            MyFile << ret[i] << " ";
        MyFile << endl;
        // Close the file
        MyFile.close();
        return ret;
    }
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    for (int i = 0; i < numprocs - 1; i++, l += perproc)
    {

        pq.push(make_pair(a[l], i));
        ind.push_back(make_pair(l + 1, l + perproc));
    }
    pq.push(make_pair(a[l], numprocs - 1));
    ind.push_back(make_pair(l + 1, N));
    while (!pq.empty())
    {
        pair<int, int> p = pq.top();
        int val = p.first, id = p.second;
        ret.push_back(val);
        if (ind[id].first < ind[id].second)
        {
            pq.push(make_pair(a[ind[id].first], id));
            ind[id].first++;
        }
        pq.pop();
    }
    ofstream MyFile(argv[2]);

    // Write to the file
    for (int i = 0; i < N; i++)
        MyFile << ret[i] << " ";
    MyFile << endl;
    // Close the file
    MyFile.close();
    return ret;
}
int part(int arr[], int l, int r)
{
    if (l > r)
        return -1;
    int key = arr[l];
    int l1 = l + 1, r1 = r;
    while (l1 <= r1)
    {
        if (arr[l1] < key)
            l1++;
        else if (arr[r1] >= key)
            r1--;
        else if (arr[l1] >= key && arr[r1] < key)
            std::swap(arr[l1], arr[r1]);
    }
    int l0 = l;
    int i = l + 1;
    while (i <= r && arr[i] < arr[l])
    {
        std::swap(arr[i], arr[l]);
        l = i;
        i++;
    }
    return l;
}

void quicksort(int arr[], int l, int r)
{

    if (l >= r)
        return;
    int par = part(arr, l, r);

    if (par >= l)
        quicksort(arr, l, par);
    if (par + 1 <= r)
        quicksort(arr, par + 1, r);
}

int main(int argc, char **argv)
{
    int rank, numprocs;
    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    // /synchronize all processes/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int N = -1, ind = 0;
    string myText;
    ifstream MyReadFile(argv[1]);

    getline(MyReadFile, myText);
    N = stoi(myText);
    int arr[N];
    for (int i = 0; i < N; i++)
        MyReadFile >> arr[i];
    MyReadFile.close();

    int l = 0;
    if (rank == 0)
    {
        int per_proc = N / numprocs;

        for (int i = 1; i < numprocs; i++, l += per_proc)
            MPI_Send(arr + l, per_proc, MPI_INT, i, 0, MPI_COMM_WORLD);
    }
    else
    {
        int received[N / numprocs];
        MPI_Recv(received, N / numprocs, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        if (N / numprocs)
            quicksort(received, 0, N / numprocs - 1);
        MPI_Send(received, N / numprocs, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    if (rank == 0)
    {
        // cout << l << " " << N - 1 << endl;
        // for (int i = l; i < N; i++)
        //     cout << arr[i] << " ";
        // cout << endl;
        quicksort(arr, l, N - 1);
        l = 0;
        // for (int i = l; i < N; i++)
            // cout << arr[i] << " ";
        // cout << endl;

        for (int i = 1; i < numprocs; i++, l += N / numprocs)
        {
            MPI_Recv(arr + l, N / numprocs, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        merge_sorted(N, numprocs, arr, argv);
        // for (int i = l; i < N; i++)
            // cout << arr[i] << " ";
        // cout << endl;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {

        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}