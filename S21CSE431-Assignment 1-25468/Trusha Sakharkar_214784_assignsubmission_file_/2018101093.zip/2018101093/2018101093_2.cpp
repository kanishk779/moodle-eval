#include <bits/stdc++.h>
#include <mpi.h>
using namespace std;
void pqs(vector<int> &primary_arr,int my_rank, int pool_start, int pool_size)
{
    if (pool_size == 0)
		return;
	if (pool_size == 1)
	{
		sort(primary_arr.begin(), primary_arr.end());
		return;
	}
    int i,j,temp,part;
    int lowerhalf=0;
    if (my_rank < pool_start + pool_size / 2)
        lowerhalf=1;
	int	pivot = 0;
	if (my_rank == pool_start)
	{
        if(primary_arr.size())
            pivot=primary_arr[0];
		for (i = 0; i < pool_size; i++)
			if (i + pool_start != my_rank)
				MPI_Send(&pivot, 1, MPI_INT, i + pool_start, 0, MPI_COMM_WORLD);
	}
	else
		MPI_Recv(&pivot, 1, MPI_INT, pool_start, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    i = 0;
	for (j = 0; j < primary_arr.size(); ++j)
	{
        if (primary_arr[j] <= pivot)
		{
            temp=primary_arr[i];
            primary_arr[i]=primary_arr[j];
            primary_arr[j]=temp;
			i++;
		}
    }
    part=i;
	vector<int> send_arr, get_arr, temp_arr;
	if (lowerhalf)
	{
        for(i=0;i<part;i++)
            send_arr.push_back(primary_arr[i]);
        for(i=part;i<primary_arr.size();i++)
            temp_arr.push_back(primary_arr[i]);
        primary_arr=temp_arr;

		int send_size = send_arr.size(), get_size;

		MPI_Send(&send_size, 1, MPI_INT, my_rank + pool_size / 2, 0, MPI_COMM_WORLD);
		MPI_Send(&send_arr.front(), send_size, MPI_INT, my_rank + pool_size / 2, 0, MPI_COMM_WORLD);
		
        MPI_Recv(&get_size, 1, MPI_INT, my_rank + pool_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		get_arr.resize(get_size);
		MPI_Recv(&get_arr.front(), get_size, MPI_INT, my_rank + pool_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}
	else if (pool_size % 2 == 0 || my_rank != pool_start + pool_size - 1)
	{
         for(i=0;i<part;i++)
            temp_arr.push_back(primary_arr[i]);
        for(i=part;i<primary_arr.size();i++)
            send_arr.push_back(primary_arr[i]);
        primary_arr=temp_arr;

		int send_size = send_arr.size(), get_size;

		MPI_Recv(&get_size, 1, MPI_INT, my_rank - pool_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		get_arr.resize(get_size);
		MPI_Recv(&get_arr.front(), get_size, MPI_INT, my_rank - pool_size / 2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		MPI_Send(&send_size, 1, MPI_INT, my_rank - pool_size / 2, 0, MPI_COMM_WORLD);
		MPI_Send(&send_arr.front(), send_size, MPI_INT, my_rank - pool_size / 2, 0, MPI_COMM_WORLD);
	}
    temp_arr.clear();
	primary_arr.insert(primary_arr.end(), get_arr.begin(), get_arr.end());

    if (pool_size % 2 != 0 && my_rank == pool_start)
	{
		int get_size;
		MPI_Recv(&get_size, 1, MPI_INT, pool_size + pool_start - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		get_arr.resize(get_size);
		MPI_Recv(&get_arr.front(), get_size, MPI_INT, pool_size + pool_start - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		primary_arr.insert(primary_arr.end(), get_arr.begin(), get_arr.end());
	}
	else if (pool_size % 2 != 0 && my_rank == pool_size + pool_start - 1)
	{
        for(i=0;i<part;i++)
            temp_arr.push_back(primary_arr[i]);
        for(i=part;i<primary_arr.size();i++)
            send_arr.push_back(primary_arr[i]);
        primary_arr=temp_arr;

		int send_size = send_arr.size();

		MPI_Send(&send_size, 1, MPI_INT, pool_start, 0, MPI_COMM_WORLD);
		MPI_Send(&send_arr.front(), send_size, MPI_INT, pool_start, 0, MPI_COMM_WORLD);
	}

	if (!lowerhalf)
		pqs(primary_arr, my_rank, pool_start + pool_size / 2, pool_size - pool_size / 2);
	else
		pqs(primary_arr, my_rank, pool_start, pool_size / 2);
}

int main(int argc, char *argv[])
{
	MPI_Init(&argc, &argv);
	int size, my_rank,i;
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	if (argc<3 || argc>3)
		MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);

	vector<int> primary_arr;
	int primary_arr_size;

	if (my_rank == 0)
	{
		ifstream in(argv[1]);
		auto cinbuf = cin.rdbuf(in.rdbuf());

		int x,n,k;
		vector<vector<int>> arr(size);
		arr.clear();
		cin >> n;
		for (i = 0; i < n; i++)
		{
			cin >> x;
            k=i%size;
			arr[k].push_back(x);
		}
		primary_arr = arr[0];
		for (i=0;i<size-1;i++)
		{
			int primary_arr_size = arr[i+1].size();
			MPI_Send(&primary_arr_size, 1, MPI_INT, i+1, 0, MPI_COMM_WORLD);
			MPI_Send(&arr[i+1][0], primary_arr_size, MPI_INT, i+1, 0, MPI_COMM_WORLD);
		}
	}
	else
	{
		int primary_arr_size;
		MPI_Recv(&primary_arr_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		primary_arr.resize(primary_arr_size);
		MPI_Recv(&primary_arr.front(), primary_arr_size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	pqs(primary_arr, my_rank, 0, size);
    primary_arr_size = primary_arr.size();
	if (my_rank == 0)
	{
		vector<int> get_arr, ret;
		ofstream cout(argv[2]);
		for (i = size - 1; i > 0; i--)
		{
			MPI_Recv(&primary_arr_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			get_arr.resize(primary_arr_size);
			MPI_Recv(&get_arr.front(), primary_arr_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			for (auto i : get_arr)
				cout << i << endl;
		}
		for (i=0;i<primary_arr.size();i++)
			cout << primary_arr[i] << endl;
	}
	else
	{
		MPI_Send(&primary_arr_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
		MPI_Send(&primary_arr.front(), primary_arr_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Finalize();
	return EXIT_SUCCESS;
}
