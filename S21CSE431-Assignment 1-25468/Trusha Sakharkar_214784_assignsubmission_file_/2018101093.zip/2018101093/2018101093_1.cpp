#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    double reduction_result = 0,buffer=0;
    ifstream in(argv[1]);
	auto cinbuf = cin.rdbuf(in.rdbuf());
    int N,a;
    cin>>N;

    if (argc<3 || argc>3)
		MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    
    int s=numprocs,i;
    int my_rank=rank;
    int q=N/s;
    if(N%s!=0)
        q++;
    for(i=0;i<q;i++)
    {
        a=(my_rank+1)+i*s;
        if(a>N)
            break;
        a*=a;
        buffer+=(double)(1.0/a);
    }
    MPI_Reduce(&buffer, &reduction_result, 1, MPI_DOUBLE, MPI_SUM,0, MPI_COMM_WORLD);

    if(my_rank==0)
    {
		ofstream cout(argv[2]);
      //  std::cout << std::fixed;
        cout<<std::setprecision(7)<<reduction_result<<endl;
        //doesn't work for 6 decimal paces

      // printf("%lf", reduction_result);
    }
    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
// int main(int argc, char* argv[])
// {
//     MPI_Init(&argc, &argv);
//     int root_rank = 0;
//     int size = 0;
//     int my_rank;
//     double reduction_result = 0,buffer=0;
//     ifstream in(argv[1]);
// 	auto cinbuf = cin.rdbuf(in.rdbuf());
//     int N,a;
//     cin>>N;

//     if (argc<3 || argc>3)
// 		MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);

//     MPI_Comm_size(MPI_COMM_WORLD, &size);
//     MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

//     int s=size,i;
//     int q=N/s;
//     if(N%s!=0)
//         q++;
//     for(i=0;i<q;i++)
//     {
//         a=(my_rank+1)+i*s;
//         if(a>N)
//             break;
//         a*=a;
//         buffer+=(double)(1.0/a);
//     }
//     MPI_Reduce(&buffer, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, root_rank, MPI_COMM_WORLD);

//     if(my_rank==root_rank)
//     {
// 		ofstream cout(argv[2]);
//       //  std::cout << std::fixed;
//         cout<< setprecision(6) <<reduction_result<<endl;
//         //doesn't work for 6 decimal paces

//        printf("%lf", reduction_result);
//     }
//     MPI_Finalize(); 
//     return EXIT_SUCCESS;
// }

