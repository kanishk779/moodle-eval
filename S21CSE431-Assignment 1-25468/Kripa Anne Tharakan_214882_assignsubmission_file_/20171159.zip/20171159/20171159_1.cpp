/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int min(int a, int b)
{
    return a<b?a:b;
}
int max(int a, int b)
{
    return a>b?a:b;
}

int main( int argc, char **argv ) 
{
    int rank, numprocs, sender;
    MPI_Status status;
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_process = 0;
    if (rank == root_process)
    {
        int n = 2;
        ifstream inpfile;
        inpfile.open(argv[1]);
        inpfile >> n; 
        inpfile.close();

        int numprocs2 = min(numprocs, n);
        MPI_Bcast(&numprocs2, 1, MPI_INT, 0, MPI_COMM_WORLD);
        for(int i = 1; i < numprocs2; i++) 
        {
            int arr[2];
            arr[0] = (n/numprocs2)*(i-1);
            if (i==numprocs2-1) arr[1] = n-arr[0];
            else arr[1] = n/numprocs2;
            MPI_Send( arr, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
         }

         /* and, finally, I collet the partial sums from the slave processes, 
          * print them, and add them to the grand sum, and print it */
         double partial_sum = 0, sum = 0;
         for(int i = 1; i < numprocs2; i++) 
        {
            MPI_Recv(&partial_sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            sender = status.MPI_SOURCE;
            // printf("Partial sum %f returned from process %i\n", partial_sum, sender);
            sum += partial_sum;
         }
         // printf("The grand total is: %.6f\n", sum);
         ofstream opfile;
         opfile.open(argv[2]);
         opfile << sum;
         opfile.close();
    }
    else
    {
    	int numprocs2;
        MPI_Bcast(&numprocs2, 1, MPI_INT, 0, MPI_COMM_WORLD);
    	if(rank < numprocs2)
    	{
	        int arr[2];
	        MPI_Recv(arr, 2, MPI_INT, root_process, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	        double psum = 0.0;
	        for (int i=arr[0]+1; i<=arr[0]+arr[1]; i++)
	            psum+=1.0/(i*i);
	        MPI_Send( &psum, 1, MPI_DOUBLE, root_process, 0, MPI_COMM_WORLD);
	    }

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}