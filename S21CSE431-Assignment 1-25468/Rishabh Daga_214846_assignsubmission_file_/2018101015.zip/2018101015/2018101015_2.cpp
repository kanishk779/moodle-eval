/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int partition (int arr[], int low, int high) {

    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] < arr[high]) {
            i++;
            arr[j] = (arr[i] + arr[j]) - (arr[i] = arr[j]);
        }
    }
    arr[high] = (arr[i+1] + arr[high]) - (arr[i+1] = arr[high]);
    return ++i;
}

void quickSort(int arr[], int low, int high) {
    if (low >= high)
        return;
    int pi = partition(arr, low, high);
    quickSort(arr, low, pi - 1);
    quickSort(arr, pi + 1, high);
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );

    double tbeg = MPI_Wtime();

    /* write your code here */

    if (rank == 0) {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        int N;
        input_file >> N;
        int unsorted_arr[N];
        for(int i = 0; i < N; i++)
            input_file >> unsorted_arr[i];
        input_file.close();

        vector<queue<int>> intermediate_sorted_arr(numprocs);
        int chunk_size = N / numprocs, extra = N % numprocs;
        int sorted_arr[N];

        int first_arr[chunk_size + extra];
        for (int i = 0; i < chunk_size + extra; i++)
            first_arr[i] = unsorted_arr[i];
        quickSort(first_arr, 0, chunk_size + extra - 1);
        for (int i = 0; i < chunk_size + extra; i++)
            intermediate_sorted_arr[0].push(first_arr[i]);

        for (int i = 1; i < numprocs; i++) {
            MPI_Send(&N, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(unsorted_arr + (i * chunk_size) + extra, chunk_size, MPI_INT, i, 1, MPI_COMM_WORLD);
        }
        for (int i = 1; i < numprocs; i++) {
            int temp_arr[chunk_size];
            MPI_Recv(temp_arr, chunk_size, MPI_INT, i, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (int j = 0; j < chunk_size; j++)
                intermediate_sorted_arr[i].push(temp_arr[j]);
        }
        priority_queue <pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
        for (int i = 0; i < numprocs; i++) {
            if (!intermediate_sorted_arr[i].empty()) {
                pq.push({intermediate_sorted_arr[i].front(), i});
                intermediate_sorted_arr[i].pop();
            }
        }
        for(int k = 0; k < N;) {
            int index = pq.top().second;
            sorted_arr[k++] = pq.top().first;
            pq.pop();
            if (!intermediate_sorted_arr[index].empty()) {
                pq.push({intermediate_sorted_arr[index].front(), index});
                intermediate_sorted_arr[index].pop();
            }
        }

        ofstream outfile(argv[2]);
        for(int i = 0; i < N; i++) {
            outfile << sorted_arr[i];
            if (i != N-1)
                outfile << " ";
        }
        outfile.close();

    }
    else {
        int N;
        MPI_Recv(&N, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int chunk_size = N / numprocs;
        int temp_arr[chunk_size];
        MPI_Recv(temp_arr, chunk_size, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        quickSort(temp_arr, 0, chunk_size - 1);
        MPI_Send(temp_arr, chunk_size, MPI_INT, 0, 2, MPI_COMM_WORLD);
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double maxTime, elapsedTime = MPI_Wtime() - tbeg;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if (rank == 0) {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}