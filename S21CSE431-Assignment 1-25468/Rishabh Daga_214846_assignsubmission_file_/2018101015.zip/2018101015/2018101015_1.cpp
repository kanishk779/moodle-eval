/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);

    /* write your code here */

    fstream input_file;
    input_file.open(argv[1], ios::in);
    int N;
    input_file >> N;
    input_file.close();

    double tbeg = MPI_Wtime();

    double local_sum = 0;

    if (rank) {
        MPI_Recv(&N, 1, MPI_INT, 0, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int last = (rank + 1) * (N / numprocs);
        if (rank == numprocs-1)
            last = N;
        for (int i = rank * (N / numprocs) + 1; i <= last; i++)
            local_sum += (1. / (i * i));
        MPI_Send(&local_sum, 1, MPI_DOUBLE, 0,rank, MPI_COMM_WORLD);
    }
    else {
        for (int i = 1; i <= (N / numprocs); i++)
            local_sum += (1. / (i * i));
        for (int i = 1; i < numprocs; i++)
            MPI_Send(&N, 1, MPI_INT, i,0, MPI_COMM_WORLD);
        for (int i = 1; i < numprocs; i++) {
            double proc_ans = 0;
            MPI_Recv(&proc_ans, 1, MPI_DOUBLE, i, MPI_ANY_TAG,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            local_sum+=proc_ans;
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);
    double maxTime, elapsedTime = MPI_Wtime() - tbeg;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (!rank) {
        printf("Total time (s): %f\n", maxTime);

        ofstream outfile(argv[2]);
        outfile << fixed << setprecision(6) << local_sum << endl;
        outfile.close();
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}