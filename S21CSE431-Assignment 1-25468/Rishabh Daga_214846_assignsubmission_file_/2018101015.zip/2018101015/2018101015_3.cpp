/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    int v, E;

    if (rank == 0) {

        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> v >> E;
        int edges[E + 1][2];
        for (int i = 0; i < E; ++i)
            input_file >> edges[i][0] >> edges[i][1];
        input_file.close();

        MPI_Bcast(&E, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&edges, (E + 1) * 2, MPI_INT, 0, MPI_COMM_WORLD);

        vector<vector<int>> adj;

        adj.resize(E + 1);
        for (int i = 0; i < E; ++i) {
            for (int j = 0; j < E; j++) {
                if ((edges[i][1] == edges[j][1] || edges[i][1] == edges[j][0] || edges[i][0] == edges[j][1] || edges[i][0] == edges[j][0]) && i != j)
                    adj[i + 1].push_back(j + 1);
            }
        }
        int chunk_size = E / numprocs, start = rank * chunk_size + 1, end = (rank + 1) * chunk_size;
        if (rank == numprocs - 1)
            end = E;
        int total = 0, num[E + 1];
        bool assigned[E + 1];

        for (int i = 0; i <= E; ++i) {
            assigned[i] = false;
            num[i] = i;
        }

        while (total < E) {
            MPI_Bcast(&total, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&num, E + 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&assigned, E + 1, MPI_INT, 0, MPI_COMM_WORLD);

            vector<int> current;
            for (int i = start; i <= end; ++i) {
                if (assigned[i] == false) {
                    bool flag = true;
                    for (int j = 0; j < adj[i].size(); j++) {
                        if (adj[i][j] > i && assigned[adj[i][j]] == false) {
                            flag = false;
                            break;
                        }
                    }
                    if (flag)
                        current.push_back(i);
                }
            }
            total += current.size();
            for (int i = 0; i < current.size(); ++i) {
                map<int, int> m;
                for (int j = 0; j < adj[current[i]].size(); j++) {
                    int k = adj[current[i]][j];
                    if (assigned[k] == true)
                        m[num[k]]++;
                }
                int j;
                for (j = 1; m[j]; j++);
                assigned[current[i]] = true;
                num[current[i]] = j;
            }
            for (int i = 1; i < numprocs; ++i) {
                int update_size;
                MPI_Recv(&update_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                total += update_size;
                int updates[update_size + 1][2];
                MPI_Recv(&updates, update_size * 2, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                for (int j = 0; j < update_size; j++) {
                    num[updates[j][0]] = updates[j][1];
                    assigned[updates[j][0]] = true;
                }
            }
        }
        MPI_Bcast(&total, 1, MPI_INT, 0, MPI_COMM_WORLD);
        set<int> ss;
        for (int i = 1; i <= E; ++i)
            ss.insert(num[i]);

        ofstream outfile(argv[2]);
        outfile << ss.size() << endl;
        for (int i = 1; i <= E; ++i)
            outfile << num[i] << " ";
        outfile << endl;
        outfile.close();
    }
    else {

        MPI_Bcast(&E, 1, MPI_INT, 0, MPI_COMM_WORLD);
        int edges[E + 1][2];
        MPI_Bcast(&edges, (E + 1) * 2, MPI_INT, 0, MPI_COMM_WORLD);

        vector<vector<int>> adj;
        adj.resize(E + 1);
        for (int i = 0; i < E; ++i) {
            for (int j = 0; j < E; j++) {
                if (edges[i][1] == edges[j][0] || edges[i][0] == edges[j][0] || edges[i][1] == edges[j][1] || edges[i][0] == edges[j][1])
                    adj[i + 1].push_back(j + 1);
            }
        }

        bool assigned[E + 1];
        int num[E + 1];
        int total = 0, chunk_size = E / numprocs, start = rank * chunk_size + 1, end = start * chunk_size;
        if (rank == numprocs - 1)
            end = E;

        while (total < E) {
            MPI_Bcast(&total, 1, MPI_INT, 0, MPI_COMM_WORLD);
            if (total >= E)
                break;
            MPI_Bcast(&num, E + 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&assigned, E + 1, MPI_INT, 0, MPI_COMM_WORLD);

            vector<int> current;
            for (int i = start; i <= end; ++i) {
                if (assigned[i] == false) {
                    bool flag = true;
                    for (int j = 0; j < adj[i].size(); j++) {
                        if (adj[i][j] > i && assigned[adj[i][j]] == false) {
                            flag = false;
                            break;
                        }
                    }
                    if (flag)
                        current.push_back(i);
                }
            }
            int updates[current.size() + 1][2];
            int update_size = current.size();
            for (int i = 0; i < current.size(); ++i) {
                map<int, int> m;
                for (int j = 0; j < adj[current[i]].size(); j++) {
                    int k = adj[current[i]][j];
                    if (assigned[k] == true)
                        m[num[k]]++;
                }

                int j;
                for (j = 1; m[j]; j++);
                updates[i][1] = j, updates[i][0] = current[i];
            }
            MPI_Send(&update_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            MPI_Send(&updates, update_size * 2, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }
    }
    MPI_Finalize();
    return EXIT_SUCCESS;
}
