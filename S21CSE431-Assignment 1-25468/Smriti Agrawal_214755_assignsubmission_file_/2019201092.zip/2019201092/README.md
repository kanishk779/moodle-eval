Question1:

To Compile- 
	mpic++ 2019201092_1.cpp -o 2019201092_1
To Run- 
	mpirun -np 2 2019201092_1 q1_inp q1_out
Observation & Analysis-
	-Under this problem, we distributed the responsibilty of calculating individual reciprocals among child processes.
	-On having calculated this reciprocal, the slave proccess send their partial results to Master process which eventually adds them all up to 		generate the final result.
	-We observed that for smaller values of n time is more than the medicore values of n. And further compared to these medicore values, the 		time increases with a very very few difference.


Question2:

To Compile- 
	mpic++ 2019201092_2.cpp -o 2019201092_2
To Run- 
	mpirun -np 2 2019201092_2 q2_inp q2_out
Observation & Analysis-
	-If the array size(n) is not a mutiple of no.of processes(p), then append a MIN value n%p no. of times.
	-To apply quicksort in a parallel fashion, we first split the given array into equal sized chunks to apply sequential quick sort on them 		individually.
	-The parent process then finally merge those chunks using the k-way merge algorithm to output the sorted array.
	-We observed that parallel execution with more than one process, the execution time decreases when the input size and the number of process 		increases.
	-Quick do UNSTABLE sorting.
