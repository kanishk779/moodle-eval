#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
#include <cstring>
#include <iostream>
using namespace std;
#define max_val 1e9
#define ll long long int

int readFile(string input_file)
{
    fstream file;
    file.open(input_file.c_str(), ios::in); 
    ll n;
    file >> n;
    return n;
}

void writeFile(double result, string output_file)
{
    fstream file;
    file.open(output_file.c_str(),ios::out); 
    file<<setprecision(7)<<result<< endl;
    file.close();
}

int getJobs(int N, int p)
{
	return N/p;
}

ll calPow(int i)
{
	return pow(i,2);
}

int main( int argc, char **argv ) {
    int id, p;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &id );
    MPI_Comm_size( MPI_COMM_WORLD, &p );
    string input_file= argv[1], output_file = argv[2];
    int N = readFile(input_file);
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime(), total_sum = 0;

    /* write your code here */
    
    if(id==0){

      int njobs, i=1;
        while(i<p)
        {
         //P0 sends to each Process from P1...Pn-1 what portion of jobs they'll do.
        
          if(i==p-1 && true)    njobs = N/p + N%p;
          else          njobs = N/p;
            
          MPI_Send(&njobs, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
          i++;
        }

      njobs = getJobs(N,p), i=calPow(1);
      while(i<=njobs) {total_sum += (1.0/calPow(i));i++;}

     //Now receive their part from every other process.
      double total = total_sum;
      i=calPow(1);
      while(i<p){
        double sum = 0.0;
        MPI_Recv(&sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        total+=sum;
        i++;
     } 
  
    writeFile(total,output_file);

    }
    else{

      double sum=0.0;
      int previous_offset = (id)*(N/p) +1, nRange, i= previous_offset;
      MPI_Recv(&nRange, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      while(i<nRange+previous_offset)
      {
          sum+=(1/pow(i,2));
          i++;
      }

      MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime= calPow(0);
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( id == 0 && true) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}