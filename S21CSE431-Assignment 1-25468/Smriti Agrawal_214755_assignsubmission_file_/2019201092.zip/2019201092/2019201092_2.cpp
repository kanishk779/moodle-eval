#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <stdlib.h>
#include <bits/stdc++.h>
using namespace std;
#define max_val 1e9
#define ll long long int

void mergeSortedArrays(ll *result, ll *arr1, ll sz1, ll *arr2, ll sz2, ll flag)
{
    ll i=0, j=0, k=0;
    while(i<sz1 && j<sz2)
    {
        if(arr1[i] > arr2[j])		result[k] = arr2[j++];
        else 						result[k] = arr1[i++];
        k++;
    }

    while(i<sz1)					{result[k] = arr1[i++];    k++;}

    while(j<sz2)					{result[k] = arr2[j++];    k++;}

}

ll partition (ll *arr, ll low, ll high)
{
    ll pivot = arr[high], i= low-1, j;  // selecting last element as pivot
  
    for (j = low; j < high; j++)
    {
        // If the current element is smaller than or equal to pivot
        if(arr[j]> pivot)		continue;

        i++;    // increment index of smaller element
        swap(arr[i], arr[j]);
    }
    swap(arr[i + 1], arr[high]);
    return (i + 1);
}

void quicksort(ll *a, ll left, ll right)    
{
    if(left < right)
    {
        ll q= partition(a, left, right);
        quicksort(a, left, q-1);
        quicksort(a, q+1, right);
    }
}

void readFile(string input_file, vector<ll> &arr, ll &n)
{
	fstream file;
    file.open(input_file.c_str(), ios::in); 
	ll tt;
    file>> n;
	while(file >> tt)
        arr.push_back(tt);
}

void copyData(ll * data, vector<ll> arr)
{
	for(int i=0;i<arr.size();i++)
        data[i] = arr[i];
}

void writeFile(string output_file, ll * chunk, ll n)
{
	fstream file;
    file.open(output_file.c_str(),ios::out); 
    for(int i=0;i<n;i++)
        file<<chunk[i] << endl;
    file.close();
}

ll getJobs(int N, int p)
{
    return N/p;
}

bool replaceCondition()
{
	return true;
}

ll calPow(int i)
{
    return pow(i,2);
}

int main( int argc, char **argv ) {
    int id, p;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &id );
    MPI_Comm_size( MPI_COMM_WORLD, &p );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );

    ll * data,* chunk,* other;
    ll m,s,step, cnt=1,root=0, n;
    string input_file= argv[1], output_file = argv[2];
    MPI_Status status;
    double tbeg = MPI_Wtime();
    
    if(id==0 || false)
    {
        ll r;
        vector<ll> arr;
        readFile(input_file, arr, n);
        s = getJobs(n,p); r = n%p;
        data = (ll *)malloc((n+p-r)*sizeof(ll));
        copyData(data, arr);

        if(r!=0 && true)
        {
            s++;
            ll last_point_index = n+p-r;
            for(int i=n;i<last_point_index ;i++)
                data[i]=max_val;
        }
    }
        
    MPI_Bcast(&s,cnt,MPI_LONG_LONG_INT,root,MPI_COMM_WORLD);
    chunk = (ll *)malloc(s*sizeof(ll));
    MPI_Scatter(data,s,MPI_LONG_LONG_INT,chunk,s,MPI_LONG_LONG_INT,root,MPI_COMM_WORLD);
    quicksort(chunk,0,s-1);

    step = calPow(1);
    ll flag=1;
    for(;step < p; )
    {
        // printf("step= %d,id= %d\n",step,id);
        flag=1;
        if(id%(2*step)==0)
        {
            if(p>id+step && replaceCondition)
            {
                // printf("Inside %d\n",id);
                MPI_Recv(&m,1,MPI_LONG_LONG_INT,id+step,0,MPI_COMM_WORLD,&status);
                other = (ll *)malloc(m*sizeof(ll));
                MPI_Recv(other,m,MPI_LONG_LONG_INT,id+step,0,MPI_COMM_WORLD,&status);
                ll *result = (ll *)malloc((s+m)*sizeof(ll));
                mergeSortedArrays(result,chunk,s,other,m,flag);
                chunk= result;
                flag=0;
                s +=m;
            } 
        }
        else
        {
            MPI_Send(&s,1,MPI_LONG_LONG_INT,id-step,0,MPI_COMM_WORLD);
            MPI_Send(chunk,s,MPI_LONG_LONG_INT,id-step,0,MPI_COMM_WORLD);
            flag=1;
            break;
        }
        step *= 2;
    }

    if(id==0 || false)
    	writeFile(output_file, chunk, n);


    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime= calPow(0);
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( id == 0 && replaceCondition) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}

/*
mpic++ 2019201092_1.cpp -o 2019201092_1
mpirun -np 3 2019201092_1 q1_inp q1_out
*/