// DSATUR algorithm

#include <stdio.h>
#include <string.h>
#include <mpi.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define debug 0

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_process = 0;

    if (argc != 3)
    {
        if (rank == root_process)
            fprintf(stderr, "Usage: %s %s %s infilename outfilename\n", argv[0], argv[1], argv[2]);
        MPI_Finalize();
        exit(1);
    }
    char *input_file = argv[1];
    char *output_file = argv[2];
    int nv, ne, N;
    int **adj_matrix;
    if (rank == root_process)
    {
        // the root reads out all the array elements
        FILE *fr = fopen(input_file, "r");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", input_file);
            MPI_Finalize();
            exit(1);
        }
        fscanf(fr, "%d %d", &nv, &ne);
        if (debug)
            cout << "VERTICES:\t" << nv << "\nEDGES:   \t" << ne << "\n";
        vector<pair<int, int> > adj_list[nv];
        vector<pair<int, int> > edges;
        N = ne; // the number of vertices in the final line graph
        for (int i = 0; i < ne; i++)
        {
            int u, v;
            fscanf(fr, "%d %d", &u, &v);
            u--;
            v--;
            edges.push_back(make_pair(u, v));
            adj_list[u].push_back(make_pair(v, i));
            adj_list[v].push_back(make_pair(u, i));
        }
        // now edges contain all the required edges
        adj_matrix = new int *[N];
        for (int i = 0; i < N; i++)
            adj_matrix[i] = new int[N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                adj_matrix[i][j] = 0;
        // identify where all the elements are linked

        for (int i = 0; i < ne; i++)
        {
            for (auto p1 : adj_list[edges[i].first])
                if (p1.first != edges[i].second) // no need to self link
                    for (auto p2 : adj_list[p1.first])
                    {
                        adj_matrix[i][p2.second] = 1;
                        adj_matrix[p2.second][i] = 1;
                    }
            for (auto p1 : adj_list[edges[i].second])
                if (p1.first != edges[i].first) // no need to self link
                    for (auto p2 : adj_list[p1.first])
                    {
                        adj_matrix[i][p2.second] = 1;
                        adj_matrix[p2.second][i] = 1;
                    }
        }
        if (debug)
        {
            cout << "\nThe adj matrix is\n";
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                    cout << (int)adj_matrix[i][j] << " ";
                cout << "\n";
            }
            cout << "\n";
        }
        // and the adj matrix for the line graph is done!
        fclose(fr);
    }
    // root shares the value of N with everyone
    MPI_Bcast(&N, 1, MPI_INT, root_process, MPI_COMM_WORLD);

    // everyone makes their own copy of the matrix, and allocates space if not done
    if (rank != root_process)
    {
        adj_matrix = new int *[N];
        for (int i = 0; i < N; i++)
            adj_matrix[i] = new int[N];
    }
    // now invite them here

    for (int i = 0; i < N; i++)
        MPI_Bcast(adj_matrix[i], N, MPI_CHAR, 0, MPI_COMM_WORLD);

    if (debug)
    {
        cout << "RANK " << rank << " The adj matrix is: [";
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
                cout << (int)adj_matrix[i][j] << ",";
            cout << "],[";
        }
        cout << "\n";
    }

    // identify when to start / stop
    int startval = (N * rank) / numprocs;
    int endval = (N * (rank + 1)) / numprocs;

    // now let's start coloring
    int num_colors_used = 0;
    int **colors = new int *[N];     // color classes
    int **free_color = new int *[N]; // free colors: node can be put in that color class
    for (int i = 0; i < N; i++)
    {
        colors[i] = new int[N];
        free_color[i] = new int[N];
    }

    int *OK = new int[N];       // is the node already counted?
    int *sat = new int[N];      // number of neighbors
    int *free_num = new int[N]; // number of free classes for each node

    // first initialize
    for (int i = 0; i < N; i++)
    {
        int sum = 0;
        for (int j = 0; j < N; ++j)
        {
            colors[i][j] = 0;
            free_color[i][j] = 0;
            sum += adj_matrix[i][j];
        }
        sat[i] = sum;
        if (debug)
            cout << sum;
        free_num[i] = 0;
        OK[i] = 0;
    }
    if (debug)
        cout << "\n";
    int min_id, min_free, min_sat;
    //we color N nodes each after other:
    for (int v = 0; v < N; v++)
    {
        min_free = N;
        min_sat = N;
        min_id = -1;
        for (int i = startval; i < endval; i++)
            if (!OK[i] && (min_free > free_num[i] || (min_free == free_num[i] && sat[i] < min_sat)))
            {
                min_free = free_num[i];
                min_sat = sat[i];
                min_id = i;
            }
    }
    struct
    {
        int free;
        int id;
    } p, tmp_p;
    p.id = min_id;
    p.free = min_free; // min_sat also include here
    if (debug)
        cout << "\nRANK:" << rank << " PID:" << p.id << " FREE:" << p.free;
    // look for min_free and min_id among all processes and store it in tmp_p
    MPI_Allreduce(&p, &tmp_p, 1, MPI_2INT, MPI_MINLOC, MPI_COMM_WORLD);
    min_id = tmp_p.id;
    min_free = tmp_p.free;
    if (debug)
        if (rank == root_process)
            cout << "\nFINAL RANK: " << rank << " PID:" << min_id << " FREE:" << min_free;
    OK[min_id] = 1; // color the point obtained from above!
    if (min_free == 0)
    {
        //We need a new color class.
        colors[num_colors_used][min_id] = 1;
        //the new color class posible class for the rest:
        if (debug)
        {
            cout << "\nRANK:" << rank << "(" << startval << "," << endval << ") OK:";
            for (int i = startval; i < endval; i++)
                cout << OK[i];
            cout << "\n";
        }
        for (int i = startval; i < endval; i++)
            if (!OK[i])
            {
                free_color[i][num_colors_used] = 1;
                free_num[i]++;
            }
        //but not for the connected nodes:
        for (int i = startval; i < endval; i++)
        {
            if (!OK[i] && adj_matrix[i][min_id])
            {
                free_color[i][num_colors_used] = 0;
                free_num[i]--;
            }
        }
        num_colors_used++;
        if (debug)
            cout << "HERE!" << rank << ":" << num_colors_used;
    }
    else
    {
        if (debug)
            cout << "\nCASE 2:" << rank << '\n';
        //We put node into an old color class.
        int id_from, c;
        for (id_from = 0; id_from < numprocs; id_from++)
        {
            int other_startval = N * id_from / numprocs, other_endval = N * (id_from + 1) / numprocs;
            if (min_id >= other_startval && min_id > other_endval)
                break;
        }
        if (debug)
            cout << "HHH" << rank << " " << id_from << '\n';
        if (rank == id_from)
            for (c = 0; !free_color[min_id][c]; c++)
                ;

        MPI_Bcast(&c, 1, MPI_INT, id_from, MPI_COMM_WORLD);

        colors[c][min_id] = 1;

        //the connected nodes' freedom decreases:
        for (int i = startval; i < endval; i++)
        {

            if (!OK[i] && free_color[i][c] && adj_matrix[i][min_id])
            {
                free_color[i][c] = 0;
                free_num[i]--;
            }
        }
    }
    if (debug)
    {
        cout << "\n"
             << rank << "DESAT NUMBER OF COLORS USED: " << num_colors_used << "|";
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                cout << colors[i][j];
        cout << "|";
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                cout << free_color[i][j];
        cout << "|";
        for (int i = 0; i < N; i++)
            cout << OK[i];
        cout << "|";
        for (int i = 0; i < N; i++)
            cout << sat[i];
        cout << "\n";
    }
    int *color_sum = new int[num_colors_used];
    for (int i = 0; i < num_colors_used; i++)
    {
        color_sum[i] = 0;
        for (int j = 0; j < N; j++)
            color_sum[i] += colors[i][j];
    }
    if (rank == root_process)
    {
        vector<int> perm;
        for (int i = 0; i < num_colors_used; i++)
        {
            int max = 0, maxcol;
            for (int j = 0; j < N; j++)
                if (color_sum[j] > max)
                {
                    max = color_sum[j];
                    maxcol = j;
                }
            for (int j = 0; j < N; j++)
                if (colors[maxcol][j])
                    perm.push_back(j);
            color_sum[maxcol] = 0;
            if (debug)
                cout << "\n"
                     << i << ":" << max << ";" << maxcol;
        }
        int *colorings = new int[N];
        int nc = 0;
        int *ispresentcolor = new int[num_colors_used + 5];
        for (int i = 0; i < num_colors_used + 5; i++)
            ispresentcolor[i] = 0;
        // test perm
        for (int i = 0; i < N; i++)
        {
            //int sum = 0;
            colorings[i] = -1;
            for (int j = 0; j < N; j++)
            {
                if (perm[j] == i)
                {
                    colorings[i] = j + 1;
                    ispresentcolor[j] = 1;
                }
                break;
            }
        }
        for (int i = 0; i < num_colors_used + 5; i++)
            nc += ispresentcolor[i];

        /* logic ends */
        /* write answer to output file*/

        // reading from input file
        FILE *fr = fopen(output_file, "w");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", output_file);
            MPI_Finalize();
            exit(1);
        }
        fprintf(fr, "%d\n", nc);
        for (int i = 0; i < N; i++)
            fprintf(fr, "%d ", colorings[i]);
        fclose(fr);
    }
    /* end of write your code here */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}