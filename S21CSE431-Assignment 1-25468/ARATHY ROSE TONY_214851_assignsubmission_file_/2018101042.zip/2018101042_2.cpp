#include <stdio.h>
#include <string.h>
#include <mpi.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define debug 0

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_process = 0;

    //printf("%s %s %s\n",  argv[0], argv[1], argv[2]);
    if (argc != 3)
    {
        if (rank == root_process)
            fprintf(stderr, "Usage: %s %s %s infilename outfilename\n", argv[0], argv[1], argv[2]);
        MPI_Finalize();
        exit(1);
    }
    char *input_file = argv[1];
    char *output_file = argv[2];
    int n;
    int *main_array; // dynamic alloc
    if (rank == root_process)
    {
        // the root reads out all the array elements
        if (debug)
        {
            printf("INPUT FILE: %s\n", input_file);
            printf("OUTPUT FILE: %s\n", output_file);
        }
        // reading from input file
        FILE *fr = fopen(input_file, "r");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", input_file);
            MPI_Finalize();
            exit(1);
        }
        fscanf(fr, "%d", &n);
        // here, while reading we need to split it up and pad it with useless elements so that it becomes easier to scatter
        int actual_array_size = n;
        if (numprocs != 1)
            actual_array_size = (numprocs) * (n / (numprocs) + (n % (numprocs) != 0));

        main_array = (int *)malloc((actual_array_size + 7) * sizeof(int));
        for (int i = 0; i < n; i++)
            fscanf(fr, "%d", &main_array[i]);
        for (int i = n; i < actual_array_size + 7; i++)
            main_array[i] = INT_MAX;
        if (debug)
        {
            printf("Number read: %d\n", n);
            printf("ACTUAL ARRAY SIZE: %d\n", actual_array_size);
            printf("Array read: ");
            for (int i = 0; i < actual_array_size; i++)
                printf("%d ", main_array[i]);
            printf("\n");
            fflush(stdout);
        }
        fclose(fr);
    }
    int *small_array;

    // the root has the task of giving everyone work
    if (numprocs == 1)
    {
        sort(main_array, main_array + n);
        small_array = main_array;
    }
    else
    {
        // first he has to give the size of array to everyone
        MPI_Bcast(&n, 1, MPI_INT, root_process, MPI_COMM_WORLD);
        /* logic starts   */
        // how much work to give per process?
        // we need to know the size of work for each process
        int min_work_per_process = n / numprocs;
        int remaining_work = n % numprocs;
        int small_array_size = min_work_per_process + (remaining_work != 0);
        int actual_array_size = numprocs * small_array_size;

        //    if (debug)
        //        printf("%d %d %d %d %d\n", numprocs, min_work_per_process, remaining_work, small_array_size, actual_array_size);

      
        // let's scatter using MPI_scatter; however, this requires the array to be full: to denote empty values, let's use INT_MAX
        small_array = (int *)malloc(sizeof(int) * small_array_size);
        fflush(stdout);
        MPI_Scatter(main_array, small_array_size, MPI_INT,
                    small_array, small_array_size, MPI_INT, root_process, MPI_COMM_WORLD);

        // now the work of main_array is done
        free(main_array);
        main_array = NULL;

        // now for each process, let them figure out their size and do it
        int actual_work = small_array_size;
        if (debug)
        {
            printf("\nRank %d :", rank);
            for (int i = 0; i < actual_work; i++)
                printf("%d, ", small_array[i]);
            printf("\n");
        }
        // as they have got their arrays, let's sort and merge them
        sort(small_array, small_array + small_array_size);

        // merge them
        for (int step = 1; step < numprocs; step = 2 * step)
        {
            if (rank % (2 * step) != 0)
            {
                if (debug)
                {
                    printf("S: %d %d, size: %d, send to %d: ", rank, step, small_array_size, rank - step);
                    for (int i = 0; i < small_array_size; i++)
                        printf("%d,", small_array[i]);
                    printf("\n");
                }
                MPI_Send(small_array, small_array_size, MPI_INT, rank - step, root_process, MPI_COMM_WORLD);
                break;
            }
            int other_array_rank = rank + step;
            if (other_array_rank < numprocs)
            {
                int other_array_size = small_array_size;
                if (other_array_rank + small_array_size > actual_array_size) // overexceed?
                    other_array_size = actual_array_size - other_array_rank;
                int *other_array = (int *)malloc(other_array_size * sizeof(int));
                MPI_Recv(other_array, other_array_size, MPI_INT, other_array_rank, root_process, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                if (debug)
                {
                    printf("R: %d %d, size: %d, receive from %d, size: %d\t", rank, step, small_array_size, other_array_rank, other_array_size);
                    printf("MY ARRAY:");
                    for (int i = 0; i < small_array_size; i++)
                        printf("%d ", small_array[i]);
                    printf("\tOTHER ARRAY:");
                    for (int i = 0; i < other_array_size; i++)
                        printf("%d ", other_array[i]);
                    printf("\n");
                }
                // merge and free memory
                int *merged_array = (int *)malloc((small_array_size + other_array_size) * sizeof(int));
                int i = 0, j = 0, k = 0;
                while (i < small_array_size && j < other_array_size)
                {
                    if (small_array[i] > other_array[j])
                        merged_array[k++] = other_array[j++];
                    else
                        merged_array[k++] = small_array[i++];
                }
                while (i < small_array_size)
                    merged_array[k++] = small_array[i++];
                while (j < other_array_size)
                    merged_array[k++] = other_array[j++];
                free(small_array);
                free(other_array);
                small_array = merged_array;
                small_array_size += other_array_size;
            }
        }
    }
    /* logic ends */
    /* write answer to output file*/
    if (rank == root_process)
    {
        // reading from input file
        FILE *fr = fopen(output_file, "w");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", output_file);
            MPI_Finalize();
            exit(1);
        }
        if (debug)
            for (int i = 0; i < n; i++)
                printf("%d ", small_array[i]);

        for (int i = 0; i < n; i++)
            fprintf(fr, "%d ", small_array[i]);
        fclose(fr);
    }
    /* end of write your code here */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}