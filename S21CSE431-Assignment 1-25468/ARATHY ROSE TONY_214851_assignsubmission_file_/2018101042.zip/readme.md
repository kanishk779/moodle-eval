# DS ASSIGNMENT 1

## QUESTION 1

Use the numerical identity that the sum of the reciprocals of the squares of integers converges to pi^2/6

### How to run?

It needs two arguments: input file and output file

> mpic++ 2018101042_1.cpp
> mpirun -n 5 ./a.out input output

### Logic used

1. The root process opens the input file given by argument 1 (shown here as `input`), and reads n from it.
2. It then broadcasts the number n to all other processes.
3. Each of the processes calculate `min_work_per_process = floor(n / actual_num_procs)` and `remaining_work = n % actual_num_procs`.
4. Then each process (where rank is the rank of the process) calculates 1/(r<sup>2</sup>) for r in the task list as follows:
   1. Each process does its own work, i.e. min_work_per_process. This work consists of values of r from `(min_work_per_process - 1) * rank + 1` to `(min_work_per_process * rank) + 1`
   2. Each process might get additional work from the remaining_work. (max 1), which is determined by the formula: `r = min_work_per_process * actual_num_procs + rank`. However for this, its rank should be less than `remaining_work`
5. Once the process adds up the values for all its work, it sends them back to the root_process, where all the process outputs are added up to `answer`.
6. Then the root_process outputs the `ans` to the output file (shown here as `output`) given by argument 2.

### Example

- N = 5, numprocs = 4
- Process 1 calculates: 1/1^2 + 1/4^2
- Process 2 calculates: 1/2^2 + 1/5^2
- Process 3 calculates: 1/3^2

Then all the values are summed up.

### Analysis

The complexity depends on two factors:

- the number of proresses: `numprocs`
- the input number: `n`

Here, the root does not contribute to the process.

1. Reading the file: O(1): only root does this
2. Computing the sum: approximately `O(n/numprocs)` : all processes apart from root does this
3. Other computations (like sending N to all the processes and gathering the sum) : `O(1)` or `O(numprocs)`

- Approximate time complexity : `O(n/numprocs)`
- Approximate memory complexity : `O(1)`

We can see that, increasing the value of n while keeping `numprocs` constant does not change the time taken much. Same goes for the value of `N`.

## QUESTION 2

Implementing parallel quicksort

### How to run?

It needs two arguments: input file and output file

> mpic++ 2018101042_2.cpp
> mpirun -n 5 ./a.out input output

### Logic used

1. The root process opens the input file given by argument 1 (shown here as `input`), and reads n from it.
2. Once n is read, an integer array of size `(numprocs) * (floor(n / numprocs) + (n % numprocs != 0))` is allocated. The extra space ensures that no process is left without an array to sort, and all processes have the same number of elements to sort.
3. The root process starts reading the file and storing the array values inside it.
4. The empty spaces in the array is filled with `INT_MAX`, so that, while sorting, these elements stay at the end and do not mess up the algorithm.
5. Then, the root process broadcasts the size of the array to everyone.
6. Each of the processes calculate `small_array_size = floor(n / numprocs) + (n % numprocs != 0)` and `actual_array_size = numprocs * small_array_size`. Here `small_array_size` is the array size allotted for the process to sort, while `actual_array_size` is the size that the process has to sort.
7. Then we allocate space for the `small_array` so that it can contain the array that the process has to sort.
8. Then we use `MPI_Scatter` to evenly give all processes the small array from the original array as read by the root process. Once this is done, the main array is freed.
9. Each process independently sorts the array using the STD library `qsort` function. The `qsort` function implements quicksort for us.
10. Once that is done, all the `small_array` has to be merged. The gist is that we try to collect the sums to some even number and then fold back to 0, as powers of 2. These are the steps:
    1. If the process is not a collecting process (i.e. not divisible by 2^step for the iteration), the process sends its array to the previous process (which is guaranteed to do at least one reception as it is even).
    2. If the process is a collecting process for the step, it receives the `other_array` from the above process and merges them in ascending order and updates its own `small_array`.
11. At the end of this exercise, the merged sorted array is at process 0, which is same as the root process.
12. Then the root_process outputs the sorted array to the output file (shown here as `output`) given by argument 2.

### Example

- N = 8
- numprocs = 10
- Array = [0,1,2,3,4,5,6,7]
- Actual Array = [0,1,2,3,4,5,6,7,X,X,X]

Merging:

LEVEL 0

- 1->0 [1]
- 3->2 [3]
- 5->4 [5]
- 7->6 [7]
- 9->8 [X]

LEVEL 1

- 2->0 [2,3]
- 6->4 [6,7]

LEVEL 2

- 4->0 [4, 5, 6, 7]

LEVEL 3

- 8->0 [X, X]

Sorted array = [0,1,2,3,4,5,6,7]

### Analysis

The complexity depends on two factors:

- the number of array elements: `n`
- the number of processes: `numprocs`

Here, the root does not contribute to the process.

1. Reading the file: O(n): only root does this
2. Sorting the smaller array: approximately `O(n/numprocs * log (n/numprocs))`
3. Merging them: `O(log numprocs * (n/numprocs))` (approx)

- Approximate time complexity : `O(n/numprocs * log (n/numprocs))`
- Approximate memory complexity : `O(n)`

## QUESTION 3

Parallel edge coloring (edit: the code currently attached has some bugs in it)

### How to run?

It needs two arguments: input file and output file

> mpic++ 2018101042_3.cpp
> mpirun -n 5 ./a.out input output

### DSATUR Algorithm

1. Find the optimal node to be colored:
   - has minimal freedom - that we can put this node into less suitable color classes;
   - for equal freedom nodes has maximum saturation - has many neighbours. (This step is debated in the literature.)
2. Color the chosen node:
   - put into the first free color class, or
   - open a new class if none is free. (Opening a new color class will increase the freedom of all nodes by one!)
3. Update information of the remaining nodes:
   - If the just colored node have a neighbour, then
   - It cannot be placed in the same color class, so
   - Thefreedomofthisnodewilldecreasebyone.

### Logic used

1. The root process opens the input file given by argument 1 (shown here as `input`), and reads `nv` and `ne`, i.e. the number of edges and vertices from it.
2. Then a adjecency list of size `nv` is made along with an edge vector.
3. As edges are being read, both the adjacency list and the edge vectors get updated.
4. After reading all the edges, we have to convert this to a line graph:
   1. First, make an adjacency matrix for the new line graph or size `NxN` where `N=ne`
   2. For each edge i, check the adjacency list of the starting vertex.
   3. For every vertex j except the original edge in the adjacency list of i.start, mark 1 on the adjacency matrix at `(i.start,j)`. Also, do the same for the ending point of the graph, as the graph is bidirectional.
5. After getting the adjacency matrix, we share both `N` and the `adj_matrix` to everyone.
6. Then we do the DSATUR coloring algorithm.
7. Then the root_process outputs the number of colors used and the color of each edge of the array.

### Example

- G: nv=3, ne=2
- Edges: (1,2), (1,3)

Converting to line graph:

Adjacency matrix:

```text
0 1
1 0
```

After doing the algorithm,

OUTPUT:

```text
2
1 2
```

### Analysis

We are overusing time at converting the graph into a line graph: `O(N^2)`

Since this forms the bottleneck of the operation, following this approach will not lower the memory requirement.

Hence the only way is to parallelize line graph making.
