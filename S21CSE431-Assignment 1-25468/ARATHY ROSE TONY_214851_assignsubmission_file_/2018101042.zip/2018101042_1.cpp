// Use the numerical identity that the sum of the reciprocals of the squares of integers converges to pi^2/6

#include <stdio.h>
#include <string.h>
#include <mpi.h>
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int root_process = 0;

    // check if all inputs are given
    if (argc != 3)
    {
        if (rank == root_process)
            fprintf(stderr, "Usage: %s %s %s infilename outfilename\n", argv[0], argv[1], argv[2]);
        MPI_Finalize();
        exit(1);
    }
    char *input_file = argv[1];
    char *output_file = argv[2];
    int n;
    if (rank == root_process)
    {
        // reading from input file
        FILE *fr = fopen(input_file, "r");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", input_file);
            MPI_Finalize();
            exit(1);
        }
        fscanf(fr, "%d", &n);
        fclose(fr);
    }
    MPI_Bcast(&n, 1, MPI_INT, root_process, MPI_COMM_WORLD);
    /*
    * rank: current process rank 
    * numprocs: number of processes
    * root_process: the root process
    * */

    /* logic starts   */
    double ans = 0;
    double reciprocal_square = 0;
    int actual_num_procs = numprocs - 1;
    if (numprocs == 1)
        for (int i = 1; i <= n; i++)
            ans += 1 / ((double)i * i);
    else
    {
        int min_work_per_process = n / actual_num_procs;
        int remaining_work = n % actual_num_procs;
        if (rank != root_process)
        {
            // there are a total of actual_num_procs that can actually do the work
            // so the work needs to be split
            // how to split?
            // 1st process can do from (rank-1)*min_work_per_process to rank * min_work_per_process
            // let's check if this would work
            int start = (rank - 1) * min_work_per_process + 1;
            int end = rank * min_work_per_process + 1;
            for (int i = start; i < end; i++)
                reciprocal_square += 1 / ((double)i * i);
            // what about the remaining work? who would do it?
            if (rank <= remaining_work)
            {
                int i2 = min_work_per_process * actual_num_procs + rank;
                reciprocal_square += 1 / ((double)i2 * i2);
            }
        }

        // share your values of reciprocal squares
        MPI_Reduce(&reciprocal_square, &ans, 1, MPI_DOUBLE,
                   MPI_SUM, root_process, MPI_COMM_WORLD);
    }
    /* logic ends */
    /* write answer to output file*/
    if (rank == root_process)
    {
        // reading from input file
        FILE *fr = fopen(output_file, "w");
        if (!fr)
        {
            fprintf(stderr, "File %s does not exist\n", output_file);
            MPI_Finalize();
            exit(1);
        }
        fprintf(fr, "%.6lf", ans);
        fclose(fr);
    }
    /* end of write your code here */
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    if (rank == 0)
    {
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}