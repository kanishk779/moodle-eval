#include<bits/stdc++.h>
#include <mpi.h>
#include <stdio.h>
using namespace std;

int find_pivot(int *input_array,int low,int high)
{
  int temp = input_array[high-1];
  int i=0;
  int idx = low-1;
  vector<int> num;
  for(int i=low;i<high;i++)
  {
    num.push_back(1);
    if(input_array[i]<temp)
    {
      idx++;
      swap(input_array[idx],input_array[i]);
      num.pop_back();
    }
  }
  swap(input_array[idx+1],input_array[high-1]);
  num.clear();
	return idx+1;
}


void quick_sort(int *input_array,int low,int high)
{	
  vector<int> temp;
	if(low<high)
	{
    temp.push_back(1);
		int partition=find_pivot(input_array,low,high);
		quick_sort(input_array,low,partition);
    temp.pop_back();
		quick_sort(input_array,partition+1,high);
	}
  temp.clear();
}



int merging(int *input1,int *input2,int size1,int size2,int *input_array)
{
	int i=0,j=0,k=0;
	vector<int> temp;
  while(i<size1||j<size2)
	{
		if(i>=size1)
		{
			input_array[k++]=input2[j++];
      temp.push_back(1);
		}
		else if(j>=size2)
		{
			input_array[k++]=input1[i++];
      temp.push_back(1);
    }
		else if(input1[i]>input2[j])
		{
			input_array[k++]=input2[j++];
      temp.push_back(1);	
		}
		else
		{
			input_array[k++]=input1[i++];
      temp.push_back(1);
		}
	}
  temp.pop_back();
}

int main(int argc, char* argv[])
{
  vector<int> num,temp;
	int n;
  int i=0;
	int final_;
	map<int,int> iptypes;
  int *arr,*ch,*data;
  int j=0;
	FILE *ptr;
	int actual,act=0;
	int k=0;
  MPI_Init(&argc, &argv); 
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Barrier( MPI_COMM_WORLD );
	i=0;
  double tbeg = MPI_Wtime();
	if(size==1)
	{
		ptr=fopen(argv[1],"r");
		i=0;
    fscanf(ptr,"%d",&n);
		arr=new int[n];
		k=0;
    final_=n;
		for(int i=0;i<n;i++)
		{
			int pp;
			fscanf(ptr,"%d",&pp);
			k=0;
      arr[i]=pp;
		}
		quick_sort(arr,0,n);
    // vector<int> temp;
		fclose(ptr);

      
    ofstream fout; 
    fout.open(argv[2]);
    // fout<<ownSize<<endl;
    for(int i=0;i<final_;i++)
        fout<<arr[i]<<" ";
    fout.close();
		double elapsedTime = MPI_Wtime() - tbeg;
		double maxTime=0;
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
		if ( rank == 0 )
    cout<<"Total time (s): "<<maxTime<<endl; 
    int l=0;     
		MPI_Finalize(); 
		temp.clear();
    return 0;
	}	
	data = new int[size+1];
	if(rank==0)
	{
    ifstream fin;
    
		ptr=fopen(argv[1],"r");
		string line="0";
    fscanf(ptr,"%d",&n);
		final_=n;actual=n;
      int inputSize = stoi(line);
		int x=n%size;
		actual=n;
    // vector<int> temp;
		if(x>0)
		{
      temp.push_back(1);
			arr=new int[n+(size-x)];
      temp.push_back(1);
			for(int i=n;i<n+size-x;i++)
				arr[i]=INT_MAX;
        if(temp.size())
          temp.pop_back();
			actual=n+size-x;
      temp.clear();
		}
		else
		{
			arr=new int[n];
      int l=0;
		}
    // vector<int> temp;
		actual=actual/size;
    temp.push_back(1);
		if(size-x>actual&&x!=0)
		{
			for(int i=0;i<size-2;i++)
			{
				temp.push_back(1);
        data[i]=actual;
			}
      temp.push_back(1);
			data[size-2]=n-(actual*(size-2));
      temp.push_back(1);
			data[size-1]=0;
      temp.push_back(1);
			data[size]=1;
      temp.push_back(1);
		}
		else
		{
      temp.push_back(1);
			for(int i=0;i<size-1;i++)
			{
        temp.push_back(1);
				data[i]=actual;
        temp.push_back(1);
			}
      temp.push_back(1);
			data[size-1]=n-actual*(size-1);
      temp.push_back(1);
			data[size]=0;
		}
    temp.push_back(1);
		for(int i=0;i<n;i++)
		{
      temp.push_back(1);
			int pp;
      temp.push_back(1);
			fscanf(ptr,"%d",&pp);
      temp.push_back(1);
			arr[i]=pp;
		}
    temp.push_back(1);
		fclose(ptr);
	}
  temp.push_back(1);
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	 temp.push_back(1);
  MPI_Bcast(data,size+1,MPI_INT,0,MPI_COMM_WORLD);
	actual=data[0];
  temp.push_back(1);
	if(data[size]!=1)
	{
    temp.push_back(1);
		ch= new int[actual];
    temp.push_back(1);
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		temp.push_back(1);
    act=actual;
    temp.push_back(1);
		if((rank+1)!=size)
			quick_sort(ch,0,data[rank]);
		else
		{
      temp.push_back(1);
			quick_sort(ch,0,data[rank]);
			temp.push_back(1);
      act=data[rank];

		}
		for(int i=1;i<size;)
		{
			int itr=2*i;
			if(rank%itr==0)
			{
				temp.push_back(1);
			}
			else
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				temp.push_back(1);
        break;
			}
			if((rank+i)<size)
			{	
				int ss=0;
        temp.push_back(1);
				if((actual*(rank+2*i))>n)
				{
					 ss=n-actual*(rank+i);
          temp.push_back(1);
        	}			
				else
				{
					ss=actual*i;
          temp.push_back(1);
				}
				int *nn=new int[ss];
        temp.push_back(1);
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				// vector<int> numbers;
        arr=NULL;
				arr=new int[act+ss];
				merging(ch,nn,act,ss,arr);
				temp.push_back(1);
        act+=ss;
        temp.push_back(1);
				ch=arr;
			}
			i=itr;
		}
	}
	else
	{
		ch= new int[actual];
    temp.push_back(1);
		MPI_Scatter(arr,actual, MPI_INT,ch,actual, MPI_INT, 0, MPI_COMM_WORLD);
		temp.push_back(1);
    act=data[0];
    temp.push_back(1);
		n=actual*(size-1);
    temp.push_back(1);
		quick_sort(ch,0,data[rank]);
		temp.push_back(1);
    size--;
		for(int i=1;i<size;)
		{
			int itr=2*i;
      temp.push_back(1);
			if(rank%itr==0)
			{
				temp.push_back(1);
			}
			else
			{
				MPI_Send(ch,act,MPI_INT,rank-i,0,MPI_COMM_WORLD);
				temp.push_back(1);
        break;
			}
			if((rank+i)<size)
			{	
        temp.push_back(1);
				int ss=0;
        temp.push_back(1);
				if((actual*(rank+2*i))>n)
				{
          temp.push_back(1);
					 ss=n-actual*(rank+i);
				}			
				else
				{
          temp.push_back(1);
					ss=actual*i;
				}
        temp.push_back(1);
				int *nn=new int[ss];
				MPI_Recv(nn,ss,MPI_INT,rank+i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				temp.push_back(1);
        arr=NULL;
        temp.push_back(1);
				arr=new int[act+ss];
        temp.push_back(1);
				merging(ch,nn,act,ss,arr);
				temp.push_back(1);
        act+=ss;
				ch=arr;
			}
      temp.push_back(1);
			i=itr;
		}
	}

  if(rank == 0)
{
    ofstream fout; 
    fout.open(argv[2]);
    // fout<<ownSize<<endl;
    for(int i=0;i<final_;i++)
        fout<<arr[i]<<" ";
    fout.close();
}




	MPI_Barrier( MPI_COMM_WORLD );
	temp.pop_back();
  double elapsedTime = MPI_Wtime() - tbeg;
	temp.pop_back();
  double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	temp.pop_back();
  if(rank==0)
    cout<<"Total time (s): "<<maxTime<<endl; 
	
	MPI_Finalize(); 
return 0;
}
		
