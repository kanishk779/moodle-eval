Question 1:

Approach : let N = 100 , np = 7(no of cores )
to find : 1/1^2 + 1/2^2 + ...... 1/N^N

Sol: I have split N numners into np 
such as N/np
Special case: see for last core , it should not hold extra values


******int num = rank*loopSize + i;******
Example :
100/7 = 14   N/np

core 1: [1,2,...14]  computation(1/1^1 + 1/2^2 + ... 1/14^14)
core 2: [15 .... 28]
core 3..  .....  


core 7  [....100]

send all answers to core 1(rank0)
add there and write back to op-file.txt



question: 2

-It is sorting the array using Quicksort parallely.
-We know number of process - p.
array size - n.
-we will divide n equally among p, elements to calculate by each process , approx
n/p.
-sort each subarray using quicksort done by process parallely.
-Then we need to merge sorted subarray which takes O( log p) time complexity.
-Merging takes place as 2 process combine their subarray until all subarray are
-combined and produce sorted array.

