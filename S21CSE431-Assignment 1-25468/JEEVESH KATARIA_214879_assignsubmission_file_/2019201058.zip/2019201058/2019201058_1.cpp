# include <cstdlib>
# include <ctime>
# include <iomanip>
# include <iostream>
# include <mpi.h>
#include <fstream> 

using namespace std;
// format : 

// Compiling your program : mpic++ <roll-number>_<problem-number>.cpp
// Executing your program : mpirun -np <number-of-processes> a.out <input-file> <output-file>



int readFromFile(string path)
{
    ifstream fin;
    string line; 
    fin.open(path); 
    getline(fin, line);  
    fin.close();
    int ip  = stoi(line);
    return ip;
}

void writeToFile(string path,double result)
{
    ofstream fout; 
    fout.open(path);
    fout<<fixed<<setprecision(7)<<result<<endl;
    fout.close();
}


int main(int argc, char **argv)
{

string inputFilePath = argv[1];    
int n = readFromFile(inputFilePath);
int rank,size;
MPI_Status status;


MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&rank);
MPI_Comm_size(MPI_COMM_WORLD,&size);
 double tbeg = MPI_Wtime();
double result = 0;
int loopSize = 1 + ((n - 1) / size);
for(int i=0;i<loopSize;i++)
{
    int num = rank*loopSize + i;
    num++;
    if(num>n)
        break;
    int square = num*num;
    double oneUponSquare = double(1)/double(square);
    result += oneUponSquare;
}


if(rank!=0)
{
    MPI_Send(&result,1,MPI_DOUBLE,0,123,MPI_COMM_WORLD);
}
else
{

    for(int i=1;i<size;i++)
    {
        double temp = 0;
        MPI_Recv(&temp,1,MPI_DOUBLE,i,MPI_ANY_TAG,MPI_COMM_WORLD,&status);
        result += temp;
    }
    writeToFile(argv[2],result);
}

double elapsedTime = MPI_Wtime() - tbeg;
		double maxTime;
		MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
		if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
		}
MPI_Finalize();
return 0;
}