#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

string input,output;
int main( int argc, char **argv   ) {
    int rank, numprocs;
    int  num_intervals;
    int ierr;

    int root_process=0;
    double  sum=0;
    double partial_sum=0;

    /* start up MPI */
    MPI_Init( &argc, &argv   );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank   );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs   );

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD   );
    double tbeg = MPI_Wtime();

    /* write your code here */
/*    cout << argv[1]<<endl;
    cout << argv[2]<<endl;*/


    if (rank ==0 )
    {
    input=argv[1];
    output=argv[2];
    ifstream fin(input);
        fin >> num_intervals;


    }
    ierr = MPI_Bcast(&num_intervals, 1, MPI_INT, root_process, MPI_COMM_WORLD);

    partial_sum=0;

    //cout <<"hi1"<<endl;

    for( long long int i=rank+1;i<=num_intervals;i+=numprocs  )
    {

        partial_sum+=1/pow(i,2);

    }

    ierr = MPI_Reduce(&partial_sum, &sum, 1, MPI_DOUBLE,  MPI_SUM, root_process, MPI_COMM_WORLD);

    if(rank==root_process)
    {
        ofstream fout;
        fout.open(output);
        fout << fixed<< setprecision(6)<<sum <<"\n";
        fout.close();

    }


    //cout <<"hi2"<<endl;

    MPI_Barrier( MPI_COMM_WORLD   );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD   );
    if ( rank == 0   ) {
        printf( "Total time (s): %f\n", maxTime   );


    }
    //cout <<"hi3"<<endl;

    /* shut down MPI */
    MPI_Finalize();
    return 0;


}

