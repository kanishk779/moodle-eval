/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "mpi.h"
using namespace std;

typedef long long int ll;

vector<long long int> vec;
vector<long long int>ar;
string input,output;
vector<long long int >rec;
vector<long long int >tmp;

void insertion_sort(ll  low,ll  high)
{
    for(ll  i = low+1; i<high+1; i+=1)
    {
        ll val = ar[i];
        ll  j = i-1;

        while(j > low-1 && val <= ar[j]-1)
        {
            ll tmp=ar[j];
            j-=1;
            ar[j+1] = tmp;
        }

        ar[j+1] = ar[i];
    }
    return;
}


pair<ll ,ll > partition(ll  low,ll  high,ll pivot)
{
    ll  j = low;
    while(j<high+1)
    {


        if(ar[j] > pivot)
        {
            swap(ar[j],ar[high]);
            high=high-1;
        }
        else if(!(ar[j] - pivot))
            j=j+1;
        else
        {
            swap(ar[j],ar[low]);
            j=j+1;
            low=low+1;
        }
    }

    return {low,high};
}

void quicksort(ll  low,ll  high)
{
    if(high <= low)
        return;

    if(high-low <= 20)
    {
        insertion_sort( low, high);
        return;
    }

    ll pivot;

    ll p=rand()%(high-(low-1));
    p+=low;
    
    ll q=rand()%(high-(low-1));
    q+=low;

    ll r=rand()%(high-(low-1));
    r+=low;
    if(ar[p]-ar[q]>0)
    {
        swap(ar[p],ar[q]);
    }
    if(ar[p]-ar[r]>0)
    {
        swap(ar[p],ar[r]);
    }
    if(ar[r]-ar[q]>0)
    {
        swap(ar[q],ar[r]);
    }
    pivot=ar[r];


    pair<ll ,ll > lh = partition( low, high, pivot);

    quicksort( low, lh.first - 1);
    quicksort( lh.second + 1, high);

    return;
}



int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    ll  n;
    if(rank==0)
    {

        output = argv[2];
        input = argv[1];

        ll t;
        ifstream fin (input);
        //fin >> n;
        ll count=0;
        while(fin >> t)
        {
            if(count!=0)
                vec.push_back(t);
            else
            {
                n=t;
            }
            count++;
        }

        ll subtract=n%numprocs;
        n -= subtract;
        fin.close();
    }

    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */
    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    ll m ;

    m= n;
    m/=numprocs; 

    ar.resize(m);

    MPI_Scatter(vec.data(),m,MPI_LONG_LONG_INT,ar.data(),m,MPI_LONG_LONG_INT,0,MPI_COMM_WORLD);


    ll i = 1;
    quicksort(0,m-1);
    MPI_Status stat;
    for (i=1;i<numprocs;)

    {
        ll check = i;
        check*=2;

        if(rank%check!=0)
        {
            ll sz = (ll) ar.size();
            ll rec_proc = rank-i;
            MPI_Send(ar.data(),sz,MPI_LONG_LONG_INT,rec_proc,0,MPI_COMM_WORLD);
            break;
        }
        if(i<numprocs-rank)
        {

            ll sz;
            if(n-rank*m-check*m<0)
            {
                sz = n-(rank+i)*m;
            }
            else 
            {
                sz=m*i;

            }
            rec.resize(sz);
            ll send_proc = rank+i;
            MPI_Recv(rec.data(),sz,MPI_LONG_LONG_INT,send_proc,0,MPI_COMM_WORLD,&stat);

            ll rsze=(ll)ar.size();
            rsze+=(ll)rec.size();

            tmp.resize(rsze);


            vector<int>::iterator ptr;
             /*for (ptr = ar.begin(); ptr < ar.end(); ptr++) 
                         cout << *ptr << " ";*/
            std::merge(ar.begin(), ar.end(), rec.begin(), rec.end(), tmp.begin());
            ll totsize=tmp.size();
            ll arsize=ar.size();

            //cout << totsize;
            //cout << arsize;
            ar = tmp;
        }
        i = check;
    }

    if(rank==0)
    {
        ll sz = (ll) vec.size();
        if(sz%numprocs!=0)
        {
            ar.insert(ar.end(),vec.begin()+n,vec.end());
            ll sortsze=ar.size()-1;
            quicksort(n,sortsze);

            tmp.resize(sz);

            
            vector<int>::iterator ptr;
             /*for (ptr = ar.begin(); ptr < ar.end(); ptr++) 
                         cout << *ptr << " ";*/
            std::merge(ar.begin(), ar.begin() + n, ar.begin() + n, ar.end(), tmp.begin());
            ll totsize=tmp.size();
            ll arsize=ar.size();

            //cout << totsize;
            //cout << arsize;
            ar = tmp;
        }
        ofstream fout;
        fout.open (output);


        ll i=0;
        ll tot;
        tot=(long long int) (ar.size());
        while(i<0)
        {

            fout << ar[i] << " ";
            i++;
        }
        fout << endl;
        fout.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
