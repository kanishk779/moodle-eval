#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
string input,output;

void missing_found(vector<int> &vec, int colors[], int l, int r, int n,long long int adj[501][501])
{
    long long int i=l;
    while(i<r+1)
    {
        long long int ch=0;
        if (!(colors[i]  ))
        {
            long long int mk = -100000;
            for (long long int j = 1; j < n+1; j++)
            {
                if (!(adj[i][j] - 1))
                {
                    if (!(colors[j] ))
                    {
                        mk = max(mk, j);
                    }
                }
            }
            if (mk >= i)
            {
                ch=-1;

            }
            else
            {
                vec.push_back(i);
            }
        }
        i+=1;
    }
}


int main(int argc, char **argv)
{
    int rank, numprocs;

    /* start up MPI */
    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    /*synchronize all processes*/
    MPI_Barrier(MPI_COMM_WORLD);
    double tbeg = MPI_Wtime();

    /* write your code here */
    int parent_proc=0;
    int n, m;
    long long int adj[501][501];
    int colors[501];
    if( !(rank))
    {
        FILE *file = NULL;
        for (long long int i = 0; i <= m; i++)
        {
            for (long long int j = 0; j <= m; j++)
            {
                adj[i][j] = 0;
            }
        }

        input=argv[1];
        ifstream fin(input);
        ll t;
        vector<int> inputvec;
        while(fin >> t)
        {
           inputvec.push_back(t);
        }
        fin.close();
        n=inputvec[0];
        m=inputvec[1];
        ll pos=0;
        vector<vector<int>> edges(m);
        for(int i=2;i<inputvec.size();i+=2)
        {
            int x=inputvec[i];
            int y=inputvec[i+1];
            edges[pos]={x,y};
            pos++;



        }
        for (long long int i = 0; i < m; i++)
        {
            for (long long int j = i + 1; j < m; j++)
            {
                for(long long int z=0;z<2;z+=1)
                {
                    for(long long int zz=0;zz<2;zz+=1)
                    {
                        if(!(edges[j][z]-edges[i][zz]))
                        {
                            adj[j+1][i+1]=adj[i+1][j+1]=1;

                        }
                    }
                }
            }
        }
        for (long long int i = 1; i <= m; i++)
        {
            colors[i] = 0;
        }
    }
    MPI_Bcast(&n, 1, MPI_INT, parent_proc, MPI_COMM_WORLD);

    MPI_Bcast(&adj[0][0], 501 * 501, MPI_INT, parent_proc, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, parent_proc, MPI_COMM_WORLD);
    n = m;
    while (1)
    {
        MPI_Bcast(colors, n + 1, MPI_INT, parent_proc, MPI_COMM_WORLD);
        bool f = 0;
        for (int i = 1; i <= n; i++)
        {
            if (!colors[i])
                f = 1;
        }
        if (!f)
            break;
        int a[2];
        if (!(rank ))
        {
            long long int len_per_process = n ;
            len_per_process/= (numprocs);
            long long int start = 1;
            for (long long int i = 1; i < numprocs; i++)
            {
                pair<int ,int > b;

                b.second=start + len_per_process - 1;
                b.first= start;
                a[0]=b.first;
                a[1]=b.second;
                MPI_Send(a, 2, MPI_INT, i, 0, MPI_COMM_WORLD);
                start +=  len_per_process;
            }
            vector<int> vec;
            missing_found(vec, colors, start, n, n, adj);
            vector<int> to_be_colored;
            for (long long int i=0;i<vec.size() ;i++)
            {
                to_be_colored.push_back(vec[i]);
            }


            for (int i = 1; i < numprocs; i++)
            {
                int vec_size;
                int to_besize;
                to_besize=to_be_colored.size();
                MPI_Recv(&vec_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                vector<int> vec(vec_size);
                if (vec_size )
                {
                    MPI_Recv(&vec[0], vec_size, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
                for (long long int i=0;i<vec.size() ; i++)
                {
                    to_be_colored.push_back(vec[i]);
                }
            }

            for (int q=0;q<to_be_colored.size();q++)
            {

                vector<int> smallest_p_num(n + 1, 0);
                long long int i=1;
                while(i<n+1)
                {

                
        

                    if(! (adj[to_be_colored[q]][i] - 1))
                    {
                        smallest_p_num[colors[i]] = 1;
                    }
                    i++;
                }
                i=1;
                while(i<n+1)
                {
                    if(! (smallest_p_num[i] ))
                    {
                        colors[to_be_colored[q]] = i;
                        break;
                    }
                    i++;
                }
            }
        }
        else if(rank)
        {

            ll cnt=0;
            MPI_Recv(a, 2, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            vector<int> vec;
            int vec_size;
            missing_found(vec, colors, a[0], a[1], n, adj);
            vec_size=vec.size();
            MPI_Send(&vec_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
            if(vec_size==0)
            {
                // cout <<"error empty ";

                cnt++;
            }
            else
            {

                MPI_Send(&vec[0], vec_size, MPI_INT, 0, 0, MPI_COMM_WORLD);
            }
        }
    }

    set<int > st;
    MPI_Barrier(MPI_COMM_WORLD);
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce(&elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, parent_proc, MPI_COMM_WORLD);
    if (!rank )
    {
        int cnt=0;
        FILE *file = NULL;
        file = fopen(argv[2], "w");
        for(int i=1;i<n+1;i=i+1){
            if(st.count(colors[i])==0)
            {
                cnt++;
            }
            st.insert(colors[i]);

        }
        fprintf(file, "%d\n", cnt);

        
        for (int i = 1; i < n+1; i+=1)
        {

            fprintf(file, "%d ", colors[i]);
        }
        fprintf(file,"\n");
        fclose(file);
        printf("Total time (s): %f\n", maxTime);
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}
