2018101001
Question 1:
Master process,(rank=0) takes the input from the file input.txt. We run a loop from 1 to N and divide the numbers into (size/No of processess). Now slave processes recive their chunk of subset of numbers which are summed up by the slave processes and the values retured to master process where they all collectively summed up and answer is printed in output.txt.

Question 2:
Master process divides the input a and is divided in two and outpot of the files is printes
