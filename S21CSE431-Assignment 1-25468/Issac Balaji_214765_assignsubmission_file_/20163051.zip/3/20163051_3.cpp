#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#define max_rows 1000000
int str_length = 0;
using namespace std;
int* convertStrtoArr(string str, int arr[]) 
{ 
	// get length of string str 

	//cout<<str<<endl;
	int j = 0, i;
	bool neg = false;
	// Traverse the string 
	for (i = 0; str[i] != '\0'; i++) { 
		
		// if str[i] is ', ' then split 
		if (str[i] == '-') 
			neg = true;
		else if (str[i] == ' '){ 
			// Increment j to point to next 
			// array location 
			if(neg){
			    arr[j] = arr[j] * -1;
			}
			neg = false;
			j++; 
		} 
		else { 

			// subtract str[i] by 48 to convert it to int 
			// Generate number by multiplying 10 and adding 
			// (int)(str[i]) 
			//cout <<str[i]<<" before "<<arr[j] << " "<<i<<" "<<j<<endl; 
			arr[j] = arr[j] * 10 + (str[i] - 48); 
			//cout <<str[i]<<" after "<<arr[j] << " "<<i<<" "<<j<<endl; 
		} 
	} 
	if(neg){
	    //cout<<j<<endl;
	    arr[j] = arr[j] * -1;
	}
	str_length = j++;
	
} 
bool checkColor(int array1[], int edgeSz) 
{ 
    bool checkInComplete = false;
    for (int i = 0; i < edgeSz; i++) { 
	if(array1[i]==0){
	    checkInComplete = true;
	    break;
	}
    }
    return checkInComplete;
} 
int findNextAvailableColor(bool arr[],int size){
    int i,ret = -1; 
    for (i=0; i < size; i++) {
	if(arr[i]){
	    ret = i;
	    break;
	}
    }
    return ret;
}
void printArray(bool arr[], int size) 
{ 
    int i; 
    for (i=0; i < size; i++) 
        cout<<arr[i]<<" "; 
    cout<<endl;; 
} 
void printArray(int arr[], int size) 
{ 
    int i; 
    for (i=0; i < size; i++) 
        cout<<arr[i]<<" "; 
    cout<<endl;; 
} 
int randomizeNodesToProcess(int nodeArray[],int nodeSz,int Nrank, int size){
    int j=-1;
    if(Nrank>nodeSz)
	return -1;
    else{
	int floorN = (int)floor((double)size/nodeSz);
	int ceilN = (int)ceil((double)size/nodeSz);
	//cout<<"ceilN :"<<ceilN<<"size :"<<size<<"nodeSz :"<<nodeSz<<endl;
	for(int i=0;i<=nodeSz;i++){
	    j = (ceilN*Nrank)+i;
	    //cout<<"j :"<<j<<endl;
	    if(j>nodeSz) 
		return -1;
	    else if((nodeArray[j]==0)){
		break;
	    }
	}
    }
    return j+1;
}
int main(int argc, char* argv[])
{
        ifstream MyReadFile(argv[1]);
        string input,inputLine;
        getline (MyReadFile, input);
	int arr[2];
	arr[0] = 0;
	arr[1] = 0;
	convertStrtoArr(input,arr); 
	int edgeSize = arr[1];
	int nodeSize = arr[0];
	int* nodeVisited = (int*)malloc(sizeof(int) *nodeSize);
	bool edgesGraph[nodeSize][nodeSize];
	for (int i = 0; i <= nodeSize; i++) { 
	    for (int j = 0; j <= nodeSize; j++) {
		edgesGraph[i][j] = false;
		edgesGraph[j][i] = false;
	    }
	    nodeVisited[i] = 0;
	}
	int* edgesGraphColor = (int*)malloc(sizeof(int) *edgeSize); 
	int edgesInput[edgeSize][2];
	int u,v;
	for (int i = 0; i < edgeSize; i++) { 
	    getline (MyReadFile, inputLine);
	    edgesInput[i][0] =0;
	    edgesInput[i][1]=0;
	    convertStrtoArr(inputLine,edgesInput[i]);
	    u = edgesInput[i][0]-1;
	    v = edgesInput[i][1]-1;
	    edgesGraph[u][v] = true;
	    edgesGraph[v][u] = true;
	    edgesGraphColor[i] = 0;
	}

	
	//for (int i = 0; i < arr[1]; i++) { 
	    //cout<<"node "<<i<<endl;
	    //printArray(edgesGraph[i],arr[0]);
	//}
        int tag=1;
        int size;
	int color = -1;
        int rank;
	int final = -1;
	int node,nextNode=-1;
        MPI_Status status;
        MPI_Init (&argc,&argv);
        MPI_Comm_size (MPI_COMM_WORLD,&size);
        MPI_Comm_rank (MPI_COMM_WORLD,&rank);

	int processNode[size];
	int loop =0;
	while(checkColor(edgesGraphColor, edgeSize)){
	    //cout<<"start of new loop for rank"<<rank<<endl;
	    MPI_Barrier(MPI_COMM_WORLD);
	    int edgesGraphColorN[nodeSize];
	    MPI_Allreduce(edgesGraphColor, &edgesGraphColorN, edgeSize, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	    for(int n=0;n<edgeSize;n++){
		if(edgesGraphColor[n]==0){
		     edgesGraphColor[n] = edgesGraphColorN[n];
		}
	    }
	    if(!checkColor(edgesGraphColor, edgeSize))
		break;
	    //cout<<"edgesGraphColor by rank "<<rank<<": ";
	    //printArray(edgesGraphColor,edgeSize); 
	    //cout<<"nodeVisited by rank "<<rank<<": ";
	    //printArray(nodeVisited,nodeSize);  
	    int nodeVisitedN[nodeSize];
	    MPI_Allreduce(nodeVisited, &nodeVisitedN, nodeSize, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	    for(int n=0;n<nodeSize;n++){
		if(nodeVisited[n]==0)
		    nodeVisited[n] = nodeVisitedN[n];
	    }
	    //cout<<"nodeVisited by rank "<<rank<<": ";
	    //printArray(nodeVisited,nodeSize);  
	    node = randomizeNodesToProcess(nodeVisited, nodeSize, rank, size);
	    MPI_Allgather(&node, 1, MPI_INT, &processNode, 1, MPI_INT, MPI_COMM_WORLD);
	    //cout<<"processNode by rank "<<rank<<": ";
	    //printArray(processNode,size);  
	     
	    //BROADCAST
	    //cout<<"loop "<<loop<<" rank "<<rank<<endl;
	    loop++;
	    if(loop==edgeSize)
		break;
	    bool breakBool = false;
	    if(node == -1){
		//cout<<"\t\t\tnode ==-1 rank "<<rank<<" loop "<<loop<<endl;
		continue;
	    }
	    for(int m=0;m<size;m++){
		if((processNode[m]==node) && (m<rank)){
		    breakBool = true;
		    break;
		}
	    }
 	    if(breakBool){
		//cout<<"\t\t\t(processNode[m]==node) && (m>rank) rank "<<rank<<" loop "<<loop<<endl;
		continue;
	    }
	    int u = node;
	    bool colorsAvailable[nodeSize];
	    int attachedProcess[nodeSize];
	    
	    for(int k=0;k<nodeSize;k++){
	    	colorsAvailable[k] = true;
		attachedProcess[k] = nodeVisited[k]-1;
	    }  
	    //attachedProcess[processNode[rank]-1] = rank;
	    //cout<<"attachedProcess by rank "<<rank<<": ";
	    //printArray(attachedProcess,nodeSize);  
	    for(int m=0;m<size;m++){
		attachedProcess[processNode[m]-1] = m;
		if((processNode[m]==node) && (m<rank)){
		    attachedProcess[processNode[m]-1] = -1;
		}
	    }
	    //cout<<"\t\tattachedProcess by rank "<<rank<<","<<loop<<" :";
	    //printArray(attachedProcess,nodeSize); 
	    for(int l=0;l<edgeSize;l++){	
		if(((edgesInput[l][0]) == node) || ((edgesInput[l][1]) == node)){
		    //cout<<"failed: "<<l<<" "<<edgesInput[l][0]<<" "<<edgesInput[l][1]<<" "<<"ch "<<attachedProcess[(edgesInput[l][0]-1)]<<" "<<attachedProcess[(edgesInput[l][1]-1)]<<" "<<rank<<" "<<loop<<endl;		    
		    if(((attachedProcess[(edgesInput[l][0]-1)] >-1) && (attachedProcess[(edgesInput[l][0]-1)]<rank)) || ((attachedProcess[(edgesInput[l][1]-1)] >-1) &&(attachedProcess[(edgesInput[l][1]-1)]<rank))){		
		//cout<<"failed: "<<l<<" "<<edgesInput[l][0]<<" "<<edgesInput[l][1]<<" "<<"ch "<<attachedProcess[(edgesInput[l][0]-1)]<<" "<<attachedProcess[(edgesInput[l][1]-1)]<<" "<<rank<<" "<<loop<<endl;
			attachedProcess[processNode[rank]-1] = -1;
		    }
		    else{
			//cout<<"failed: "<<edgesGraphColor[l]<<" l: "<<l<<endl;
			if(edgesGraphColor[l] != 0)
			    colorsAvailable[edgesGraphColor[l]-1] = false;
		    }
		}
	    }
	    //cout<<"attachedProcess[processNode[rank]-1] for rank, loop "<<rank<<","<<loop<<" :"<<attachedProcess[processNode[rank]-1]<<endl;
	    if(attachedProcess[processNode[rank]-1]==-1){
		//cout<<"\t\t\tattachedProcess[processNode[rank]-1]==-1 rank "<<rank<<" loop "<<loop<<endl;
		continue;
	    }
	    //cout<<"\t\tcolorsAvailable by rank "<<rank<<": ";
	    //printArray(colorsAvailable,nodeSize);  
	    for(int l=0;l<edgeSize;l++){
		if((edgesGraphColor[l]==0) && (((edgesInput[l][0]) == node) || ((edgesInput[l][1]) == node))){
		    int otherNode;
		    if((edgesInput[l][0]) == node) 
			otherNode = edgesInput[l][1];
		    else
			otherNode = edgesInput[l][0];
		    //cout<<"otherNode :"<<otherNode<<endl;
		    for(int o=0;o<edgeSize;o++){
			if(((edgesInput[o][0]) == otherNode) || ((edgesInput[o][1]) == otherNode)){
			    if(edgesGraphColor[o] != 0)
			    	colorsAvailable[edgesGraphColor[o]-1] = false;
			}
		    }
		    
	    	    //cout<<"colorsAvailable by rank "<<rank<<": ";
	    	    //printArray(colorsAvailable,nodeSize);
		    for(int k=0;k<nodeSize;k++){
			if(colorsAvailable[k]){
			    //cout<<"k "<<k<<endl;
			    edgesGraphColor[l] = k+1;
			    colorsAvailable[k] = false;
			    break;
			}
		    }
		}
	    }
	    if(!checkColor(edgesGraphColor, edgeSize)){
		final = rank;
	    }
	    nodeVisited[processNode[rank]-1] = rank+1;
	    //cout<<"\t\tnodeVisited by rank "<<rank<<"f: ";
	    //printArray(nodeVisited,nodeSize); 
	    //cout<<"\t\tedgesGraphColor by rank "<<rank<<"f: ";
	    //printArray(edgesGraphColor,edgeSize); 
	}
	if(rank == final){
	    MPI_Barrier(MPI_COMM_WORLD);
	    int edgesGraphColorN[nodeSize];
	    MPI_Allreduce(edgesGraphColor, &edgesGraphColorN, edgeSize, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	    int maxNum = 0;

	    for (int i=0; i < edgeSize; i++) {
		if(edgesGraphColor[i] > maxNum)
		    maxNum = edgesGraphColor[i];
		    //cout<< recieved[i] <<' ';
	    }
	    ofstream MyWriteFile(argv[2]);
	    MyWriteFile <<maxNum<<endl;
	    for (int i=0; i < edgeSize; i++) {
		    MyWriteFile <<edgesGraphColor[i]<<' ';
		    //cout<< recieved[i] <<' ';
	    }
	    //cout<<endl;
	    MyWriteFile.close(); 
	}
	MPI_Finalize();    
	//printArray(edgesGraphColor,edgeSize);     
	return 0; 
}

