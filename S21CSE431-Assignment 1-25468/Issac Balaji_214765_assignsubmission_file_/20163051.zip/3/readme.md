Pseudocode:
Initialize the edgeColor Array with null color 0 for all edges.
Initialize the nodeVisited Array with null value 0 for all nodes.
loop until none of the edges is 0:
	MPI_BARRIER -- to stop all process at this step
	MPI All reduce -> edgeColor, edge size
	if(all edges have edgeColor)
		terminate the process;
	MPI All reduce -> nodeVisited, node size
	based on nodeVisted Array find a random node which is not visited.
	MPI All gather -> processNodes, sending the current node.
	processNodes contain global info what other process have chosen a node.
	if a node is not assigned,
		continue;
	initialize available colors Array (size = total no of nodes)
	
	check if node is valid only if below conditions satisfy
		if currentNode is selected by other process also
			node with lesser rank takes the node.
		for all the edges connected to the node should also be not assigned, if any node is assigned, then 
			node with lesser rank takes the node -> otherNode.
		also in other step find all the used colors for that node if it already assigned a color.
		
		assign the available colors to all the available nodes in edgeColor Array.
			update the node visited by the process
	end loop
print the edgeColor Array.

sample test:
mpic++ 20163051_3.cpp
mpirun -np 1 a.out test test1		//  for single process
mpirun -np 10 a.out test test10  	//  for single process
