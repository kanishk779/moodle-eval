#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#define max_rows 1000000
int str_length = 0;
using namespace std;
int* convertStrtoArr(string str, int arr[]) 
{ 
	// get length of string str 

	//cout<<str<<endl;
	int j = 0, i;
	bool neg = false;
	// Traverse the string 
	for (i = 0; str[i] != '\0'; i++) { 
		
		// if str[i] is ', ' then split 
		if (str[i] == '-') 
			neg = true;
		else if (str[i] == ' '){ 
			// Increment j to point to next 
			// array location 
			if(neg){
			    arr[j] = arr[j] * -1;
			}
			neg = false;
			j++; 
		} 
		else { 

			// subtract str[i] by 48 to convert it to int 
			// Generate number by multiplying 10 and adding 
			// (int)(str[i]) 
			//cout <<str[i]<<" before "<<arr[j] << " "<<i<<" "<<j<<endl; 
			arr[j] = arr[j] * 10 + (str[i] - 48); 
			//cout <<str[i]<<" after "<<arr[j] << " "<<i<<" "<<j<<endl; 
		} 
	} 
	if(neg){
	    //cout<<j<<endl;
	    arr[j] = arr[j] * -1;
	}
	str_length = j++;
	
} 
void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 
int split (int arrayInputSplit[], int min, int max) 
{ 
    int piv = arrayInputSplit[max];    
    int i = (min - 1);  
  
    for (int j = min; j <= max-1; j++) 
    { 
         
        if (arrayInputSplit[j] <= piv) 
        { 
            i++;    
            swap(&arrayInputSplit[i], &arrayInputSplit[j]); 
        } 
    } 
    swap(&arrayInputSplit[i + 1], &arrayInputSplit[max]); 
    return (i + 1); 
} 
void quicksort(int arrayInput[], int min, int max){
	//cout<<"in "<<min<<" "<<max<<endl;
	if(min<max){
		int piv = split(arrayInput, min, max);
		quicksort(arrayInput, min, piv-1);
		quicksort(arrayInput, piv+1,max);
	}
	//cout<<"out "<<min<<" "<<max<<endl;
}
void printArray(int arr[], int size) 
{ 
    int i; 
    for (i=0; i < size; i++) 
        cout<<arr[i]<<" "; 
    cout<<endl;; 
} 
int main(int argc, char* argv[])
{
        ifstream MyReadFile(argv[1]);
        string input,inputLine;
        getline (MyReadFile, input);
    	getline (MyReadFile, inputLine);
	//cout << input;
	MyReadFile.close();
        int N = atoi(input.c_str());
	//cout<<inputLine<<endl;
        string str = inputLine;//"2 -6 -3 14";

	str_length = str.length(); 
	// create an array with size as string 
	// length and initialize with 0  
	int arr[str.length()];

	for (int i = 0; i < str_length; i++) // ...initialize it
	{
	    arr[i] = 0;
	}
	convertStrtoArr(str,arr); 

	int *finalArr;
	//cout << "arr[] = "; 
	//int sum =0;
	//for (int i = 0; i <= str_length; i++) { 
	//	cout << arr[i] << " "; 
	//	sum += arr[i]; // sum of array 
	//} 

	// print sum of array 
	//cout << "\nSum of array is = " << sum << endl; 
	//quicksort(arr, 0, N); 
    	//cout<<"Sorted array: n"<<endl; 
    	//printArray(arr, N);
	//cout<<"line122";
        int * array;
        int tag=1;
        int size;
        int rank;
        MPI_Status status;
        MPI_Init (&argc,&argv);
        MPI_Comm_size (MPI_COMM_WORLD,&size);
        MPI_Comm_rank (MPI_COMM_WORLD,&rank);
	int *recieved;
        int sentsz,SENDER,pivot;
	//splitArray
	//if(rank<pow(2,floor(log2(size+1)))){
	if(rank!=0){
	    SENDER = (rank-1)/2;
	    //cout<<"expect recv from "<<SENDER<<" to "<<rank<<endl;
	    MPI_Recv(&sentsz, 1, MPI_INT, SENDER, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    if(sentsz>0){
	    	//cout<<"init recv "<<sentsz<<" from "<<SENDER<<" to "<<rank<<endl;
		recieved = (int *)malloc(sentsz * sizeof(*recieved));
	 	MPI_Recv(recieved, sentsz, MPI_INT, SENDER, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    }
	}
	else{
	    sentsz = N;
	    recieved = arr;
	}
        if((sentsz >1) && (((2*rank)+2)<size)){
	    //cout<<"check "<<rank<<endl;
	    pivot = recieved[0];
	    int leftsz = 0, rightsz = 0;
	    int left[sentsz];
	    int right[sentsz];
	    int *leftRecv;
	    int *rightRecv;
	    for (int i = 0; i < sentsz; i++) {
	    	if(recieved[i] <= pivot){
		    left[leftsz] = recieved[i];
		    leftsz++;
		}
		else{
		    right[rightsz] = recieved[i];
		    rightsz++;		
		}
	    } 
	    MPI_Send(&leftsz, 1, MPI_INT, ((2*rank)+1), rank, MPI_COMM_WORLD);	    
	    //cout<<"init sent "<<leftsz<<" from "<<rank<<" to "<<((2*rank)+1)<<endl;
	    if(leftsz>0)
	    	MPI_Send(left, leftsz, MPI_INT, ((2*rank)+1), rank, MPI_COMM_WORLD);
	    MPI_Send(&rightsz, 1, MPI_INT, ((2*rank)+2), rank, MPI_COMM_WORLD);
	    //cout<<"init sent "<<rightsz<<" from "<<rank<<" to "<<((2*rank)+2)<<endl;
	    if(rightsz >0)
		MPI_Send(right, rightsz, MPI_INT, ((2*rank)+2), rank, MPI_COMM_WORLD);

	    //cout<<rank<<endl;
	    SENDER = (rank-1)/2;
	    if(leftsz>0){
	    	leftRecv = (int *)malloc(leftsz * sizeof(*leftRecv));
	    	MPI_Recv(leftRecv, leftsz, MPI_INT, ((2*rank)+1), MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    }
	    //cout<<"next recv "<<leftsz<<" from "<<((2*rank)+1)<<" to "<<rank<<endl;
	    if(rightsz >0){
	    	rightRecv = (int *)malloc(rightsz * sizeof(*rightRecv));
	    	MPI_Recv(rightRecv, rightsz, MPI_INT, ((2*rank)+2), MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	    }
	    //cout<<"next recv "<<rightsz<<" from "<<((2*rank)+2)<<" to "<<rank<<endl;
	    
	    //cout<<rank<<leftsz<<" "<<rightsz<<endl;
	    int sentProcess[sentsz];
	    for(int i=0;i<leftsz;i++){
		sentProcess[i] = leftRecv[i];
		//cout<<"rank l"<<rank<<" "<<sentProcess[i]<<" "<<i<<endl;
	    }
	    for(int i=0;i<rightsz;i++){
		sentProcess[leftsz+i] = rightRecv[i];
		//cout<<"rank r"<<rank<<" "<<sentProcess[leftsz+i]<<" "<<(leftsz+i)<<endl;
	    }
	    
	    if(rank!=0){
		//cout<<"next sent "<<sentsz<<" from "<<rank<<" to "<<SENDER<<endl;
	    	MPI_Send(sentProcess, sentsz, MPI_INT,SENDER , rank, MPI_COMM_WORLD);
		//cout<<"nextf sent "<<sentsz<<" from "<<rank<<" to "<<SENDER<<endl;
	    }
	    else{
		ofstream MyWriteFile(argv[2]);
		for (int i=0; i < N; i++) {
		    MyWriteFile <<sentProcess[i]<<' ';
		    //cout<< sentProcess[i] <<' ';
		}
		//cout<<endl;
	    	MyWriteFile.close(); 
   	    }
	}

	//processArray
	else{
	    //sort manually
	    //cout<<"checke "<<rank<<endl;
	    if(sentsz>1){
		//cout<<"before sort "<<sentsz<<endl;
		//printArray(recieved, sentsz);
		quicksort(recieved, 0, sentsz-1);
		//cout<<"after sort "<<rank<<endl;
		//printArray(recieved, sentsz);
	    }
	    int zerosz =0;
	   if(((2*rank)+1)<size){
		//cout<<"next sent "<<sentsz<<" from "<<rank<<" to "<<((2*rank)+1)<<endl;
		MPI_Send(&zerosz, 1, MPI_INT, ((2*rank)+1), rank, MPI_COMM_WORLD);
	   }
	   if(((2*rank)+2)<size){
		//cout<<"next sent "<<sentsz<<" from "<<rank<<" to "<<((2*rank)+2)<<endl;
		MPI_Send(&zerosz, 1, MPI_INT, ((2*rank)+2), rank, MPI_COMM_WORLD);
	   }
	   SENDER = (rank-1)/2;
	   if(rank!=0){
		//cout<<"next sent "<<sentsz<<" from "<<rank<<" to "<<SENDER<<endl;
	   	MPI_Send(recieved, sentsz, MPI_INT, SENDER, rank, MPI_COMM_WORLD);
		//cout<<"nextf sent "<<sentsz<<" from "<<rank<<" to "<<SENDER<<endl;
	   }
	   else{		
		ofstream MyWriteFile(argv[2]);
		for (int i=0; i < N; i++) {
		    MyWriteFile <<recieved[i]<<' ';
		    //cout<< recieved[i] <<' ';
		}
		//cout<<endl;
	    	MyWriteFile.close(); 		 
	   }
	}
	//}
	MPI_Finalize();         
	return 0; 
}

