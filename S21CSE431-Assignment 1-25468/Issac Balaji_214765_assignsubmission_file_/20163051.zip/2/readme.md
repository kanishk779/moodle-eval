Pseudocode:
Use the logic of a tree structure that process x's parent rank will be (x-1/2).
Therefore any node can have it child rank either 2*y + 1, or 2*y + 2.
Ex:
0
-->1
   -->3
      -->7
      -->8
   -->4
      -->9
      -->10
-->2
   -->5
      -->11
      -->12
   -->6
      -->13
      -->14
Step 1: if not root, Recieve the array
Step 2: if child process is available, 	
		split the array based on a random pivot
		send all the num's less than pivot to left child
		send all the num's greater or equal to pivot to right child
		gather the sorted array from left and right child
		if not root node
			pass it to parent
		else
			end the algo.

	if not available
		sort manually using quicksort algo.
	
		

sample test:
mpic++ 20163051_2.cpp
mpirun -np 1 a.out test test1		//  for single process
mpirun -np 10 a.out test test10  	//  for single process
