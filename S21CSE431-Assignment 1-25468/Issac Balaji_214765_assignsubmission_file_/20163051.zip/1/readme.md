Pseudocode:
if rank > size, 
	buffer = 0
else
	buffer = 1/ pow(rank,2)
MPI Reduce to result, sum

		

sample test:
mpic++ 20163051_1.cpp
mpirun -np 1 a.out test test1		//  for single process
mpirun -np 10 a.out test test10  	//  for single process
