#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;
int main(int argc, char* argv[])
{
    //cout << argv[0]<<endl;
    ifstream MyReadFile(argv[1]);
    string input;
    getline (MyReadFile, input);
    //cout << input;
    MyReadFile.close();
    MPI_Init(&argc, &argv);
    int N = atoi(input.c_str());
    //cout << szi<<endl;
    int root_rank = 0;
    int my_rank;
    int size;
    double reduction_result = 0.0;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    double buffer  = 0.0;
	//cout<<"init "<<N<<" "<<my_rank<<" "<<size<<endl;
    if(N<=size){
	if(N<=my_rank){
	    buffer = 0.0;
	} else{
            buffer = 1/pow(my_rank+1,2) ;    
	}
    }
    else{
	int x=0,d = N/size;
	//cout<<"inside else "<<x+(my_rank*d)<<endl;
	while((x<d)&&((x+(my_rank*d))<N)){
	    //cout<<x<<" "<<d<<" "<<my_rank<<" "<<x+(my_rank*d)<<" "<<buffer<<endl;
	    buffer = buffer + (1/pow((x+1+(my_rank*d)),2));	
	    x++;
	}
    }
    
    //printf ("%d, %f\n",my_rank, buffer);
    MPI_Reduce(&buffer, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, root_rank,MPI_COMM_WORLD);
 
    if(my_rank == root_rank)
        printf("%f\n", reduction_result);
    MPI_Finalize(); 
	ofstream MyWriteFile(argv[2]);

	  // Write to the file
	  MyWriteFile << reduction_result<<endl;
	 
	  // Close the file
	  MyWriteFile.close();
    return EXIT_SUCCESS;
}

