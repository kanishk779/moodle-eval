/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define MX_IN 1000005

void merge(int* arr1, int* arr2, int s1, int s2) {

	int i1 = 0, i2 = 0, f=0;
	int *f_arr = new int[s1+s2];

	while(i1 < s1 && i2 < s2) {
		if (arr1[i1] < arr2[i2]) f_arr[f++] = arr1[i1++];
		else f_arr[f++] = arr2[i2++];
	}
	
	while(i1 < s1) f_arr[f++] = arr1[i1++];
	while(i2 < s2) f_arr[f++] = arr2[i2++];

	for(int i=0; i<s1+s2; i++) {
		arr1[i] = f_arr[i];
	}

	delete f_arr;
}

void quick_sort(int* arr, int s, int e) {
	
	if (s < e) {
		int p_i = s, s_i = p_i +1, l_i = e;

		while(s_i <= l_i) {
			while (s_i <=e && arr[s_i] <= arr[p_i]) s_i++;

			while(l_i > p_i && arr[l_i] >= arr[p_i]) l_i--;

			if(s_i < l_i) {
				swap(arr[s_i], arr[l_i]);
			}
		}

		swap(arr[p_i], arr[l_i]);

		quick_sort(arr, s, l_i-1);
		quick_sort(arr, l_i+1, e);
	}
	
	return;
}

int main (int argc, char **argv ) {
	int rank, numprocs, unused = 0;

	/* Start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

	/* Synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();
	int sorted[MX_IN];
	int N;

	ifstream input;
	FILE *output;

	if (rank == 0) {
		/* Input, Output file stream opening */
		if (argc < 3) {
			fprintf(stderr, "Invalid number of arguments. Input/Output file missing\n"); 
			return 404;
		}
		
		input.open(argv[1]);
		output = fopen(argv[2], "w");

		/* Reading input */	
		int arr[MX_IN];

		input >> N;

		for(int i = 0; i<N; i++) {
			input >> arr[i];
		}

		input.close();

		/* Processing */

		int div_procs = N / numprocs;
		int extra = N % numprocs;
		int num_elems[numprocs] = {0};
		
		int sent = 0;

		for( int i=0; i<numprocs; i++) {
			num_elems[i] += div_procs;
			if (extra) {num_elems[i]++; extra--;}
			if (num_elems[i] < 1) unused++;
		}
		
		for (int i=1; i<numprocs; i++) MPI_Send( &unused , 1 , MPI_INT , i , 0 , MPI_COMM_WORLD);

		sent += num_elems[0];

		for (int i=1; i<numprocs-unused; i++) {
			MPI_Send( num_elems+i , 1 , MPI_INT , i , 0 , MPI_COMM_WORLD);
			if (num_elems[i]) MPI_Send( arr + sent , num_elems[i] , MPI_INT , i , 0 , MPI_COMM_WORLD);
			sent += num_elems[i];
		}

		for (int i=0; i<num_elems[0]; i++) {
			sorted[i] = arr[i];
		}

		quick_sort(sorted, 0, num_elems[0]-1);

		/* Merging on separate procs */
		for(int i=1; i<=8; i*=2) {
			if (i < numprocs-unused) {
				int num2;
				MPI_Recv( &num2, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				if (num2) {
					int* elements_2 = new int[num2];
					MPI_Recv(elements_2, num2, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
					merge(sorted, elements_2, num_elems[0], num2);
					delete elements_2;
					num_elems[0] += num2;
				}					
			}
		}
		
	}

	else  {
		
		MPI_Recv( &unused , 1 , MPI_INT , 0 , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);

		if (rank < numprocs - unused) {
			int elements[MX_IN];
			int num;

			MPI_Recv ( &num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, 0);
			if(num != 0){
				MPI_Recv( elements , num , MPI_INT , 0 , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);

				quick_sort(elements, 0, num-1);
			
				/* Merge on separate procs */
				for (int i=2; i<=16; i*=2) {
					if(rank % i == 0) {
						if (rank + i/2 < numprocs-unused) {
							int num2;
							MPI_Recv( &num2, 1, MPI_INT, rank+i/2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
							if (num2) {
								int* elements_2 = new int[num2];
								MPI_Recv(elements_2, num2, MPI_INT, rank+i/2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
								merge(elements, elements_2, num, num2);
								delete elements_2;
								num += num2;
							}					
						}
					} 

					else {
						if (rank - i/2 >= 0) {
							MPI_Send( &num, 1, MPI_INT, rank-i/2, 0, MPI_COMM_WORLD);
							if (num) MPI_Send( elements, num, MPI_INT, rank-i/2, 0, MPI_COMM_WORLD);
						}
					}
				}
			}
		}
	}

	if (rank == 0) {
		for (int i=0; i<N; i++) {
			fprintf(output, "%d ", sorted[i]);
		}
		fprintf(output, "\n");

		fclose(output);
	}

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}
	
	/* Shut down MPI */
	MPI_Finalize();
	return 0;
}
