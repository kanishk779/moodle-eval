/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define MX_IN 10005

int main (int argc, char **argv ) {
	int rank, numprocs;

	/* Start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

	/* Synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();
	double sum = 0, sum_temp = 0;

	ifstream input;
	FILE *output;

	if (rank == 0) {
		/* Input, Output file stream opening */
		if (argc < 3) {
			fprintf(stderr, "Invalid number of arguments. Input/Output file missing\n"); 
			return 404;
		}
		
		input.open(argv[1]);
		output = fopen(argv[2], "w");

		/* Reading input */	
		int N;
		double arr[MX_IN];

		input >> N;

		for(int i = 0; i<N; i++) {
			arr[i] = (double) (i+1)*(i+1);
		}

		input.close();

		/* Processing */
		int div_procs = N / numprocs;
		int extra = N % numprocs;
		int num_elems[numprocs] = {0};

		int sent = 0;
		
		for( int i=0; i<numprocs; i++) {
			num_elems[i] += div_procs;
			if (extra) {num_elems[i]++; extra--;}
		}

		sent += num_elems[0];
		for (int i=1; i<numprocs; i++) {
			MPI_Send(num_elems+i, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
			MPI_Send( arr + sent , num_elems[i] , MPI_DOUBLE , i , 0 , MPI_COMM_WORLD);
			sent += num_elems[i];
		}

		for  (int i=0; i<num_elems[0]; i++) {
			arr[i] = 1/arr[i];
			sum_temp += arr[i];
		}
	}

	else {

		double elements[MX_IN/11];
		int num;

		MPI_Recv( &num , 1 , MPI_INT , 0 , 0 , MPI_COMM_WORLD , 0);

		if(num != 0){
			MPI_Recv( elements , num , MPI_DOUBLE , 0 , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
		
			for(int i=0; i<num; i++) {
				elements[i] = 1/elements[i];
				sum_temp += elements[i];
			}
		}

	}

	MPI_Reduce (&sum_temp, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

	/* Writing output */
	if (rank == 0) {
		fprintf(output, "%.6f\n", sum);
		fclose(output);
	}

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}
	
	/* shut down MPI */
	MPI_Finalize();
	return 0;
}
