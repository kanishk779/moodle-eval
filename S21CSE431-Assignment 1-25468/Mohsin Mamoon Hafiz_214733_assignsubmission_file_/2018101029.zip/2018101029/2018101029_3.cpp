/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

#define MX_IN 510

int main (int argc, char **argv ) {
	int rank, numprocs, unused = 0;	
	int num_elems[11] = {0}, start[11] = {0};

	/* Start up MPI */
	MPI_Init( &argc, &argv );

	MPI_Comm_rank( MPI_COMM_WORLD, &rank );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

	/* Synchronize all processes */
	MPI_Barrier( MPI_COMM_WORLD );
	double tbeg = MPI_Wtime();
	int M, N;
	bool is_valid[MX_IN] = {0};
	int edges[MX_IN][2] = {0};
	int edges_rand[MX_IN];
	int line_adj[MX_IN][MX_IN] = {0};
	int color[MX_IN] ={0};
	int colored = 0;


	ifstream input;
	FILE *output;

	if (rank == 0) {
		/* Input, Output file stream opening */
		if (argc < 3) {
			fprintf(stderr, "Invalid number of arguments. Input/Output file missing\n"); 
			return 404;
		}
		
		input.open(argv[1]);
		output = fopen(argv[2], "w");

		/* Reading input */	
		
		input >> N;
		input >> M;

		for(int i = 0; i<M; i++) {
			input >> edges[i][0];
			input >> edges[i][1];
			is_valid[i] = 1;
			edges_rand[i] = rand();
			for (int j=0; j<M+5; j++) {
				line_adj[i][j] = -1;
			}
		}
		
		input.close();

		/* Processing */

		int div_procs = M / numprocs;
		int extra = M % numprocs;

		int sent = 0;

		for( int i=0; i<numprocs; i++) {
			num_elems[i] += div_procs;
			if (extra) {num_elems[i]++; extra--;}
			if (num_elems[i] < 1) unused++;
			start[i] = sent;
			sent += num_elems[i];
		}
	}

	MPI_Bcast( &M , 1 , MPI_INT , 0 , MPI_COMM_WORLD );
	MPI_Bcast( edges , M*2 , MPI_INT , 0 , MPI_COMM_WORLD );
	MPI_Bcast( is_valid , M , MPI_C_BOOL , 0 , MPI_COMM_WORLD );
	MPI_Bcast( num_elems , numprocs , MPI_INT , 0 , MPI_COMM_WORLD );
	MPI_Bcast( &unused , 1 , MPI_INT , 0 , MPI_COMM_WORLD );
	MPI_Bcast( start , numprocs , MPI_INT , 0 , MPI_COMM_WORLD );
	MPI_Bcast( line_adj , MX_IN*MX_IN , MPI_INT , 0 , MPI_COMM_WORLD);
	MPI_Bcast( edges_rand , M , MPI_INT , 0 , MPI_COMM_WORLD);


	/* Finding the line graph */

	int *nums = new int[num_elems[rank]];

	for(int i=start[rank]; i<start[rank]+num_elems[rank]; i++) {
		nums[i-start[rank]] = 0;
		int p = 0;
		for( int j=0; j<M; j++) {
			if (i != j && (edges[j][0] == edges[i][0] || edges[j][1] == edges[i][0] || edges[j][0] == edges[i][1] || edges[j][1] == edges[i][1])) {
				line_adj[i][p++] = j;
			}
		}
		nums[i-start[rank]] = ++p;
	}
	
	if (rank == 0) {
		int adj[MX_IN], n, r;
		for(int i=1; i<numprocs-unused; i++) {
			for (int j=0; j<num_elems[i]; j++) {
				MPI_Recv( &n , 1 , MPI_INT , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
				MPI_Recv( &r , 1 , MPI_INT , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
				MPI_Recv( adj , n , MPI_INT , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
				for (int j=0; j<n; j++) line_adj[r][j] = adj[j];
			}
		}
	}
	else {
		for (int i=start[rank]; i<start[rank]+num_elems[rank]; i++) {
			MPI_Send( nums+i-start[rank] , 1 , MPI_INT , 0 , 0 , MPI_COMM_WORLD);
			MPI_Send(&i, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
			MPI_Send(line_adj[i], nums[i-start[rank]], MPI_INT, 0, 0, MPI_COMM_WORLD);
		}
	}

	MPI_Bcast( line_adj , MX_IN*MX_IN , MPI_INT , 0 , MPI_COMM_WORLD);

	/* Coloring the vertices of line graph using Jones Plassmann algorithm */
	
	int valid = num_elems[rank];
	while(colored < M) {
		int temp_colored = 0;
		if(rank == 0) temp_colored = colored;
	
		vector<int> toColor;
		set<int> present;
		for (int i=start[rank]; i<start[rank]+num_elems[rank] && valid; i++) {
			if (!is_valid[i]) continue;
			bool flag = true;
			present.clear();
			for (int j=0; j<nums[i-start[rank]]; j++) {
				int neighbour = line_adj[i][j];
				if (color[neighbour]) present.insert(color[neighbour]);	
				if (!is_valid[neighbour]) continue;
				if(edges_rand[neighbour] > edges_rand[i] || (edges_rand[neighbour] == edges_rand[i] && i<neighbour)) {
					flag = false;
					break;
				}
			}

			if (flag) {
				int min = 1;
				while(present.find(min) != present.end()) min++;
				color[i] = min;
				toColor.push_back(i);
			}
		}

		for(int i=0; i<toColor.size(); i++) {
			is_valid[toColor[i]] = 0;
			valid--;
			temp_colored++;
		}

		if (rank == 0) {
			for (int i=1; i<numprocs-unused; i++) {
				MPI_Recv( color+start[i] , num_elems[i] , MPI_INT , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
				MPI_Recv( is_valid+start[i] , num_elems[i] , MPI_C_BOOL , i , 0 , MPI_COMM_WORLD , MPI_STATUS_IGNORE);
			}
		}
		else {
			MPI_Send( color+start[rank] , num_elems[rank] , MPI_INT , 0 , 0 , MPI_COMM_WORLD);
			MPI_Send( is_valid+start[rank] , num_elems[rank] , MPI_C_BOOL , 0 , 0 , MPI_COMM_WORLD);
		}

		MPI_Bcast( color , M , MPI_INT , 0 , MPI_COMM_WORLD );
		MPI_Bcast( is_valid , M , MPI_C_BOOL , 0 , MPI_COMM_WORLD );
		MPI_Reduce( &temp_colored , &colored , 1 , MPI_INT , MPI_SUM , 0 , MPI_COMM_WORLD);
		MPI_Bcast( &colored , 1 , MPI_INT , 0 , MPI_COMM_WORLD);
		toColor.clear();
	}


	if (rank == 0) {
		set<int> clrs;
		for (int i=0; i<M; i++) clrs.insert(color[i]);
		
		fprintf(output, "%ld\n", clrs.size());
		for (int i=0; i<M; i++) fprintf(output, "%d ", color[i]);
		fprintf(output, "\n");
		
		fclose(output);
	}

	MPI_Barrier( MPI_COMM_WORLD );
	double elapsedTime = MPI_Wtime() - tbeg;
	double maxTime;
	MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
	if ( rank == 0 ) {
		printf( "Total time (s): %f\n", maxTime );
	}
	
	/* Shut down MPI */
	MPI_Finalize();
	return 0;
}
