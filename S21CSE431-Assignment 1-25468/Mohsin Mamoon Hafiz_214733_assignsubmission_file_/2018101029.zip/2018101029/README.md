# Distributed Systems: Assignment 1

### `Mohsin Mamoon Hafiz`
#### `2018101029`
____________________________________________

## Question 1: Sum of reciprocal of squares.

#### Solution

1. Take input and create an array arr[N].
2. Set $arr[i] = i^2$ and divide the array into smaller sub arrays each sent to an available process.
3. In each process, do $arr[i] = \frac{1}{arr[i]}$ and store the sum of the subarray in a variable.
4. Use MPI_Reduce to sum up all the temporary sum variables from different processes to get the final result.




## Question 2: Parallel QuickSort

#### Solution

1. Take input and divide the array into smaller sub arrays each sent to an available process.
2. In each process, sort the subarray using quick sort.
3. Each process merges it's own sorted subarray with that of the next process.
4. Repeat 3 until all subarrays are merged to give the final sorted array.




## Question 3: Parallel Edge coloring of a Graph

#### Solution

1. Take input and divide the edges equally among the available processes.
2. Create a line graph from the input graph with each process calculating the neighbours of the vertices formed by the edges sent to it.
3. Synchronise the adjaceny matrix for the line graph between all processes. (Each process sends their calculated part of adjacency matrix to root (rank 0) process which updates the global variable and broadcasts to all).
4. Use Joness-Plassman Algorithm to color the vertices of the line graph. The colors of vertices in line graph correspond the colors of edges in original graph:

      i. Root process associates a random number with each vertex and broadcasts this to all processes.
      ii. In each iteration, each processor finds an independent set of vertices (from the ones assigned to it) by selecting the vertices which have highest random number among their neighbours.
      iii. Every vertex in this set is colored the minimum color that none of their neighbours have.
      iv. This coloring is sunchronised between all processes.
      v. Step ii - iv is repeated until all vertices are colored.