
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 
  
/* This function takes last element as pivot, places 
   the pivot element at its correct position in sorted 
    array, and places all smaller (smaller than pivot) 
   to left of pivot and all greater elements to right 
   of pivot */
int partition (int arr[], int low, int high) 
{ 
    int pivot = arr[high];    // pivot 
    int i = (low - 1);  // Index of smaller element 
  
    for (int j = low; j <= high- 1; j++) 
    { 
        // If current element is smaller than or 
        // equal to pivot 
        if (arr[j] <= pivot) 
        { 
            i++;    // increment index of smaller element 
            swap(&arr[i], &arr[j]); 
        } 
    } 
    swap(&arr[i + 1], &arr[high]); 
    return (i + 1); 
} 
  
/* The main function that implements QuickSort 
 arr[] --> Array to be sorted, 
  low  --> Starting index, 
  high  --> Ending index */
void quickSort(int arr[], int low, int high) 
{ 
    if (low < high) 
    { 
        /* pi is partitioning index, arr[p] is now 
           at right place */
        int pi = partition(arr, low, high); 
  
        // Separately sort elements before 
        // partition and after partition 
        quickSort(arr, low, pi - 1); 
        quickSort(arr, pi + 1, high); 
    } 
} 

class myComparator
{
public:
    int operator() (const pair<int,pair<int,int> >& p1, const pair<int,pair<int,int> >& p2)
    {
        return p1 > p2;
    }
};
int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

     int n;
    if(rank==0)
    {
        // freopen(argv[1], "r", stdin);
        // freopen(argv[2], "w", stdout);
        // cin>>n;
        

        // for(int i=0;i<n;i++)    cin>>arr[i];
        
        // read size of data
        FILE *file = NULL;
        // int n;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);

        int arr[n];
        int ans[n];

        vector<int> data(n);
        for (int i = 0; i < n; i++)
            fscanf(file, "%d", &(arr[i]));
        fclose(file);

        // vector<vector<int> > final(min(numprocs,n));

        for (int i=1;i<numprocs;i++)    MPI_Send(&n,1,MPI_INT,i, 0, MPI_COMM_WORLD);

        for(int i=1;i<min(n,numprocs);i++)    
        {
            int start=max(1,(n/numprocs))*i+1,end=start+max(1,(n/numprocs))-1;
            if(i==(numprocs-1)) end+=n%numprocs;
            // if(end>n) break;
            MPI_Send(&arr[start-1],end-start+1,MPI_INT,i, 0, MPI_COMM_WORLD);
        }
        quickSort(arr,0,max(1,n/numprocs)-1);
        // for(int j=0;j<max(1,n/numprocs);j++) final[0].push_back(arr[j]);
        
        for(int i=1;i<min(n,numprocs);i++)    
        {
            int start=max(1,(n/numprocs))*i+1,end=start+max(1,(n/numprocs))-1;
            if(i==(numprocs-1)) end+=n%numprocs;
            MPI_Recv(&arr[start-1], end-start+1 , MPI_INT,i, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            // for(int j=start-1;j<end;j++) final[i-1].push_back(arr[j]);
        }
        // for(int i=0;i<n;i++)    cout<<arr[i]<<" ";
        // cout<<endl;

        priority_queue <pair<int ,pair<int,int> > ,vector<pair<int,pair<int,int> > >, myComparator> pq;
        // int divs=min(n,numprocs),size=max(1,n/numprocs),modu;
        for(int i=0;i<min(n,numprocs);i++)
        {
            int start=max(1,(n/numprocs))*i+1,end=start+max(1,(n/numprocs))-1;
            if(i==(numprocs-1)) end+=n%numprocs;
            pq.push(make_pair(arr[start-1],make_pair(i,0)));
        }
        pair<int ,pair<int,int> > temp;
        int pt=0;
        while (pq.empty() == false)
        {
            temp=pq.top();
            pq.pop();
            ans[pt]=temp.first;
            pt++;
            int start=max(1,(n/numprocs))*temp.second.first+1,end=start+max(1,(n/numprocs))-1;
            if(temp.second.first==(numprocs-1)) end+=n%numprocs;
            if((start+temp.second.second)<end)
            {
                temp.second.second++;
                temp.first=arr[start+temp.second.second-1];
                pq.push(temp);
            }
        }
        // for(int i=0;i<n;i++)    cout<<ans[i]<<" ";
        // cout<<endl;
        file = fopen(argv[2], "w");
        for (int i = 0; i < n; i++)
        fprintf(file, "%d ", ans[i]);
        fclose(file);

    }
    else
    {
        MPI_Recv(&n, 1, MPI_INT,0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        int start=max(1,(n/numprocs))*rank+1,end=start+max(1,(n/numprocs))-1;
        if(rank==(numprocs-1)) end+=n%numprocs;
        if(end<=n)
        {
            int arr[end-start+1];
            MPI_Recv(&arr[0], end-start+1 , MPI_INT,0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            quickSort(arr,0,end-start);
            MPI_Send(&arr[0],end-start+1,MPI_INT,0, 0, MPI_COMM_WORLD);
        }
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}