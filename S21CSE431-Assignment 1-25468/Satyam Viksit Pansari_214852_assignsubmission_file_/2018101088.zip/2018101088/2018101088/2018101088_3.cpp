
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    int n,m,maxcols;
    FILE *file = NULL;
    if(rank==0)
    {
        // freopen(argv[1], "r", stdin);
        // freopen(argv[2], "w", stdout);
        // int n;
        file = fopen(argv[1], "r");
        // cin>>n>>m;
        fscanf(file, "%d", &n);
        fscanf(file, "%d", &m);
    }
    // if(numprocs>1)
    MPI_Bcast(&m,1,MPI_INT,0,  MPI_COMM_WORLD);

    int matrix[m * m];
    if(rank==0)
    {
        pair<int , int > arr[m];
        // int adjmt[n][n];
        // for(int i=0;i<n;i++)for(int j=0;j<n;j++)adjmt[i][j]=0;
        for(int i=0;i<m;i++)
        {
            // cin >> arr[i].first >> arr[i].second ;
            fscanf(file, "%d", &(arr[i].first));
            fscanf(file, "%d", &(arr[i].second));
        }
        fclose(file);
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(arr[i].first==arr[j].second || arr[j].first==arr[i].second || arr[i].first==arr[j].first || arr[i].second==arr[j].second)
                    matrix[m*i+j]=1;
                else
                    matrix[m*i+j]=0;
                if(i==j) matrix[m*i+j]=0;
                // cout<<matrix[m*i+j]<<" ";
            }
            // cout<<endl;
        }
    }
    MPI_Bcast(&matrix[0],m*m,MPI_INT,0,  MPI_COMM_WORLD);
    int colours[m];
    for(int i=0;i<m;i++)colours[i]=0;
    int start=max(1,(m/numprocs))*rank+1,end=start+max(1,(m/numprocs))-1;
    if(rank==(numprocs-1)) end+=m%numprocs;
    set <int> nodes;
    for(int i=start ; i<=end;i++) nodes.insert(i);
    while(1)
    {
        vector<int> ntoc;
        for(set<int>::iterator itr=nodes.begin();itr!=nodes.end();itr++)
        {
            bool flag=true;
            for(int i = (*itr) - 1 ; i< m ; i++)
                if(matrix[(*itr-1)*m + i]==1 && colours[i]==0) {flag=false; break; }
            if (flag) ntoc.push_back(*itr);
        }
        if(rank<m)
        {
            for(int i=0;i<ntoc.size();i++)
            {
                int col=1;
                vector<int> scols;
                nodes.erase(ntoc[i]);
                for(int j=0 ; j< m ; j++)
                {
                    if(matrix[(ntoc[i]-1)*m + j]==1 && colours[j]!=0) scols.push_back(colours[j]);
                }
                sort(scols.begin(),scols.end());
                for(int j=0;j<scols.size();j++)
                {
                    if(scols[j]!=col)
                    {
                        break;
                    }
                    col++;
                }
                colours[ntoc[i]-1]=col;
            }
        }
        if(rank!=0) 
        {
            MPI_Send(&colours[0],m,MPI_INT,0, 0, MPI_COMM_WORLD);
        }
        else
        {
            int temp[m];
            for(int j=1;j<numprocs;j++)
            {
                MPI_Recv(&temp[0],m,MPI_INT,j, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                for(int i=0;i<m;i++) colours[i]=max(colours[i],temp[i]);
            }
        }
        // if(numprocs>1)
        MPI_Bcast(&colours[0],m,MPI_INT,0,  MPI_COMM_WORLD);
        bool bf =true;
        for(int i=0;i<m;i++)if (colours[i]==0) bf=false;
        if(bf) break;
    }
    if(rank==0)
    {
        maxcols=0;
        for(int i=0;i<m;i++) 
        {
            maxcols=max(maxcols,colours[i]);
        }
        file = fopen(argv[2], "w");
        fprintf(file, "%d \n", maxcols);
        for (int i = 0; i < n; i++)
        fprintf(file, "%d ", colours[i]);
        fclose(file);
        cout<<endl;
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }
    /* shut down MPI */
    MPI_Finalize();
    return 0;
}