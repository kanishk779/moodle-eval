## Distributed Systems - Assignment 1 
---
##### Satyam Viksit Pansari (2018101088)
---
## Description and Analysis of Solutions
---
### Question 1 :

#### Implementation Approach

1. Main/master process will be divided into multiple child processes.Now the master process "sends" the data to the other child/slave processes for their computations. Each process will do their part of computation in parallel. In the end, master process after completing its own part/computation "receives" the result of respective process's computation and hence done. So this is the message passing happening in parallel algorithms.
2. Used the following MPI Commands :
    1. MPI_Send
    2. MPI_Recv 


### Question 2 :

#### Implementation Approach

1. The input array is divided into multiple equal chunks (size of array/number of processes). Each small array chunk is assigned to a process. Then each process parallelly sorts the chunk of array allocated to it. Algorithm used for sorting is Quick Sort Algorithm. Then we reate an output array to store the final sorted array. Create a min heap of size k (using Priority Queue) and insert the first element in all the arrays into the heap. Repeat following steps until priority queue has no more elements. Remove minimum element from heap (minimum is always at root) and store it in output array. Insert next element from the array from which the element is extracted. If the array doesn’t have any more elements, then do nothing.
2. Used the following MPI Commands: 
    1. MPI_Send
    2. MPI_Recv 

### Question 3 :

#### Implementation Approach 

1. The basic strategy is to convert the original graph into a line graph. Given a graph G, its line graph L(G) is a graph such that. Each vertex of L(G) represents an edge of G; and. two vertices of L(G) are adjacent if and only if their corresponding edges share a common endpoint ("are incident") in G. Now the colouring of the line graph can be done using delta(L(G))+1 colors where L(G) represents the line graph of original graph and delta(L(G)) represents the maximum degree of the line graph. Now the problem gets converted to coloring the vertices of the line graph using atmost delta(L(G)) + 1 colors. Jones - Plassmann Algorithm is used to implement the vertex coloring algorithm.
2. The algorithm states : 
    1. Initially assign random numbers to all the vertices.
    2. Each vertex looks at its neighbours and if it had the highest number, it gets assigned the lowest available color.
    3. Each uncoloured vertex looks at its uncoloured neighbours and gets colored with the lowest available color if has the highest number, and so on.
3. Initially the adjacency matrix of the Line Graph is broadcasted to all the processes. Each process gets assigned equal number of vertices of the graph which they are supposed to color. Then each process parallelly implements the above algorithm and color the vertices. Then the changes done by each process in the final color array parallelly is sent to the master process to update the final color matrix. The master process receives individual final color array from all the processes. It updates the final color array completeley i.e. it incorporates all the changes of the colored vertices. Finally the final color array is broadcasted to all the processes so that there remains consistency globally. This process goes on until all the vertices are colored.
4. Used the following MPI Commands : 
    1. MPI_Bcast 
    2. MPI_Send
    3. MPI_Recv

---