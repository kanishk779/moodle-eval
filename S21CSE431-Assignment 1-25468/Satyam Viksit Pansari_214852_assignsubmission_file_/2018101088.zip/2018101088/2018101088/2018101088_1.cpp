
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    int n;
    if(rank==0)
    {
        // freopen(argv[1], "r", stdin);
        // freopen(argv[2], "w", stdout);
        // read size of data
        FILE *file = NULL;
        // int n;
        file = fopen(argv[1], "r");
        fscanf(file, "%d", &n);
        fclose(file);
        for(int i=1;i<numprocs;i++)
            MPI_Send(&n,1,MPI_INT,i, 0, MPI_COMM_WORLD);
    }
    else
    {
        MPI_Recv(&n, 1, MPI_INT,0, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    int start=max(1,(n/numprocs))*rank+1,end=start+max(1,(n/numprocs))-1;
    if(rank==(numprocs-1)) end+=n%numprocs;
    // cout<<rank<<","<<start<<","<<end<<"\n";
    double sum=0.0;
    if(end<=n)
    {
        for(int i=start;i<=end;i++)
        {
            sum+=(1.0/(i*i));
        }
    }
    if(rank!=0)
    {
        MPI_Send(&sum,1,MPI_DOUBLE,0, 0, MPI_COMM_WORLD);
    }
    else
    {
        double temp;
        for(int i=1;i<numprocs;i++)
        {
            MPI_Recv(&temp,1,MPI_DOUBLE,i, MPI_ANY_TAG, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            sum+=temp;
        }
        // cout<<sum<<"\n";
        FILE *file = NULL;
        file = fopen(argv[2], "w");
        fprintf(file, "%.6f\n", sum);
        fclose(file);
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}