#How to run
mpic++ 2018101009_<problem_number>.cpp
mpirun -np 11 ./a.out inputfile.txt outputfile.txt


#Q1

The process is parallelised by assigning each process i,i+numprocs,i+2*numprocs... etc calculations till N. The final result is gathered using MPI_SUM while MPI_REDUCE-ing all the partial sums.

#Q2

The array is divided into chunks and then each chunk is quicksorted in a separate process. These chunks are then sent back and merged (upto log2 steps) and the final sorted array is obtained.

#Q3
