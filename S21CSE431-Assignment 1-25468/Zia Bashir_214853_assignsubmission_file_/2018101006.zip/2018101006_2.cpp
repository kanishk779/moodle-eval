/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;

#define ll long long int
#define ppi pair<int, pair<int, int> >  

    

vector<vector<int>>ans;
vector<int> arr,chnk,output;



int partition(vector<int> &a, int i, int j)
{
    int temp;
    int x;
 
    x=a[(i+j)/2];
    while ((i<j)&&(a[i]<=x)) i++;
    while(a[j]>x) j--;
    while(i<j)
           {
               temp=a[i]; a[i]=a[j]; a[j]=temp;
               i++; j--;
               while (a[i]<=x) i++;
               while (a[j]>x) j--;
           }
           return j;
}
 
void qsortRec(vector<int> &a, int l, int r)
{
    int m;
    m=partition(a, l, r);
    if (l<r)
 {
    if ((m-l+1)<(r-m))
    {
        qsortRec (a, l, m);
        qsortRec (a, m+1, r);
    }
 
    else {
        qsortRec (a, m+1, r);
        qsortRec (a, l, m);
    }
 
 }
}
vector<int> mergeKArrays() 
{ 
    priority_queue<ppi, vector<ppi>, greater<ppi> > pq; 
  
    for (int i = 0; i < ans.size(); i++) 
        pq.push({ ans[i][0], { i, 0 } }); 
    while (pq.empty() == false) { 
        ppi curr = pq.top(); 
        pq.pop(); 
        int i = curr.second.first; 
        int j = curr.second.second; 
        output.push_back(curr.first); 
        if (j + 1 < ans[i].size()) 
            pq.push({ ans[i][j + 1], { i, j + 1 } }); 
    } 
    return output; 
} 
int main( int argc, char **argv ) {
    int rank, numprocs;
    int n,stind,endind,chnksz,chnklen;
    MPI_Status status;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
   //synchronize all processes/
    if(rank==0)
    {
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n; 
        arr.resize(n);
        for(int i = 0; i < n; i++) {
            input_file >> arr[i];
        } 
        input_file.close();

    }

    MPI_Barrier( MPI_COMM_WORLD );
    
    double tbeg = MPI_Wtime();
    if(rank==0){
        int len=n/numprocs;
        if(n%numprocs) len++;
        qsortRec(arr, 0,len-1);
        for(int i=1;i<numprocs;i++){
            endind=((len*i)+len-1);
            if(endind>=n) endind=n-1;
            chnksz=endind-(len*i)+1;
            MPI_Send(&chnksz,1,MPI_INT,i,101,MPI_COMM_WORLD);
            if((len*i)<=endind)
            MPI_Send(&arr[(len*i)],chnksz,MPI_INT,i,101,MPI_COMM_WORLD);

        }
    if(numprocs>1){
        chnk.resize(len);
        for(int i=0;i<len;i++)chnk[i]=arr[i];
        ans.push_back(chnk);
        for(int i=1;i<numprocs;i++){
            endind=((len*i)+len-1);
            if(endind>=n)endind=n-1;
            chnksz=endind-(len*i)+1;
            if((len*i)<=endind){
            MPI_Recv(&chnk[0],chnksz,MPI_INT,i,110,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            ans.push_back(chnk);
            }
        }
        arr=mergeKArrays();
    }

    }
    else{
            //recieve chunksize from root
            MPI_Recv(&chnklen,1,MPI_INT,0,101,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            if(chnklen>0){
            chnk.resize(chnklen);
            //recieve chunk from root
            MPI_Recv(&chnk[0],chnklen,MPI_INT,0,101,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            qsortRec(chnk, 0,chnklen-1);
            //send sorted chunk back to root
            MPI_Send(&chnk[0],chnklen,MPI_INT,0,110,MPI_COMM_WORLD);
            }
    }
    /* write your code here */

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        ofstream outfile(argv[2]);
        for(int i=0;i<n;i++,outfile<<arr[i-1]<<" ");
        outfile.close();
        cout<<"\nTotal Time (sec): " <<maxTime<< endl; 
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}