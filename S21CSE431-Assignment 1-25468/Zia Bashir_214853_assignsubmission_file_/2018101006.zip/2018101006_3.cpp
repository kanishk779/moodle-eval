/* MPI Program Template */
#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
using namespace std;

typedef long long int ll;

#define fi first
#define se second
#define pb push_back
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
  
  
vvi brr(510,vi(510,0));
vi crr(510,0),drr(510,0),arr(1002);
  
int main( int argc, char **argv ) {
    int rank, numprocs;
    int n,m,sz;
    vector<ii>mat;
    /* start up MPI */
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );    
    //synchronize all processes/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();
        if(rank==0){
        int a,b,a1,b1; 
        fstream input_file;
        input_file.open(argv[1], ios::in);
        input_file >> n>>m; 
        ii pt;
        for(int i=0;i<m;i++){
            input_file>>a>>b;
            pt.fi=min(a,b);
            pt.se=max(a,b);
            mat.pb(pt);
        }
        for(int i=0;i<mat.size();i++){
            drr[i+1]=i+1;
            for(int j=i+1;j<mat.size();j++){
                        if(mat[i].fi==mat[j].fi || mat[i].fi==mat[j].se || mat[i].se==mat[j].fi || mat[i].se==mat[j].se){
                        brr[i+1][j+1]=brr[j+1][i+1]=1;
                        }
            }
        }
        input_file.close();
       }
    /* write your code here */
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&brr[0][0], ((510)*(510))  , MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&drr[0], ((510))  , MPI_INT, 0, MPI_COMM_WORLD); 
    sz=m/numprocs;
    if(m%numprocs) sz++;
    int l=(rank*sz)+1,r=l+sz-1;
    if(r>m)r=m;
    while(1){
        vi ind;
        bool fg=0;
        int mark=0;
        
        for(int i=l;i<=r;++i){
            if(crr[i]==0){
            fg=0;
            for(int j=1;j<=m;++j){
                if(brr[i][j]!=0)
                {
                    if(!crr[j] && drr[j]>drr[i])
                    {
                        fg=1;
                        break;
                    }
                }
            }
            if(fg==0){
                set<int>v;
                for(int j=1;j<=m;++j){
                    if( brr[i][j]!=0 && crr[j]!=0)
                            v.insert(crr[j]);
                }
                int k=1;
                for(auto it=v.begin();it!=v.end();it++){
                    if((*it)==k)k++;
                    else break;
                }
                crr[i]=k;
                ind.pb(i);
                ind.pb(k);
            }
            }
        }
        for(int i=0;i<ind.size();i++)
        arr[i]=ind[i];
        int ln=ind.size();
       
        for(int i=0;i<numprocs;++i){
            MPI_Bcast(&ln,1 , MPI_INT, i, MPI_COMM_WORLD);
            MPI_Bcast(&arr[0],ln , MPI_INT, i, MPI_COMM_WORLD);
            if(i!=rank){
                int j=0;
                while(j<ln) { 
                crr[arr[j]]=arr[j+1];
                j+=2;
                }
               // for(int j=0;j<ln;j+=2)
               /// crr[arr[j]]=arr[j+1];
            }
            ln=ind.size();
            for(int j=0;j<ind.size();++j) arr[j]=ind[j];

        }
        for(int i=1;i<=m;i++){
            if(crr[i]!=0) mark++;
        }
        if(mark==m)  break;

      }
     int maxi=0;
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if (!rank) {
        int i=1;
        while(i<=m){
                maxi=max(maxi,crr[i]);
        i++;
        }
        ofstream outfile(argv[2]);
        outfile<<maxi<<" ";
        for(int i=1;i<=m;i++){
        outfile<<crr[i]<<" ";
        }
        outfile.close();
   printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}