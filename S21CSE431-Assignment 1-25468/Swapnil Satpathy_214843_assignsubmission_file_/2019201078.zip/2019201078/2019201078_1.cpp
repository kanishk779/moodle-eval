#include <iostream>
#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <iomanip> 
using namespace std;


int main( int argc, char **argv ) {
    
    MPI_Init( &argc, &argv);
    MPI_Status status;
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    int npres;
    MPI_Comm_size(MPI_COMM_WORLD,&npres);
    
    
    MPI_Barrier(MPI_COMM_WORLD);
    double time = MPI_Wtime();

    
    
    

    string file1;
    stringstream ssa(argv[argc-2]);
    ssa>> file1;
    
    string file2;
    stringstream ssb(argv[argc-1]);
    ssb>>file2;

    string line;
    ifstream fd1;
    ofstream fd2;
    fd1.open(file1);
    fd2.open(file2);
    int n;
    if (fd1.is_open())
    {
        while(getline(fd1,line))
        {
            stringstream ssc(line);
            ssc>>n;
            break;
        }
        
        fd1.close();
    }
	
    double res=0.0;
    double ans;
	if(rank!=0)
	{
		
		for(int i=((n*rank)/(npres))+1;i<=(n*(rank+1))/(npres);i++){
			res+=(1.0/(i*i));
        }
		MPI_Send(&res,1,MPI_DOUBLE,0,1,MPI_COMM_WORLD);

	}
    else
	   {
		double temp=0.0;
		for(int i=1;i<=(n/npres);i++)
			temp+=(1.0/(i*i));

		for(int j=1;j<npres;j++)
		{
			MPI_Recv(&ans,1,MPI_DOUBLE,j,1,MPI_COMM_WORLD, &status);
			temp+=ans;		
		}
		res=temp;
	   }

    MPI_Barrier(MPI_COMM_WORLD);
    double maxi;
    double end = MPI_Wtime()-time;
    
    MPI_Reduce(&end,&maxi,1,MPI_DOUBLE,MPI_MAX,0,MPI_COMM_WORLD);
    if (rank == 0) {
        printf("Total time (s): %f\n",maxi);
    
    fd2<<setprecision(7)<<res;
    fd2.close();
    }

    MPI_Finalize();
    return 0;
}
