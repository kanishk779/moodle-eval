# Distributed Systems Assignment 1

## Problem 1

The individual terms are distributed to all processes as equally as possible. Each process knows what N is, and it can calculate for itself what range of terms to add up and it does so. Then a reduce is done by adding all the summations done at individual processes.

## Problem 2

The array is first divided as equally as possible and sent to all processes using scatter. Each process then quicksorts their chunk of the array and all these chunks are put together using gather. Then, at the 0th process all these sorted chunks are merged using a heap which contains the index of the sorted chunk it is currently processing. 

## Problem 3

First, the given graph is converted into a line graph. The transformed graph is then flattened out. Certain processes are allocated certain vertices and parts of the flattened graph corresponding to the vertice and it's neighbours are sent to the process that the vertex has been assigned to (using scater). A degree vector is also broadcasted that gives information about the degree of the vertices of the newly transformed graph. In addition, these vertices are assigned random values.

Then, we run through M iterations, where M is the number of vertices of the line graph. At a process, all the vertices assigned to it are iterated through. The neighbours of each vertice is checked. If the neighbour has not been assigned any color yet, it checks whether the neighbour should be given more priority or itself (a node has more priority than it's neighbour if it's degree is greater or in the case of equal degree, if it's random vaue is greater). If a neighbour is colored, the vertice notes that it cannot take the color for itself. If there is no neighbour with a higher priority for a vertex, the node is assigned the minimum color that doesn't conflict with it's neighbours.

The information about the colors assigned to each vertex is communicated to other processes before beginning the next iteration and all processes are synchronized at the end of every iteration so that the updated information about the assignment is receieved.
