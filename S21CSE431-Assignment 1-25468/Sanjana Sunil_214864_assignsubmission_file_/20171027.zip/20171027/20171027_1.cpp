/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

double getTerm(int denominator) {
    double val = (double) denominator;
    return (double) 1 / (val*val);
}

double getSeriesSum(int start_val, int end_val) {
    double total = 0.0f;
    for(int i=start_val; i<=end_val; ++i)
        total += getTerm(i);
    
    return total;
}

int main( int argc, char **argv ) {
    int rank, numprocs;

    ifstream fin;
    ofstream fout;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    fin.open(argv[1]);
    fout.open(argv[2]);

    int N;
    fin >> N;

    double reduction_result = 0.0f;

    if(numprocs >= N)
    {
        double val = 0;
        if(rank < N) val = getTerm(rank+1);
        MPI_Reduce(&val, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    }
    else
    {
        int vals_per_process = N/numprocs;
        int start_val = (rank*vals_per_process) + 1;
        int end_val = start_val + vals_per_process - 1;

        double process_series_sum = getSeriesSum(start_val, end_val);

        MPI_Reduce(&process_series_sum, &reduction_result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

        if(rank == 0)
        {
            if((vals_per_process*numprocs)+1 <= N)
                reduction_result += getSeriesSum(vals_per_process*numprocs+1, N);
        }
    } 

    // if(rank == 0) cout << setprecision(7) << reduction_result << endl;
    if(rank == 0) fout << setprecision(7) << reduction_result;

    fin.close();
    fout.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}