/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    ifstream fin;
    ofstream fout;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    fin.open(argv[1]);
    fout.open(argv[2]);

    int N, M;
    fin >> N >> M;
    
    vector<int> edge_nums;

    vector<int> flattened_graph;
    vector<int> flattened_graph_indices;

    vector<int> send_counts_indices;
    vector<int> displs_indices;
    vector<int> send_counts_graph;
    vector<int> displs_graph;
    vector<int> degree(M, 0);

    // Send indices
    for(int i=0; i<numprocs; ++i) 
    {
        send_counts_indices.push_back(0);
        send_counts_indices[i] += (M / numprocs);
    }
    for(int i=0; i<(M%numprocs); ++i) send_counts_indices[i]++;

    int displacement = 0;
    for(int i=0; i<numprocs; ++i)
    {
        displs_indices.push_back(displacement);
        displacement += send_counts_indices[i];
    }

    if(rank == 0)
    {
        for(int i=0; i<M; ++i) edge_nums.push_back(i);
        random_shuffle(edge_nums.begin(), edge_nums.end());

        // Store the node, edge number
        vector<pair<int,int>> graph[N];
        for(int i=0; i<M; ++i)
        {
            int u, v;
            fin >> u >> v;
            graph[u-1].push_back({v-1, edge_nums[i]});
            graph[v-1].push_back({u-1, edge_nums[i]});
        }

        vector<int> line_graph[M];
        vector<int> edge_processed(M, 0);
        for(int i=0; i<N; ++i)
        {
            for(int j=0; j<int(graph[i].size()); ++j)
            {
                int u = i;
                int v = graph[i][j].first;

                int new_node_num = graph[i][j].second;

                if(!edge_processed[new_node_num])
                {
                    // Connect to all outgoing edges from u
                    for(int k=0; k<int(graph[u].size()); ++k)
                    {
                        if(graph[u][k].second != new_node_num)
                            line_graph[new_node_num].push_back(graph[u][k].second);
                    }
                    // Connect to all outgoing edges from v
                    for(int k=0; k<int(graph[v].size()); ++k)
                    {
                        if(graph[v][k].second != new_node_num)
                            line_graph[new_node_num].push_back(graph[v][k].second);
                    }

                    edge_processed[new_node_num] = 1;
                }
            }
        }

        for(int i=0; i<M; ++i)
        {
            int idx = int(flattened_graph.size());
            for(int j=0; j<int(line_graph[i].size()); ++j)
                flattened_graph.push_back(line_graph[i][j]);

            flattened_graph_indices.push_back(idx);
            degree[i] = int(line_graph[i].size());
        }

        // Send flattened graph
        int proc_idx = 0;
        int M_for_proc = 0;
        for(int i=0; i<M; ++i)
        {
            if(M_for_proc <= 0)
            {
                M_for_proc = send_counts_indices[proc_idx++];
                send_counts_graph.push_back(0);
            }

            send_counts_graph.back() += degree[i];
            M_for_proc--;
        }
        while(int(send_counts_graph.size()) < numprocs) send_counts_graph.push_back(0);

        displacement = 0;
        for(int i=0; i<numprocs; ++i)
        {
            displs_graph.push_back(displacement);
            displacement += send_counts_graph[i];
        }
    }

    int M_for_proc = send_counts_indices[rank];
    // MPI_Scatter(&send_counts_indices[0], 1, MPI_INT, &M_for_proc, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    int starting_vertex_num = displs_indices[rank];
    // MPI_Scatter(&displs_indices[0], 1, MPI_INT, &starting_vertex_num, 1, MPI_INT, 0, MPI_COMM_WORLD);

    vector<int> flattened_subgraph_indices(M_for_proc, 0);
    MPI_Scatterv(&flattened_graph_indices[0], &send_counts_indices[0], &displs_indices[0], MPI_INT, &flattened_subgraph_indices[0], M_for_proc, MPI_INT, 0, MPI_COMM_WORLD);

    for(int i=M_for_proc-1; i>=0; --i)
        flattened_subgraph_indices[i] -= flattened_subgraph_indices[0];

    // Length of flattened graph
    int graph_size;
    MPI_Scatter(&send_counts_graph[0], 1, MPI_INT, &graph_size, 1, MPI_INT, 0, MPI_COMM_WORLD);
    vector<int> flattened_subgraph(graph_size, 0);
    MPI_Scatterv(&flattened_graph[0], &send_counts_graph[0], &displs_graph[0], MPI_INT, &flattened_subgraph[0], graph_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Broadcast degree vector
    MPI_Bcast(&degree[0], M, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier( MPI_COMM_WORLD );
    
    vector<int> colors(M, -1);
    for(int i=0; i<M; ++i)
    {
        for(int j=0; j<M_for_proc; ++j)
        {
            int node_num = starting_vertex_num + j;
            if(colors[node_num] != -1) continue;

            bool better_neighbour_exists = false;
            vector<bool> invalid_colors(M, false);

            for(int k=flattened_subgraph_indices[j]; k<flattened_subgraph_indices[j]+degree[node_num]; ++k)
            {
                int neighbour = flattened_subgraph[k];
                if(colors[neighbour] == -1)
                {
                    if(degree[neighbour] > degree[node_num] || 
                      (degree[neighbour] == degree[node_num] && node_num < neighbour)) 
                        better_neighbour_exists = true;
                }
                else invalid_colors[colors[neighbour]] = true;
            }

            if(!better_neighbour_exists)
            {
                for(int k=0; k<M; ++k)
                {
                    if(!invalid_colors[k])
                    {
                        colors[node_num] = k;
                        break;
                    }
                }
            }
        }

        vector<int> temp_colors(M, -1);
        MPI_Allgatherv(&colors[starting_vertex_num], M_for_proc, MPI_INT, &temp_colors[0], &send_counts_indices[0], &displs_indices[0], MPI_INT, MPI_COMM_WORLD);
        MPI_Barrier( MPI_COMM_WORLD );
        colors = temp_colors;
    }


    if(rank == 0)
    {
        int max_color = -1;
        for(auto color : colors) max_color = max(max_color, color);

        fout << max_color + 1 << endl;
        for(auto edge_num : edge_nums)
            fout << colors[edge_num] + 1 << " ";
        fout << endl;
    }

    fin.close();
    fout.close();

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}