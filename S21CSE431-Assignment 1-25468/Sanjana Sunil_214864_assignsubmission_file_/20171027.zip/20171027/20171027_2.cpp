/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

long long int arr[1000006];

int compare(const void *a, const void *b) {
    if(*(long long int*)a - *(long long int*)b < 0) return -1;
    if(*(long long int*)a - *(long long int*)b > 0) return 1;
    return 0;
}

struct comp
{
    bool operator()(const pair<int,int>& a, const pair<int,int>& b) {
        return arr[a.first] > arr[b.first];
    }
};

int main( int argc, char **argv ) {
    int rank, numprocs;

    ifstream fin;
    ofstream fout;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    int N;
    int send_counts[numprocs];
    int displs[numprocs];
    
    if(rank == 0)
    {
        fin.open(argv[1]);
        fout.open(argv[2]);

        fin >> N;

        // long long int arr[N];
        for(int i=0; i<N; ++i) fin >> arr[i];

        // Send the amount of elements each process will receive
        for(int i=0; i<numprocs; ++i) 
        {
            send_counts[i] = 0;
            send_counts[i] += (N / numprocs);
        }
        
        // Send remaining elements
        for(int i=0; i<(N%numprocs); ++i) send_counts[i]++;

        int displacement = 0;
        for(int i=0; i<numprocs; ++i)
        {
            displs[i] = displacement;
            displacement += send_counts[i];
        }
    }

    // Tell each process how many elements they would have to sort
    int N_for_proc;
    MPI_Scatter(send_counts, 1, MPI_INT, &N_for_proc, 1, MPI_INT, 0, MPI_COMM_WORLD);
    long long int sub_arr[N_for_proc+1];

    // Send array
    MPI_Scatterv(arr, send_counts, displs, MPI_LONG_LONG_INT, sub_arr, N_for_proc, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);

    // Sort array
    qsort(sub_arr, N_for_proc, sizeof(long long int), compare);

    // Get arrays
    MPI_Gatherv(sub_arr, N_for_proc, MPI_LONG_LONG_INT, arr, send_counts, displs, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);

    if(rank == 0)
    {
        priority_queue<pair<int,int>, vector<pair<int,int>>, comp> pq;
        
        int cur_proc = 0;
        for(int i=0; i<N; i += send_counts[cur_proc], cur_proc++)
            pq.push({i, i+send_counts[cur_proc]-1});
        
        vector<long long int> sorted;
        while(!pq.empty())
        {
            pair<int,int> idxs = pq.top();
            pq.pop();

            sorted.push_back(arr[idxs.first]);
            if(idxs.first + 1 <= idxs.second) pq.push({idxs.first + 1, idxs.second});
        }

        for(auto val : sorted) fout << val << " ";

        fin.close();
        fout.close();
    }

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}