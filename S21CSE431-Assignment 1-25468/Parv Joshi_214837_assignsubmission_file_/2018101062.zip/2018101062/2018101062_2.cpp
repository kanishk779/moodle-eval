#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

void quicksort(int a[], int s, int n)
{
  int x, p, i;
  if (n <= 1)
    return;
  x = a[s + n/2];
  swap(a[s], a[s + n/2]);
  p = s;
  for (i = s+1; i < s+n; i++)
    if (a[i] < x) {
      p++;
      swap(a[i], a[p]);
    }
  swap(a[s], a[p]);
  quicksort(a, s, p-s);
  quicksort(a, p+1, s+n-p-1);
}


int main( int argc, char **argv ) {

    int rank, numprocs;

    MPI_Status status; 

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen(argv[1], "r", stdin);
    int n=0;
    int *a;
    srand(time(NULL));
    if(rank==0)
    {
        cin>>n;
        a = new int [n];
        for(int i=0;i<n;i++)
		    cin>>a[i];
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int c = (n%numprocs!=0) ? n/numprocs+1 : n/numprocs;
    int chunk[c];
    MPI_Scatter(&a[0], c, MPI_INT, &chunk[0], c, MPI_INT, 0, MPI_COMM_WORLD);
    int s = (n >= c * (rank+1)) ? c : n - c * rank;
    if(s<0)
        s=0;
    quicksort(chunk, 0, s);

    if(rank!=0 && s>0)
    {
        MPI_Send(&chunk[0], s, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }
    if(rank==0)
    {
        int i=0;
        for(i=0;i<s;i++)
            a[i]=chunk[i];
        for(int j=1;j<numprocs;j++)
        {
            int s = (n >= c * (j+1)) ? c : n - c * j;
            if(s<0)
                s=0;
            int recv[s];
            if(s>0)
            {   
                MPI_Recv(&recv, s, MPI_INT, j, 0, MPI_COMM_WORLD, &status);
                for(int k=0;k<s;k++)
                {
                    a[i]=recv[k];
                    i++;
                }
            }
        }
        unordered_map<int,int>seen;
        priority_queue <pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>> > pq;
        int s=0,loc=0;
        for(i=0;i<numprocs;i++)
        {
            s = (n >= c * (i+1)) ? c : n - c * i;
            if(s<0 || loc>=n)
                break;
            if(seen[loc]==0)
            {
                seen[loc]=1;
                pq.push({a[loc], loc});

                loc+=s;
            }
            else
                break;
        }
        vector<int>ans(n,0);
        i=0;
        while(!pq.empty())
        {
            loc = pq.top().second;
            ans[i]=pq.top().first;
            i++;
            pq.pop();
            if(loc+1<n && seen[loc+1]==0)
            {
                pq.push({a[loc+1],loc+1});
            }
        }
        ofstream outans;
        outans.open(argv[2]);
        for(i=0;i<n;i++)
            outans<<ans[i]<<" ";
        outans.close();
        cout<<endl;
    }
    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}