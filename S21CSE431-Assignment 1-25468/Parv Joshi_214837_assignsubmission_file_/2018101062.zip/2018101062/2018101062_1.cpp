/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main( int argc, char **argv ) {
    int rank, numprocs;

    MPI_Status status; 
    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll n=0;
    freopen(argv[1], "r", stdin);
    if(rank==0)
    {
        cin>>n;
        long double sum = 0.00;
        ll i=0,start=1;;
        ll proc=0;
        ll distribution = ((long long int)ceil(((long double)(n))/numprocs));
        for(i=1;i<=distribution;i++)
        {
            sum += ((long double)(1))/(i*i);
        }
        start+=distribution;
        for(i=1;i<numprocs;i++)
        {
            ll last = min(start+distribution,n+1);
            ll a[2]={0};
            if(start<=n)
            {
                a[0]=start; a[1]=last-1;
                // cout<<start<<" "<<last-1<<"\n";
                start+=(last-start);
                proc=i;

                MPI_Send(&a[0], 2, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD); 
                // cout<<"heello";
            }
            else
            {
                a[0]=-1;
                MPI_Send(&a[0], 2, MPI_LONG_LONG_INT, i, 0, MPI_COMM_WORLD);
            }
        }
        long double temp=0.00;
        for(i=1;i<=proc;i++)
        {
            MPI_Recv(&temp, 1, MPI_LONG_DOUBLE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
            sum+=temp;
        }
        ofstream outans;
        outans.open(argv[2]);
        outans<<fixed<<setprecision(6)<<sum<<"\n";
        outans.close();
    }
    else
    {
        ll a[2];
        MPI_Recv(&a, 2, MPI_LONG_LONG_INT, 0, 0, MPI_COMM_WORLD, &status); 
        if(a[0]!=-1)
        {
            long double sub_sum=0.00;
            for(ll i=a[0];i<=a[1];i++)
            {
                sub_sum += ((long double)(1))/(i*i);
            }
            MPI_Send(&sub_sum, 1, MPI_LONG_DOUBLE, 0, 0, MPI_COMM_WORLD);
        } 
    }
    

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}