/* MPI Program Template */

#include <stdio.h>
#include <string.h>
#include "mpi.h"
#include <fstream>
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int adj[501][501];


int main( int argc, char **argv ) {
    int rank, numprocs;

    /* start up MPI */
    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
    
    /*synchronize all processes*/
    MPI_Barrier( MPI_COMM_WORLD );
    double tbeg = MPI_Wtime();

    /* write your code here */

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen(argv[1], "r", stdin);

    int n=0, m=0;
    int sizes[501]={0};
    if(rank==0)
    {
        cin>>n>>m;
        int u=0, v=0;
        map<pair<int,int>,int>edges_to_vertices;
        vector<pair<int,int>>edges;
        int curr_v=1;
        for(int i=0;i<m;i++)
        {
            cin>>u>>v;
            edges_to_vertices.insert({{u,v}, curr_v});
            edges_to_vertices.insert({{v,u}, curr_v});
            edges.push_back({u,v});
            edges.push_back({v,u});
            curr_v++;
        }
        map<pair<int,int>,int>edge_already_created;
        int match_vertex, es=edges.size(), un,vn;
        for(int i=0;i<es;i++)
        {
            un=edges_to_vertices[edges[i]];
            match_vertex=edges[i].second;
            for(int j=i+1;j<es;j++)
            {
                if(match_vertex == edges[j].first)
                {
                    vn=edges_to_vertices[edges[j]];
                    if(vn!=un)
                    {
                        if(edge_already_created[{un,vn}]==0)
                        {
                            adj[un][sizes[un]]=vn;
                            sizes[un]++;
                            adj[vn][sizes[vn]]=un;
                            sizes[vn]++;
                            edge_already_created[{un,vn}]=1;
                            edge_already_created[{vn,un}]=1;
                        }
                    }
                }
            }
        }
        // // for(int i=1;i<=n;i++)
        // // {
        // //     cout<<i<<" - ";
        // //     for(int j=0;j<sizes[i];j++)
        // //     {
        // //         cout<<adj[i][j]<<" ";
        // //     }
        // //     cout<<"\n";
        // // }
    }
    MPI_Bcast(adj, ((501)*(501))  , MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(sizes, 501  , MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1  , MPI_INT, 0, MPI_COMM_WORLD);

    /*Check If Braodcasted Correctly have Reached*/
    // if(rank==0)
    // {
    //     for(int i=1;i<=n;i++)
    //     {
    //         cout<<i<<" - ";
    //         for(int j=0;j<sizes[i];j++)
    //         {
    //             cout<<adj[i][j]<<" ";
    //         }
    //         cout<<"\n";
    //     } 
    // }

    int colours[501]={0};
    int temp_colours[501]={0};

    int c = (m%numprocs!=0) ? m/numprocs+1 : m/numprocs;
    int s = (m >= c * (rank+1)) ? c : m - c * rank;

    int start = (c*rank)+1, last = c*rank+s;
    if(s<=0)
    {
        start=-1;last=-2;
    }
    // if(s!=0)
    // {
    //     for(int i= start;i<=last;i++)
    //         cout<<i<<"\n";
    // }
    int vertices_covered=0;
    while(vertices_covered!=m)
    {
        // cout<<"Before";
        // for(int i=1;i<=n;i++)
        // {
        //     cout<<colours[i]<<" ";
        // }
        // cout<<"\n";
        int seen_vertex=0;
        int find_vertex_seen=0;
        for(int i = start; i<=last ;i++)
        {
            bool ismax = true;
            set<int>colours_found;
            if(colours[i]==0)
            {
                for(int j =0; j<sizes[i];j++)
                {
                    if(i<adj[i][j])
                    {
                        if(colours[adj[i][j]]==0)
                        {
                            ismax=false;
                            break;
                        }
                    }
                    if(colours[adj[i][j]]!=0)
                    {
                        colours_found.insert(colours[adj[i][j]]);
                    }
                }
            }
            else
                ismax=false;
            if(ismax==true)
            {
                seen_vertex++;
                int assign_colour=1;
                if(colours_found.size()!=0)
                {
                    for(auto itr = colours_found.begin(); itr!= colours_found.end();itr++)
                    {
                        if(*itr!=assign_colour)
                            break;
                        else
                            assign_colour++;   
                    }
                }
                colours[i]=assign_colour;
            }
        }
        for(int i=0;i<numprocs;i++)
        {
            if(i==rank)
            {
                MPI_Bcast(colours, 501  , MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(&seen_vertex, 1, MPI_INT, i, MPI_COMM_WORLD);
                vertices_covered+=seen_vertex;
            }
            else
            {
                MPI_Bcast(temp_colours, 501  , MPI_INT, i, MPI_COMM_WORLD);
                MPI_Bcast(&find_vertex_seen, 1, MPI_INT, i, MPI_COMM_WORLD);
                vertices_covered+=find_vertex_seen;
                for(int j=1;j<=m;j++)
                {
                    if(temp_colours[j]!=0)
                        colours[j]=temp_colours[j];
                }
            }
        }
    }
    if(rank==0)
    {
        unordered_map<int,int>colour_count;
        for(int i=1;i<=m;i++)
        {
            colour_count[colours[i]]++;
        }
        ofstream outans;
        outans.open(argv[2]);
        outans<<colour_count.size()<<"\n";
        for(int i=1;i<=m;i++)
            outans<<colours[i]<<" ";
        // cout<<colour_count.size()<<"\n";
        // for(int i=1;i<=n;i++)
        //     cout<<colours[i]<<" ";
        // cout<<"\n";
    }

    
    /*Code Ends*/

    MPI_Barrier( MPI_COMM_WORLD );
    double elapsedTime = MPI_Wtime() - tbeg;
    double maxTime;
    MPI_Reduce( &elapsedTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );
    if ( rank == 0 ) {
        printf( "Total time (s): %f\n", maxTime );
    }

    /* shut down MPI */
    MPI_Finalize();
    return 0;
}