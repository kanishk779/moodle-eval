Assignment 1 - Distributed Systems (MPI)
Parv Joshi - 2018101062

This Assignment has 3 Questions -
1) 2018101062_1.cpp -> Sum of Squares of Reciprocal
2) 2018101062_2.cpp -> Parallel Quicksort
3) 2018101062_3.cpp -> Edge Colouring



Running

Compilation
mpic++ 2018101062_<QNo>.cpp

Running
mpirun -np <no. of processes> a.out <input file> <output file>

Q1 - Sum of Squares of Reciprocal
1) Distributed N Process among the number of processes
2) Each Process Calculates its sum of squared reciprocals
3) The partial sum is then passed to root process which in turn prints final answer

Q2 - Parallel Quicksort
1) First we scatter the input array into chunks among the processes.
2) Each Process does a quicksort on its portion of the array
3) Process send the partially sorted array to root process
4) All Arrays are merged in O(n*num_process*log(num_process))
5) Final Answer is Outputed

Q3 - Edge Colouring
1) First we convert our Graph To a Line Graph (Converting Edges to Vertices)
2) Then Using Jones-Plassman Algo we parallelly compute vertex colouring
3) We select largest vertex which is non-coloured
4) We then give smallest possible colour
5) We finally output number of colours used and colour of each edge
 

